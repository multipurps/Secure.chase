import { useState, useEffect, useCallback } from 'react';
import { supabase, getUserAccounts, getCurrentUser } from '../lib/supabase';

export interface Account {
  id: string;
  user_id: string;
  account_type: string; // 'checking' | 'savings' | 'credit' | 'investment' | 'business'
  account_name: string;
  last4: string;
  balance: number;
  available_balance?: number;
  credit_limit?: number;
  is_active?: boolean;
}

export function formatBalance(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
  }).format(amount);
}

export function maskAccount(last4: string): string {
  return `...${last4}`;
}

let _cachedAccounts: Account[] = [];
let _cacheUserId: string | null = null;
const _listeners: Set<() => void> = new Set();

function notifyListeners() {
  _listeners.forEach(fn => fn());
}

export function invalidateAccountCache() {
  _cachedAccounts = [];
  _cacheUserId = null;
  notifyListeners();
}

export async function refreshAccountsGlobal(): Promise<Account[]> {
  const user = await getCurrentUser();
  if (!user) return [];
  const raw = await getUserAccounts(user.id);
  _cachedAccounts = raw as Account[];
  _cacheUserId = user.id;
  notifyListeners();
  return _cachedAccounts;
}

export function useAccounts() {
  const [accounts, setAccounts] = useState<Account[]>(_cachedAccounts);
  const [loading, setLoading] = useState(_cachedAccounts.length === 0);
  const [userId, setUserId] = useState<string | null>(_cacheUserId);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const user = await getCurrentUser();
      if (!user) { setAccounts([]); setLoading(false); return; }
      setUserId(user.id);
      if (_cacheUserId === user.id && _cachedAccounts.length > 0) {
        setAccounts(_cachedAccounts);
        setLoading(false);
        return;
      }
      const raw = await getUserAccounts(user.id);
      _cachedAccounts = raw as Account[];
      _cacheUserId = user.id;
      setAccounts(_cachedAccounts);
    } catch (e) {
      console.error('useAccounts error', e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    _listeners.add(load);
    return () => { _listeners.delete(load); };
  }, [load]);

  async function updateBalance(accountId: string, newBalance: number) {
    await supabase.from('accounts').update({ balance: newBalance }).eq('id', accountId);
    _cachedAccounts = _cachedAccounts.map(a =>
      a.id === accountId ? { ...a, balance: newBalance } : a
    );
    notifyListeners();
  }

  return { accounts, loading, userId, reload: load, updateBalance };
}

// Save a transaction to Supabase and update the account balance
export async function saveTransaction(tx: {
  account_id: string;
  description: string;
  amount: number;       // positive = credit, negative = debit
  type: 'credit' | 'debit';
  category?: string;
  status?: string;
  reference?: string;
  memo?: string;
  recipient?: string;
  tx_type?: string;     // 'zelle' | 'wire' | 'bill_pay' | 'transfer' | 'check_deposit' | 'credit_card'
}) {
  const now = new Date().toISOString();
  const { data: acct } = await supabase
    .from('accounts')
    .select('balance')
    .eq('id', tx.account_id)
    .single();

  const oldBalance = acct?.balance ?? 0;
  const newBalance = oldBalance + tx.amount;

  await supabase.from('transactions').insert([{
    account_id: tx.account_id,
    description: tx.description,
    amount: Math.abs(tx.amount),
    type: tx.type,
    category: tx.category ?? 'transfer',
    status: tx.status ?? 'Posted',
    date: now,
    running_balance: newBalance,
    reference: tx.reference ?? `REF${Date.now()}`,
    memo: tx.memo ?? '',
    recipient: tx.recipient ?? '',
    tx_type: tx.tx_type ?? 'transfer',
    created_at: now,
  }]);

  await supabase.from('accounts').update({ balance: newBalance }).eq('id', tx.account_id);

  // Invalidate cache so all screens refresh
  invalidateAccountCache();
  return newBalance;
}
