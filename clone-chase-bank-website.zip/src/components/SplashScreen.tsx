import { useEffect, useState } from 'react';

/**
 * Chase Mobile Banking Splash Screen
 *
 * Animation timeline (2.5s total):
 *   0.0s – 0.9s : 4 octagon segments rotate-in and assemble (staggered)
 *   0.9s – 1.3s : assembled octagon scales/locks into place
 *   1.3s – 2.0s : "CHASE" text fades + slides in from left
 *   2.0s – 2.5s : hold final layout, then navigate
 *
 * Final layout:  CHASE  [octagon]   (text on left, symbol on right)
 * Background:    deep Chase blue #117ACA  (authentic brand blue)
 * Color:         white throughout
 */

interface SplashScreenProps {
  onComplete: () => void;
}

// Authentic Chase octagon segment paths — normalized 55×55 unit square
// Derived from real Wikimedia SVG: Chase_logo_2007.svg
const SEGMENTS = [
  // NE blade — top-right
  { id: 'ne', d: "M 19.67,0 C 18.60,0 17.73,0.87 17.73,1.94 L 17.73,15.55 L 53.67,15.55 L 37.30,0.003 Z", originX: 35, originY: 8 },
  // SE blade — bottom-right
  { id: 'se', d: "M 54.98,19.67 C 54.98,18.59 54.12,17.73 53.04,17.73 L 39.44,17.73 L 39.44,53.67 L 54.977,37.29 Z", originX: 47, originY: 35 },
  // SW blade — bottom-left
  { id: 'sw', d: "M 35.32,54.97 C 36.39,54.97 37.26,54.10 37.26,53.03 L 37.26,39.43 L 1.32,39.43 L 17.68,54.967 Z", originX: 20, originY: 47 },
  // NW blade — top-left
  { id: 'nw', d: "M 0,35.31 C 0,36.38 0.87,37.26 1.94,37.26 L 15.54,37.26 L 15.54,1.31 L 0.003,17.68 Z", originX: 8, originY: 20 },
];

// Each segment starts rotated outward and scales from 0, then snaps in
const SEGMENT_DELAYS = [0, 0.12, 0.24, 0.36]; // stagger in seconds

export default function SplashScreen({ onComplete }: SplashScreenProps) {
  const [phase, setPhase] = useState<'assembling' | 'locking' | 'text' | 'done'>('assembling');
  const [segmentStates, setSegmentStates] = useState([false, false, false, false]);

  useEffect(() => {
    // Stagger segment assembly
    SEGMENT_DELAYS.forEach((delay, i) => {
      setTimeout(() => {
        setSegmentStates(prev => {
          const next = [...prev];
          next[i] = true;
          return next;
        });
      }, delay * 1000);
    });

    // Lock phase
    const lockTimer = setTimeout(() => setPhase('locking'), 900);
    // Text phase
    const textTimer = setTimeout(() => setPhase('text'), 1300);
    // Done
    const doneTimer = setTimeout(() => {
      setPhase('done');
      onComplete();
    }, 2700);

    return () => {
      clearTimeout(lockTimer);
      clearTimeout(textTimer);
      clearTimeout(doneTimer);
    };
  }, [onComplete]);

  const octSize = 36; // px — match CHASE text height exactly

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        backgroundColor: '#1352AA', // exact Chase blue matching Welcome + Login
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 9999,
        overflow: 'hidden',
      }}
    >
      {/* Subtle radial glow behind logo */}
      <div
        style={{
          position: 'absolute',
          width: 380,
          height: 380,
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(255,255,255,0.07) 0%, transparent 70%)',
          pointerEvents: 'none',
        }}
      />

      {/* Logo lockup: CHASE [gap] [octagon] */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 12,
        }}
      >
        {/* ── CHASE wordmark ── */}
        <div
          style={{
            opacity: phase === 'text' || phase === 'done' ? 1 : 0,
            transform: phase === 'text' || phase === 'done' ? 'translateX(0)' : 'translateX(-18px)',
            transition: 'opacity 0.55s cubic-bezier(0.22,1,0.36,1), transform 0.55s cubic-bezier(0.22,1,0.36,1)',
            fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
            fontWeight: 700,
            fontSize: 22,
            letterSpacing: 3,
            color: '#ffffff',
            lineHeight: 1,
            userSelect: 'none',
          }}
        >
          CHASE
        </div>

        {/* ── Octagon symbol ── */}
        <div
          style={{
            transform: phase === 'locking' || phase === 'text' || phase === 'done'
              ? 'scale(1)'
              : 'scale(0.88)',
            transition: 'transform 0.35s cubic-bezier(0.34,1.56,0.64,1)',
          }}
        >
          <svg
            width={octSize}
            height={octSize}
            viewBox="0 0 55 55"
            xmlns="http://www.w3.org/2000/svg"
            style={{ display: 'block', overflow: 'visible' }}
            aria-hidden="true"
          >
            {SEGMENTS.map((seg, i) => (
              <path
                key={seg.id}
                d={seg.d}
                fill="#ffffff"
                style={{
                  transformOrigin: `${seg.originX}px ${seg.originY}px`,
                  opacity: segmentStates[i] ? 1 : 0,
                  transform: segmentStates[i]
                    ? 'rotate(0deg) scale(1)'
                    : `rotate(${i % 2 === 0 ? 40 : -40}deg) scale(0.4)`,
                  transition: segmentStates[i]
                    ? `opacity 0.38s ease-out, transform 0.52s cubic-bezier(0.22,1,0.36,1)`
                    : 'none',
                }}
              />
            ))}
          </svg>
        </div>
      </div>
    </div>
  );
}
