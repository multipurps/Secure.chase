import ChaseLogo from './ChaseLogo';

export default function AccessibilityPage({ onBack }: { onBack: () => void }) {
  const sections = [
    { title: 'Our Commitment', body: 'JPMorgan Chase is committed to making our digital products and services accessible to all customers, including those with disabilities.' },
    { title: 'Screen Reader Support', body: 'Chase Mobile is designed to be compatible with VoiceOver on iOS and TalkBack on Android. All interactive elements include descriptive labels.' },
    { title: 'Text Size', body: "The application respects your device's system text size settings. You can adjust text size in your device's Accessibility settings." },
    { title: 'Color Contrast', body: 'We follow WCAG 2.1 AA contrast ratio guidelines to ensure text and interface elements are clearly visible.' },
    { title: 'Touch Targets', body: 'All interactive elements are designed with minimum touch target sizes to accommodate users with motor impairments.' },
    { title: 'Biometric Authentication', body: 'Face ID and Touch ID are supported to provide easier, password-free sign-in for eligible devices.' },
    { title: 'Alternative Access', body: 'If you experience difficulty using Chase Mobile, our full-featured website at chase.com is also accessible, or you may call us at 1-800-935-9935 for telephone banking.' },
    { title: 'Feedback', body: 'We are continuously working to improve accessibility. If you encounter any barriers, please contact us at 1-800-935-9935 or visit a local Chase branch.' },
  ];

  return (
    <div style={{ position: 'fixed', inset: 0, display: 'flex', flexDirection: 'column', fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", background: '#fff' }}>
      {/* Blue header */}
      <div style={{ background: '#1352AA', paddingTop: 'max(env(safe-area-inset-top,44px),44px)', paddingBottom: 20, display: 'flex', flexDirection: 'column', alignItems: 'center', position: 'relative', flexShrink: 0 }}>
        <button onClick={onBack} style={{ position: 'absolute', top: 'max(env(safe-area-inset-top,44px),44px)', left: 16, background: 'none', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4, padding: 8 }}>
          <svg width="8" height="13" viewBox="0 0 8 13" fill="none"><path d="M7 1L1 6.5L7 12" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
          <span style={{ color: '#fff', fontSize: 15, fontWeight: 500 }}>Back</span>
        </button>
        <ChaseLogo color="#ffffff" size={28} showText />
      </div>

      {/* Scrollable content */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '24px 20px 40px' }}>
        <h1 style={{ fontSize: 26, fontWeight: 700, color: '#111', margin: '0 0 6px' }}>Accessibility</h1>
        <p style={{ fontSize: 13, color: '#888', marginBottom: 24 }}>Our commitment to accessible banking for everyone</p>

        {sections.map((s, i) => (
          <div key={i} style={{ marginBottom: 20 }}>
            <div style={{ fontSize: 15, fontWeight: 700, color: '#111', marginBottom: 6 }}>{i + 1}. {s.title}</div>
            <div style={{ fontSize: 14, color: '#555', lineHeight: 1.6 }}>{s.body}</div>
          </div>
        ))}

        <div style={{ marginTop: 32, textAlign: 'center', fontSize: 12, color: '#999' }}>
          © 2026 JPMorgan Chase &amp; Co. All rights reserved.
        </div>
      </div>
    </div>
  );
}
