import ChaseLogo from './ChaseLogo';

export default function TermsOfUsePage({ onBack }: { onBack: () => void }) {
  const sections = [
    { title: 'Acceptance of Terms', body: 'By accessing or using Chase Mobile, you agree to be bound by these Terms of Use and all applicable laws and regulations.' },
    { title: 'Use of the Application', body: 'This application is intended solely for personal, non-commercial use by authorized Chase account holders. Unauthorized use is strictly prohibited.' },
    { title: 'Account Security', body: 'You are responsible for maintaining the confidentiality of your username and password. Notify Chase immediately of any unauthorized access to your account.' },
    { title: 'Electronic Communications', body: 'By using Chase Mobile, you consent to receive electronic communications from JPMorgan Chase Bank, N.A. regarding your accounts and services.' },
    { title: 'Intellectual Property', body: 'All content, trademarks, and data on this application are the property of JPMorgan Chase & Co. and are protected by applicable intellectual property laws.' },
    { title: 'Limitation of Liability', body: 'JPMorgan Chase Bank, N.A. shall not be liable for any indirect, incidental, or consequential damages arising from your use of this application.' },
    { title: 'Privacy Policy', body: 'Your use of this application is also governed by our Privacy Policy, which is incorporated into these Terms by reference.' },
    { title: 'Modifications', body: 'Chase reserves the right to modify these Terms at any time. Continued use of the application after changes constitutes your acceptance of the revised Terms.' },
    { title: 'Governing Law', body: 'These Terms are governed by the laws of the State of New York, without regard to conflict of law provisions.' },
    { title: 'Contact Us', body: 'If you have questions about these Terms, contact Chase customer service at 1-800-935-9935.' },
  ];

  return (
    <div style={{ position: 'fixed', inset: 0, display: 'flex', flexDirection: 'column', fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", background: '#fff' }}>
      {/* Blue header */}
      <div style={{ background: '#1352AA', paddingTop: 'max(env(safe-area-inset-top,44px),44px)', paddingBottom: 20, display: 'flex', flexDirection: 'column', alignItems: 'center', position: 'relative', flexShrink: 0 }}>
        <button onClick={onBack} style={{ position: 'absolute', top: 'max(env(safe-area-inset-top,44px),44px)', left: 16, background: 'none', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4, padding: 8 }}>
          <svg width="8" height="13" viewBox="0 0 8 13" fill="none"><path d="M7 1L1 6.5L7 12" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
          <span style={{ color: '#fff', fontSize: 15, fontWeight: 500 }}>Back</span>
        </button>
        <ChaseLogo color="#ffffff" size={28} showText />
      </div>

      {/* Scrollable content */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '24px 20px 40px' }}>
        <h1 style={{ fontSize: 26, fontWeight: 700, color: '#111', margin: '0 0 6px' }}>Terms of Use</h1>
        <p style={{ fontSize: 13, color: '#888', marginBottom: 24 }}>Last updated: January 1, 2026</p>

        {sections.map((s, i) => (
          <div key={i} style={{ marginBottom: 20 }}>
            <div style={{ fontSize: 15, fontWeight: 700, color: '#111', marginBottom: 6 }}>{i + 1}. {s.title}</div>
            <div style={{ fontSize: 14, color: '#555', lineHeight: 1.6 }}>{s.body}</div>
          </div>
        ))}

        <div style={{ marginTop: 32, textAlign: 'center', fontSize: 12, color: '#999' }}>
          © 2026 JPMorgan Chase &amp; Co. All rights reserved.
        </div>
      </div>
    </div>
  );
}
