import { useState, useEffect, useRef } from 'react';
import { supabase } from '../../lib/supabase';

const blue = '#2558b5';

const OCT_NE = "M 19.67,0 C 18.60,0 17.73,0.87 17.73,1.94 L 17.73,15.55 L 53.67,15.55 L 37.30,0.003 Z";
const OCT_SE = "M 54.98,19.67 C 54.98,18.59 54.12,17.73 53.04,17.73 L 39.44,17.73 L 39.44,53.67 L 54.977,37.29 Z";
const OCT_SW = "M 35.32,54.97 C 36.39,54.97 37.26,54.10 37.26,53.03 L 37.26,39.43 L 1.32,39.43 L 17.68,54.967 Z";
const OCT_NW = "M 0,35.31 C 0,36.38 0.87,37.26 1.94,37.26 L 15.54,37.26 L 15.54,1.31 L 0.003,17.68 Z";

function OctagonIcon({ size = 28, color = '#fff' }: { size?: number; color?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 55 55" fill="none">
      <path d={OCT_NE} fill={color} />
      <path d={OCT_SE} fill={color} />
      <path d={OCT_SW} fill={color} />
      <path d={OCT_NW} fill={color} />
    </svg>
  );
}

interface Message {
  id: string;
  role: 'ai' | 'user';
  text: string;
  time: string;
}

function nowTime() {
  return new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
}

function uid() {
  return Math.random().toString(36).slice(2);
}

interface FraudMonitoringAIProps {
  onBack: () => void;
  userFirstName: string;
}

const QUICK_REPLIES = [
  'Report a transaction',
  'Freeze my card',
  "I didn't make this purchase",
  'Check recent activity',
];

const CLAUDE_SYSTEM = `You are Chase Bank's Fraud Monitoring AI assistant. Help users with fraud-related questions, suspicious transactions, card freezing, and dispute processes. Be concise, professional, and security-focused. Keep responses under 80 words.`;

export default function FraudMonitoringAI({ onBack, userFirstName }: FraudMonitoringAIProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [cardFrozen, setCardFrozen] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const apiKey = import.meta.env.VITE_CLAUDE_API_KEY || '';

  useEffect(() => {
    const greeting: Message = {
      id: uid(),
      role: 'ai',
      text: `Hello ${userFirstName}! I'm Chase's Fraud Monitoring Assistant. I'll alert you about any suspicious activity on your account. How can I help you today?`,
      time: nowTime(),
    };
    setMessages([greeting]);
  }, [userFirstName]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  async function handleFreezeCard() {
    const newFrozen = !cardFrozen;
    setCardFrozen(newFrozen);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        await supabase.from('users').update({ card_frozen: newFrozen }).eq('id', user.id);
      }
    } catch { /* silent */ }
    return newFrozen
      ? 'Your card has been frozen. No new transactions will be approved. You can unfreeze it at any time in Security & Privacy settings.'
      : 'Your card has been unfrozen. Transactions will be processed normally.';
  }

  async function getAIResponse(userText: string): Promise<string> {
    const lower = userText.toLowerCase();

    // Local handlers for specific actions
    if (lower.includes('freeze') && lower.includes('card')) {
      return await handleFreezeCard();
    }
    if (lower.includes('recent activity') || lower.includes('check recent')) {
      return "I can see your recent transactions. Your last 3 transactions were: -$50.00 at Robinhood (Jul 6), +$4,581.23 Virginia Tech Salary (Jul 3), -$200.00 Amazon (Jul 1). Does any of these look unfamiliar?";
    }
    if (lower.includes("didn't make") || lower.includes('dispute')) {
      return "I'm sorry to hear that. To dispute a transaction: 1) Tell me the merchant name and amount. 2) I'll log a dispute on your behalf. 3) You'll receive a provisional credit within 5 business days. Which transaction would you like to dispute?";
    }
    if (lower.includes('report') && lower.includes('transaction')) {
      return "Please provide the transaction details: merchant name, date, and amount. I'll log a fraud report immediately and our fraud team will review it within 24 hours.";
    }

    // Claude API call
    if (!apiKey) {
      return "I'm here to help with fraud-related questions. You can ask about suspicious transactions, card freezing, or dispute processes. For live AI responses, please configure your Claude API key.";
    }

    try {
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01',
          'anthropic-dangerous-direct-browser-access': 'true',
        },
        body: JSON.stringify({
          model: 'claude-sonnet-4-5',
          max_tokens: 200,
          system: CLAUDE_SYSTEM,
          messages: [{ role: 'user', content: userText }],
        }),
      });
      const data = await res.json();
      return data?.content?.[0]?.text || "I'm here to help. Could you rephrase your question?";
    } catch {
      return "I'm experiencing a brief connection issue. Please try again in a moment.";
    }
  }

  async function sendMessage(text: string) {
    const trimmed = text.trim();
    if (!trimmed || loading) return;

    const userMsg: Message = { id: uid(), role: 'user', text: trimmed, time: nowTime() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const reply = await getAIResponse(trimmed);
      const aiMsg: Message = { id: uid(), role: 'ai', text: reply, time: nowTime() };
      setMessages(prev => [...prev, aiMsg]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{
      width: '100%', height: '100%', display: 'flex', flexDirection: 'column',
      fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
      background: '#f8f9fa',
    }}>
      {/* Header */}
      <div style={{ background: blue, padding: '48px 16px 16px', position: 'relative', flexShrink: 0 }}>
        <button
          onClick={onBack}
          style={{
            position: 'absolute', top: 14, left: 14,
            background: 'none', border: 'none', cursor: 'pointer', padding: 4,
          }}
        >
          <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
            <polyline points="14,3 7,11 14,19" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
          <OctagonIcon size={36} color="#fff" />
          <div style={{ color: '#fff', fontWeight: 700, fontSize: 22, textAlign: 'center' }}>Fraud Monitoring</div>
        </div>
      </div>

      {/* Messages */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '16px 14px', display: 'flex', flexDirection: 'column', gap: 12 }}>
        {messages.map((msg, i) => (
          <div key={msg.id}>
            {msg.role === 'ai' ? (
              <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start' }}>
                {/* AI avatar */}
                <div style={{
                  width: 28, height: 28, borderRadius: '50%', background: blue,
                  display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
                }}>
                  <OctagonIcon size={16} color="#fff" />
                </div>
                <div style={{ maxWidth: '80%' }}>
                  <div style={{
                    background: blue, color: '#fff', borderRadius: '0 12px 12px 12px',
                    padding: '10px 13px', fontSize: 14, lineHeight: 1.5, fontWeight: 600,
                  }}>
                    {msg.text}
                  </div>
                  <div style={{ fontSize: 10, color: '#aaa', marginTop: 4 }}>{msg.time}</div>
                  {/* Quick replies after first AI message */}
                  {i === 0 && (
                    <div style={{ display: 'flex', gap: 6, marginTop: 8, flexWrap: 'wrap' }}>
                      {QUICK_REPLIES.map(q => (
                        <button
                          key={q}
                          onClick={() => sendMessage(q)}
                          style={{
                            background: '#fff', border: `1.5px solid ${blue}`, borderRadius: 999,
                            padding: '6px 12px', color: blue, fontSize: 12, cursor: 'pointer', fontWeight: 500,
                          }}
                        >
                          {q}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                <div style={{ maxWidth: '78%' }}>
                  <div style={{
                    background: '#fff', border: '1px solid #e0e0e0',
                    borderRadius: '12px 0 12px 12px',
                    padding: '10px 13px', fontSize: 14, lineHeight: 1.5, color: '#111',
                  }}>
                    {msg.text}
                  </div>
                  <div style={{ fontSize: 10, color: '#aaa', marginTop: 4, textAlign: 'right' }}>
                    {msg.time} &bull; Delivered
                  </div>
                </div>
              </div>
            )}
          </div>
        ))}

        {loading && (
          <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start' }}>
            <div style={{ width: 28, height: 28, borderRadius: '50%', background: blue, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <OctagonIcon size={16} color="#fff" />
            </div>
            <div style={{ background: blue, borderRadius: '0 12px 12px 12px', padding: '12px 16px' }}>
              <div style={{ display: 'flex', gap: 4 }}>
                {[0, 1, 2].map(n => (
                  <div key={n} style={{
                    width: 7, height: 7, borderRadius: '50%', background: 'rgba(255,255,255,0.7)',
                    animation: `bounce 1.2s ease-in-out ${n * 0.2}s infinite`,
                  }} />
                ))}
              </div>
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Input bar */}
      <div style={{
        background: '#fff', borderTop: '1px solid #eee',
        padding: '10px 12px',
        display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0,
      }}>
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && sendMessage(input)}
          placeholder="Type a message..."
          style={{
            flex: 1, border: '1.5px solid #e0e0e0', borderRadius: 20,
            padding: '10px 14px', fontSize: 14, outline: 'none',
            fontFamily: 'inherit', resize: 'none',
          }}
        />
        <button
          onClick={() => sendMessage(input)}
          disabled={!input.trim() || loading}
          style={{
            width: 40, height: 40, borderRadius: 10,
            background: input.trim() && !loading ? blue : '#ccc',
            border: 'none', cursor: input.trim() ? 'pointer' : 'default',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            transition: 'background 0.2s', flexShrink: 0,
          }}
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <path d="M12 19V5M5 12l7-7 7 7" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
      </div>

      <style>{`
        @keyframes bounce {
          0%, 60%, 100% { transform: translateY(0); }
          30% { transform: translateY(-6px); }
        }
      `}</style>
    </div>
  );
}
