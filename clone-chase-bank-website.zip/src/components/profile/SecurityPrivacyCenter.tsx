import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';

const blue = '#2558b5';
const navy = '#1a3a6b';

interface SecurityPrivacyCenterProps {
  onBack: () => void;
  onFraudAI: () => void;
}

const OCT_NE = "M 19.67,0 C 18.60,0 17.73,0.87 17.73,1.94 L 17.73,15.55 L 53.67,15.55 L 37.30,0.003 Z";
const OCT_SE = "M 54.98,19.67 C 54.98,18.59 54.12,17.73 53.04,17.73 L 39.44,17.73 L 39.44,53.67 L 54.977,37.29 Z";
const OCT_SW = "M 35.32,54.97 C 36.39,54.97 37.26,54.10 37.26,53.03 L 37.26,39.43 L 1.32,39.43 L 17.68,54.967 Z";
const OCT_NW = "M 0,35.31 C 0,36.38 0.87,37.26 1.94,37.26 L 15.54,37.26 L 15.54,1.31 L 0.003,17.68 Z";

function OctagonIcon({ size = 28, color = '#fff' }: { size?: number; color?: string }) {
  const sc = size / 55;
  return (
    <svg width={size} height={size} viewBox="0 0 55 55" fill="none">
      <path d={OCT_NE} fill={color} transform={`scale(${sc * 55 / size})`} />
      <path d={OCT_SE} fill={color} transform={`scale(${sc * 55 / size})`} />
      <path d={OCT_SW} fill={color} transform={`scale(${sc * 55 / size})`} />
      <path d={OCT_NW} fill={color} transform={`scale(${sc * 55 / size})`} />
    </svg>
  );
}

function ChevronRight() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <polyline points="5,3 11,8 5,13" stroke="#aaa" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export default function SecurityPrivacyCenter({ onBack, onFraudAI }: SecurityPrivacyCenterProps) {
  const [loginDates, setLoginDates] = useState<string[]>([]);
  const [darkWeb, setDarkWeb] = useState(false);
  const [creditMonitor, setCreditMonitor] = useState(false);
  const [marketingOpt, setMarketingOpt] = useState(true);
  const [dataShare, setDataShare] = useState(false);

  useEffect(() => {
    (async () => {
      const { data } = await supabase.auth.getSession();
      if (data.session) {
        const now = new Date();
        const prev = new Date(now.getTime() - 3 * 24 * 60 * 60 * 1000);
        setLoginDates([
          now.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
          prev.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
        ]);
      }
    })();
  }, []);

  function Toggle({ on, onChange }: { on: boolean; onChange: (v: boolean) => void }) {
    return (
      <button onClick={() => onChange(!on)} style={{
        width: 44, height: 26, borderRadius: 13,
        background: on ? blue : '#ccc', border: 'none', cursor: 'pointer',
        position: 'relative', transition: 'background 0.25s', padding: 0, flexShrink: 0,
      }}>
        <div style={{
          width: 20, height: 20, borderRadius: '50%', background: '#fff',
          position: 'absolute', top: 3, left: on ? 20 : 3,
          transition: 'left 0.25s', boxShadow: '0 1px 3px rgba(0,0,0,0.2)',
        }} />
      </button>
    );
  }

  function Card({ title, subtitle, children }: { title: string; subtitle?: string; children: React.ReactNode }) {
    return (
      <div style={{ background: '#fff', borderRadius: 12, margin: '0 16px 14px', overflow: 'hidden', boxShadow: '0 1px 4px rgba(0,0,0,0.07)' }}>
        <div style={{ padding: '14px 16px 6px' }}>
          <div style={{ fontWeight: 700, fontSize: 15, color: '#111' }}>{title}</div>
          {subtitle && <div style={{ fontSize: 12, color: '#888', marginTop: 3 }}>{subtitle}</div>}
        </div>
        {children}
      </div>
    );
  }

  function Row({ label, right, onPress }: { label: string; right?: React.ReactNode; onPress?: () => void }) {
    const inner = (
      <div style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        padding: '12px 16px', borderTop: '1px solid #f0f0f0',
      }}>
        <span style={{ fontSize: 14, color: '#111' }}>{label}</span>
        {right || <ChevronRight />}
      </div>
    );
    if (onPress) return <button onClick={onPress} style={{ width: '100%', background: 'none', border: 'none', cursor: 'pointer', textAlign: 'left', padding: 0 }}>{inner}</button>;
    return inner;
  }

  return (
    <div style={{
      width: '100%', height: '100%', overflowY: 'auto',
      background: '#f0f4f8', fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
      paddingBottom: 80,
    }}>
      {/* Header */}
      <div style={{ background: '#fff', display: 'flex', alignItems: 'center', padding: '14px 16px', borderBottom: '1px solid #eee' }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
          <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
            <polyline points="14,3 7,11 14,19" stroke="#555" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
        <div style={{ flex: 1, textAlign: 'center', fontWeight: 700, fontSize: 16, color: '#111', marginRight: 30 }}>
          Security &amp; Privacy Center
        </div>
      </div>

      {/* Blue banner */}
      <div style={{
        background: navy, padding: '28px 20px 24px',
        borderRadius: '0 0 12px 12px', margin: '0 0 14px',
        textAlign: 'center',
      }}>
        <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 10 }}>
          <OctagonIcon size={36} color="#fff" />
        </div>
        <div style={{ color: '#fff', fontWeight: 700, fontSize: 17, marginBottom: 8 }}>
          Welcome to Security &amp; Privacy Center
        </div>
        <div style={{ color: 'rgba(255,255,255,0.85)', fontSize: 13, lineHeight: 1.6, maxWidth: 320, margin: '0 auto' }}>
          Our tools help you manage your data, protect your privacy and keep your accounts secure. Together, we can protect you better.
        </div>
      </div>

      {/* Report fraud button */}
      <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 16 }}>
        <button
          onClick={onFraudAI}
          style={{
            background: '#fff', border: `2px solid ${blue}`, borderRadius: 999,
            padding: '12px 32px', color: blue, fontWeight: 700, fontSize: 15,
            cursor: 'pointer',
          }}
        >
          Report fraud
        </button>
      </div>

      {/* Card 1 — Devices */}
      <Card title={`Devices (${loginDates.length} total)`} subtitle="Keep track of your devices and manage their access to your accounts.">
        {loginDates.map((date, i) => (
          <div key={i} style={{
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            padding: '12px 16px', borderTop: '1px solid #f0f0f0',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{ width: 10, height: 10, borderRadius: '50%', background: i === 0 ? blue : '#ccc' }} />
              <span style={{ fontSize: 14, color: '#111' }}>
                {i === 0 ? 'This device (iPhone)' : 'iPhone (previous session)'}
              </span>
            </div>
            <span style={{ fontSize: 12, color: '#888' }}>{date}</span>
          </div>
        ))}
      </Card>

      {/* Card 2 — Linked apps */}
      <Card title="Linked apps & websites (2 total)" subtitle="Monitor and manage who you allow to access your accounts.">
        {[
          { name: 'Robinhood', isNew: true, date: 'Nov 2024' },
          { name: 'Mint', isNew: false, date: 'Jan 2024' },
        ].map((app, i) => (
          <div key={i} style={{
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            padding: '12px 16px', borderTop: '1px solid #f0f0f0',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ fontSize: 14, color: '#111' }}>{app.name}</span>
              {app.isNew && (
                <span style={{ background: '#e8f5e9', color: '#388e3c', fontSize: 10, fontWeight: 700, padding: '2px 8px', borderRadius: 999 }}>New</span>
              )}
            </div>
            <span style={{ fontSize: 12, color: '#888' }}>{app.date}</span>
          </div>
        ))}
      </Card>

      {/* Card 3 — External accounts */}
      <Card title="External accounts" subtitle="Manage your linked accounts from other institutions.">
        <Row label="Link an external account to keep track of all your finances in one place" />
      </Card>

      {/* Card 4 — Privacy choices */}
      <Card title="Privacy choices">
        <Row
          label="Marketing data sharing"
          right={<Toggle on={marketingOpt} onChange={setMarketingOpt} />}
        />
        <Row
          label="Third-party data sharing"
          right={<Toggle on={dataShare} onChange={setDataShare} />}
        />
      </Card>

      {/* Card 5 — Identity protection */}
      <Card title="Identity protection">
        <Row
          label="Dark web monitoring"
          right={<Toggle on={darkWeb} onChange={setDarkWeb} />}
        />
        <Row
          label="Credit monitoring alerts"
          right={<Toggle on={creditMonitor} onChange={setCreditMonitor} />}
        />
        <Row label="Identity theft coverage" />
      </Card>

      {/* Card 6 — Two-step verification */}
      <Card title="Two-step verification">
        <div style={{ padding: '12px 16px', borderTop: '1px solid #f0f0f0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <div style={{ fontSize: 14, color: '#111' }}>Current method</div>
            <div style={{ fontSize: 12, color: '#888' }}>SMS to (***) ***-1234</div>
          </div>
          <button style={{ background: 'none', border: 'none', cursor: 'pointer', color: blue, fontWeight: 600, fontSize: 14 }}>Manage</button>
        </div>
      </Card>
    </div>
  );
}
