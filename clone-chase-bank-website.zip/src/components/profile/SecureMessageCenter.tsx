import { useState } from 'react';

const blue = '#2558b5';

interface Props { onBack: () => void; }

const MESSAGES = [
  {
    id: '1', from: 'Chase' as const, subject: 'Account Statement Available',
    preview: 'Your July 2023 account statement is now available online.',
    date: 'Jul 5, 2023', read: true,
    body: 'Your July 2023 account statement for HIGH SCHOOL CHECKING (...8721) is now available. You can view and download it from the Statements & Documents section.',
  },
  {
    id: '2', from: 'Chase' as const, subject: 'Important Security Notice',
    preview: 'We noticed a new sign-in to your Chase account.',
    date: 'Jul 2, 2023', read: true,
    body: 'We noticed a new sign-in to your Chase account from iPhone on July 2, 2023 at 10:43 AM ET. If this was you, no action is needed. If you do not recognize this activity, please call us immediately at 1-800-935-9935.',
  },
  {
    id: '3', from: 'Chase' as const, subject: 'Payment Confirmation',
    preview: 'Your bill payment of $125.00 has been processed.',
    date: 'Jun 30, 2023', read: false,
    body: 'Your bill payment of $125.00 to CREDIT CARD (...1234) has been successfully processed on June 30, 2023. Your updated balance will reflect within 1-2 business days.',
  },
];

export default function SecureMessageCenter({ onBack }: Props) {
  const [view, setView] = useState<'inbox' | 'compose' | 'detail'>('inbox');
  const [selectedMsg, setSelectedMsg] = useState<typeof MESSAGES[0] | null>(null);
  const [composeSubject, setComposeSubject] = useState('');
  const [composeBody, setComposeBody] = useState('');
  const [sent, setSent] = useState(false);

  if (view === 'detail' && selectedMsg) {
    return (
      <div style={{ width: '100%', height: '100%', overflowY: 'auto', background: '#f0f4f8', fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", paddingBottom: 80 }}>
        <div style={{ background: '#fff', display: 'flex', alignItems: 'center', padding: '14px 16px', borderBottom: '1px solid #eee' }}>
          <button onClick={() => setView('inbox')} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
            <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
              <polyline points="14,3 7,11 14,19" stroke="#555" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
          <div style={{ flex: 1, textAlign: 'center', fontWeight: 700, fontSize: 16, color: '#111', marginRight: 30 }}>Message</div>
        </div>
        <div style={{ margin: '16px', background: '#fff', borderRadius: 12, padding: 16, boxShadow: '0 1px 4px rgba(0,0,0,0.07)' }}>
          <div style={{ fontWeight: 700, fontSize: 16, color: '#111', marginBottom: 4 }}>{selectedMsg.subject}</div>
          <div style={{ fontSize: 12, color: '#888', marginBottom: 16 }}>From: Chase Bank &bull; {selectedMsg.date}</div>
          <div style={{ fontSize: 14, color: '#333', lineHeight: 1.6 }}>{selectedMsg.body}</div>
        </div>
      </div>
    );
  }

  if (view === 'compose') {
    return (
      <div style={{ width: '100%', height: '100%', overflowY: 'auto', background: '#f0f4f8', fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", paddingBottom: 80 }}>
        <div style={{ background: '#fff', display: 'flex', alignItems: 'center', padding: '14px 16px', borderBottom: '1px solid #eee' }}>
          <button onClick={() => setView('inbox')} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
            <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
              <polyline points="14,3 7,11 14,19" stroke="#555" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
          <div style={{ flex: 1, textAlign: 'center', fontWeight: 700, fontSize: 16, color: '#111', marginRight: 30 }}>New message</div>
        </div>
        {sent ? (
          <div style={{ padding: 32, textAlign: 'center' }}>
            <div style={{ width: 56, height: 56, borderRadius: '50%', background: '#e8f5e9', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px' }}>
              <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
                <path d="M5 14l6 6L23 8" stroke="#43a047" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
            <div style={{ fontWeight: 700, fontSize: 18, color: '#111', marginBottom: 8 }}>Message sent!</div>
            <div style={{ fontSize: 14, color: '#888' }}>We'll respond within 1-2 business days.</div>
            <button onClick={() => { setView('inbox'); setSent(false); setComposeSubject(''); setComposeBody(''); }} style={{ marginTop: 24, background: blue, color: '#fff', border: 'none', borderRadius: 6, padding: '13px 32px', fontWeight: 700, fontSize: 15, cursor: 'pointer' }}>
              Back to inbox
            </button>
          </div>
        ) : (
          <div style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div style={{ background: '#fff', borderRadius: 12, padding: 16, boxShadow: '0 1px 4px rgba(0,0,0,0.07)' }}>
              <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>To</div>
              <div style={{ fontSize: 14, color: '#111', borderBottom: '1px solid #f0f0f0', paddingBottom: 12, marginBottom: 12 }}>Chase Bank — Customer Support</div>
              <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Subject</div>
              <input
                value={composeSubject}
                onChange={e => setComposeSubject(e.target.value)}
                placeholder="Enter subject"
                style={{ width: '100%', border: 'none', borderBottom: '1.5px solid #ccc', outline: 'none', fontSize: 14, padding: '4px 0', background: 'none', marginBottom: 16 }}
              />
              <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Message</div>
              <textarea
                value={composeBody}
                onChange={e => setComposeBody(e.target.value)}
                placeholder="Type your message here..."
                rows={6}
                style={{ width: '100%', border: '1px solid #e0e0e0', borderRadius: 8, outline: 'none', fontSize: 14, padding: 10, fontFamily: 'inherit', resize: 'none' }}
              />
            </div>
            <button
              onClick={() => setSent(true)}
              disabled={!composeSubject.trim() || !composeBody.trim()}
              style={{
                width: '100%', background: composeSubject.trim() && composeBody.trim() ? blue : '#ccc',
                color: '#fff', border: 'none', borderRadius: 6, padding: '15px 0',
                fontWeight: 700, fontSize: 16, cursor: 'pointer',
              }}
            >
              Send message
            </button>
          </div>
        )}
      </div>
    );
  }

  return (
    <div style={{ width: '100%', height: '100%', overflowY: 'auto', background: '#f0f4f8', fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", paddingBottom: 80 }}>
      {/* Header */}
      <div style={{ background: '#fff', display: 'flex', alignItems: 'center', padding: '14px 16px', borderBottom: '1px solid #eee' }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
          <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
            <polyline points="14,3 7,11 14,19" stroke="#555" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
        <div style={{ flex: 1, textAlign: 'center', fontWeight: 700, fontSize: 16, color: '#111', marginRight: 30 }}>Secure message center</div>
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '16px 16px 12px' }}>
        <div style={{ fontWeight: 700, fontSize: 24, color: '#111' }}>Inbox</div>
        <button onClick={() => setView('compose')} style={{ background: blue, color: '#fff', border: 'none', borderRadius: 6, padding: '8px 16px', fontWeight: 600, fontSize: 14, cursor: 'pointer' }}>
          Compose
        </button>
      </div>

      <div style={{ background: '#fff', borderRadius: 12, margin: '0 16px', overflow: 'hidden', boxShadow: '0 1px 4px rgba(0,0,0,0.07)' }}>
        {MESSAGES.map((msg, i) => (
          <button
            key={msg.id}
            onClick={() => { setSelectedMsg(msg); setView('detail'); }}
            style={{
              width: '100%', background: msg.read ? '#fff' : '#f0f6ff',
              border: 'none', borderBottom: i < MESSAGES.length - 1 ? '1px solid #f0f0f0' : 'none',
              cursor: 'pointer', textAlign: 'left', padding: '14px 16px',
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontWeight: msg.read ? 500 : 700, fontSize: 14, color: '#111' }}>{msg.subject}</span>
              <span style={{ fontSize: 11, color: '#aaa' }}>{msg.date}</span>
            </div>
            <div style={{ fontSize: 12, color: '#888', marginTop: 3 }}>{msg.preview}</div>
            {!msg.read && <div style={{ width: 8, height: 8, borderRadius: '50%', background: blue, marginTop: 6 }} />}
          </button>
        ))}
      </div>
    </div>
  );
}
