import { useState, useEffect, useRef } from 'react';
import { supabase } from '../../lib/supabase';

const blue = '#2558b5';

const OCT_NE = "M 19.67,0 C 18.60,0 17.73,0.87 17.73,1.94 L 17.73,15.55 L 53.67,15.55 L 37.30,0.003 Z";
const OCT_SE = "M 54.98,19.67 C 54.98,18.59 54.12,17.73 53.04,17.73 L 39.44,17.73 L 39.44,53.67 L 54.977,37.29 Z";
const OCT_SW = "M 35.32,54.97 C 36.39,54.97 37.26,54.10 37.26,53.03 L 37.26,39.43 L 1.32,39.43 L 17.68,54.967 Z";
const OCT_NW = "M 0,35.31 C 0,36.38 0.87,37.26 1.94,37.26 L 15.54,37.26 L 15.54,1.31 L 0.003,17.68 Z";

function OctagonIcon({ size = 28, color = '#fff' }: { size?: number; color?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 55 55" fill="none">
      <path d={OCT_NE} fill={color} />
      <path d={OCT_SE} fill={color} />
      <path d={OCT_SW} fill={color} />
      <path d={OCT_NW} fill={color} />
    </svg>
  );
}

interface Message {
  id: string;
  role: 'ai' | 'user';
  text: string;
  time: string;
}

function nowTime() {
  return new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
}

function uid() {
  return Math.random().toString(36).slice(2);
}

const QUICK_REPLIES = ['Check my balance', 'Recent transactions', 'Make a payment', 'Find an ATM'];

const CLAUDE_SYSTEM = `You are Chase Bank's Digital Assistant. Help users with banking questions including account balances, transaction history, payments, transfers, credit cards, and general Chase banking services. Be helpful, accurate, and professional. Keep responses under 80 words.`;

const DEMO_BALANCE = '$2,122.73';
const DEMO_TRANSACTIONS = [
  { merchant: 'Robinhood Funds', date: 'Jul 6, 2023', amount: '-$50.00' },
  { merchant: 'Virginia Tech Salary', date: 'Jul 3, 2023', amount: '+$4,581.23' },
  { merchant: 'Amazon', date: 'Jul 1, 2023', amount: '-$200.00' },
];

interface Props {
  onBack: () => void;
  userFirstName: string;
}

export default function ChaseDigitalAssistant({ onBack, userFirstName }: Props) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const apiKey = import.meta.env.VITE_CLAUDE_API_KEY || '';

  useEffect(() => {
    setMessages([{
      id: uid(),
      role: 'ai',
      text: `Hi ${userFirstName}! I'm your Chase Digital Assistant. I can help with account questions, transactions, payments, and more.`,
      time: nowTime(),
    }]);
  }, [userFirstName]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  async function getAIResponse(userText: string): Promise<string> {
    const lower = userText.toLowerCase();

    if (lower.includes('balance')) {
      let bal = DEMO_BALANCE;
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
          const { data } = await supabase.from('accounts').select('balance').eq('user_id', user.id).single();
          if (data?.balance) bal = `$${Number(data.balance).toLocaleString('en-US', { minimumFractionDigits: 2 })}`;
        }
      } catch { /* use demo */ }
      return `Your HIGH SCHOOL CHECKING account balance is ${bal}. Available balance matches your present balance.`;
    }

    if (lower.includes('recent') || lower.includes('transaction')) {
      const list = DEMO_TRANSACTIONS.map(t => `${t.merchant} on ${t.date}: ${t.amount}`).join('; ');
      return `Your 3 most recent transactions: ${list}.`;
    }

    if (lower.includes('payment') || lower.includes('pay')) {
      return 'To make a payment, go to Pay & Transfer in the bottom navigation. You can pay bills, send money with Zelle, or set up recurring payments. Would you like me to walk you through the process?';
    }

    if (lower.includes('atm') || lower.includes('branch')) {
      return 'There are 3 Chase ATMs near you: 1) Chase ATM — 0.2 miles (Main St), 2) Chase ATM — 0.5 miles (Oak Ave), 3) Chase Branch — 0.8 miles (Park Blvd). Open Mon-Fri 9AM–5PM.';
    }

    if (!apiKey) {
      return "I can help with balance inquiries, transactions, payments, and ATM locations. For full AI capabilities, configure your Claude API key in environment settings.";
    }

    try {
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01',
          'anthropic-dangerous-direct-browser-access': 'true',
        },
        body: JSON.stringify({
          model: 'claude-sonnet-4-5',
          max_tokens: 200,
          system: CLAUDE_SYSTEM,
          messages: [{ role: 'user', content: userText }],
        }),
      });
      const data = await res.json();
      return data?.content?.[0]?.text || "I'm here to help. Could you rephrase that?";
    } catch {
      return "I'm having a brief connection issue. Please try again in a moment.";
    }
  }

  async function sendMessage(text: string) {
    const trimmed = text.trim();
    if (!trimmed || loading) return;
    setMessages(prev => [...prev, { id: uid(), role: 'user', text: trimmed, time: nowTime() }]);
    setInput('');
    setLoading(true);
    try {
      const reply = await getAIResponse(trimmed);
      setMessages(prev => [...prev, { id: uid(), role: 'ai', text: reply, time: nowTime() }]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{
      width: '100%', height: '100%', display: 'flex', flexDirection: 'column',
      fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
      background: '#f8f9fa',
    }}>
      {/* Header */}
      <div style={{ background: blue, padding: '48px 16px 16px', position: 'relative', flexShrink: 0 }}>
        <button onClick={onBack} style={{ position: 'absolute', top: 14, left: 14, background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
          <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
            <polyline points="14,3 7,11 14,19" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
          <OctagonIcon size={36} color="#fff" />
          <div style={{ color: '#fff', fontWeight: 700, fontSize: 22, textAlign: 'center' }}>Chase Digital Assistant™</div>
        </div>
      </div>

      {/* Messages */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '16px 14px', display: 'flex', flexDirection: 'column', gap: 12 }}>
        {messages.map((msg, i) => (
          <div key={msg.id}>
            {msg.role === 'ai' ? (
              <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start' }}>
                <div style={{ width: 28, height: 28, borderRadius: '50%', background: blue, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <OctagonIcon size={16} color="#fff" />
                </div>
                <div style={{ maxWidth: '80%' }}>
                  <div style={{ background: blue, color: '#fff', borderRadius: '0 12px 12px 12px', padding: '10px 13px', fontSize: 14, lineHeight: 1.5, fontWeight: 600 }}>
                    {msg.text}
                  </div>
                  <div style={{ fontSize: 10, color: '#aaa', marginTop: 4 }}>{msg.time}</div>
                  {i === 0 && (
                    <div style={{ display: 'flex', gap: 6, marginTop: 8, flexWrap: 'wrap' }}>
                      {QUICK_REPLIES.map(q => (
                        <button key={q} onClick={() => sendMessage(q)} style={{
                          background: '#fff', border: `1.5px solid ${blue}`, borderRadius: 999,
                          padding: '6px 12px', color: blue, fontSize: 12, cursor: 'pointer', fontWeight: 500,
                        }}>{q}</button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                <div style={{ maxWidth: '78%' }}>
                  <div style={{ background: '#fff', border: '1px solid #e0e0e0', borderRadius: '12px 0 12px 12px', padding: '10px 13px', fontSize: 14, color: '#111' }}>
                    {msg.text}
                  </div>
                  <div style={{ fontSize: 10, color: '#aaa', marginTop: 4, textAlign: 'right' }}>{msg.time} &bull; Delivered</div>
                </div>
              </div>
            )}
          </div>
        ))}
        {loading && (
          <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start' }}>
            <div style={{ width: 28, height: 28, borderRadius: '50%', background: blue, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <OctagonIcon size={16} color="#fff" />
            </div>
            <div style={{ background: blue, borderRadius: '0 12px 12px 12px', padding: '12px 16px' }}>
              <div style={{ display: 'flex', gap: 4 }}>
                {[0,1,2].map(n => (
                  <div key={n} style={{ width: 7, height: 7, borderRadius: '50%', background: 'rgba(255,255,255,0.7)', animation: `bounce 1.2s ease-in-out ${n*0.2}s infinite` }} />
                ))}
              </div>
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div style={{ background: '#fff', borderTop: '1px solid #eee', padding: '10px 12px', display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0 }}>
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && sendMessage(input)}
          placeholder="Type a message..."
          style={{ flex: 1, border: '1.5px solid #e0e0e0', borderRadius: 20, padding: '10px 14px', fontSize: 14, outline: 'none', fontFamily: 'inherit' }}
        />
        <button
          onClick={() => sendMessage(input)}
          disabled={!input.trim() || loading}
          style={{
            width: 40, height: 40, borderRadius: 10,
            background: input.trim() && !loading ? blue : '#ccc',
            border: 'none', cursor: input.trim() ? 'pointer' : 'default',
            display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
          }}
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <path d="M12 19V5M5 12l7-7 7 7" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
      </div>

      <style>{`@keyframes bounce { 0%,60%,100% { transform:translateY(0);} 30% { transform:translateY(-6px);} }`}</style>
    </div>
  );
}
