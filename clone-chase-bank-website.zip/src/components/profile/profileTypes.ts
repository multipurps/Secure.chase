export interface AlertSetting {
  id: string;
  label: string;
  description: string;
  enabled: boolean;
}

export interface SecureMessage {
  id: string;
  subject: string;
  preview: string;
  date: string;
  read: boolean;
  from: 'Chase' | 'You';
  body: string;
}
