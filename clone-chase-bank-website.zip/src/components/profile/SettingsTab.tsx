import { useState, useRef } from 'react';
import { supabase } from '../../lib/supabase';

const blue = '#2558b5';

interface SettingsTabProps {
  userProfile: {
    firstName: string;
    lastName: string;
    email: string;
    username: string;
    phone: string;
    address: string;
    dob: string;
    photoUrl?: string;
  };
  onSecurityPrivacy: () => void;
  onProfilePhotoChange: (url: string) => void;
}

const ZOOM_OPTIONS = [
  { label: '80% (Smaller)', value: 0.8 },
  { label: '90% (Small)', value: 0.9 },
  { label: '100% (Default)', value: 1.0 },
  { label: '110% (Large)', value: 1.1 },
  { label: '120% (Larger)', value: 1.2 },
  { label: '130% (Largest)', value: 1.3 },
];

function ZoomSetting() {
  const saved = parseFloat(localStorage.getItem('appZoom') || '1');
  const [zoom, setZoom] = useState(saved);
  const [showSheet, setShowSheet] = useState(false);

  function applyZoom(val: number) {
    setZoom(val);
    localStorage.setItem('appZoom', String(val));
    document.documentElement.style.fontSize = `${val * 16}px`;
    setShowSheet(false);
  }

  return (
    <>
      <div
        onClick={() => setShowSheet(true)}
        style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', cursor: 'pointer' }}
      >
        <div style={{ fontWeight: 600, fontSize: 14, color: '#111' }}>App zoom size</div>
        <span style={{ fontSize: 14, color: '#888' }}>{Math.round(zoom * 100)}%</span>
      </div>

      {showSheet && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.45)', zIndex: 600, display: 'flex', alignItems: 'flex-end' }} onClick={() => setShowSheet(false)}>
          <div style={{ background: '#fff', width: '100%', borderRadius: '16px 16px 0 0', padding: '20px 0 40px' }} onClick={e => e.stopPropagation()}>
            <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 16 }}>
              <div style={{ width: 40, height: 4, background: '#ccc', borderRadius: 2 }} />
            </div>
            <div style={{ fontWeight: 700, fontSize: 17, textAlign: 'center', marginBottom: 12, color: '#111' }}>App zoom size</div>
            {ZOOM_OPTIONS.map(opt => (
              <button key={opt.value} onClick={() => applyZoom(opt.value)} style={{
                width: '100%', padding: '14px 20px', background: 'none', border: 'none',
                borderBottom: '1px solid #f0f0f0', display: 'flex', justifyContent: 'space-between',
                alignItems: 'center', cursor: 'pointer', fontSize: 15, color: '#111',
              }}>
                <span>{opt.label}</span>
                {zoom === opt.value && (
                  <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                    <polyline points="3,9 7,13 15,5" stroke={blue} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                )}
              </button>
            ))}
          </div>
        </div>
      )}
    </>
  );
}

function AccordionRow({
  icon,
  label,
  isLink,
  onPress,
  children,
}: {
  icon: React.ReactNode;
  label: string;
  isLink?: boolean;
  onPress?: () => void;
  children?: React.ReactNode;
}) {
  const [open, setOpen] = useState(false);

  return (
    <div style={{ borderBottom: '1px solid #f0f0f0' }}>
      <button
        onClick={isLink ? onPress : () => setOpen(o => !o)}
        style={{
          width: '100%', background: 'none', border: 'none', cursor: 'pointer',
          display: 'flex', alignItems: 'center', gap: 12,
          padding: '16px 16px', textAlign: 'left',
        }}
      >
        <span style={{ color: '#555', display: 'flex' }}>{icon}</span>
        <span style={{ flex: 1, fontSize: 15, color: '#111', fontWeight: 500 }}>{label}</span>
        {isLink ? (
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
            <polyline points="5,3 11,8 5,13" stroke="#aaa" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        ) : (
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" style={{ transform: open ? 'rotate(180deg)' : 'rotate(0deg)', transition: 'transform 0.25s' }}>
            <polyline points="3,6 8,11 13,6" stroke="#aaa" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        )}
      </button>
      {!isLink && open && (
        <div style={{
          padding: '0 16px 16px',
          animation: 'fadeIn 0.2s ease',
        }}>
          {children}
        </div>
      )}
    </div>
  );
}

function Toggle({ on, onChange }: { on: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!on)}
      style={{
        width: 48, height: 28, borderRadius: 14,
        background: on ? blue : '#ccc',
        border: 'none', cursor: 'pointer',
        position: 'relative', transition: 'background 0.25s', padding: 0,
      }}
    >
      <div style={{
        width: 22, height: 22, borderRadius: '50%', background: '#fff',
        position: 'absolute', top: 3,
        left: on ? 22 : 3,
        transition: 'left 0.25s',
        boxShadow: '0 1px 4px rgba(0,0,0,0.18)',
      }} />
    </button>
  );
}

export default function SettingsTab({ userProfile, onSecurityPrivacy, onProfilePhotoChange }: SettingsTabProps) {
  const [faceId, setFaceId] = useState(false);
  const [twoStep, setTwoStep] = useState(true);
  const [dividends, setDividends] = useState(true);
  const [paperless, setPaperless] = useState(true);
  const [overdraft, setOverdraft] = useState(false);
  const [taxElectronic, setTaxElectronic] = useState(true);
  const [changePwMode, setChangePwMode] = useState(false);
  const [currentPw, setCurrentPw] = useState('');
  const [newPw, setNewPw] = useState('');
  const [confirmPw, setConfirmPw] = useState('');
  const [pwMsg, setPwMsg] = useState('');
  const [pwLoading, setPwLoading] = useState(false);
  const [showCurrentPw, setShowCurrentPw] = useState(false);
  const [showNewPw, setShowNewPw] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const pwStrength = (() => {
    if (!newPw) return 0;
    let s = 0;
    if (newPw.length >= 8) s++;
    if (/[A-Z]/.test(newPw)) s++;
    if (/[0-9]/.test(newPw)) s++;
    if (/[^A-Za-z0-9]/.test(newPw)) s++;
    return s;
  })();

  const strengthLabel = ['', 'Weak', 'Fair', 'Good', 'Strong'][pwStrength];
  const strengthColor = ['', '#e53935', '#fb8c00', '#fdd835', '#43a047'][pwStrength];

  async function handleChangePassword() {
    setPwMsg('');
    if (!currentPw || !newPw || !confirmPw) { setPwMsg('All fields required.'); return; }
    if (newPw !== confirmPw) { setPwMsg('Passwords do not match.'); return; }
    if (newPw.length < 8) { setPwMsg('Password must be at least 8 characters.'); return; }
    setPwLoading(true);
    try {
      const { error } = await supabase.auth.updateUser({ password: newPw });
      if (error) throw error;
      setPwMsg('Password updated successfully.');
      setChangePwMode(false);
      setCurrentPw(''); setNewPw(''); setConfirmPw('');
    } catch {
      setPwMsg('Failed to update password. Please try again.');
    } finally {
      setPwLoading(false);
    }
  }

  async function handlePhotoUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    const ext = file.name.split('.').pop();
    const path = `avatars/${user.id}.${ext}`;
    const { error: upErr } = await supabase.storage.from('avatars').upload(path, file, { upsert: true });
    if (upErr) return;
    const { data } = supabase.storage.from('avatars').getPublicUrl(path);
    const url = data.publicUrl;
    await supabase.from('users').update({ photo_url: url }).eq('id', user.id);
    onProfilePhotoChange(url);
  }

  return (
    <div style={{ paddingTop: 12 }}>
      <style>{`@keyframes fadeIn { from { opacity:0; transform:translateY(-6px); } to { opacity:1; transform:translateY(0); } }`}</style>

      <div style={{ background: '#fff', borderRadius: 12, margin: '0 16px 16px', overflow: 'hidden', boxShadow: '0 1px 4px rgba(0,0,0,0.07)' }}>

        {/* Row 1 — Security & privacy (link) */}
        <AccordionRow
          isLink
          onPress={onSecurityPrivacy}
          icon={
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
              <path d="M12 2L4 6v6c0 5.25 3.5 10.14 8 11.35C16.5 22.14 20 17.25 20 12V6l-8-4z" stroke="#555" strokeWidth="1.8" fill="none" />
            </svg>
          }
          label="Security & privacy"
        />

        {/* Row 2 — Personal details */}
        <AccordionRow
          icon={
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
              <circle cx="12" cy="8" r="4" stroke="#555" strokeWidth="1.8" />
              <path d="M4 20c0-4 3.582-7 8-7s8 3 8 7" stroke="#555" strokeWidth="1.8" strokeLinecap="round" />
            </svg>
          }
          label="Personal details"
        >
          {/* Profile photo */}
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', marginBottom: 16 }}>
            <div style={{
              width: 68, height: 68, borderRadius: '50%',
              background: userProfile.photoUrl ? 'transparent' : '#e0e0e0',
              overflow: 'hidden', display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              {userProfile.photoUrl
                ? <img src={userProfile.photoUrl} alt="avatar" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                : <span style={{ fontWeight: 700, color: '#888', fontSize: 22 }}>
                    {(userProfile.firstName[0] || 'D') + (userProfile.lastName[0] || 'U')}
                  </span>
              }
            </div>
            <input ref={fileRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={handlePhotoUpload} />
            <button onClick={() => fileRef.current?.click()} style={{ background: 'none', border: 'none', cursor: 'pointer', color: blue, fontSize: 14, marginTop: 6, fontWeight: 600 }}>
              Edit
            </button>
          </div>

          {[
            { label: 'Name', value: `${userProfile.firstName} ${userProfile.lastName}`, editable: false },
            { label: 'Email address', value: userProfile.email, editable: false },
            { label: 'Phone number', value: userProfile.phone || '—', editable: true },
            { label: 'Mailing address', value: userProfile.address || '—', editable: true },
            { label: 'Date of birth', value: userProfile.dob || '—', editable: false },
          ].map(row => (
            <div key={row.label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 0', borderBottom: '1px solid #f5f5f5' }}>
              <div>
                <div style={{ fontSize: 12, color: '#888' }}>{row.label}</div>
                <div style={{ fontSize: 14, color: row.editable ? '#111' : '#aaa' }}>{row.value}</div>
              </div>
              {row.editable && (
                <button style={{ background: 'none', border: 'none', cursor: 'pointer', color: blue, fontSize: 13, fontWeight: 600 }}>Edit</button>
              )}
              {!row.editable && (
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
                  <rect x="3" y="11" width="18" height="11" rx="2" stroke="#ccc" strokeWidth="1.8" />
                  <path d="M7 11V7a5 5 0 0 1 10 0v4" stroke="#ccc" strokeWidth="1.8" />
                </svg>
              )}
            </div>
          ))}
        </AccordionRow>

        {/* Row 3 — Sign-in preferences */}
        <AccordionRow
          icon={
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
              <rect x="3" y="11" width="18" height="11" rx="2" stroke="#555" strokeWidth="1.8" />
              <path d="M7 11V7a5 5 0 0 1 10 0v4" stroke="#555" strokeWidth="1.8" />
            </svg>
          }
          label="Sign-in preferences"
        >
          {/* Face ID */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid #f5f5f5' }}>
            <div>
              <div style={{ fontWeight: 600, fontSize: 14, color: '#111' }}>Face ID / Touch ID</div>
              <div style={{ fontSize: 12, color: '#888', marginTop: 2 }}>Sign in using biometric authentication</div>
            </div>
            <Toggle on={faceId} onChange={setFaceId} />
          </div>

          {/* Change password */}
          <div style={{ padding: '10px 0', borderBottom: '1px solid #f5f5f5' }}>
            <button
              onClick={() => setChangePwMode(m => !m)}
              style={{ background: 'none', border: 'none', cursor: 'pointer', color: blue, fontSize: 14, fontWeight: 600, padding: 0 }}
            >
              Change password
            </button>
            {changePwMode && (
              <div style={{ marginTop: 12, display: 'flex', flexDirection: 'column', gap: 10 }}>
                {[
                  { label: 'Current password', val: currentPw, set: setCurrentPw, show: showCurrentPw, setShow: setShowCurrentPw },
                  { label: 'New password', val: newPw, set: setNewPw, show: showNewPw, setShow: setShowNewPw },
                  { label: 'Confirm new password', val: confirmPw, set: setConfirmPw, show: false, setShow: () => {} },
                ].map((f, i) => (
                  <div key={i} style={{ position: 'relative' }}>
                    <div style={{ fontSize: 11, color: '#888', marginBottom: 2 }}>{f.label}</div>
                    <div style={{ display: 'flex', borderBottom: '1.5px solid #ccc' }}>
                      <input
                        type={f.show ? 'text' : 'password'}
                        value={f.val}
                        onChange={e => f.set(e.target.value)}
                        style={{ flex: 1, border: 'none', outline: 'none', fontSize: 14, padding: '4px 0', background: 'none' }}
                      />
                      {i < 2 && (
                        <button onClick={() => f.setShow(!f.show)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: blue, fontSize: 12, fontWeight: 600 }}>
                          {f.show ? 'Hide' : 'Show'}
                        </button>
                      )}
                    </div>
                  </div>
                ))}
                {/* Strength indicator */}
                {newPw.length > 0 && (
                  <div>
                    <div style={{ display: 'flex', gap: 4, marginBottom: 4 }}>
                      {[1,2,3,4].map(n => (
                        <div key={n} style={{ flex: 1, height: 4, borderRadius: 2, background: n <= pwStrength ? strengthColor : '#e0e0e0' }} />
                      ))}
                    </div>
                    <div style={{ fontSize: 11, color: strengthColor }}>{strengthLabel}</div>
                  </div>
                )}
                {pwMsg && <div style={{ fontSize: 12, color: pwMsg.includes('success') ? '#43a047' : '#e53935' }}>{pwMsg}</div>}
                <button
                  onClick={handleChangePassword}
                  disabled={pwLoading}
                  style={{
                    background: pwLoading ? '#aaa' : blue, color: '#fff', border: 'none',
                    borderRadius: 6, padding: '12px 0', fontWeight: 700, fontSize: 15, cursor: 'pointer', marginTop: 4,
                  }}
                >
                  {pwLoading ? 'Saving...' : 'Save password'}
                </button>
              </div>
            )}
          </div>

          {/* Two-step verification */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid #f5f5f5' }}>
            <div>
              <div style={{ fontWeight: 600, fontSize: 14, color: '#111' }}>Two-step verification</div>
              <div style={{ fontSize: 12, color: '#888', marginTop: 2 }}>Current method: SMS</div>
            </div>
            <Toggle on={twoStep} onChange={setTwoStep} />
          </div>

          {/* App zoom size */}
          <ZoomSetting />
        </AccordionRow>

        {/* Row 4 — Investments */}
        <AccordionRow
          icon={
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
              <polyline points="3,17 8,12 12,15 17,9 21,12" stroke="#555" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          }
          label="Investments"
        >
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid #f5f5f5' }}>
            <div>
              <div style={{ fontWeight: 600, fontSize: 14 }}>Dividend reinvestment</div>
              <div style={{ fontSize: 12, color: '#888' }}>Automatically reinvest dividends</div>
            </div>
            <Toggle on={dividends} onChange={setDividends} />
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0' }}>
            <div>
              <div style={{ fontWeight: 600, fontSize: 14 }}>Tax document delivery</div>
              <div style={{ fontSize: 12, color: '#888' }}>Electronic</div>
            </div>
            <Toggle on={taxElectronic} onChange={setTaxElectronic} />
          </div>
        </AccordionRow>

        {/* Row 5 — Account settings */}
        <AccordionRow
          icon={
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
              <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" stroke="#555" strokeWidth="1.8" fill="none" />
              <polyline points="9,22 9,12 15,12 15,22" stroke="#555" strokeWidth="1.8" />
            </svg>
          }
          label="Account settings"
        >
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid #f5f5f5' }}>
            <div>
              <div style={{ fontWeight: 600, fontSize: 14 }}>Overdraft protection</div>
              <div style={{ fontSize: 12, color: '#888' }}>Cover overdrafts automatically</div>
            </div>
            <Toggle on={overdraft} onChange={setOverdraft} />
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '1px solid #f5f5f5' }}>
            <div>
              <div style={{ fontWeight: 600, fontSize: 14 }}>Paperless statements</div>
              <div style={{ fontSize: 12, color: '#888' }}>Total Checking (...8721)</div>
            </div>
            <Toggle on={paperless} onChange={setPaperless} />
          </div>
          <div style={{ padding: '10px 0', borderBottom: '1px solid #f5f5f5' }}>
            <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 6 }}>Account nickname</div>
            <input
              type="text"
              defaultValue="HIGH SCHOOL CHECKING"
              style={{
                width: '100%', border: 'none', borderBottom: '1.5px solid #ccc',
                outline: 'none', fontSize: 14, padding: '4px 0', background: 'none',
              }}
            />
          </div>
          <div style={{ padding: '10px 0' }}>
            <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 6 }}>Language preference</div>
            <select style={{ border: 'none', borderBottom: '1.5px solid #ccc', outline: 'none', fontSize: 14, padding: '4px 0', background: 'none', width: '100%' }}>
              <option>English</option>
              <option>Spanish</option>
            </select>
          </div>
        </AccordionRow>
      </div>

      {/* Feedback + Legal */}
      <div style={{ display: 'flex', justifyContent: 'space-between', padding: '0 16px 24px', marginTop: 4 }}>
        <button style={{ background: 'none', border: 'none', cursor: 'pointer', color: blue, fontSize: 14 }}>Give us feedback</button>
        <button style={{ background: 'none', border: 'none', cursor: 'pointer', color: blue, fontSize: 14 }}>Legal information</button>
      </div>
    </div>
  );
}
