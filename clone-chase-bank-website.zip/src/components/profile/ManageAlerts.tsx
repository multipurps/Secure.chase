import { useState } from 'react';
import { supabase } from '../../lib/supabase';

const blue = '#2558b5';

interface Props { onBack: () => void; }

interface AlertItem {
  id: string;
  label: string;
  description: string;
  enabled: boolean;
}

const DEFAULT_ALERTS: AlertItem[] = [
  { id: 'low_balance', label: 'Low balance', description: 'Alert when balance drops below $100', enabled: true },
  { id: 'large_transaction', label: 'Large transactions', description: 'Alert for transactions over $500', enabled: true },
  { id: 'login_activity', label: 'Login activity', description: 'Alert for new sign-ins to your account', enabled: true },
  { id: 'payment_due', label: 'Payment due', description: 'Alert 3 days before payment due date', enabled: true },
  { id: 'direct_deposit', label: 'Direct deposit', description: 'Alert when direct deposit is received', enabled: false },
  { id: 'atm_withdrawal', label: 'ATM withdrawal', description: 'Alert for all ATM withdrawals', enabled: false },
  { id: 'online_purchase', label: 'Online purchases', description: 'Alert for online/card-not-present transactions', enabled: true },
  { id: 'international', label: 'International transactions', description: 'Alert for foreign transactions', enabled: true },
];

function Toggle({ on, onChange }: { on: boolean; onChange: (v: boolean) => void }) {
  return (
    <button onClick={() => onChange(!on)} style={{
      width: 44, height: 26, borderRadius: 13,
      background: on ? blue : '#ccc', border: 'none', cursor: 'pointer',
      position: 'relative', transition: 'background 0.25s', padding: 0, flexShrink: 0,
    }}>
      <div style={{
        width: 20, height: 20, borderRadius: '50%', background: '#fff',
        position: 'absolute', top: 3, left: on ? 20 : 3,
        transition: 'left 0.25s', boxShadow: '0 1px 3px rgba(0,0,0,0.2)',
      }} />
    </button>
  );
}

export default function ManageAlerts({ onBack }: Props) {
  const [alerts, setAlerts] = useState<AlertItem[]>(DEFAULT_ALERTS);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  function toggle(id: string, val: boolean) {
    setAlerts(prev => prev.map(a => a.id === id ? { ...a, enabled: val } : a));
    setSaved(false);
  }

  async function saveAlerts() {
    setSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const settings: Record<string, boolean> = {};
        alerts.forEach(a => { settings[a.id] = a.enabled; });
        await supabase.from('users').update({ alert_settings: settings }).eq('id', user.id);
      }
      setSaved(true);
    } catch { /* silent */ }
    finally { setSaving(false); }
  }

  return (
    <div style={{ width: '100%', height: '100%', overflowY: 'auto', background: '#f0f4f8', fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", paddingBottom: 100 }}>
      {/* Header */}
      <div style={{ background: '#fff', display: 'flex', alignItems: 'center', padding: '14px 16px', borderBottom: '1px solid #eee' }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
          <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
            <polyline points="14,3 7,11 14,19" stroke="#555" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
        <div style={{ flex: 1, textAlign: 'center', fontWeight: 700, fontSize: 16, color: '#111', marginRight: 30 }}>Manage alerts</div>
      </div>

      <div style={{ padding: '16px 16px 12px', fontWeight: 700, fontSize: 24, color: '#111' }}>Manage alerts</div>
      <div style={{ padding: '0 16px 16px', fontSize: 13, color: '#888' }}>Choose which alerts you'd like to receive for your accounts.</div>

      <div style={{ background: '#fff', borderRadius: 12, margin: '0 16px', overflow: 'hidden', boxShadow: '0 1px 4px rgba(0,0,0,0.07)' }}>
        {alerts.map((alert, i) => (
          <div key={alert.id} style={{
            display: 'flex', alignItems: 'center', gap: 12,
            padding: '14px 16px',
            borderBottom: i < alerts.length - 1 ? '1px solid #f0f0f0' : 'none',
          }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 600, fontSize: 14, color: '#111' }}>{alert.label}</div>
              <div style={{ fontSize: 12, color: '#888', marginTop: 2 }}>{alert.description}</div>
            </div>
            <Toggle on={alert.enabled} onChange={v => toggle(alert.id, v)} />
          </div>
        ))}
      </div>

      {/* Save button */}
      <div style={{ padding: '20px 16px' }}>
        <button
          onClick={saveAlerts}
          disabled={saving}
          style={{
            width: '100%', background: saving ? '#aaa' : blue,
            color: '#fff', border: 'none', borderRadius: 6,
            padding: '15px 0', fontWeight: 700, fontSize: 16, cursor: 'pointer',
          }}
        >
          {saving ? 'Saving...' : saved ? 'Saved!' : 'Save preferences'}
        </button>
      </div>
    </div>
  );
}
