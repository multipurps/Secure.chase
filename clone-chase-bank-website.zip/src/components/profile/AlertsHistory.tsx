

interface Props { onBack: () => void; }

const ALERTS = [
  { type: 'Transaction', title: 'Large transaction alert', msg: 'A transaction of $4,581.23 was credited to your account.', date: 'Jul 3, 2023', read: true },
  { type: 'Security', title: 'New sign-in detected', msg: 'Your account was accessed from a new device: iPhone.', date: 'Jul 2, 2023', read: true },
  { type: 'Transaction', title: 'Debit alert', msg: 'A transaction of $50.00 was debited from your account at Robinhood.', date: 'Jul 1, 2023', read: false },
  { type: 'Payment', title: 'Payment due reminder', msg: 'Your credit card payment of $125.00 is due in 3 days.', date: 'Jun 28, 2023', read: false },
  { type: 'Security', title: 'Password changed', msg: 'Your online banking password was recently changed.', date: 'Jun 20, 2023', read: true },
  { type: 'Transaction', title: 'Direct deposit received', msg: 'A direct deposit of $4,581.23 from Virginia Tech was posted.', date: 'Jun 15, 2023', read: true },
];

const TYPE_COLORS: Record<string, string> = {
  Transaction: '#2558b5',
  Security: '#e53935',
  Payment: '#fb8c00',
};

export default function AlertsHistory({ onBack }: Props) {
  return (
    <div style={{ width: '100%', height: '100%', overflowY: 'auto', background: '#f0f4f8', fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", paddingBottom: 80 }}>
      {/* Header */}
      <div style={{ background: '#fff', display: 'flex', alignItems: 'center', padding: '14px 16px', borderBottom: '1px solid #eee' }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
          <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
            <polyline points="14,3 7,11 14,19" stroke="#555" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
        <div style={{ flex: 1, textAlign: 'center', fontWeight: 700, fontSize: 16, color: '#111', marginRight: 30 }}>Alerts history</div>
      </div>

      <div style={{ padding: '16px 16px 0', fontWeight: 700, fontSize: 24, color: '#111', marginBottom: 12 }}>Alerts history</div>

      <div style={{ background: '#fff', borderRadius: 12, margin: '0 16px', overflow: 'hidden', boxShadow: '0 1px 4px rgba(0,0,0,0.07)' }}>
        {ALERTS.map((alert, i) => (
          <div key={i} style={{
            padding: '14px 16px',
            borderBottom: i < ALERTS.length - 1 ? '1px solid #f0f0f0' : 'none',
            display: 'flex', gap: 12, alignItems: 'flex-start',
            background: alert.read ? '#fff' : '#f8f9ff',
          }}>
            <div style={{
              width: 10, height: 10, borderRadius: '50%', marginTop: 5, flexShrink: 0,
              background: TYPE_COLORS[alert.type] || '#888',
            }} />
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontWeight: alert.read ? 500 : 700, fontSize: 14, color: '#111' }}>{alert.title}</span>
                <span style={{ fontSize: 11, color: '#aaa' }}>{alert.date}</span>
              </div>
              <div style={{ fontSize: 13, color: '#666', marginTop: 3, lineHeight: 1.4 }}>{alert.msg}</div>
              <div style={{
                display: 'inline-block', marginTop: 6, padding: '2px 8px',
                background: `${TYPE_COLORS[alert.type]}20`, borderRadius: 999,
                fontSize: 10, fontWeight: 700, color: TYPE_COLORS[alert.type],
              }}>{alert.type}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
