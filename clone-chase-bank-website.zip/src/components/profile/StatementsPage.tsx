import { useState, useEffect } from 'react';
import { useAccounts, formatBalance } from '../../hooks/useAccounts';
import { supabase, getCurrentUser } from '../../lib/supabase';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

const blue = '#1352AA';
const navy = '#1a3a6b';

interface Props {
  onBack: () => void;
}

function ChaseOctagonWatermark(doc: jsPDF, pageW: number, pageH: number) {
  // Draw Chase octagon as a light watermark using lines
  doc.saveGraphicsState();
  (doc as any).setGState(new (doc as any).GState({ opacity: 0.08 }));
  doc.setFillColor(21, 82, 170);
  const cx = pageW / 2;
  const cy = pageH / 2;
  const r = 60;
  // Draw 4 trapezoid segments of the Chase octagon
  const segments = [
    // NE
    [[cx, cy], [cx + r * 0.35, cy - r * 0.35], [cx + r * 0.7, cy - r * 0.7], [cx + r * 0.7, cy]],
    // SE
    [[cx, cy], [cx + r * 0.35, cy + r * 0.35], [cx + r * 0.7, cy + r * 0.7], [cx + r * 0.7, cy]],
    // SW
    [[cx, cy], [cx - r * 0.35, cy + r * 0.35], [cx - r * 0.7, cy + r * 0.7], [cx - r * 0.7, cy]],
    // NW
    [[cx, cy], [cx - r * 0.35, cy - r * 0.35], [cx - r * 0.7, cy - r * 0.7], [cx - r * 0.7, cy]],
  ];
  segments.forEach(pts => {
    doc.setDrawColor(21, 82, 170);
    doc.setLineWidth(0.5);
    // Draw triangle as a rough segment
    doc.triangle(
      pts[0][0], pts[0][1],
      pts[1][0], pts[1][1],
      pts[2][0], pts[2][1],
      'F'
    );
  });
  // Chase text watermark
  doc.setFontSize(72);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(21, 82, 170);
  doc.text('CHASE', cx, cy + 12, { align: 'center' });
  doc.restoreGraphicsState();
}

function generateStatementPDF(
  account: { account_name: string; last4: string; balance: number },
  period: string,
  transactions: { description: string; date: string; amount: number; type: string; running_balance?: number }[]
) {
  const doc = new jsPDF({ unit: 'pt', format: 'a4' });
  const pageW = doc.internal.pageSize.getWidth();
  const pageH = doc.internal.pageSize.getHeight();

  // ── Watermark ──
  try { ChaseOctagonWatermark(doc, pageW, pageH); } catch {}

  // ── Header ──
  doc.setFillColor(21, 82, 170);
  doc.rect(0, 0, pageW, 80, 'F');

  // Chase wordmark
  doc.setFontSize(24);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(255, 255, 255);
  doc.text('CHASE', 40, 42);

  // Octagon placeholder (small)
  doc.setFillColor(255, 255, 255);
  doc.circle(108, 36, 12, 'F');
  doc.setFillColor(21, 82, 170);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.text('C', 108, 40, { align: 'center' });

  doc.setFontSize(11);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(200, 220, 255);
  doc.text('JPMorgan Chase Bank, N.A. | Member FDIC', 40, 62);
  doc.text('Account Statement', pageW - 40, 42, { align: 'right' });
  doc.setTextColor(255, 255, 255);
  doc.text(period, pageW - 40, 62, { align: 'right' });

  // ── Account Info ──
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 30, 30);
  doc.text(account.account_name.toUpperCase(), 40, 110);
  doc.setFontSize(11);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(90, 90, 90);
  doc.text(`Account ending in ...${account.last4}`, 40, 128);
  doc.text(`Statement Period: ${period}`, 40, 144);
  doc.text(`Closing Balance: ${formatBalance(account.balance)}`, 40, 160);

  // ── Divider ──
  doc.setDrawColor(200, 200, 200);
  doc.setLineWidth(0.5);
  doc.line(40, 172, pageW - 40, 172);

  // ── Transactions Table ──
  if (transactions.length === 0) {
    doc.setFontSize(12);
    doc.setTextColor(120, 120, 120);
    doc.text('No transactions for this period.', 40, 200);
  } else {
    const rows = transactions.map(tx => [
      new Date(tx.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      tx.description,
      tx.type === 'credit' ? `+${formatBalance(tx.amount)}` : `-${formatBalance(tx.amount)}`,
      tx.running_balance != null ? formatBalance(tx.running_balance) : '',
    ]);

    autoTable(doc, {
      head: [['Date', 'Description', 'Amount', 'Balance']],
      body: rows,
      startY: 185,
      margin: { left: 40, right: 40 },
      styles: { fontSize: 9, cellPadding: 5, textColor: [30, 30, 30] },
      headStyles: { fillColor: [21, 82, 170], textColor: [255, 255, 255], fontStyle: 'bold' },
      alternateRowStyles: { fillColor: [245, 247, 252] },
      columnStyles: {
        0: { cellWidth: 80 },
        1: { cellWidth: 'auto' },
        2: { cellWidth: 80, halign: 'right' },
        3: { cellWidth: 80, halign: 'right' },
      },
      didDrawPage: (_data: unknown) => {
        // Watermark on each page
        try { ChaseOctagonWatermark(doc, pageW, pageH); } catch {}
        // Footer
        doc.setFontSize(8);
        doc.setTextColor(150, 150, 150);
        doc.text(
          '© 2026 JPMorgan Chase & Co. | chase.com | 1-800-935-9935',
          pageW / 2, pageH - 20, { align: 'center' }
        );
      },
    });
  }

  // ── Footer ──
  doc.setFontSize(8);
  doc.setTextColor(150, 150, 150);
  doc.text(
    '© 2026 JPMorgan Chase & Co. | chase.com | 1-800-935-9935',
    pageW / 2, pageH - 20, { align: 'center' }
  );

  doc.save(`Chase_Statement_${account.last4}_${period.replace(/\s/g, '_')}.pdf`);
}

function getStatementPeriods(): string[] {
  const periods: string[] = [];
  const now = new Date();
  for (let i = 0; i < 12; i++) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    periods.push(d.toLocaleDateString('en-US', { month: 'long', year: 'numeric' }));
  }
  return periods;
}

export default function StatementsPage({ onBack }: Props) {
  const { accounts, loading } = useAccounts();
  const [selectedAccountId, setSelectedAccountId] = useState<string | null>(null);
  const [downloading, setDownloading] = useState<string | null>(null);
  const [userId, setUserId] = useState<string | null>(null);

  useEffect(() => {
    getCurrentUser().then(u => setUserId(u?.id ?? null));
  }, []);

  useEffect(() => {
    if (accounts.length > 0 && !selectedAccountId) {
      setSelectedAccountId(accounts[0].id);
    }
  }, [accounts, selectedAccountId]);

  const periods = getStatementPeriods();

  async function handleDownload(period: string) {
    const acct = accounts.find(a => a.id === selectedAccountId);
    if (!acct || !userId) return;
    setDownloading(period);
    try {
      const [monthStr, yearStr] = period.split(' ');
      const months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
      const monthIdx = months.indexOf(monthStr);
      const year = parseInt(yearStr);
      const startDate = new Date(year, monthIdx, 1).toISOString();
      const endDate = new Date(year, monthIdx + 1, 0, 23, 59, 59).toISOString();

      const { data: txs } = await supabase
        .from('transactions')
        .select('*')
        .eq('account_id', selectedAccountId)
        .gte('date', startDate)
        .lte('date', endDate)
        .order('date', { ascending: true });

      generateStatementPDF(
        { account_name: acct.account_name, last4: acct.last4, balance: acct.balance },
        period,
        (txs || []) as { description: string; date: string; amount: number; type: string; running_balance?: number }[]
      );
    } catch (e) {
      console.error('Download error', e);
    } finally {
      setDownloading(null);
    }
  }

  return (
    <div style={{
      width: '100%', height: '100%', display: 'flex', flexDirection: 'column',
      background: '#f0f4f8', fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
    }}>
      {/* Header */}
      <div style={{
        background: navy, padding: '52px 16px 16px',
        display: 'flex', alignItems: 'center', gap: 12, flexShrink: 0,
      }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path d="M15 18l-6-6 6-6" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
        <span style={{ color: '#fff', fontSize: 17, fontWeight: 700 }}>Statements & Documents</span>
      </div>

      {/* Account selector */}
      <div style={{ background: '#fff', padding: '16px', borderBottom: '1px solid #eee', flexShrink: 0 }}>
        <div style={{ fontSize: 12, color: '#888', marginBottom: 6 }}>Select account</div>
        <select
          value={selectedAccountId ?? ''}
          onChange={e => setSelectedAccountId(e.target.value)}
          style={{
            width: '100%', padding: '10px 12px', borderRadius: 8,
            border: '1px solid #ddd', fontSize: 15, fontWeight: 600,
            color: blue, background: '#fff', cursor: 'pointer',
          }}
        >
          {accounts.map(a => (
            <option key={a.id} value={a.id}>
              {a.account_name} (...{a.last4})
            </option>
          ))}
        </select>
      </div>

      {/* Statements list */}
      <div style={{ flex: 1, overflowY: 'auto', paddingBottom: 80 }}>
        {loading ? (
          <div style={{ padding: 32, textAlign: 'center', color: '#888' }}>Loading...</div>
        ) : (
          <div style={{ margin: 16, background: '#fff', borderRadius: 12, overflow: 'hidden', boxShadow: '0 2px 8px rgba(0,0,0,0.08)' }}>
            <div style={{ padding: '14px 16px', borderBottom: '1px solid #eee', fontWeight: 700, fontSize: 15, color: '#111' }}>
              Monthly Statements
            </div>
            {periods.map((period, idx) => (
              <div key={period} style={{
                display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                padding: '14px 16px',
                borderBottom: idx < periods.length - 1 ? '1px solid #f0f0f0' : 'none',
              }}>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 15, color: '#111' }}>{period}</div>
                  <div style={{ fontSize: 12, color: '#888', marginTop: 2 }}>
                    {selectedAccountId
                      ? `${accounts.find(a => a.id === selectedAccountId)?.account_name ?? ''} (...${accounts.find(a => a.id === selectedAccountId)?.last4 ?? ''})`
                      : ''}
                  </div>
                </div>
                <button
                  onClick={() => handleDownload(period)}
                  disabled={downloading === period}
                  style={{
                    display: 'flex', alignItems: 'center', gap: 6,
                    background: downloading === period ? '#eee' : blue,
                    color: '#fff', border: 'none', borderRadius: 8,
                    padding: '8px 14px', fontSize: 13, fontWeight: 600,
                    cursor: downloading === period ? 'not-allowed' : 'pointer',
                    transition: 'background 0.2s',
                  }}
                >
                  {downloading === period ? (
                    <span>Generating...</span>
                  ) : (
                    <>
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                        <path d="M12 15l-4-4h3V3h2v8h3l-4 4z" fill="#fff" />
                        <path d="M5 18h14v2H5v-2z" fill="#fff" />
                      </svg>
                      PDF
                    </>
                  )}
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Info note */}
        <div style={{ margin: '0 16px 16px', padding: 16, background: '#fff', borderRadius: 12, boxShadow: '0 2px 8px rgba(0,0,0,0.06)' }}>
          <div style={{ fontSize: 13, color: '#888', lineHeight: 1.6 }}>
            Each statement is available as a downloadable PDF. Statements include your Chase octagon watermark, account summary, and full transaction history for the selected period.
          </div>
          <div style={{ fontSize: 12, color: '#aaa', marginTop: 8 }}>
            Need paper statements? Call 1-800-935-9935 or visit a Chase branch.
          </div>
        </div>
      </div>
    </div>
  );
}
