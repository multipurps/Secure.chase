const blue = '#2558b5';

interface ConnectTabProps {
  onAlertsHistory: () => void;
  onManageAlerts: () => void;
  onSecureMessages: () => void;
  onDigitalAssistant: () => void;
  onStatements: () => void;
}

function Card({ title, rows }: { title: string; rows: { label: string; onPress: () => void }[] }) {
  return (
    <div style={{
      background: '#fff',
      borderRadius: 12,
      margin: '0 16px 16px',
      overflow: 'hidden',
      boxShadow: '0 1px 4px rgba(0,0,0,0.07)',
    }}>
      <div style={{ padding: '16px 16px 8px', fontWeight: 700, fontSize: 16, color: '#111' }}>{title}</div>
      {rows.map((row, i) => (
        <button
          key={row.label}
          onClick={row.onPress}
          style={{
            width: '100%',
            background: 'none',
            border: 'none',
            borderTop: i === 0 ? '1px solid #f0f0f0' : '1px solid #f0f0f0',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            padding: '14px 16px',
            textAlign: 'left',
          }}
        >
          <span style={{ fontSize: 15, color: '#111' }}>{row.label}</span>
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
            <polyline points="5,3 11,8 5,13" stroke="#aaa" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
      ))}
    </div>
  );
}

export default function ConnectTab({ onAlertsHistory, onManageAlerts, onSecureMessages, onDigitalAssistant, onStatements }: ConnectTabProps) {
  return (
    <div style={{ paddingTop: 12 }}>
      <Card
        title="Alerts & messages"
        rows={[
          { label: 'Alerts history', onPress: onAlertsHistory },
          { label: 'Manage alerts', onPress: onManageAlerts },
          { label: 'Secure message center', onPress: onSecureMessages },
        ]}
      />
      <Card
        title="Help & Support"
        rows={[
          { label: 'Payment assistance', onPress: () => {} },
          { label: 'Chat with the Chase Digital Assistant™', onPress: onDigitalAssistant },
          { label: 'Schedule a meeting', onPress: () => {} },
          { label: 'Contact us', onPress: () => {} },
          { label: 'FAQs', onPress: () => {} },
        ]}
      />
      <Card
        title="Document manager"
        rows={[
          { label: 'Statements & documents', onPress: onStatements },
        ]}
      />

      {/* Feedback + Legal */}
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        padding: '0 16px 24px',
        marginTop: 8,
      }}>
        <button style={{ background: 'none', border: 'none', cursor: 'pointer', color: blue, fontSize: 14 }}>
          Give us feedback
        </button>
        <button style={{ background: 'none', border: 'none', cursor: 'pointer', color: blue, fontSize: 14 }}>
          Legal information
        </button>
      </div>
    </div>
  );
}
