import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import ConnectTab from './ConnectTab';
import SettingsTab from './SettingsTab';
import SecurityPrivacyCenter from './SecurityPrivacyCenter';
import FraudMonitoringAI from './FraudMonitoringAI';
import ChaseDigitalAssistant from './ChaseDigitalAssistant';
import AlertsHistory from './AlertsHistory';
import ManageAlerts from './ManageAlerts';
import SecureMessageCenter from './SecureMessageCenter';
import StatementsPage from './StatementsPage';

export type ProfileSubPage =
  | 'none'
  | 'security-privacy'
  | 'fraud-ai'
  | 'digital-assistant'
  | 'alerts-history'
  | 'manage-alerts'
  | 'secure-messages'
  | 'statements';

interface ProfileSettingsProps {
  onBack: () => void;
  onSignOut: () => void;
}

const blue = '#2558b5';

export default function ProfileSettings({ onBack, onSignOut }: ProfileSettingsProps) {
  const [activeTab, setActiveTab] = useState<'connect' | 'settings'>('connect');
  const [subPage, setSubPage] = useState<ProfileSubPage>('none');
  const [userProfile, setUserProfile] = useState<{
    firstName: string;
    lastName: string;
    email: string;
    username: string;
    phone: string;
    address: string;
    dob: string;
    photoUrl?: string;
  }>({
    firstName: 'Demo',
    lastName: 'User',
    email: 'demo@example.com',
    username: 'demouser01',
    phone: '',
    address: '',
    dob: '',
  });

  useEffect(() => {
    (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      const { data } = await supabase
        .from('users')
        .select('*')
        .eq('id', user.id)
        .single();
      if (data) {
        setUserProfile({
          firstName: data.first_name || 'Demo',
          lastName: data.last_name || 'User',
          email: data.email || user.email || '',
          username: data.username || 'demouser01',
          phone: data.phone || '',
          address: [data.street_address, data.city, data.state, data.zip].filter(Boolean).join(', '),
          dob: data.date_of_birth || '',
          photoUrl: data.photo_url || undefined,
        });
      }
    })();
  }, []);

  const initials = `${userProfile.firstName[0] || 'D'}${userProfile.lastName[0] || 'U'}`.toUpperCase();

  // Sub-page routing
  if (subPage === 'security-privacy') return <SecurityPrivacyCenter onBack={() => setSubPage('none')} onFraudAI={() => setSubPage('fraud-ai')} />;
  if (subPage === 'fraud-ai') return <FraudMonitoringAI onBack={() => setSubPage('none')} userFirstName={userProfile.firstName} />;
  if (subPage === 'digital-assistant') return <ChaseDigitalAssistant onBack={() => setSubPage('none')} userFirstName={userProfile.firstName} />;
  if (subPage === 'alerts-history') return <AlertsHistory onBack={() => setSubPage('none')} />;
  if (subPage === 'manage-alerts') return <ManageAlerts onBack={() => setSubPage('none')} />;
  if (subPage === 'secure-messages') return <SecureMessageCenter onBack={() => setSubPage('none')} />;
  if (subPage === 'statements') return <StatementsPage onBack={() => setSubPage('none')} />;

  return (
    <div style={{
      width: '100%',
      height: '100%',
      overflowY: 'auto',
      background: '#f0f4f8',
      fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
      paddingBottom: 80,
    }}>
      {/* Top bar */}
      <div style={{
        background: '#fff',
        padding: '14px 16px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        borderBottom: '1px solid #eee',
      }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
          <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
            <polyline points="14,3 7,11 14,19" stroke="#555" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
        <div style={{ width: 60 }} />
        <button
          onClick={onSignOut}
          style={{ background: 'none', border: 'none', cursor: 'pointer', color: blue, fontWeight: 600, fontSize: 15 }}
        >
          Sign out
        </button>
      </div>

      {/* Page title */}
      <div style={{ padding: '20px 16px 0', background: '#f0f4f8' }}>
        <div style={{ fontWeight: 700, fontSize: 26, color: '#111' }}>Profile &amp; Settings</div>
      </div>

      {/* User identity row */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        gap: 14,
        padding: '16px 16px 8px',
        background: '#f0f4f8',
      }}>
        {/* Avatar */}
        <div style={{
          width: 52, height: 52, borderRadius: '50%',
          background: userProfile.photoUrl ? 'transparent' : '#ccc',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          overflow: 'hidden', flexShrink: 0,
        }}>
          {userProfile.photoUrl ? (
            <img src={userProfile.photoUrl} alt="avatar" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          ) : (
            <span style={{ fontWeight: 700, fontSize: 20, color: '#555' }}>{initials}</span>
          )}
        </div>
        <div style={{ fontWeight: 700, fontSize: 18, color: '#111' }}>
          {userProfile.firstName} {userProfile.lastName}
        </div>
      </div>

      {/* Tab bar */}
      <div style={{
        display: 'flex',
        background: '#f0f4f8',
        padding: '0 16px',
        gap: 0,
        borderBottom: '2px solid #e0e0e0',
        marginBottom: 4,
      }}>
        {(['connect', 'settings'] as const).map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            style={{
              flex: 1,
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              padding: '12px 0',
              fontWeight: activeTab === tab ? 700 : 400,
              fontSize: 15,
              color: activeTab === tab ? blue : '#888',
              borderBottom: activeTab === tab ? `3px solid ${blue}` : '3px solid transparent',
              transition: 'all 0.2s',
              textTransform: 'capitalize',
              marginBottom: -2,
            }}
          >
            {tab.charAt(0).toUpperCase() + tab.slice(1)}
          </button>
        ))}
      </div>

      {/* Tab content */}
      {activeTab === 'connect' ? (
        <ConnectTab
          onAlertsHistory={() => setSubPage('alerts-history')}
          onManageAlerts={() => setSubPage('manage-alerts')}
          onSecureMessages={() => setSubPage('secure-messages')}
          onDigitalAssistant={() => setSubPage('digital-assistant')}
          onStatements={() => setSubPage('statements')}
        />
      ) : (
        <SettingsTab
          userProfile={userProfile}
          onSecurityPrivacy={() => setSubPage('security-privacy')}
          onProfilePhotoChange={(url: string) => setUserProfile(p => ({ ...p, photoUrl: url }))}
        />
      )}
    </div>
  );
}
