import { useState } from 'react';

interface Props {
  onClose: () => void;
  customNote?: string;
  customDetails?: string;
}

export default function TransferRestrictionModal({ onClose, customNote, customDetails }: Props) {
  const [copied, setCopied] = useState(false);

  function copyDetails() {
    if (!customDetails) return;
    navigator.clipboard.writeText(customDetails).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }

  return (
    <div
      style={{
        position: 'fixed', inset: 0, zIndex: 9000,
        background: 'rgba(0,0,0,0.45)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: 24,
      }}
    >
      <div
        style={{
          background: '#fff',
          borderRadius: 14,
          padding: '28px 24px 0',
          width: '100%',
          maxWidth: 360,
          boxShadow: '0 8px 40px rgba(0,0,0,0.18)',
          textAlign: 'center',
        }}
      >
        {/* Title */}
        <div style={{ fontWeight: 700, fontSize: 17, color: '#1c1c1e', lineHeight: 1.4, marginBottom: 12 }}>
          We locked your transfer due to unusual activity.
        </div>

        {/* Subtitle */}
        <div style={{ fontSize: 14, color: '#6b6b6b', lineHeight: 1.6, marginBottom: 12 }}>
          Call us to unlock it. If you're a commercial client, reach out to your servicing team.
        </div>

        {/* Body */}
        <div style={{ fontSize: 13, color: '#6b6b6b', lineHeight: 1.6, marginBottom: customNote || customDetails ? 16 : 0 }}>
          Please note that you will not be able to complete transfers or access related transfer information online or on the mobile app until we unlock it.
        </div>

        {/* Custom note */}
        {customNote && (
          <div style={{ background: '#f5f5f7', borderRadius: 10, padding: '12px 14px', marginBottom: 12, fontSize: 13, color: '#3a3a3c', lineHeight: 1.6, textAlign: 'left' }}>
            {customNote}
          </div>
        )}

        {/* Details + Copy */}
        {customDetails && (
          <div style={{ background: '#f5f5f7', borderRadius: 10, padding: '12px 14px', marginBottom: 12, textAlign: 'left' }}>
            <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Details</div>
            <div style={{ fontSize: 13, color: '#1c1c1e', lineHeight: 1.5, marginBottom: 8 }}>{customDetails}</div>
            <button
              onClick={copyDetails}
              style={{ background: 'none', border: 'none', color: '#007aff', fontSize: 14, fontWeight: 500, cursor: 'pointer', padding: 0, fontFamily: 'inherit' }}
            >
              {copied ? 'Copied!' : 'Copy'}
            </button>
          </div>
        )}

        {/* Divider */}
        <div style={{ height: 1, background: '#e5e5ea', margin: '0 -24px' }} />

        {/* Close button */}
        <button
          onClick={onClose}
          style={{
            display: 'block', width: '100%',
            background: 'none', border: 'none',
            color: '#007aff', fontSize: 17, fontWeight: 500,
            padding: '16px 0',
            cursor: 'pointer', fontFamily: 'inherit',
            letterSpacing: -0.2,
          }}
        >
          Close
        </button>
      </div>
    </div>
  );
}
