/**
 * Pure CSS/SVG Chase credit card thumbnails — no external images.
 * variant: 'sapphire-preferred' | 'freedom-flex'
 */

interface Props {
  variant?: 'sapphire-preferred' | 'freedom-flex' | 'amazon-prime';
  width?: number;
  height?: number;
}

export default function ChaseCreditCardThumbnail({ variant = 'sapphire-preferred', width = 80, height = 52 }: Props) {
  const r = 4 * (width / 80); // scale radius

  if (variant === 'freedom-flex') {
    return (
      <svg width={width} height={height} viewBox="0 0 80 52" style={{ borderRadius: r, display: 'block', flexShrink: 0 }}>
        <defs>
          <linearGradient id="ff-bg" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#1a6bbf" />
            <stop offset="100%" stopColor="#0d4fa0" />
          </linearGradient>
          <linearGradient id="ff-gloss" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="rgba(255,255,255,0.18)" />
            <stop offset="100%" stopColor="rgba(255,255,255,0)" />
          </linearGradient>
        </defs>
        {/* Background */}
        <rect width="80" height="52" rx={r} fill="url(#ff-bg)" />
        {/* Diagonal gloss */}
        <polygon points="0,0 80,0 80,20" fill="url(#ff-gloss)" />
        {/* Chase octagon simplified top-left */}
        <rect x="6" y="6" width="9" height="9" rx="2" fill="rgba(255,255,255,0.2)" />
        <rect x="7.5" y="7.5" width="6" height="6" rx="1" fill="rgba(255,255,255,0.5)" />
        {/* "freedom" wordmark */}
        <text x="18" y="13" fontSize="5.5" fontWeight="700" fill="white" fontFamily="Helvetica, Arial, sans-serif">freedom</text>
        <text x="18" y="20" fontSize="4" fontWeight="400" fill="rgba(255,255,255,0.8)" fontFamily="Helvetica, Arial, sans-serif">FLEX</text>
        {/* EMV chip */}
        <rect x="6" y="24" width="12" height="9" rx="1.5" fill="#c8a020" />
        <line x1="6" y1="27.5" x2="18" y2="27.5" stroke="#a07010" strokeWidth="0.7" />
        <line x1="12" y1="24" x2="12" y2="33" stroke="#a07010" strokeWidth="0.7" />
        {/* Mastercard circles */}
        <circle cx="60" cy="40" r="8" fill="#EB001B" />
        <circle cx="70" cy="40" r="8" fill="#F79E1B" />
        {/* Overlap blend */}
        <circle cx="65" cy="40" r="3" fill="#FF5F00" opacity="0.85" />
      </svg>
    );
  }

  if (variant === 'amazon-prime') {
    return (
      <svg width={width} height={height} viewBox="0 0 80 52" style={{ borderRadius: r, display: 'block', flexShrink: 0 }}>
        <defs>
          <linearGradient id="ap-bg" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#0d1f3c" />
            <stop offset="100%" stopColor="#1a2f4a" />
          </linearGradient>
        </defs>
        <rect width="80" height="52" rx={r} fill="url(#ap-bg)" />
        {/* gloss */}
        <polygon points="40,0 80,0 80,28" fill="rgba(255,255,255,0.06)" />
        {/* "prime" text */}
        <text x="6" y="14" fontSize="6.5" fontWeight="700" fill="#00A8E0" fontFamily="Helvetica, Arial, sans-serif">prime</text>
        {/* EMV chip */}
        <rect x="6" y="20" width="12" height="9" rx="1.5" fill="#c8a020" />
        <line x1="6" y1="23.5" x2="18" y2="23.5" stroke="#a07010" strokeWidth="0.7" />
        <line x1="12" y1="20" x2="12" y2="29" stroke="#a07010" strokeWidth="0.7" />
        {/* VISA wordmark */}
        <text x="55" y="44" fontSize="8" fontWeight="900" fill="white" fontFamily="Helvetica, Arial, sans-serif" fontStyle="italic">VISA</text>
        <text x="55" y="50" fontSize="4" fill="rgba(255,255,255,0.6)" fontFamily="Helvetica, Arial, sans-serif">Signature</text>
      </svg>
    );
  }

  // Default: Chase Sapphire Preferred
  return (
    <svg width={width} height={height} viewBox="0 0 80 52" style={{ borderRadius: r, display: 'block', flexShrink: 0 }}>
      <defs>
        <linearGradient id="sp-bg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#0a1628" />
          <stop offset="100%" stopColor="#050d1a" />
        </linearGradient>
        {/* Beam gradient */}
        <linearGradient id="beam1" x1="0" y1="1" x2="1" y2="0">
          <stop offset="0%" stopColor="rgba(160,210,255,0)" />
          <stop offset="50%" stopColor="rgba(160,210,255,0.35)" />
          <stop offset="100%" stopColor="rgba(160,210,255,0)" />
        </linearGradient>
        <linearGradient id="beam2" x1="0" y1="1" x2="1" y2="0">
          <stop offset="0%" stopColor="rgba(200,230,255,0)" />
          <stop offset="50%" stopColor="rgba(200,230,255,0.22)" />
          <stop offset="100%" stopColor="rgba(200,230,255,0)" />
        </linearGradient>
      </defs>
      {/* Background */}
      <rect width="80" height="52" rx={r} fill="url(#sp-bg)" />
      {/* Beam lines */}
      <line x1="10" y1="52" x2="70" y2="0" stroke="url(#beam1)" strokeWidth="6" />
      <line x1="20" y1="52" x2="80" y2="0" stroke="url(#beam2)" strokeWidth="3.5" />
      {/* Chase octagon top-left */}
      <rect x="6" y="5" width="9" height="9" rx="2" fill="rgba(255,255,255,0.15)" />
      <rect x="7.5" y="6.5" width="6" height="6" rx="1" fill="rgba(255,255,255,0.45)" />
      {/* SAPPHIRE wordmark */}
      <text x="18" y="12" fontSize="5" fontWeight="700" fill="white" letterSpacing="0.5" fontFamily="Helvetica, Arial, sans-serif">SAPPHIRE</text>
      <text x="18" y="18.5" fontSize="3.8" fontWeight="400" fill="rgba(255,255,255,0.7)" letterSpacing="0.5" fontFamily="Helvetica, Arial, sans-serif">PREFERRED</text>
      {/* EMV chip */}
      <rect x="6" y="24" width="12" height="9" rx="1.5" fill="#a8922a" />
      <line x1="6" y1="27.5" x2="18" y2="27.5" stroke="#8a7318" strokeWidth="0.7" />
      <line x1="12" y1="24" x2="12" y2="33" stroke="#8a7318" strokeWidth="0.7" />
      {/* Contactless symbol */}
      <path d="M22 27 Q25 24 22 21" stroke="rgba(255,255,255,0.5)" strokeWidth="1.2" fill="none" strokeLinecap="round" />
      <path d="M24 28 Q28 24 24 20" stroke="rgba(255,255,255,0.4)" strokeWidth="1.2" fill="none" strokeLinecap="round" />
      {/* Cardholder name */}
      <text x="6" y="43" fontSize="4" fill="rgba(255,255,255,0.7)" fontFamily="Helvetica, Arial, sans-serif" letterSpacing="0.3">D. BARRETT</text>
      {/* VISA wordmark */}
      <text x="58" y="47" fontSize="8" fontWeight="900" fill="white" fontFamily="Helvetica, Arial, sans-serif" fontStyle="italic">VISA</text>
      <text x="58" y="51.5" fontSize="3" fill="rgba(255,255,255,0.55)" fontFamily="Helvetica, Arial, sans-serif">Signature</text>
    </svg>
  );
}
