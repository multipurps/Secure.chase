import { useState } from 'react';

const blue = '#2558b5';
const navy = '#1a3a6b';

interface Transaction {
  id: string;
  description: string;
  dateGroup: string;
  amount: string;
  type: 'debit' | 'credit';
  status: 'Posted' | 'Pending';
  isDeposit?: boolean;
  txNum?: string;
}

const PENDING_TXS: Transaction[] = [
  {
    id: 'p1',
    description: 'ONLINE TRANSFER FROM CHK ...8626\nTRANSACTION#: 23564930030',
    dateGroup: 'Pending',
    amount: '$13,000.00',
    type: 'credit', status: 'Pending',
    txNum: '23564930030',
  },
];

const POSTED_TXS: Transaction[] = [
  {
    id: 't1',
    description: 'FEDWIRE CREDIT VIA: WELLS FARGO BANK, N.A./121000248 B/O: WFG NATIONAL TITLE INSURANC...',
    dateGroup: 'Jan 30, 2025',
    amount: '$62,000.00', type: 'credit', status: 'Posted',
  },
  {
    id: 't2',
    description: 'REMOTE ONLINE DEPOSIT # 1',
    dateGroup: 'Jan 30, 2025',
    amount: '$5,502.50', type: 'credit', status: 'Posted', isDeposit: true,
  },
  {
    id: 't3',
    description: 'CHIPS CREDIT VIA: BANK OF AMERICA, N.A./0959 B/O: ALLIED TITLE AND ESCROW SERVICES TR95630-...',
    dateGroup: 'Jan 23, 2025',
    amount: '$23,500.00', type: 'credit', status: 'Posted',
  },
  {
    id: 't4',
    description: 'FEDWIRE CREDIT VIA: SYNOVUS BANK/061100606 B/O: CHARLES W EDMONDSON PC MONTGOMER...',
    dateGroup: 'Jan 6, 2025',
    amount: '$10,230.00', type: 'credit', status: 'Posted',
  },
  {
    id: 't5',
    description: 'FEDWIRE CREDIT VIA: SCBT, NATIONAL ASSOCIATION/053200983 B/O: INDEPENDENCE TI...',
    dateGroup: 'Dec 31, 2024',
    amount: '$10,377.50', type: 'credit', status: 'Posted',
  },
  {
    id: 't6',
    description: 'ZELLE PAYMENT TO AMBER DAVIS',
    dateGroup: 'Dec 28, 2024',
    amount: '$250.00', type: 'debit', status: 'Posted',
  },
  {
    id: 't7',
    description: 'VIRGINIA TECH REG SALARY PPD ID: 6546001805',
    dateGroup: 'Dec 15, 2024',
    amount: '$4,581.23', type: 'credit', status: 'Posted',
  },
  {
    id: 't8',
    description: 'AMAZON.COM AMZN MKTP US DEBIT',
    dateGroup: 'Dec 12, 2024',
    amount: '$99.80', type: 'debit', status: 'Posted',
  },
  {
    id: 't9',
    description: 'ROBINHOOD FUNDS 111471264 WEB ID: 1464364776',
    dateGroup: 'Dec 6, 2024',
    amount: '$50.00', type: 'debit', status: 'Posted',
  },
  {
    id: 't10',
    description: 'FEDWIRE CREDIT VIA: JPMORGAN CHASE BANK/021000021 B/O: BUSINESS PAYROLL DIRECT DEP...',
    dateGroup: 'Nov 30, 2024',
    amount: '$8,250.00', type: 'credit', status: 'Posted',
  },
  {
    id: 't11',
    description: 'CHIPS CREDIT VIA: CITIBANK N.A./0008 B/O: MERIDIAN TITLE CORP 500 E 96TH ST SUITE...',
    dateGroup: 'Nov 22, 2024',
    amount: '$31,500.00', type: 'credit', status: 'Posted',
  },
  {
    id: 't12',
    description: 'ONLINE TRANSFER TO SAV ...7231 ON 11/15',
    dateGroup: 'Nov 15, 2024',
    amount: '$5,000.00', type: 'debit', status: 'Posted',
  },
  {
    id: 't13',
    description: 'REMOTE ONLINE DEPOSIT # 2',
    dateGroup: 'Nov 10, 2024',
    amount: '$3,200.00', type: 'credit', status: 'Posted', isDeposit: true,
  },
  {
    id: 't14',
    description: 'BILL PAYMENT AMERICAN EXPRESS ENDING IN 4521',
    dateGroup: 'Nov 5, 2024',
    amount: '$1,240.00', type: 'debit', status: 'Posted',
  },
  {
    id: 't15',
    description: 'FEDWIRE CREDIT VIA: US BANK N.A./091000022 B/O: NATIONAL INVESTORS TITLE INSURANCE...',
    dateGroup: 'Oct 31, 2024',
    amount: '$18,900.00', type: 'credit', status: 'Posted',
  },
  {
    id: 't16',
    description: 'ATM WITHDRAWAL CHASE 00005672 BROADWAY ST NEW YORK NY',
    dateGroup: 'Oct 25, 2024',
    amount: '$300.00', type: 'debit', status: 'Posted',
  },
  {
    id: 't17',
    description: 'VIRGINIA TECH REG SALARY PPD ID: 6546001805',
    dateGroup: 'Oct 15, 2024',
    amount: '$4,581.23', type: 'credit', status: 'Posted',
  },
  {
    id: 't18',
    description: 'ZELLE PAYMENT FROM TRAVIS TAYLOR',
    dateGroup: 'Oct 8, 2024',
    amount: '$500.00', type: 'credit', status: 'Posted',
  },
  {
    id: 't19',
    description: 'WIRE TRANSFER FEE — OUTGOING DOMESTIC WIRE',
    dateGroup: 'Oct 3, 2024',
    amount: '$25.00', type: 'debit', status: 'Posted',
  },
  {
    id: 't20',
    description: 'DOMESTIC WIRE TRANSFER TO ARIANNA SMITH (...5423)',
    dateGroup: 'Oct 3, 2024',
    amount: '$5,000.00', type: 'debit', status: 'Posted',
  },
];

function groupByDate(txs: Transaction[]) {
  const groups: Record<string, Transaction[]> = {};
  txs.forEach(tx => {
    if (!groups[tx.dateGroup]) groups[tx.dateGroup] = [];
    groups[tx.dateGroup].push(tx);
  });
  return groups;
}

export default function FullTransactionHistory({ onBack }: { onBack: () => void }) {
  const [search, setSearch] = useState('');
  const [showFilter, setShowFilter] = useState(false);
  const [displayCount, setDisplayCount] = useState(20);

  const filtered = POSTED_TXS.filter(tx =>
    !search || tx.description.toLowerCase().includes(search.toLowerCase())
  ).slice(0, displayCount);

  const groups = groupByDate(filtered);
  const dateKeys = Object.keys(groups);

  return (
    <div style={{
      width: '100%', minHeight: '100dvh', background: '#fff', overflowY: 'auto',
      paddingBottom: 80, fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", display: 'flex', flexDirection: 'column',
    }}>
      {/* HEADER */}
      <div style={{ background: navy, padding: '52px 16px 14px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 10 }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
          <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
            <polyline points="14,3 7,11 14,19" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
        <span style={{ color: '#fff', fontWeight: 700, fontSize: 17 }}>Transaction History</span>
        <button onClick={() => setShowFilter(!showFilter)} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
            <line x1="4" y1="7" x2="20" y2="7" stroke="#fff" strokeWidth="2" strokeLinecap="round" />
            <line x1="7" y1="12" x2="17" y2="12" stroke="#fff" strokeWidth="2" strokeLinecap="round" />
            <line x1="10" y1="17" x2="14" y2="17" stroke="#fff" strokeWidth="2" strokeLinecap="round" />
          </svg>
        </button>
      </div>

      {/* SEARCH */}
      <div style={{ padding: '12px 16px', background: '#fff', borderBottom: '1px solid #f0f0f0' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, background: '#f8f9fa', borderRadius: 8, padding: '10px 14px', border: '1px solid #e0e0e0' }}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
            <circle cx="11" cy="11" r="7" stroke="#aaa" strokeWidth="2" />
            <line x1="17" y1="17" x2="21" y2="21" stroke="#aaa" strokeWidth="2" strokeLinecap="round" />
          </svg>
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search transactions"
            style={{ flex: 1, border: 'none', background: 'none', outline: 'none', fontSize: 14, color: '#333' }}
          />
        </div>
      </div>

      {/* PENDING */}
      {PENDING_TXS.length > 0 && (
        <>
          <div style={{ background: '#f0f0f0', padding: '8px 16px' }}>
            <span style={{ fontSize: 12, color: '#888', letterSpacing: 1, fontWeight: 600 }}>PENDING ({PENDING_TXS.length})</span>
          </div>
          {PENDING_TXS.map((tx, i) => (
            <div key={tx.id}>
              <div style={{ padding: '14px 16px', background: '#fff', display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12 }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 700, fontSize: 14, color: '#111', lineHeight: 1.4, whiteSpace: 'pre-line' }}>
                    {tx.txNum ? (
                      <>
                        ONLINE TRANSFER FROM CHK ...8626{'\n'}
                        TRANSACTION#: <span style={{ color: blue, textDecoration: 'underline' }}>{tx.txNum}</span>
                      </>
                    ) : tx.description}
                  </div>
                  <div style={{ color: '#aaa', fontSize: 13, marginTop: 4 }}>--</div>
                </div>
                <span style={{ color: blue, fontWeight: 600, fontSize: 15, flexShrink: 0 }}>${tx.amount}</span>
              </div>
              {i < PENDING_TXS.length - 1 && <div style={{ height: 1, background: '#f5f5f5', margin: '0 16px' }} />}
            </div>
          ))}
        </>
      )}

      {/* POSTED GROUPS */}
      {dateKeys.map(date => (
        <div key={date}>
          <div style={{ background: '#f5f5f5', padding: '6px 16px' }}>
            <span style={{ fontSize: 13, color: '#888' }}>{date}</span>
          </div>
          {groups[date].map((tx, i) => (
            <div key={tx.id}>
              <div style={{ padding: '14px 16px', background: '#fff', display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12, cursor: 'pointer' }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 700, fontSize: 14, color: '#111', lineHeight: 1.45 }}>{tx.description}</div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexShrink: 0 }}>
                  {tx.isDeposit && (
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                      <rect x="2" y="4" width="20" height="15" rx="2" stroke="#aaa" strokeWidth="1.8" />
                      <line x1="2" y1="9" x2="22" y2="9" stroke="#aaa" strokeWidth="1.5" />
                      <line x1="12" y1="13" x2="12" y2="17" stroke="#aaa" strokeWidth="1.5" strokeLinecap="round" />
                      <polyline points="9,15 12,18 15,15" stroke="#aaa" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  )}
                  <span style={{
                    color: tx.type === 'credit' ? blue : '#d32f2f',
                    fontWeight: 600, fontSize: 15,
                  }}>
                    {tx.type === 'credit' ? '+' : '-'}${tx.amount}
                  </span>
                </div>
              </div>
              {i < groups[date].length - 1 && <div style={{ height: 1, background: '#f5f5f5', margin: '0 16px' }} />}
            </div>
          ))}
        </div>
      ))}

      {/* LOAD MORE */}
      {displayCount < POSTED_TXS.length && (
        <div style={{ padding: '20px 16px', textAlign: 'center' }}>
          <button onClick={() => setDisplayCount(d => d + 20)} style={{
            background: '#fff', border: `1.5px solid ${blue}`, borderRadius: 999,
            padding: '12px 32px', color: blue, fontWeight: 600, fontSize: 14, cursor: 'pointer',
          }}>
            Load more transactions
          </button>
        </div>
      )}

      {/* FILTER OVERLAY */}
      {showFilter && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.45)', zIndex: 500, display: 'flex', alignItems: 'flex-end' }} onClick={() => setShowFilter(false)}>
          <div style={{ background: '#fff', width: '100%', borderRadius: '16px 16px 0 0', padding: '20px 0 40px' }} onClick={e => e.stopPropagation()}>
            <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 16 }}>
              <div style={{ width: 40, height: 4, background: '#ccc', borderRadius: 2 }} />
            </div>
            <div style={{ fontWeight: 700, fontSize: 17, textAlign: 'center', marginBottom: 16, color: '#111', padding: '0 20px' }}>Filter Transactions</div>
            {['Date range', 'Amount range', 'Transaction type', 'Account'].map(opt => (
              <button key={opt} style={{ width: '100%', padding: '14px 20px', background: 'none', border: 'none', borderBottom: '1px solid #f0f0f0', textAlign: 'left', fontSize: 15, color: '#111', cursor: 'pointer', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                {opt}
                <svg width="9" height="16" viewBox="0 0 9 16" fill="none">
                  <polyline points="1,1 8,8 1,15" stroke="#bbb" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
