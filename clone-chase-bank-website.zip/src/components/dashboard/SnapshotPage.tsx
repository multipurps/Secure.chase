import { useState, useEffect, useRef } from 'react';

const blue = '#2558b5';

interface Props {
  onBack: () => void;
}

type Period = 'Daily' | 'Weekly' | 'Monthly';

function getDayLabel(offset: number) {
  const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const d = new Date();
  d.setDate(d.getDate() - offset);
  return days[d.getDay()];
}

function getMonthLabel(offset: number) {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const d = new Date();
  d.setMonth(d.getMonth() - offset);
  return months[d.getMonth()];
}

function getWeekLabel(offset: number) {
  return `Wk ${4 - offset}`;
}

const DATA: Record<Period, { label: string; value: number }[]> = {
  Daily: [
    { label: getDayLabel(4), value: 42 },
    { label: getDayLabel(3), value: 87 },
    { label: getDayLabel(2), value: 156 },
    { label: getDayLabel(1), value: 63 },
    { label: 'Today', value: 99 },
  ],
  Weekly: [
    { label: getWeekLabel(3), value: 320 },
    { label: getWeekLabel(2), value: 480 },
    { label: getWeekLabel(1), value: 295 },
    { label: 'This wk', value: 99 },
  ],
  Monthly: [
    { label: getMonthLabel(5), value: 1200 },
    { label: getMonthLabel(4), value: 980 },
    { label: getMonthLabel(3), value: 1450 },
    { label: getMonthLabel(2), value: 870 },
    { label: getMonthLabel(1), value: 1100 },
    { label: 'This mo', value: 99 },
  ],
};

function BarChart({ data, animated }: { data: { label: string; value: number }[]; animated: boolean }) {
  const [heights, setHeights] = useState<number[]>(data.map(() => 0));
  const max = Math.max(...data.map(d => d.value));

  useEffect(() => {
    if (animated) {
      setHeights(data.map(() => 0));
      const timers = data.map((d, i) =>
        setTimeout(() => {
          setHeights(prev => {
            const next = [...prev];
            next[i] = (d.value / max) * 140;
            return next;
          });
        }, i * 80)
      );
      return () => timers.forEach(clearTimeout);
    } else {
      setHeights(data.map(d => (d.value / max) * 140));
    }
  }, [animated, data]);

  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-around', height: 160, padding: '0 8px', gap: 8 }}>
      {data.map((d, i) => (
        <div key={i} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flex: 1, gap: 4 }}>
          <span style={{ fontSize: 10, color: blue, fontWeight: 600 }}>${d.value}</span>
          <div style={{
            width: '100%', maxWidth: 40,
            height: heights[i],
            background: i === data.length - 1 ? '#1a3a6b' : blue,
            borderRadius: '4px 4px 0 0',
            transition: 'height 0.6s ease',
            minHeight: 4,
          }} />
          <span style={{ fontSize: 11, color: '#555', fontWeight: i === data.length - 1 ? 700 : 400 }}>{d.label}</span>
        </div>
      ))}
    </div>
  );
}

export default function SnapshotPage({ onBack }: Props) {
  const [period, setPeriod] = useState<Period>('Daily');
  const [animated, setAnimated] = useState(true);
  const prevPeriod = useRef<Period>('Daily');

  function switchPeriod(p: Period) {
    if (p === period) return;
    prevPeriod.current = period;
    setPeriod(p);
    setAnimated(false);
    setTimeout(() => setAnimated(true), 50);
  }

  const data = DATA[period];
  const todayTotal = 99.80;
  const dailyAvg = 89.40;

  return (
    <div style={{
      width: '100%', minHeight: '100dvh', background: '#fff', overflowY: 'auto',
      paddingBottom: 80, fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
      display: 'flex', flexDirection: 'column',
    }}>
      {/* HEADER */}
      <div style={{ background: blue, padding: '52px 16px 16px', display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
        <button onClick={onBack} style={{ position: 'absolute', left: 16, top: 52, background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
          <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
            <polyline points="14,3 7,11 14,19" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
        <span style={{ color: '#fff', fontWeight: 700, fontSize: 17 }}>Snapshot™</span>
      </div>

      <div style={{ padding: '24px 16px 0', flex: 1 }}>
        {/* MAIN CARD */}
        <div style={{ background: '#fff', borderRadius: 12, padding: 20, boxShadow: '0 2px 12px rgba(0,0,0,0.08)', marginBottom: 16 }}>
          <div style={{ textAlign: 'center', fontWeight: 700, fontSize: 18, color: '#111', marginBottom: 4 }}>
            Credit &amp; debit card usage
          </div>
          <div style={{ textAlign: 'center', fontWeight: 700, fontSize: 40, color: '#111', marginBottom: 20 }}>
            ${todayTotal.toFixed(2)}
          </div>

          {/* PERIOD TABS */}
          <div style={{ display: 'flex', background: '#f2f4f7', borderRadius: 999, padding: 3, marginBottom: 20 }}>
            {(['Daily', 'Weekly', 'Monthly'] as Period[]).map(p => (
              <button key={p} onClick={() => switchPeriod(p)} style={{
                flex: 1, padding: '8px 0', borderRadius: 999, border: 'none',
                background: period === p ? blue : 'transparent',
                color: period === p ? '#fff' : '#888',
                fontWeight: period === p ? 700 : 400,
                fontSize: 14, cursor: 'pointer',
                transition: 'all 0.2s',
              }}>{p}</button>
            ))}
          </div>

          {/* BAR CHART */}
          <BarChart data={data} animated={animated} />

          {/* STATS */}
          <div style={{ marginTop: 16, paddingTop: 16, borderTop: '1px solid #f0f0f0' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
              <span style={{ color: '#888', fontSize: 14 }}>Daily average</span>
              <span style={{ fontWeight: 700, color: '#111', fontSize: 14 }}>${dailyAvg.toFixed(2)}</span>
            </div>
            <div style={{ borderTop: '1px solid #f0f0f0', paddingTop: 12 }}>
              <div style={{ fontWeight: 700, fontSize: 14, color: '#111', marginBottom: 8 }}>Today's top transaction</div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ color: '#666', fontSize: 14 }}>Amazon.com</span>
                <span style={{ fontWeight: 700, color: '#111', fontSize: 14 }}>$99.80</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
