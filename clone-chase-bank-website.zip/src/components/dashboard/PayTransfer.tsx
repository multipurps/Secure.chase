import { useState } from 'react';
import ZelleFlow from './zelle/ZelleFlow';
import SettingsSheet from './paytransfer/SettingsSheet';
import TransferSheet from './paytransfer/TransferSheet';
import ScheduleTransfer from './paytransfer/ScheduleTransfer';
import QuickDepositSelector from './paytransfer/QuickDepositSelector';
import CheckDepositForm from './paytransfer/CheckDepositForm';
// PayBillsPage is replaced by PayBillsFlow (dynamic import)
import WiresFlow from './paytransfer/wires/WiresFlow';
import SeeActivity from './paytransfer/SeeActivity';
import ManageRecipients from './paytransfer/ManageRecipients';
import PayBillsFlow from './investments/PayBillsFlow';

interface PayTransferProps {
  onNavigate?: (page: string) => void;
  onZelle?: () => void;
  onDeposit?: () => void;
  onPayBills?: () => void;
}

const blue = '#2558b5';
const purple = '#6d1ed4';

type SubPage =
  | null
  | 'zelle-send'
  | 'zelle-request'
  | 'schedule-transfer'
  | 'deposit-selector'
  | 'deposit-form'
  | 'pay-bills'
  | 'wires'
  | 'activity'
  | 'recipients';

function ChevronRight() {
  return (
    <svg width="9" height="16" viewBox="0 0 9 16" fill="none">
      <polyline points="1,1 8,8 1,15" stroke="#bbb" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

const GRID_ITEMS = [
  {
    id: 'pay-bills',
    icon: (
      <svg width="34" height="34" viewBox="0 0 34 34" fill="none">
        <rect x="4" y="4" width="20" height="24" rx="2.5" stroke={blue} strokeWidth="1.8" fill="none" />
        <line x1="8" y1="11" x2="20" y2="11" stroke={blue} strokeWidth="1.5" strokeLinecap="round" />
        <line x1="8" y1="15" x2="20" y2="15" stroke={blue} strokeWidth="1.5" strokeLinecap="round" />
        <line x1="8" y1="19" x2="14" y2="19" stroke={blue} strokeWidth="1.5" strokeLinecap="round" />
        <circle cx="26" cy="26" r="7" fill={blue} />
        <text x="26" y="30" textAnchor="middle" fontSize="10" fontWeight="800" fill="#fff" fontFamily="Helvetica Neue, Arial, sans-serif">$</text>
      </svg>
    ),
    label: 'Pay bills',
    zelleLabel: false,
    subPage: 'pay-bills' as SubPage,
  },
  {
    id: 'zelle-send',
    icon: (
      <svg width="34" height="34" viewBox="0 0 34 34" fill="none">
        <circle cx="17" cy="17" r="12" stroke={blue} strokeWidth="1.8" fill="none" />
        <text x="17" y="23" textAnchor="middle" fontSize="14" fontWeight="800" fill={blue} fontFamily="Helvetica Neue, Arial, sans-serif">$</text>
        <path d="M9 9 Q17 3 25 9" stroke={blue} strokeWidth="1.6" fill="none" strokeLinecap="round" />
        <path d="M25 25 Q17 31 9 25" stroke={blue} strokeWidth="1.6" fill="none" strokeLinecap="round" />
        <polyline points="22,5.5 25,9 21.5,9.5" fill={blue} stroke="none" />
        <polyline points="12,28.5 9,25 12.5,24.5" fill={blue} stroke="none" />
      </svg>
    ),
    label: 'Send money with',
    zelleLabel: true,
    subPage: 'zelle-send' as SubPage,
  },
  {
    id: 'wires',
    icon: (
      <svg width="34" height="34" viewBox="0 0 34 34" fill="none">
        <rect x="3" y="18" width="28" height="12" rx="1.5" stroke={blue} strokeWidth="1.7" fill="none" />
        <rect x="7" y="20" width="3.5" height="8" rx="0.5" fill={blue} />
        <rect x="13" y="20" width="3.5" height="8" rx="0.5" fill={blue} />
        <rect x="19" y="20" width="3.5" height="8" rx="0.5" fill={blue} />
        <rect x="25" y="20" width="3.5" height="8" rx="0.5" fill={blue} />
        <line x1="2" y1="18" x2="32" y2="18" stroke={blue} strokeWidth="2" strokeLinecap="round" />
        <path d="M8 18 L8 12 L26 12 L26 18" stroke={blue} strokeWidth="1.7" fill="none" />
        <line x1="14" y1="12" x2="14" y2="18" stroke={blue} strokeWidth="1.4" />
        <line x1="20" y1="12" x2="20" y2="18" stroke={blue} strokeWidth="1.4" />
        <path d="M11 12 L17 6 L23 12" stroke={blue} strokeWidth="1.7" fill="none" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    ),
    label: 'Wires & global transfers',
    zelleLabel: false,
    subPage: 'wires' as SubPage,
  },
  {
    id: 'transfer',
    icon: (
      <svg width="34" height="34" viewBox="0 0 34 34" fill="none">
        <path d="M6 12 L28 12" stroke={blue} strokeWidth="2" strokeLinecap="round" />
        <path d="M20 5 L28 12 L20 19" stroke={blue} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" fill="none" />
        <path d="M28 22 L6 22" stroke={blue} strokeWidth="2" strokeLinecap="round" />
        <path d="M14 15 L6 22 L14 29" stroke={blue} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" fill="none" />
      </svg>
    ),
    label: 'Transfer',
    zelleLabel: false,
    subPage: null, // opens TransferSheet
    isTransfer: true,
  },
  {
    id: 'zelle-request',
    icon: (
      <svg width="34" height="34" viewBox="0 0 34 34" fill="none">
        <rect x="4" y="4" width="18" height="22" rx="2" stroke={blue} strokeWidth="1.7" fill="none" />
        <line x1="8" y1="11" x2="19" y2="11" stroke={blue} strokeWidth="1.4" strokeLinecap="round" />
        <line x1="8" y1="15" x2="19" y2="15" stroke={blue} strokeWidth="1.4" strokeLinecap="round" />
        <line x1="8" y1="19" x2="14" y2="19" stroke={blue} strokeWidth="1.4" strokeLinecap="round" />
        <circle cx="26" cy="26" r="7" fill={blue} />
        <text x="26" y="30" textAnchor="middle" fontSize="10" fontWeight="800" fill="#fff" fontFamily="Helvetica Neue, Arial, sans-serif">$</text>
      </svg>
    ),
    label: 'Request/Split with',
    zelleLabel: true,
    subPage: 'zelle-request' as SubPage,
  },
  {
    id: 'deposit',
    icon: (
      <svg width="34" height="34" viewBox="0 0 34 34" fill="none">
        <rect x="3" y="8" width="28" height="18" rx="2.5" stroke={blue} strokeWidth="1.7" fill="none" />
        <line x1="8" y1="15" x2="16" y2="15" stroke={blue} strokeWidth="1.5" strokeLinecap="round" />
        <line x1="8" y1="19" x2="13" y2="19" stroke={blue} strokeWidth="1.5" strokeLinecap="round" />
        <circle cx="24" cy="17" r="6" fill="none" stroke={blue} strokeWidth="1.6" />
        <line x1="24" y1="14" x2="24" y2="20" stroke={blue} strokeWidth="1.5" strokeLinecap="round" />
        <polyline points="21,22 24,25 27,22" stroke={blue} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" fill="none" />
      </svg>
    ),
    label: 'Deposit checks',
    zelleLabel: false,
    subPage: 'deposit-selector' as SubPage,
  },
];

interface DepositAccount { name: string; last4: string; balance: string; }

export default function PayTransfer({ onNavigate: _onNavigate, onZelle: _onZelle, onDeposit: _onDeposit }: PayTransferProps) {
  const [subPage, setSubPage] = useState<SubPage>(null);
  const [showSettingsSheet, setShowSettingsSheet] = useState(false);
  const [showTransferSheet, setShowTransferSheet] = useState(false);
  const [depositAccount, setDepositAccount] = useState<DepositAccount | null>(null);

  // Sub-page routing
  if (subPage === 'zelle-send' || subPage === 'zelle-request') {
    return <ZelleFlow onBack={() => setSubPage(null)} />;
  }
  if (subPage === 'schedule-transfer') {
    return <ScheduleTransfer onBack={() => setSubPage(null)} onCancel={() => setSubPage(null)} />;
  }
  if (subPage === 'deposit-selector') {
    return (
      <QuickDepositSelector
        onBack={() => setSubPage(null)}
        onSelectAccount={(name, last4, balance) => {
          setDepositAccount({ name, last4, balance });
          setSubPage('deposit-form');
        }}
      />
    );
  }
  if (subPage === 'deposit-form' && depositAccount) {
    return (
      <CheckDepositForm
        accountName={depositAccount.name}
        accountLast4={depositAccount.last4}
        accountBalance={depositAccount.balance}
        onBack={() => setSubPage('deposit-selector')}
        onCancel={() => setSubPage(null)}
      />
    );
  }
  if (subPage === 'pay-bills') {
    return <PayBillsFlow onBack={() => setSubPage(null)} />;
  }
  if (subPage === 'wires') {
    return <WiresFlow onBack={() => setSubPage(null)} />;
  }
  if (subPage === 'activity') {
    return <SeeActivity onBack={() => setSubPage(null)} />;
  }
  if (subPage === 'recipients') {
    return <ManageRecipients onBack={() => setSubPage(null)} />;
  }

  return (
    <div style={{
      width: '100%', height: '100%', overflowY: 'auto', overflowX: 'hidden',
      background: '#f0f4f8', paddingBottom: 80,
      fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
    }}>
      {/* Page Header */}
      <div style={{ background: '#f0f4f8', padding: '20px 16px 16px' }}>
        <div style={{ fontSize: 28, fontWeight: 700, color: '#111' }}>Pay & Transfer</div>
      </div>

      {/* 6-icon Grid */}
      <div style={{ padding: '0 16px 16px' }}>
        <div style={{
          display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 16,
          background: '#fff', borderRadius: 16, padding: 20,
          boxShadow: '0 2px 12px rgba(0,0,0,0.07)',
        }}>
          {GRID_ITEMS.map(item => (
            <button
              key={item.id}
              onClick={() => {
                if ((item as { isTransfer?: boolean }).isTransfer) {
                  setShowTransferSheet(true);
                } else if (item.subPage) {
                  setSubPage(item.subPage);
                }
              }}
              style={{
                background: 'none', border: 'none', cursor: 'pointer',
                display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10, padding: 0,
              }}
            >
              {/* Icon circle */}
              <div style={{
                width: 72, height: 72, borderRadius: '50%',
                background: '#fff', border: '1px solid #e8e8e8',
                boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                {item.icon}
              </div>
              {/* Label */}
              <div style={{ textAlign: 'center', lineHeight: 1.25 }}>
                <div style={{ fontSize: 13, color: blue, fontWeight: 500 }}>{item.label}</div>
                {item.zelleLabel && (
                  <div style={{ display: 'inline' }}>
                    <span style={{ fontSize: 13, color: purple, fontStyle: 'italic', fontWeight: 700 }}>Zelle</span>
                    <span style={{ fontSize: 9, color: purple, fontStyle: 'italic', fontWeight: 700, verticalAlign: 'super' }}>®</span>
                  </div>
                )}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Three-row white card */}
      <div style={{ padding: '0 16px' }}>
        <div style={{ background: '#fff', borderRadius: 12, overflow: 'hidden', boxShadow: '0 2px 8px rgba(0,0,0,0.06)' }}>
          {[
            { label: 'See activity', action: () => setSubPage('activity') },
            { label: 'Manage recipients', action: () => setSubPage('recipients') },
            { label: 'Settings', action: () => setShowSettingsSheet(true) },
          ].map((row, i) => (
            <div key={row.label}>
              <button
                onClick={row.action}
                style={{
                  width: '100%', background: 'none', border: 'none', cursor: 'pointer',
                  display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                  padding: '18px 20px', textAlign: 'left',
                }}
              >
                <span style={{ fontSize: 15, color: '#111', fontWeight: 400 }}>{row.label}</span>
                <ChevronRight />
              </button>
              {i < 2 && <div style={{ borderTop: '1px solid #f0f0f0', margin: '0 16px' }} />}
            </div>
          ))}
        </div>
      </div>

      {/* Settings sheet */}
      {showSettingsSheet && <SettingsSheet onClose={() => setShowSettingsSheet(false)} />}

      {/* Transfer sheet */}
      {showTransferSheet && (
        <TransferSheet
          onClose={() => setShowTransferSheet(false)}
          onAccountTransfer={() => { setShowTransferSheet(false); setSubPage('schedule-transfer'); }}
          onBrokerageTransfer={() => setShowTransferSheet(false)}
        />
      )}
    </div>
  );
}
