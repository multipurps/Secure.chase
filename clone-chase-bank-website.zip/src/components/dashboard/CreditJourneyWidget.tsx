const navy = '#1a3a6b';

interface Props {
  onSeeDetails: () => void;
}

function Gauge({ score, size }: { score: number; size: number }) {
  const cx = size / 2;
  const cy = size * 0.78;
  const r = size * 0.42;
  const pct = (score - 300) / (850 - 300);
  const angle = Math.PI - pct * Math.PI;
  const needleLen = r - size * 0.06;
  const nx = cx + needleLen * Math.cos(angle);
  const ny = cy - needleLen * Math.sin(angle);

  const segments = [
    { start: 0,    end: 0.25, color: '#d32f2f' },
    { start: 0.25, end: 0.45, color: '#f57c00' },
    { start: 0.45, end: 0.62, color: '#fbc02d' },
    { start: 0.62, end: 0.82, color: '#8bc34a' },
    { start: 0.82, end: 1,    color: '#2e7d32' },
  ];

  function arcPath(sp: number, ep: number) {
    const s = Math.PI - sp * Math.PI;
    const e = Math.PI - ep * Math.PI;
    const x1 = cx + r * Math.cos(s);
    const y1 = cy - r * Math.sin(s);
    const x2 = cx + r * Math.cos(e);
    const y2 = cy - r * Math.sin(e);
    return `M ${x1.toFixed(2)} ${y1.toFixed(2)} A ${r} ${r} 0 0 1 ${x2.toFixed(2)} ${y2.toFixed(2)}`;
  }

  const sw = size * 0.09;

  return (
    <svg width={size} height={size * 0.62} viewBox={`0 0 ${size} ${size * 0.62}`}>
      {/* track */}
      <path
        d={`M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${cx + r} ${cy}`}
        stroke="rgba(255,255,255,0.18)"
        strokeWidth={sw}
        fill="none"
        strokeLinecap="round"
      />
      {/* coloured segments */}
      {segments.map((seg, i) => (
        <path key={i} d={arcPath(seg.start, seg.end)} stroke={seg.color} strokeWidth={sw} fill="none" strokeLinecap="butt" />
      ))}
      {/* needle */}
      <line x1={cx} y1={cy} x2={nx.toFixed(2)} y2={ny.toFixed(2)}
        stroke="#fff" strokeWidth={size * 0.024} strokeLinecap="round" />
      {/* pivot */}
      <circle cx={cx} cy={cy} r={size * 0.042} fill="#fff" />
    </svg>
  );
}

export default function CreditJourneyWidget({ onSeeDetails }: Props) {
  const score = 780;
  const now = new Date();
  const mm = String(now.getMonth() + 1).padStart(2, '0');
  const dd = String(now.getDate()).padStart(2, '0');
  const yy = String(now.getFullYear()).slice(2);
  const dateStr = `${mm}/${dd}/${yy}`;

  return (
    <div style={{
      margin: '16px 16px 0',
      background: navy,
      borderRadius: 16,
      padding: '20px 16px',
      fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
    }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>

        {/* LEFT — text only, NO gauge */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', paddingTop: 4 }}>
          <div style={{ color: '#fff', fontWeight: 700, fontSize: 20, marginBottom: 12 }}>
            Credit Journey
          </div>
          <div style={{ color: '#fff', fontWeight: 700, fontSize: 30, lineHeight: 1, marginBottom: 8 }}>
            {score}
          </div>
          <div style={{ color: 'rgba(255,255,255,0.72)', fontSize: 11, lineHeight: 1.5 }}>
            Credit score as of {dateStr} | by VantageScore® 3.0
          </div>
          <div style={{ color: 'rgba(255,255,255,0.82)', fontSize: 12, marginTop: 6, lineHeight: 1.4 }}>
            Learn more about your credit and how to improve it.
          </div>
        </div>

        {/* RIGHT — ONE gauge only */}
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flexShrink: 0, width: 130 }}>
          <Gauge score={score} size={130} />
          <div style={{ color: '#fff', fontWeight: 700, fontSize: 17, marginTop: -2 }}>{score}</div>
          <div style={{ color: '#fff', fontWeight: 700, fontSize: 14, marginBottom: 12 }}>Excellent</div>
          <button
            onClick={onSeeDetails}
            style={{
              background: 'transparent',
              border: '1.5px solid #fff',
              borderRadius: 999,
              padding: '8px 18px',
              color: '#fff',
              fontWeight: 600,
              fontSize: 13,
              cursor: 'pointer',
              whiteSpace: 'nowrap',
              fontFamily: 'inherit',
            }}
          >
            See details
          </button>
        </div>
      </div>
    </div>
  );
}
