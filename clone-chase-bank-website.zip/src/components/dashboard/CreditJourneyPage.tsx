import { useState, useEffect, useRef } from 'react';

const blue = '#2558b5';

interface Props {
  onBack: () => void;
}

function AnimatedGauge({ score, animate }: { score: number; animate: boolean }) {
  const [displayScore, setDisplayScore] = useState(0);
  const [drawPct, setDrawPct] = useState(0);
  const rafRef = useRef<number>(0);

  useEffect(() => {
    if (!animate) { setDisplayScore(score); setDrawPct((score - 300) / 550); return; }
    const start = Date.now();
    const duration = 1000;
    function tick() {
      const elapsed = Date.now() - start;
      const pct = Math.min(elapsed / duration, 1);
      const ease = 1 - Math.pow(1 - pct, 3);
      setDisplayScore(Math.round(ease * score));
      setDrawPct(ease * (score - 300) / 550);
      if (pct < 1) rafRef.current = requestAnimationFrame(tick);
    }
    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, [animate, score]);

  const size = 280;
  const cx = size / 2;
  const cy = size * 0.58;
  const r = size * 0.36;

  const stops = [
    { pct: 0, color: '#d32f2f' },
    { pct: 0.33, color: '#f57c00' },
    { pct: 0.55, color: '#fbc02d' },
    { pct: 0.78, color: '#8bc34a' },
    { pct: 1, color: '#388e3c' },
  ];

  function arcPath(startPct: number, endPct: number, outerR: number) {
    const s = Math.PI - startPct * Math.PI;
    const e = Math.PI - endPct * Math.PI;
    const x1 = cx + outerR * Math.cos(s);
    const y1 = cy - outerR * Math.sin(s);
    const x2 = cx + outerR * Math.cos(e);
    const y2 = cy - outerR * Math.sin(e);
    return `M ${x1} ${y1} A ${outerR} ${outerR} 0 0 1 ${x2} ${y2}`;
  }

  const segments: { start: number; end: number; color: string }[] = [];
  for (let i = 0; i < stops.length - 1; i++) {
    segments.push({ start: stops[i].pct, end: Math.min(stops[i + 1].pct, drawPct), color: stops[i].color });
  }

  const scoreAngle = Math.PI - drawPct * Math.PI;
  const dotX = cx + r * Math.cos(scoreAngle);
  const dotY = cy - r * Math.sin(scoreAngle);

  return (
    <div style={{ position: 'relative', width: size, height: size * 0.65, margin: '0 auto' }}>
      <svg width={size} height={size * 0.65} viewBox={`0 0 ${size} ${size * 0.65}`}>
        {/* Track */}
        <path
          d={`M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${cx + r} ${cy}`}
          stroke="#e0e0e0" strokeWidth={18} fill="none" strokeLinecap="round"
        />
        {/* Colored arc */}
        {segments.filter(s => s.end > s.start).map((seg, i) => (
          <path key={i}
            d={arcPath(seg.start, seg.end, r)}
            stroke={seg.color} strokeWidth={18} fill="none" strokeLinecap="butt"
          />
        ))}
        {/* Score dot */}
        {drawPct > 0 && (
          <circle cx={dotX} cy={dotY} r={9} fill="#fff" stroke="#388e3c" strokeWidth={3} />
        )}
        {/* Scale labels */}
        <text x={cx - r - 10} y={cy + 18} fontSize={11} fill="#888" textAnchor="middle">300</text>
        <text x={cx + r + 10} y={cy + 18} fontSize={11} fill="#888" textAnchor="middle">850</text>
        {[{ val: '660', pct: 0.33 }, { val: '720', pct: 0.55 }, { val: '780', pct: 0.78 }].map((m, i) => {
          const a = Math.PI - m.pct * Math.PI;
          const mx = cx + (r + 20) * Math.cos(a);
          const my = cy - (r + 20) * Math.sin(a);
          return <text key={i} x={mx} y={my} fontSize={10} fill="#aaa" textAnchor="middle">{m.val}</text>;
        })}
      </svg>

      {/* Center score badge */}
      <div style={{
        position: 'absolute',
        left: '50%', top: '42%',
        transform: 'translate(-50%, -50%)',
        textAlign: 'center',
      }}>
        <div style={{
          display: 'inline-flex', alignItems: 'center', gap: 4,
          background: '#fff', border: '1px solid #e0e0e0',
          borderRadius: 999, padding: '4px 10px',
          marginBottom: 4,
        }}>
          <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
            <polygon points="5,1 5,1 9,9 1,9" fill="#388e3c" />
          </svg>
          <span style={{ fontSize: 12, fontWeight: 700, color: '#388e3c' }}>+20 PTS</span>
        </div>
        <div style={{ fontSize: 52, fontWeight: 700, color: '#111', lineHeight: 1 }}>{displayScore}</div>
        <div style={{ fontSize: 15, color: '#888', letterSpacing: 2, fontWeight: 700, marginTop: 2 }}>GREAT</div>
      </div>
    </div>
  );
}

type CreditTab = 'credit' | 'alerts' | 'offers';

export default function CreditJourneyPage({ onBack }: Props) {
  const [tab, setTab] = useState<CreditTab>('credit');
  const [animated, setAnimated] = useState(false);
  const [alertsRead, setAlertsRead] = useState([false, false, false]);

  const unreadCount = alertsRead.filter(r => !r).length;

  useEffect(() => {
    const t = setTimeout(() => setAnimated(true), 100);
    return () => clearTimeout(t);
  }, []);

  const nextUpdate = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });

  const alerts = [
    { title: 'Score increased', desc: 'Your credit score increased by 20 points.', date: 'Sep 10, 2024', type: 'positive' },
    { title: 'New account opened', desc: 'A new credit card account was opened in your name.', date: 'Aug 28, 2024', type: 'neutral' },
    { title: 'Hard inquiry detected', desc: 'A new hard inquiry appeared on your credit report.', date: 'Aug 15, 2024', type: 'warning' },
  ];

  const factors = [
    { label: 'Late Payments', value: '0', rating: 'Great', color: '#388e3c' },
    { label: 'Oldest Account', value: '12 yrs 10 mos', rating: 'Good', color: '#388e3c' },
    { label: 'Credit Utilization', value: '12%', rating: 'Great', color: '#388e3c' },
    { label: 'Total Accounts', value: '8', rating: 'Good', color: '#388e3c' },
    { label: 'Hard Inquiries', value: '1', rating: 'Good', color: '#388e3c' },
    { label: 'Derogatory Marks', value: '0', rating: 'Great', color: '#388e3c' },
  ];

  return (
    <div style={{
      width: '100%', height: '100%', overflowY: 'auto',
      background: '#f0f4f8',
      fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
      paddingBottom: 80,
    }}>
      {/* Header */}
      <div style={{ background: blue, padding: '16px 16px 0' }}>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 12 }}>
          <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
              <polyline points="15,4 7,12 15,20" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
          <span style={{ color: '#fff', fontWeight: 700, fontSize: 17, flex: 1, textAlign: 'center', marginRight: 24 }}>
            Chase Credit Journey
          </span>
        </div>

        {/* Tabs */}
        <div style={{ display: 'flex', borderBottom: '1px solid rgba(255,255,255,0.3)' }}>
          {([
            { key: 'credit', label: 'Credit' },
            { key: 'alerts', label: `Alerts`, badge: unreadCount },
            { key: 'offers', label: 'Offers', badge: 3 },
          ] as { key: CreditTab; label: string; badge?: number }[]).map(t => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              style={{
                flex: 1, background: 'none', border: 'none', cursor: 'pointer',
                padding: '10px 4px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
                borderBottom: tab === t.key ? '3px solid #fff' : '3px solid transparent',
                color: tab === t.key ? '#fff' : 'rgba(255,255,255,0.65)',
                fontWeight: tab === t.key ? 700 : 400, fontSize: 14,
              }}
            >
              {t.label}
              {t.badge !== undefined && t.badge > 0 && (
                <div style={{
                  background: '#fff', color: blue,
                  borderRadius: 999, padding: '1px 6px',
                  fontSize: 10, fontWeight: 700, minWidth: 18, textAlign: 'center',
                }}>
                  {t.badge}
                </div>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* CREDIT TAB */}
      {tab === 'credit' && (
        <div>
          {/* Powered by Experian */}
          <div style={{ padding: '12px 16px 0', display: 'flex', alignItems: 'center', gap: 4 }}>
            <span style={{ fontSize: 11, color: '#888' }}>powered by</span>
            <span style={{ fontSize: 11, color: '#6d1ed4', fontWeight: 700 }}>experian.</span>
          </div>

          {/* Main gauge card */}
          <div style={{ margin: 16, background: '#fff', borderRadius: 14, padding: '24px 16px 20px', boxShadow: '0 2px 12px rgba(0,0,0,0.08)' }}>
            <AnimatedGauge score={780} animate={animated} />

            {/* Chart as table link */}
            <div style={{ textAlign: 'center', marginTop: 8 }}>
              <button style={{ background: 'none', border: 'none', cursor: 'pointer', color: blue, fontSize: 13, fontWeight: 600 }}>
                View chart as table ›
              </button>
            </div>

            <div style={{ textAlign: 'center', color: '#888', fontSize: 12, marginTop: 8 }}>
              Next update: {nextUpdate} | based on VantageScore® 3.0 ⓘ
            </div>
          </div>

          {/* Milestone card */}
          <div style={{
            margin: '0 16px 16px', background: '#fff', borderRadius: 14,
            padding: 16, boxShadow: '0 2px 12px rgba(0,0,0,0.06)',
            display: 'flex', alignItems: 'center', gap: 14,
          }}>
            {/* Illustrated character */}
            <div style={{
              width: 70, height: 70, borderRadius: 12, flexShrink: 0,
              background: 'linear-gradient(135deg, #e8f4ff 0%, #d0e8ff 100%)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 36,
              overflow: 'hidden',
            }}>
              <svg width="60" height="60" viewBox="0 0 60 60" fill="none">
                {/* Body */}
                <circle cx="30" cy="18" r="10" fill="#5b9bd5" />
                <rect x="18" y="28" width="24" height="20" rx="4" fill="#2558b5" />
                {/* Arms raised */}
                <line x1="18" y1="32" x2="8" y2="22" stroke="#2558b5" strokeWidth="4" strokeLinecap="round" />
                <line x1="42" y1="32" x2="52" y2="22" stroke="#2558b5" strokeWidth="4" strokeLinecap="round" />
                {/* Confetti */}
                <rect x="5" y="8" width="5" height="5" rx="1" fill="#f7d100" transform="rotate(20 7 10)" />
                <rect x="48" y="5" width="4" height="4" rx="1" fill="#e83e8c" transform="rotate(-15 50 7)" />
                <rect x="12" y="2" width="4" height="4" rx="1" fill="#2ac" transform="rotate(10 14 4)" />
                <rect x="44" y="14" width="4" height="6" rx="1" fill="#ff6b35" transform="rotate(25 46 17)" />
                <circle cx="10" cy="18" r="2.5" fill="#a855f7" />
                <circle cx="50" cy="10" r="2" fill="#388e3c" />
              </svg>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: '#111', letterSpacing: 1, marginBottom: 4 }}>WELCOME BACK</div>
              <div style={{ fontSize: 13, color: '#555', lineHeight: 1.5 }}>
                You've reached a milestone. Your credit score went from{' '}
                <strong style={{ color: '#111' }}>good to great</strong>. Nice work!
              </div>
            </div>
          </div>

          {/* Alerts notification */}
          <div style={{
            margin: '0 16px 16px', background: '#fff', borderRadius: 14,
            padding: 16, boxShadow: '0 2px 12px rgba(0,0,0,0.06)',
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ position: 'relative' }}>
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
                  <path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 01-3.46 0" stroke="#555" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" fill="none" />
                </svg>
                <div style={{ position: 'absolute', top: -2, right: -2, width: 16, height: 16, borderRadius: '50%', background: blue, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <span style={{ color: '#fff', fontSize: 9, fontWeight: 700 }}>{unreadCount}</span>
                </div>
              </div>
              <span style={{ fontSize: 14, color: '#111' }}>
                You have <strong>{unreadCount}</strong> unread alert{unreadCount !== 1 ? 's' : ''}.
              </span>
            </div>
            <button onClick={() => setTab('alerts')} style={{ background: 'none', border: 'none', cursor: 'pointer', color: blue, fontSize: 13, fontWeight: 600 }}>
              See details ›
            </button>
          </div>

          {/* Factors */}
          <div style={{ margin: '0 16px 16px', background: '#fff', borderRadius: 14, padding: 20, boxShadow: '0 2px 12px rgba(0,0,0,0.06)' }}>
            <div style={{ fontWeight: 700, fontSize: 16, color: '#111', marginBottom: 16 }}>Factors that impact your score</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 0 }}>
              {factors.map((f, i) => (
                <div key={i} style={{
                  padding: '14px 12px',
                  borderBottom: i < factors.length - 2 ? '1px solid #f0f0f0' : 'none',
                  borderRight: i % 2 === 0 ? '1px solid #f0f0f0' : 'none',
                }}>
                  <div style={{ fontSize: 13, fontWeight: 700, color: '#111', marginBottom: 6 }}>{f.label}</div>
                  <div style={{ fontSize: 24, fontWeight: 700, color: '#111', marginBottom: 8, lineHeight: 1 }}>{f.value}</div>
                  <div style={{ borderTop: '1px solid #f0f0f0', paddingTop: 8, display: 'flex', alignItems: 'center', gap: 6 }}>
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                      <circle cx="12" cy="12" r="10" fill={f.color + '20'} stroke={f.color} strokeWidth="1.5" />
                      <path d="M8 12l2.5 2.5L16 9" stroke={f.color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                    <span style={{ fontSize: 12, color: f.color, fontWeight: 600 }}>{f.rating}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ALERTS TAB */}
      {tab === 'alerts' && (
        <div style={{ padding: '16px 0' }}>
          {alerts.map((alert, i) => (
            <div
              key={i}
              onClick={() => {
                const updated = [...alertsRead];
                updated[i] = true;
                setAlertsRead(updated);
              }}
              style={{
                margin: '0 16px 12px', background: '#fff', borderRadius: 12,
                padding: 16, boxShadow: '0 1px 6px rgba(0,0,0,0.06)',
                cursor: 'pointer', borderLeft: `4px solid ${alertsRead[i] ? '#ddd' : blue}`,
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: alertsRead[i] ? 400 : 700, fontSize: 14, color: '#111', marginBottom: 4 }}>
                    {alert.title}
                    {!alertsRead[i] && (
                      <span style={{ marginLeft: 8, width: 8, height: 8, borderRadius: '50%', background: blue, display: 'inline-block' }} />
                    )}
                  </div>
                  <div style={{ fontSize: 13, color: '#666', lineHeight: 1.4 }}>{alert.desc}</div>
                </div>
                <span style={{ fontSize: 12, color: '#aaa', flexShrink: 0, marginLeft: 8 }}>{alert.date}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* OFFERS TAB */}
      {tab === 'offers' && (
        <div style={{ padding: '16px 16px' }}>
          <div style={{ fontSize: 15, color: '#555', textAlign: 'center', marginBottom: 16 }}>
            Credit card offers for your accounts
          </div>
          {[
            { merchant: 'Chase Sapphire Reserve', cashback: '75,000 bonus points', desc: 'After spending $4,000 in first 3 months', badge: 'Limited time' },
            { merchant: 'Chase Freedom Unlimited', cashback: '$250 cash back', desc: 'After spending $500 in first 3 months', badge: 'New' },
            { merchant: 'Chase Sapphire Preferred', cashback: '60,000 bonus points', desc: 'After spending $3,000 in first 3 months', badge: 'Popular' },
          ].map((offer, i) => (
            <div key={i} style={{
              background: '#fff', borderRadius: 12, padding: 16,
              boxShadow: '0 2px 8px rgba(0,0,0,0.07)', marginBottom: 12,
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 15, color: '#111', marginBottom: 4 }}>{offer.merchant}</div>
                  <div style={{ fontSize: 18, fontWeight: 700, color: blue, marginBottom: 4 }}>{offer.cashback}</div>
                  <div style={{ fontSize: 13, color: '#888' }}>{offer.desc}</div>
                </div>
                <div style={{ background: '#2a9d4e', color: '#fff', fontSize: 11, fontWeight: 700, borderRadius: 999, padding: '3px 8px', flexShrink: 0 }}>
                  {offer.badge}
                </div>
              </div>
              <button style={{
                marginTop: 12, background: blue, border: 'none', borderRadius: 8,
                padding: '10px 20px', color: '#fff', fontSize: 14, fontWeight: 600, cursor: 'pointer',
              }}>
                Learn more
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
