import { useState, useRef } from 'react';

const blue = '#2558b5';

interface Props {
  onBack: () => void;
}

export default function CheckDeposit({ onBack }: Props) {
  const [amount, setAmount] = useState('');
  const [frontPhoto, setFrontPhoto] = useState<string | null>(null);
  const [backPhoto, setBackPhoto] = useState<string | null>(null);
  const [showLimits, setShowLimits] = useState(false);
  const frontInput = useRef<HTMLInputElement>(null);
  const backInput = useRef<HTMLInputElement>(null);

  const canSubmit = amount && parseFloat(amount) > 0 && frontPhoto && backPhoto;

  function handlePhoto(e: React.ChangeEvent<HTMLInputElement>, side: 'front' | 'back') {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      const result = ev.target?.result as string;
      if (side === 'front') setFrontPhoto(result);
      else setBackPhoto(result);
    };
    reader.readAsDataURL(file);
  }

  return (
    <div style={{
      width: '100%', height: '100%', display: 'flex', flexDirection: 'column',
      background: '#fff', fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
      overflow: 'hidden',
    }}>
      {/* Header — blue */}
      <div style={{
        background: blue, padding: '14px 16px',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        flexShrink: 0,
      }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path d="M15 18l-6-6 6-6" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
        <span style={{ color: '#fff', fontSize: 15, fontWeight: 700, letterSpacing: 0.5 }}>
          CHASE QUICKDEPOSIT℠
        </span>
        <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#fff', fontSize: 14, fontWeight: 600 }}>
          CANCEL
        </button>
      </div>

      {/* Body */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '24px 20px', paddingBottom: 120 }}>
        {/* Deposit to */}
        <div style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 13, color: '#888', marginBottom: 6 }}>Deposit to</div>
          <div style={{ cursor: 'pointer' }}>
            <div style={{ fontSize: 15, fontWeight: 700, color: blue }}>
              PREMIER PLUS CKG (...1234)
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" style={{ marginLeft: 4, verticalAlign: 'middle' }}>
                <path d="M6 9l6 6 6-6" stroke={blue} strokeWidth="2" strokeLinecap="round" />
              </svg>
            </div>
            <div style={{ fontSize: 14, fontWeight: 700, color: blue, marginTop: 4 }}>$2,250.00</div>
          </div>
        </div>

        {/* Deposit amount */}
        <div style={{ textAlign: 'center', marginBottom: 28 }}>
          <div style={{ fontSize: 13, color: '#888', marginBottom: 12 }}>Deposit amount</div>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4 }}>
            <span style={{ fontSize: 36, fontWeight: 300, color: amount ? '#111' : '#ccc' }}>$</span>
            <input
              type="number"
              min="0"
              max="2000"
              step="0.01"
              value={amount}
              onChange={e => setAmount(e.target.value)}
              placeholder="0.00"
              style={{
                fontSize: 36, fontWeight: 300, color: '#111', border: 'none',
                borderBottom: '1px solid #ddd', outline: 'none', background: 'none',
                textAlign: 'center', width: 160,
                fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
              }}
            />
          </div>
          <div style={{ fontSize: 12, color: '#888', marginTop: 10 }}>
            Your current mobile deposit limit is $2,000.00
          </div>
        </div>

        {/* Check photo capture */}
        <div style={{ display: 'flex', gap: 12, marginBottom: 20 }}>
          {/* Front */}
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 13, color: '#555', textAlign: 'center', marginBottom: 6 }}>Front</div>
            <div
              onClick={() => !frontPhoto && frontInput.current?.click()}
              style={{
                height: 120, border: `2px solid ${frontPhoto ? '#ddd' : blue}`,
                borderRadius: 8, display: 'flex', flexDirection: 'column',
                alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
                overflow: 'hidden', background: '#fafafe',
              }}
            >
              {frontPhoto ? (
                <img src={frontPhoto} alt="Front" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              ) : (
                <>
                  <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
                    <path d="M23 19a2 2 0 01-2 2H3a2 2 0 01-2-2V8a2 2 0 012-2h4l2-3h6l2 3h4a2 2 0 012 2z" stroke={blue} strokeWidth="1.6" fill="none" />
                    <circle cx="12" cy="13" r="4" stroke={blue} strokeWidth="1.6" fill="none" />
                  </svg>
                </>
              )}
            </div>
            {frontPhoto && (
              <button
                onClick={() => { setFrontPhoto(null); if (frontInput.current) frontInput.current.value = ''; }}
                style={{ display: 'block', margin: '6px auto 0', background: 'none', border: 'none', color: blue, fontSize: 13, cursor: 'pointer', fontWeight: 500 }}
              >
                Retake
              </button>
            )}
            <input ref={frontInput} type="file" accept="image/*" capture="environment" style={{ display: 'none' }} onChange={e => handlePhoto(e, 'front')} />
          </div>

          {/* Back */}
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 13, color: '#555', textAlign: 'center', marginBottom: 6 }}>Back</div>
            <div
              onClick={() => frontPhoto && !backPhoto && backInput.current?.click()}
              style={{
                height: 120, border: `1px solid ${backPhoto ? '#ddd' : (frontPhoto ? '#aaa' : '#ddd')}`,
                borderRadius: 8, display: 'flex', flexDirection: 'column',
                alignItems: 'center', justifyContent: 'center',
                cursor: frontPhoto ? 'pointer' : 'not-allowed',
                overflow: 'hidden', background: frontPhoto ? '#fafafe' : '#f9f9f9',
                opacity: frontPhoto ? 1 : 0.5,
              }}
            >
              {backPhoto ? (
                <img src={backPhoto} alt="Back" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              ) : (
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
                  <path d="M23 19a2 2 0 01-2 2H3a2 2 0 01-2-2V8a2 2 0 012-2h4l2-3h6l2 3h4a2 2 0 012 2z" stroke="#aaa" strokeWidth="1.6" fill="none" />
                  <circle cx="12" cy="13" r="4" stroke="#aaa" strokeWidth="1.6" fill="none" />
                </svg>
              )}
            </div>
            {backPhoto && (
              <button
                onClick={() => { setBackPhoto(null); if (backInput.current) backInput.current.value = ''; }}
                style={{ display: 'block', margin: '6px auto 0', background: 'none', border: 'none', color: blue, fontSize: 13, cursor: 'pointer', fontWeight: 500 }}
              >
                Retake
              </button>
            )}
            <input ref={backInput} type="file" accept="image/*" capture="environment" style={{ display: 'none' }} onChange={e => handlePhoto(e, 'back')} />
          </div>
        </div>

        {/* Info bar */}
        <div style={{
          display: 'flex', alignItems: 'flex-start', gap: 10,
          background: '#f5f5f5', borderTop: '1px solid #e8e8e8',
          padding: 14, borderRadius: 8, marginBottom: 16,
        }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" style={{ flexShrink: 0, marginTop: 1 }}>
            <circle cx="12" cy="12" r="9" stroke={blue} strokeWidth="1.6" />
            <line x1="12" y1="11" x2="12" y2="17" stroke={blue} strokeWidth="1.6" strokeLinecap="round" />
            <circle cx="12" cy="8" r="1" fill={blue} />
          </svg>
          <p style={{ fontSize: 12, color: '#666', margin: 0, lineHeight: 1.6 }}>
            Deposit by 11PM ET and your money will typically be available for withdrawal by the next business day. Deposits may be subject to holds.
          </p>
        </div>
      </div>

      {/* Bottom: Next button + limits link */}
      <div style={{
        position: 'absolute', bottom: 0, left: 0, right: 0,
        background: '#fff', borderTop: '1px solid #eee',
        padding: '12px 16px 28px',
      }}>
        <button
          disabled={!canSubmit}
          style={{
            width: '100%', padding: '15px 0', borderRadius: 8, border: 'none',
            background: canSubmit ? blue : '#e8e8e8',
            color: canSubmit ? '#fff' : '#555',
            fontSize: 17, fontWeight: 600, cursor: canSubmit ? 'pointer' : 'not-allowed',
            transition: 'background 0.2s',
          }}
        >
          Next
        </button>

        {/* Limits link */}
        <button
          onClick={() => setShowLimits(v => !v)}
          style={{
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4,
            width: '100%', background: 'none', border: 'none', cursor: 'pointer',
            color: blue, fontSize: 14, fontWeight: 500, marginTop: 12,
          }}
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
            <path d="M18 15l-6-6-6 6" stroke={blue} strokeWidth="2" strokeLinecap="round" />
          </svg>
          Mobile Deposit limits
        </button>

        {showLimits && (
          <div style={{
            background: '#f5f8ff', borderRadius: 8, padding: 14, marginTop: 10,
            fontSize: 13, color: '#555', lineHeight: 1.6,
          }}>
            <strong>Mobile Deposit Limits</strong><br />
            Daily limit: $2,000.00<br />
            30-day limit: $5,000.00<br />
            Limits may vary based on account type and tenure.
          </div>
        )}
      </div>
    </div>
  );
}
