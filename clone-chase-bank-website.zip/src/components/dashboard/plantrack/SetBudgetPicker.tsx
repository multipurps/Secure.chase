const blue = '#2558b5';

const CAT_LIST = [
  { name: 'Total',                 color: blue,      iconBg: '#e8f0fe' },
  { name: 'Automotive',            color: '#2558b5', iconBg: '#e8f0fe' },
  { name: 'Bills & utilities',     color: '#1a3a6b', iconBg: '#e8eaf6' },
  { name: 'Cash out',              color: '#2e8b6e', iconBg: '#e8f5e9' },
  { name: 'Education',             color: '#1a3a6b', iconBg: '#e3f2fd' },
  { name: 'Entertainment',         color: '#c9a227', iconBg: '#fff8e1' },
  { name: 'Fees & adjustments',    color: '#c9a227', iconBg: '#fff3e0' },
  { name: 'Food & drink',          color: '#e67e22', iconBg: '#fff3e0' },
  { name: 'Gas',                   color: '#c0272d', iconBg: '#ffebee' },
  { name: 'Gifts & donations',     color: '#6b2fa0', iconBg: '#f3e5f5' },
  { name: 'Groceries',             color: '#2558b5', iconBg: '#e8f0fe' },
  { name: 'Health & wellness',     color: '#2e8b6e', iconBg: '#e8f5e9' },
  { name: 'Home',                  color: '#1a3a6b', iconBg: '#e8eaf6' },
  { name: 'Personal',              color: '#c9a227', iconBg: '#fff8e1' },
  { name: 'Professional services', color: '#1a3a6b', iconBg: '#e8eaf6' },
  { name: 'Shopping',              color: '#2e8b6e', iconBg: '#e8f5e9' },
  { name: 'Travel',                color: '#2558b5', iconBg: '#e8f0fe' },
];

interface Props {
  onBack: () => void;
  onSelectCategory: (cat: string) => void;
}

function CatDot({ color, bg }: { color: string; bg: string }) {
  return (
    <div style={{
      width: 32, height: 32, borderRadius: '50%', background: bg,
      display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
    }}>
      <div style={{ width: 14, height: 14, borderRadius: 3, background: color }} />
    </div>
  );
}

export default function SetBudgetPicker({ onBack, onSelectCategory }: Props) {
  return (
    <div style={{
      width: '100%', height: '100%', overflowY: 'auto', background: '#fff',
      fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
    }}>
      {/* Header */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '16px 20px', borderBottom: '1px solid #f0f0f0', position: 'sticky', top: 0, background: '#fff', zIndex: 10,
      }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}>
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
            <path d="M15 18l-6-6 6-6" stroke="#333" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>
        <div style={{ fontSize: 17, fontWeight: 700, color: '#111' }}>Set a budget</div>
        <button style={{ background: 'none', border: 'none', color: blue, fontSize: 16, fontWeight: 600, cursor: 'pointer' }}>
          Cancel
        </button>
      </div>

      {/* Total row — above divider */}
      <button
        onClick={() => onSelectCategory('Total')}
        style={{
          display: 'flex', alignItems: 'center', width: '100%',
          background: 'none', border: 'none', padding: '16px 20px',
          borderBottom: '1px solid #f0f0f0', cursor: 'pointer', gap: 14,
        }}
      >
        <div style={{
          width: 28, height: 28, borderRadius: '50%', border: `2px solid ${blue}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center', color: blue, fontSize: 18, fontWeight: 700, flexShrink: 0,
        }}>+</div>
        <div style={{
          width: 32, height: 32, borderRadius: '50%', background: '#e8f0fe',
          display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
        }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <rect x="2" y="5" width="20" height="14" rx="2" stroke={blue} strokeWidth="1.8"/>
            <path d="M2 10h20" stroke={blue} strokeWidth="1.6"/>
          </svg>
        </div>
        <span style={{ fontSize: 16, color: '#111', fontWeight: 500 }}>Total</span>
      </button>

      {/* Section divider */}
      <div style={{ background: '#f5f5f5', padding: '6px 20px', fontSize: 12, fontWeight: 700, color: '#888', letterSpacing: 0.5, textTransform: 'uppercase' }}>
        Categories
      </div>

      {/* Category list */}
      {CAT_LIST.filter(c => c.name !== 'Total').map((cat, i) => (
        <button
          key={i}
          onClick={() => onSelectCategory(cat.name)}
          style={{
            display: 'flex', alignItems: 'center', width: '100%',
            background: 'none', border: 'none', padding: '15px 20px',
            borderBottom: '1px solid #f0f0f0', cursor: 'pointer', gap: 14,
          }}
        >
          <div style={{
            width: 28, height: 28, borderRadius: '50%', border: `2px solid ${blue}`,
            display: 'flex', alignItems: 'center', justifyContent: 'center', color: blue, fontSize: 18, fontWeight: 700, flexShrink: 0,
          }}>+</div>
          <CatDot color={cat.color} bg={cat.iconBg} />
          <span style={{ fontSize: 15, color: '#111' }}>{cat.name}</span>
        </button>
      ))}

      <div style={{ height: 40 }} />
    </div>
  );
}
