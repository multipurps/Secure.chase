import { useState, useEffect } from 'react';
import {
  BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Cell,
} from 'recharts';

const blue = '#2558b5';

const MONTHS_SHORT = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

// Historical spending per category (demo)
const CATEGORY_HIST: Record<string, number[]> = {
  'Groceries':             [110, 98, 140, 125, 135, 125],
  'Food & drink':          [210, 180, 260, 240, 230, 250],
  'Shopping':              [400, 620, 550, 780, 700, 890],
  'Entertainment':         [60,  80,  110, 75,  90,  95],
  'Gifts & donations':     [200, 150, 300, 500, 400, 800],
  'Bills & utilities':     [110, 110, 115, 112, 118, 120],
  'Total':                 [2800, 3200, 4100, 3650, 2900, 1400],
};

function getAutoMonths() {
  const now = new Date();
  const result = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    result.push({ short: MONTHS_SHORT[d.getMonth()], year: d.getFullYear(), isCurrent: i === 0 });
  }
  return result;
}

interface Props {
  category: string;
  onBack: () => void;
  onSave: (amount: number) => void;
}

export default function BudgetAmountEntry({ category, onBack, onSave }: Props) {
  const [amount, setAmount] = useState('350');
  const [animated, setAnimated] = useState(false);
  const months6 = getAutoMonths();
  const hist = CATEGORY_HIST[category] ?? [80, 90, 100, 110, 105, 95];
  const avg = Math.round(hist.slice(0, 5).reduce((a, b) => a + b, 0) / 5);
  const [showTable, setShowTable] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setAnimated(true), 100);
    return () => clearTimeout(t);
  }, []);

  const chartData = months6.map((m, i) => ({
    name: m.short,
    value: hist[i] ?? 0,
    isCurrent: m.isCurrent,
  }));

  function handleKey(k: string) {
    if (k === 'del') {
      setAmount(v => v.length > 1 ? v.slice(0, -1) : '0');
    } else if (k === '.') {
      if (!amount.includes('.')) setAmount(v => v + '.');
    } else {
      setAmount(v => v === '0' ? k : v + k);
    }
  }

  return (
    <div style={{
      width: '100%', height: '100%', overflowY: 'auto', background: '#fff',
      fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
    }}>
      {/* Header */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '16px 20px', borderBottom: '1px solid #f0f0f0', position: 'sticky', top: 0, background: '#fff', zIndex: 10,
      }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}>
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
            <path d="M15 18l-6-6 6-6" stroke="#333" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>
        <div style={{ fontSize: 17, fontWeight: 700, color: '#111' }}>Set a budget</div>
        <button style={{ background: 'none', border: 'none', color: blue, fontSize: 16, fontWeight: 600, cursor: 'pointer' }}>
          Cancel
        </button>
      </div>

      {/* Body */}
      <div style={{ padding: '28px 24px 0', textAlign: 'center' }}>
        {/* Category icon */}
        <div style={{
          width: 64, height: 64, borderRadius: '50%', background: '#e8f0fe',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          margin: '0 auto 14px',
        }}>
          <div style={{ width: 28, height: 28, borderRadius: 6, background: blue }} />
        </div>
        <div style={{ fontSize: 22, fontWeight: 700, color: '#111', marginBottom: 4 }}>{category}</div>
        <div style={{ fontSize: 13, color: '#888', marginBottom: 20 }}>Monthly budget</div>

        {/* Amount input */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4, marginBottom: 6 }}>
          <span style={{ fontSize: 28, fontWeight: 700, color: '#333', alignSelf: 'flex-start', paddingTop: 8 }}>$</span>
          <span style={{ fontSize: 44, fontWeight: 800, color: '#111' }}>{amount}</span>
        </div>
        <div style={{ height: 2, background: '#ddd', margin: '0 60px 20px', borderRadius: 1 }} />

        {/* Insight box */}
        <div style={{
          background: '#f8f8f8', borderRadius: 10, padding: '12px 16px',
          display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20,
          textAlign: 'left',
        }}>
          <div style={{
            width: 32, height: 32, borderRadius: '50%', background: '#fff3cd',
            display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, fontSize: 16,
          }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
              <circle cx="12" cy="12" r="10" stroke="#c9a227" strokeWidth="1.8"/>
              <path d="M12 7v5" stroke="#c9a227" strokeWidth="2" strokeLinecap="round"/>
              <circle cx="12" cy="16" r="1" fill="#c9a227"/>
            </svg>
          </div>
          <div style={{ fontSize: 13, color: '#555', lineHeight: 1.5 }}>
            You've spent <strong>${avg}</strong> per month on average.
          </div>
        </div>
      </div>

      {/* Bar chart */}
      <div style={{ padding: '0 16px' }}>
        <div style={{ height: 160 }}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} barCategoryGap="35%" margin={{ top: 4, right: 4, bottom: 0, left: -28 }}>
              <XAxis
                dataKey="name"
                tick={{ fontSize: 11, fill: '#aaa' }}
                tickLine={false} axisLine={false}
              />
              <YAxis
                tick={{ fontSize: 10, fill: '#aaa' }}
                tickLine={false} axisLine={false}
                tickFormatter={v => `$${v}`}
              />
              <Bar dataKey="value" radius={[3,3,0,0]} isAnimationActive={animated} animationDuration={600} animationEasing="ease-out">
                {chartData.map((entry, i) => (
                  <Cell key={i} fill={entry.isCurrent ? '#1a3a6b' : blue} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div style={{ textAlign: 'center', marginTop: 6, marginBottom: 16 }}>
          <button
            onClick={() => setShowTable(v => !v)}
            style={{ background: 'none', border: 'none', color: blue, fontSize: 13, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 4 }}
          >
            <span>&#8801;</span> See chart as table
          </button>
        </div>
        {showTable && (
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13, marginBottom: 16 }}>
            <thead>
              <tr style={{ background: '#f5f7fa' }}>
                <th style={{ padding: '8px 10px', textAlign: 'left', color: '#555', fontWeight: 600, borderBottom: '1px solid #eee' }}>Month</th>
                <th style={{ padding: '8px 10px', textAlign: 'right', color: '#555', fontWeight: 600, borderBottom: '1px solid #eee' }}>Spent</th>
              </tr>
            </thead>
            <tbody>
              {months6.map((m, i) => (
                <tr key={i} style={{ background: m.isCurrent ? '#f0f6ff' : 'transparent' }}>
                  <td style={{ padding: '8px 10px', color: '#333', borderBottom: '1px solid #f0f0f0', fontWeight: m.isCurrent ? 700 : 400 }}>{m.short} {m.year}</td>
                  <td style={{ padding: '8px 10px', textAlign: 'right', color: '#333', borderBottom: '1px solid #f0f0f0' }}>${hist[i] ?? 0}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Numeric keypad */}
      <div style={{ padding: '0 24px', display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 4, marginBottom: 20 }}>
        {['1','2','3','4','5','6','7','8','9','.','0','del'].map(k => (
          <button
            key={k}
            onClick={() => handleKey(k)}
            style={{
              padding: '16px 0', fontSize: k === 'del' ? 18 : 22, fontWeight: 500,
              color: '#111', background: '#f5f5f5', border: 'none', borderRadius: 8, cursor: 'pointer',
            }}
          >
            {k === 'del' ? (
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" style={{ margin: '0 auto', display: 'block' }}>
                <path d="M21 7H9L3 12l6 5h12V7z" stroke="#333" strokeWidth="1.8" fill="none"/>
                <line x1="14" y1="10" x2="18" y2="14" stroke="#333" strokeWidth="1.6" strokeLinecap="round"/>
                <line x1="18" y1="10" x2="14" y2="14" stroke="#333" strokeWidth="1.6" strokeLinecap="round"/>
              </svg>
            ) : k}
          </button>
        ))}
      </div>

      {/* Save button */}
      <div style={{ padding: '0 24px 32px' }}>
        <button
          onClick={() => onSave(parseFloat(amount) || 0)}
          style={{
            width: '100%', background: blue, color: '#fff', border: 'none',
            borderRadius: 8, padding: '16px', fontSize: 17, fontWeight: 700, cursor: 'pointer',
          }}
        >
          Save
        </button>
      </div>
    </div>
  );
}
