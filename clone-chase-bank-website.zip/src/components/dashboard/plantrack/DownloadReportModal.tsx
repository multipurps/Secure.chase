import { useState } from 'react';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

const blue = '#2558b5';
const now = new Date();
const YEARS = [now.getFullYear(), now.getFullYear() - 1];

const ACCOUNTS = [
  { label: 'CREDIT CARD (...1234)', sub: 'J.P. Morgan Chase' },
  { label: 'CREDIT CARD (...5678)', sub: 'J.P. Morgan Chase' },
];

const TIMEFRAMES = [
  { label: 'Year to date' },
  { label: String(YEARS[1]) },
];

const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

interface Props {
  onClose: () => void;
}

export default function DownloadReportModal({ onClose }: Props) {
  const [selectedAcct, setSelectedAcct] = useState(0);
  const [selectedTf, setSelectedTf] = useState(0);
  const [generating, setGenerating] = useState(false);
  const [visible] = useState(true);

  function generatePDF() {
    setGenerating(true);
    setTimeout(() => {
      const doc = new jsPDF();
      const acct = ACCOUNTS[selectedAcct];
      const tf = TIMEFRAMES[selectedTf];
      const year = tf.label === 'Year to date' ? now.getFullYear() : parseInt(tf.label);

      // Title
      doc.setFontSize(20);
      doc.setTextColor(37, 88, 181);
      doc.text('CHASE', 20, 22);
      doc.setFontSize(12);
      doc.setTextColor(80, 80, 80);
      doc.text(`Spending Report — ${acct.label}`, 20, 32);
      doc.text(`Time frame: ${tf.label}`, 20, 40);
      doc.text(`Generated: ${now.toLocaleDateString('en-US', { month:'long', day:'numeric', year:'numeric' })}`, 20, 48);

      // Monthly spending table
      doc.setFontSize(13);
      doc.setTextColor(20, 20, 20);
      doc.text('Monthly Spending & Income', 20, 62);

      const SPENDING = [3200,2800,4100,3650,2900,1400,0,0,0,0,0,0];
      const INCOME   = [4200,3900,5100,4800,4100,2000,0,0,0,0,0,0];

      const rows = MONTHS.map((m, i) => [
        `${m} ${year}`,
        SPENDING[i] ? `$${SPENDING[i].toLocaleString()}` : '—',
        INCOME[i]   ? `$${INCOME[i].toLocaleString()}`   : '—',
      ]);

      autoTable(doc, {
        startY: 68,
        head: [['Month', 'Spending', 'Income']],
        body: rows,
        styles: { fontSize: 11, cellPadding: 5 },
        headStyles: { fillColor: [37, 88, 181], textColor: 255 },
        alternateRowStyles: { fillColor: [245, 247, 250] },
      });

      const afterTable = (doc as any).lastAutoTable.finalY + 10;

      // Category breakdown
      doc.setFontSize(13);
      doc.setTextColor(20, 20, 20);
      doc.text('Spending by Category', 20, afterTable);

      const cats = [
        ['Gifts & donations', '$800'],
        ['Food & drink',      '$250'],
        ['Shopping',          '$180'],
        ['Bills & utilities', '$120'],
        ['Groceries',         '$175'],
        ['Entertainment',     '$95'],
        ['Gas',               '$60'],
        ['Other',             '$120'],
      ];

      autoTable(doc, {
        startY: afterTable + 6,
        head: [['Category', 'Amount']],
        body: cats,
        styles: { fontSize: 11, cellPadding: 5 },
        headStyles: { fillColor: [37, 88, 181], textColor: 255 },
        alternateRowStyles: { fillColor: [245, 247, 250] },
      });

      const afterCats = (doc as any).lastAutoTable.finalY + 10;

      // Top merchants
      doc.setFontSize(13);
      doc.setTextColor(20, 20, 20);
      doc.text('Top Merchants', 20, afterCats);

      const merch = [
        ['SageTech',               '1 transaction',  '$3,000'],
        ['Morton Schall Corp.',    '1 transaction',  '$1,000'],
        ['Epicurean Nest Vineyard','1 transaction',  '$500'],
        ["Guard Llama Games",      '2 transactions', '$120'],
        ["Drip N' Sip Coffee",     '11 transactions','$100'],
      ];

      autoTable(doc, {
        startY: afterCats + 6,
        head: [['Merchant', 'Transactions', 'Total Spent']],
        body: merch,
        styles: { fontSize: 11, cellPadding: 5 },
        headStyles: { fillColor: [37, 88, 181], textColor: 255 },
        alternateRowStyles: { fillColor: [245, 247, 250] },
      });

      // Footer
      const pageH = doc.internal.pageSize.height;
      doc.setFontSize(9);
      doc.setTextColor(150,150,150);
      doc.text('© 2025 JPMorgan Chase Bank, N.A. Member FDIC', 20, pageH - 12);

      doc.save(`Chase_Spending_Report_${tf.label.replace(/ /g,'_')}.pdf`);
      setGenerating(false);
      onClose();
    }, 600);
  }

  return (
    <div style={{ position: 'fixed', inset: 0, zIndex: 300, display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
      {/* Backdrop */}
      <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.45)' }} onClick={onClose} />

      {/* Sheet */}
      <div style={{
        position: 'relative', background: '#fff', borderRadius: '16px 16px 0 0',
        zIndex: 1, paddingBottom: 32,
        transform: visible ? 'translateY(0)' : 'translateY(100%)',
        transition: 'transform 0.3s ease',
      }}>
        {/* Handle */}
        <div style={{ width: 40, height: 4, background: '#ddd', borderRadius: 2, margin: '12px auto 16px' }} />

        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 20px 14px', borderBottom: '1px solid #f0f0f0' }}>
          <div style={{ width: 28 }} />
          <div style={{ fontSize: 16, fontWeight: 700, color: '#111' }}>Choose spending report</div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
              <path d="M18 6L6 18M6 6l12 12" stroke="#aaa" strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </button>
        </div>

        {/* Account section */}
        <div style={{ background: '#f5f5f5', padding: '6px 20px', fontSize: 11, fontWeight: 700, color: '#888', letterSpacing: 0.5, textTransform: 'uppercase' }}>
          Credit Card
        </div>
        {ACCOUNTS.map((a, i) => (
          <button
            key={i}
            onClick={() => setSelectedAcct(i)}
            style={{ display: 'flex', alignItems: 'center', width: '100%', background: 'none', border: 'none', padding: '14px 20px', borderBottom: '1px solid #f0f0f0', cursor: 'pointer', gap: 14 }}
          >
            <div style={{
              width: 22, height: 22, borderRadius: '50%', border: `2px solid ${selectedAcct === i ? blue : '#ccc'}`,
              display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
            }}>
              {selectedAcct === i && <div style={{ width: 11, height: 11, borderRadius: '50%', background: blue }} />}
            </div>
            <div style={{ textAlign: 'left' }}>
              <div style={{ fontSize: 15, fontWeight: 600, color: '#111' }}>{a.label}</div>
              <div style={{ fontSize: 12, color: '#888' }}>{a.sub}</div>
            </div>
          </button>
        ))}

        {/* Timeframe section */}
        <div style={{ background: '#f5f5f5', padding: '6px 20px', fontSize: 11, fontWeight: 700, color: '#888', letterSpacing: 0.5, textTransform: 'uppercase' }}>
          Time Frame
        </div>
        {TIMEFRAMES.map((tf, i) => (
          <button
            key={i}
            onClick={() => setSelectedTf(i)}
            style={{ display: 'flex', alignItems: 'center', width: '100%', background: 'none', border: 'none', padding: '14px 20px', borderBottom: '1px solid #f0f0f0', cursor: 'pointer', gap: 14 }}
          >
            <div style={{
              width: 22, height: 22, borderRadius: '50%', border: `2px solid ${selectedTf === i ? blue : '#ccc'}`,
              display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
            }}>
              {selectedTf === i && <div style={{ width: 11, height: 11, borderRadius: '50%', background: blue }} />}
            </div>
            <span style={{ fontSize: 15, color: '#111' }}>{tf.label}</span>
          </button>
        ))}

        {/* Apply button */}
        <div style={{ padding: '20px 20px 0' }}>
          <button
            onClick={generatePDF}
            disabled={generating}
            style={{
              width: '100%', background: generating ? '#aaa' : blue, color: '#fff',
              border: 'none', borderRadius: 8, padding: '16px', fontSize: 17, fontWeight: 700,
              cursor: generating ? 'not-allowed' : 'pointer',
            }}
          >
            {generating ? 'Generating PDF...' : 'Apply'}
          </button>
        </div>
      </div>
    </div>
  );
}
