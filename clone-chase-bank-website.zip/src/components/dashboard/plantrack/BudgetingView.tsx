import { useState } from 'react';

const blue = '#2558b5';

const BUDGET_ROWS = [
  { name: 'Food & drink',          color: '#e67e22', icon: '🍴', spent: 250, budget: 500 },
  { name: 'Professional services', color: '#1a3a6b', icon: '💼', spent: 250, budget: 500 },
  { name: 'Groceries',             color: '#2558b5', icon: '🛒', spent: 175, budget: 425 },
  { name: 'Gifts & donations',     color: '#6b2fa0', icon: '🎁', spent: 800, budget: 500 },
  { name: 'Entertainment',         color: '#c9a227', icon: '🎬', spent: 95,  budget: 200 },
  { name: 'Shopping',              color: '#2e8b6e', icon: '🛍',  spent: 890, budget: 1000 },
];

// Category icon as SVG-colored circle
function CatIcon({ color }: { color: string; name: string }) {
  return (
    <div style={{
      width: 34, height: 34, borderRadius: '50%',
      background: color + '22', border: `1.5px solid ${color}`,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontSize: 16, flexShrink: 0,
    }}>
      <div style={{ width: 16, height: 16, borderRadius: 2, background: color, opacity: 0.8 }} />
    </div>
  );
}

interface Props {
  currentMonthLabel: string;
  onSetBudget: () => void;
  onCategoryDetail: (cat: string) => void;
}

export default function BudgetingView({ onSetBudget, onCategoryDetail }: Props) {
  const [showMore, setShowMore] = useState(false);

  const rows = showMore ? BUDGET_ROWS : BUDGET_ROWS.slice(0, 4);

  return (
    <div>
      {rows.map((row, i) => {
        const over = row.spent > row.budget;
        const pct = Math.min((row.spent / row.budget) * 100, 100);
        const diff = Math.abs(row.budget - row.spent);
        const barColor = over ? '#6b2fa0' : '#4caf50';

        return (
          <button
            key={i}
            onClick={() => onCategoryDetail(row.name)}
            style={{
              display: 'flex', alignItems: 'flex-start', width: '100%',
              background: 'none', border: 'none', padding: '14px 0',
              borderBottom: '1px solid #f0f0f0', cursor: 'pointer', gap: 12,
              textAlign: 'left',
            }}
          >
            <CatIcon color={row.color} name={row.name} />
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
                <span style={{ fontSize: 15, fontWeight: 700, color: '#111' }}>{row.name}</span>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                  <path d="M9 18l6-6-6-6" stroke="#bbb" strokeWidth="2" strokeLinecap="round"/>
                </svg>
              </div>
              <div style={{ fontSize: 13, color: over ? '#e67e22' : '#4caf50', marginBottom: 8, fontWeight: 600 }}>
                {over
                  ? `○ $${diff.toLocaleString()} over budget`
                  : `✓ $${diff.toLocaleString()} left`
                }
              </div>
              {/* Progress bar */}
              <div style={{ height: 8, background: '#eee', borderRadius: 4, overflow: 'hidden', marginBottom: 6 }}>
                <div style={{
                  height: '100%', width: `${pct}%`,
                  background: barColor, borderRadius: 4,
                  transition: 'width 0.6s ease',
                }} />
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ fontSize: 12, color: '#888' }}>${row.spent.toLocaleString()} spent</span>
                <span style={{ fontSize: 12, color: '#888' }}>${row.budget.toLocaleString()} budget</span>
              </div>
            </div>
          </button>
        );
      })}

      {/* Bottom row */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 14, paddingTop: 8, borderTop: '1px solid #f0f0f0' }}>
        <button
          onClick={() => setShowMore(v => !v)}
          style={{ background: 'none', border: 'none', color: blue, fontSize: 14, cursor: 'pointer', padding: 0 }}
        >
          {showMore ? '^ Show less' : '∨ Show more'}
        </button>
        <button
          onClick={onSetBudget}
          style={{
            background: 'none', border: `1.5px solid ${blue}`, borderRadius: 999,
            color: blue, fontSize: 14, fontWeight: 600, padding: '9px 20px', cursor: 'pointer',
          }}
        >
          Set a budget
        </button>
      </div>
    </div>
  );
}
