import { useState } from 'react';

const blue = '#2558b5';

const MERCHANTS = [
  { name: 'SageTech',                  txns: 1,  total: 3000 },
  { name: 'Morton Schall Corp.',        txns: 1,  total: 1000 },
  { name: 'Epicurean Nest Vineyard',    txns: 1,  total: 500  },
  { name: 'Guard Llama Games',          txns: 2,  total: 120  },
  { name: "Drip N' Sip Coffee",         txns: 11, total: 100  },
  { name: 'Chase Credit Card Payment',  txns: 1,  total: 85   },
  { name: 'Whole Foods Market',         txns: 3,  total: 74   },
  { name: 'Shell Gas Station',          txns: 4,  total: 61   },
];

type SortMode = 'spent' | 'txns';

interface Props {
  currentMonthLabel: string;
}

export default function SpendingByMerchant({ currentMonthLabel }: Props) {
  const [sort, setSort] = useState<SortMode>('spent');
  const [showMore, setShowMore] = useState(false);

  const sorted = [...MERCHANTS].sort((a, b) =>
    sort === 'spent' ? b.total - a.total : b.txns - a.txns
  );
  const displayed = showMore ? sorted : sorted.slice(0, 5);

  return (
    <div style={{
      background: '#fff', borderRadius: 12, padding: '20px 16px',
      boxShadow: '0 2px 8px rgba(0,0,0,0.06)', marginBottom: 16,
    }}>
      {/* Heading */}
      <div style={{ marginBottom: 4 }}>
        <div style={{ fontSize: 17, fontWeight: 700, color: '#111' }}>
          {currentMonthLabel} spending by merchant
        </div>
        <div style={{ fontSize: 13, color: '#888', marginTop: 3 }}>
          on your Chase or J.P. Morgan credit cards
        </div>
      </div>

      {/* Toggle tabs */}
      <div style={{ display: 'flex', background: '#f0f0f0', borderRadius: 8, padding: 3, margin: '14px 0', gap: 3 }}>
        {(['spent', 'txns'] as SortMode[]).map(s => (
          <button
            key={s}
            onClick={() => setSort(s)}
            style={{
              flex: 1, padding: '9px 0', borderRadius: 6, cursor: 'pointer',
              background: sort === s ? '#fff' : 'transparent',
              color: sort === s ? blue : '#888',
              fontWeight: sort === s ? 700 : 400,
              fontSize: 13,
              outline: sort === s ? `1.5px solid ${blue}` : '1.5px solid transparent',
              border: 'none',
              transition: 'all 0.2s',
            } as any}
          >
            {s === 'spent' ? 'Most spent' : 'Most transactions'}
          </button>
        ))}
      </div>

      {/* Merchant rows */}
      {displayed.map((m, i) => (
        <button
          key={i}
          style={{
            display: 'flex', alignItems: 'center', width: '100%',
            background: 'none', border: 'none', padding: '14px 0',
            borderBottom: i < displayed.length - 1 ? '1px solid #f0f0f0' : 'none',
            cursor: 'pointer', gap: 14, textAlign: 'left',
          }}
        >
          {/* Avatar circle */}
          <div style={{
            width: 44, height: 44, borderRadius: '50%', background: '#f0f0f0',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 16, fontWeight: 700, color: '#555', flexShrink: 0,
          }}>
            {m.name.charAt(0).toUpperCase()}
          </div>

          {/* Center info */}
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 15, fontWeight: 700, color: '#111', marginBottom: 2 }}>{m.name}</div>
            <div style={{ fontSize: 13, color: '#888' }}>{m.txns} transaction{m.txns > 1 ? 's' : ''}</div>
          </div>

          {/* Right: amount + chevron */}
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontSize: 16, fontWeight: 700, color: '#111' }}>
              ${m.total.toLocaleString()}.00
            </div>
            <div style={{ fontSize: 12, color: '#aaa' }}>total</div>
          </div>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" style={{ flexShrink: 0 }}>
            <path d="M9 18l6-6-6-6" stroke="#bbb" strokeWidth="2" strokeLinecap="round"/>
          </svg>
        </button>
      ))}

      {/* Footer row */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 12, borderTop: '1px solid #f0f0f0', paddingTop: 10 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          <div style={{
            width: 18, height: 18, borderRadius: '50%', border: `1.5px solid ${blue}`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: blue, fontSize: 11, fontWeight: 700,
          }}>?</div>
        </div>
        <button
          onClick={() => setShowMore(v => !v)}
          style={{ background: 'none', border: 'none', color: blue, fontSize: 13, cursor: 'pointer', padding: 0 }}
        >
          {showMore ? '^ See fewer merchants' : '∨ See more merchants'}
        </button>
      </div>
    </div>
  );
}
