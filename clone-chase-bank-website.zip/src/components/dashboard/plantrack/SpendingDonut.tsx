import { useState, useEffect } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';

const blue = '#2558b5';

const CATEGORIES = [
  { name: 'Gifts & donations', amount: 800, color: '#6b2fa0' },
  { name: 'Food & drink',      amount: 250, color: '#e67e22' },
  { name: 'Shopping',          amount: 180, color: '#2e8b6e' },
  { name: 'Bills & utilities', amount: 120, color: '#1a3a6b' },
  { name: 'Groceries',         amount: 175, color: '#2558b5' },
  { name: 'Entertainment',     amount: 95,  color: '#c9a227' },
  { name: 'Gas',               amount: 60,  color: '#c0272d' },
  { name: 'Other',             amount: 120, color: '#aaa' },
];

const total = CATEGORIES.reduce((a, b) => a + b.amount, 0);

interface Props {
  currentMonthLabel: string;
  onSetBudget: () => void;
  onDownloadReport: () => void;
  onBudgetingView: () => void;
  renderBudgeting: (active: boolean) => React.ReactNode;
}

export default function SpendingDonut({ currentMonthLabel, onSetBudget, onDownloadReport, renderBudgeting }: Props) {
  const [tab, setTab] = useState<'spending' | 'budgeting'>('spending');
  const [selectedIdx, setSelectedIdx] = useState(0);
  const [showAll, setShowAll] = useState(false);
  const [animated, setAnimated] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setAnimated(true), 200);
    return () => clearTimeout(t);
  }, []);

  const selected = CATEGORIES[selectedIdx];
  const pct = Math.round((selected.amount / total) * 100);

  // Expand segments slightly on select
  const displayCats = showAll ? CATEGORIES : CATEGORIES.slice(0, 5);

  return (
    <div style={{
      background: '#fff', borderRadius: 12, padding: '20px 16px',
      boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
      transform: animated ? 'scale(1)' : 'scale(0.97)',
      opacity: animated ? 1 : 0,
      transition: 'transform 300ms ease, opacity 300ms ease',
    }}>
      {/* Heading */}
      <div style={{ fontSize: 17, fontWeight: 700, color: '#111', marginBottom: 14 }}>
        {currentMonthLabel} spending by category
      </div>

      {/* Toggle tabs */}
      <div style={{ display: 'flex', background: '#f0f0f0', borderRadius: 8, padding: 3, marginBottom: 16, gap: 3 }}>
        {(['spending', 'budgeting'] as const).map(t => (
          <button
            key={t}
            onClick={() => setTab(t)}
            style={{
              flex: 1, padding: '9px 0', borderRadius: 6, cursor: 'pointer',
              background: tab === t ? '#fff' : 'transparent',
              color: tab === t ? blue : '#888',
              fontWeight: tab === t ? 700 : 400,
              fontSize: 14,
              outline: tab === t ? `1.5px solid ${blue}` : '1.5px solid transparent',
              transition: 'all 0.2s',
              textTransform: 'capitalize',
            } as any}
          >
            {t.charAt(0).toUpperCase() + t.slice(1)}
          </button>
        ))}
      </div>

      {tab === 'spending' ? (
        <>
          {/* Donut chart */}
          <div style={{ position: 'relative', height: 230 }}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={CATEGORIES}
                  dataKey="amount"
                  cx="50%"
                  cy="50%"
                  innerRadius={58}
                  outerRadius={82}
                  startAngle={90}
                  endAngle={-270}
                  strokeWidth={2}
                  stroke="#fff"
                  isAnimationActive={animated}
                  animationDuration={600}
                  animationEasing="ease-out"
                  onClick={(_, idx) => setSelectedIdx(idx)}
                  style={{ cursor: 'pointer' }}
                >
                  {CATEGORIES.map((cat, i) => (
                    <Cell
                      key={i}
                      fill={cat.color}
                      opacity={selectedIdx === i ? 1 : 0.75}
                      style={{ outline: 'none', filter: selectedIdx === i ? 'drop-shadow(0 0 4px rgba(0,0,0,0.2))' : 'none' }}
                    />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            {/* Center label */}
            <div style={{
              position: 'absolute', top: '50%', left: '50%',
              transform: 'translate(-50%, -50%)',
              textAlign: 'center', pointerEvents: 'none',
            }}>
              <div style={{ fontSize: 12, color: blue, fontWeight: 700, maxWidth: 90, lineHeight: 1.3 }}>
                {selected.name} ›
              </div>
              <div style={{ fontSize: 22, fontWeight: 800, color: '#111', marginTop: 4 }}>
                ${selected.amount.toLocaleString()}
              </div>
              <div style={{ fontSize: 11, color: '#888', marginTop: 2 }}>
                {pct}% of total
              </div>
            </div>
          </div>

          {/* Set a budget button */}
          <div style={{ display: 'flex', justifyContent: 'center', marginTop: 8 }}>
            <button
              onClick={onSetBudget}
              style={{
                background: 'none', border: `1.5px solid ${blue}`, borderRadius: 999,
                color: blue, fontSize: 14, fontWeight: 600, padding: '10px 24px', cursor: 'pointer',
              }}
            >
              Set a budget
            </button>
          </div>

          {/* Show all categories */}
          <div style={{ marginTop: 14, borderTop: '1px solid #f0f0f0', paddingTop: 12 }}>
            {displayCats.map((cat, i) => (
              <button
                key={i}
                onClick={() => setSelectedIdx(i)}
                style={{
                  display: 'flex', alignItems: 'center', width: '100%',
                  background: selectedIdx === i ? '#f5f7ff' : 'none',
                  border: 'none', padding: '8px 6px', borderRadius: 6,
                  cursor: 'pointer', marginBottom: 4,
                }}
              >
                <div style={{ width: 12, height: 12, borderRadius: '50%', background: cat.color, marginRight: 10, flexShrink: 0 }} />
                <div style={{ flex: 1, textAlign: 'left', fontSize: 14, color: '#333' }}>{cat.name}</div>
                <div style={{ fontSize: 14, fontWeight: 600, color: '#111' }}>${cat.amount.toLocaleString()}</div>
              </button>
            ))}
            <button
              onClick={() => setShowAll(v => !v)}
              style={{ background: 'none', border: 'none', color: blue, fontSize: 14, cursor: 'pointer', width: '100%', textAlign: 'center', marginTop: 6, padding: '6px 0' }}
            >
              {showAll ? '^ Show less' : '∨ Show all categories'}
            </button>
          </div>

          {/* Download */}
          <div style={{ marginTop: 8, borderTop: '1px solid #f0f0f0', paddingTop: 10, textAlign: 'center' }}>
            <button
              onClick={onDownloadReport}
              style={{ background: 'none', border: 'none', color: blue, fontSize: 13, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 4 }}
            >
              <span style={{ fontSize: 15 }}>&#8595;</span> Download spending report
            </button>
          </div>
        </>
      ) : (
        <>{renderBudgeting(true)}</>
      )}
    </div>
  );
}
