import { useEffect, useState } from 'react';

const blue = '#2558b5';

const CAT_COLORS: Record<string, string> = {
  'Total':                 blue,
  'Groceries':             '#2558b5',
  'Food & drink':          '#e67e22',
  'Shopping':              '#2e8b6e',
  'Entertainment':         '#c9a227',
  'Gifts & donations':     '#6b2fa0',
  'Bills & utilities':     '#1a3a6b',
  'Gas':                   '#c0272d',
  'Health & wellness':     '#2e8b6e',
  'Automotive':            '#2558b5',
  'Education':             '#1a3a6b',
  'Travel':                '#2558b5',
};

interface Props {
  budgetsSet: string[];
  onAddMore: () => void;
  onDone: () => void;
}

export default function BudgetConfirmation({ budgetsSet, onAddMore, onDone }: Props) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setVisible(true), 100);
    return () => clearTimeout(t);
  }, []);

  return (
    <div style={{
      width: '100%', height: '100%', background: '#fff',
      fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      padding: '40px 32px',
      opacity: visible ? 1 : 0,
      transition: 'opacity 0.4s ease',
    }}>
      {/* Green checkmark */}
      <div style={{
        width: 72, height: 72, borderRadius: '50%', background: '#4caf50',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        marginBottom: 20,
        transform: visible ? 'scale(1)' : 'scale(0.5)',
        transition: 'transform 0.4s cubic-bezier(0.34,1.56,0.64,1)',
      }}>
        <svg width="36" height="36" viewBox="0 0 24 24" fill="none">
          <path d="M5 12l5 5L20 7" stroke="#fff" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"
            style={{
              strokeDasharray: 30,
              strokeDashoffset: visible ? 0 : 30,
              transition: 'stroke-dashoffset 0.5s ease 0.3s',
            }}
          />
        </svg>
      </div>

      <div style={{ fontSize: 24, fontWeight: 800, color: '#111', marginBottom: 12, textAlign: 'center' }}>
        Budget set
      </div>
      <div style={{ fontSize: 15, color: '#666', textAlign: 'center', lineHeight: 1.6, maxWidth: 280, marginBottom: 32 }}>
        Stay on top of your spending throughout the month by checking on your budget.
      </div>

      {/* Category icons row */}
      {budgetsSet.length > 0 && (
        <div style={{ display: 'flex', gap: 14, marginBottom: 32, flexWrap: 'wrap', justifyContent: 'center' }}>
          {budgetsSet.map((cat, i) => (
            <div key={i} style={{
              width: 44, height: 44, borderRadius: '50%',
              background: (CAT_COLORS[cat] ?? blue) + '22',
              border: `2px solid ${CAT_COLORS[cat] ?? blue}`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <div style={{ width: 18, height: 18, borderRadius: 3, background: CAT_COLORS[cat] ?? blue }} />
            </div>
          ))}
        </div>
      )}

      {/* Add more budgets */}
      <button
        onClick={onAddMore}
        style={{
          display: 'flex', alignItems: 'center', gap: 8,
          background: 'none', border: `1.5px solid ${blue}`, borderRadius: 999,
          color: blue, fontSize: 15, fontWeight: 600, padding: '12px 28px', cursor: 'pointer',
          marginBottom: 24,
        }}
      >
        <span style={{ fontSize: 20, lineHeight: 1 }}>&#8853;</span> Add more budgets
      </button>

      <div style={{ flex: 1 }} />

      {/* Done */}
      <button
        onClick={onDone}
        style={{
          width: '100%', background: blue, color: '#fff', border: 'none',
          borderRadius: 8, padding: '16px', fontSize: 17, fontWeight: 700, cursor: 'pointer',
          maxWidth: 400,
        }}
      >
        Done
      </button>
    </div>
  );
}
