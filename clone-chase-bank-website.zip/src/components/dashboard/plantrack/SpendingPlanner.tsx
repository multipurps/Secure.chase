import { useState } from 'react';
import SpendingBarChart from './SpendingBarChart';
import SpendingDonut from './SpendingDonut';
import BudgetingView from './BudgetingView';
import SetBudgetPicker from './SetBudgetPicker';
import BudgetAmountEntry from './BudgetAmountEntry';
import BudgetConfirmation from './BudgetConfirmation';
import SpendingByMerchant from './SpendingByMerchant';
import DownloadReportModal from './DownloadReportModal';

const blue = '#2558b5';
const darkNav = '#1a3a6b';

const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];


export type SpendingView = 'main' | 'set-budget-picker' | 'budget-amount' | 'budget-confirmation' | 'budget-detail';

interface SpendingPlannerProps {
  onBack: () => void;
}

function getAutoMonths(): { label: string; short: string; year: number; monthIdx: number }[] {
  const now = new Date();
  const result = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    result.push({
      label: MONTHS[d.getMonth()],
      short: MONTHS[d.getMonth()].slice(0, 3),
      year: d.getFullYear(),
      monthIdx: d.getMonth(),
    });
  }
  return result;
}

export default function SpendingPlanner({ onBack }: SpendingPlannerProps) {
  const [view, setView] = useState<SpendingView>('main');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [budgetsSet, setBudgetsSet] = useState<string[]>([]);
  const [showDownloadModal, setShowDownloadModal] = useState(false);
  const [showAccountSheet, setShowAccountSheet] = useState(false);
  const [showTimeframeSheet, setShowTimeframeSheet] = useState(false);
  const [selectedAccount, setSelectedAccount] = useState('All accounts');
  const now = new Date();
  const [selectedMonth, setSelectedMonth] = useState(now.getMonth());
  const [selectedYear, setSelectedYear] = useState(now.getFullYear());
  const [tempMonth, setTempMonth] = useState(now.getMonth());
  const [tempYear, setTempYear] = useState(now.getFullYear());

  const months6 = getAutoMonths();
  const currentMonthLabel = MONTHS[selectedMonth];

  function handleSaveBudget(category: string, _amount: number) {
    if (!budgetsSet.includes(category)) setBudgetsSet(prev => [...prev, category]);
    setView('budget-confirmation');
  }

  function handleCategorySelect(cat: string) {
    setSelectedCategory(cat);
    setView('budget-amount');
  }

  if (view === 'set-budget-picker') {
    return <SetBudgetPicker onBack={() => setView('main')} onSelectCategory={handleCategorySelect} />;
  }
  if (view === 'budget-amount' && selectedCategory) {
    return (
      <BudgetAmountEntry
        category={selectedCategory}
        onBack={() => setView('set-budget-picker')}
        onSave={(amt: number) => handleSaveBudget(selectedCategory, amt)}
      />
    );
  }
  if (view === 'budget-confirmation') {
    return (
      <BudgetConfirmation
        budgetsSet={budgetsSet}
        onAddMore={() => setView('set-budget-picker')}
        onDone={() => setView('main')}
      />
    );
  }

  return (
    <div style={{
      width: '100%', height: '100%', overflowY: 'auto', background: '#f0f4f8',
      fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
      position: 'relative',
    }}>
      {/* Global Header */}
      <div style={{ background: darkNav, position: 'sticky', top: 0, zIndex: 50 }}>
        {/* Title bar */}
        <div style={{ display: 'flex', alignItems: 'center', padding: '14px 16px 10px' }}>
          <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0, marginRight: 12 }}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
              <path d="M15 18l-6-6 6-6" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
          <div style={{ flex: 1, textAlign: 'center', color: '#fff', fontWeight: 700, fontSize: 17 }}>Spending Planner</div>
          <div style={{ width: 34 }} />
        </div>
        {/* Filter row */}
        <div style={{
          display: 'flex', gap: 12, margin: '0 16px 12px', background: '#1e4a80',
          borderRadius: 8, padding: '10px 14px',
        }}>
          <div style={{ flex: 1 }}>
            <div style={{ color: 'rgba(255,255,255,0.7)', fontSize: 11, marginBottom: 4 }}>Account</div>
            <button
              onClick={() => setShowAccountSheet(true)}
              style={{ background: 'none', border: 'none', color: '#fff', fontSize: 14, fontWeight: 600, cursor: 'pointer', padding: 0, display: 'flex', alignItems: 'center', gap: 4 }}
            >
              {selectedAccount}
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M6 9l6 6 6-6" stroke="#fff" strokeWidth="2" strokeLinecap="round"/></svg>
            </button>
          </div>
          <div style={{ width: 1, background: 'rgba(255,255,255,0.2)' }} />
          <div style={{ flex: 1 }}>
            <div style={{ color: 'rgba(255,255,255,0.7)', fontSize: 11, marginBottom: 4 }}>Time frame</div>
            <button
              onClick={() => { setTempMonth(selectedMonth); setTempYear(selectedYear); setShowTimeframeSheet(true); }}
              style={{ background: 'none', border: 'none', color: '#fff', fontSize: 14, fontWeight: 600, cursor: 'pointer', padding: 0, display: 'flex', alignItems: 'center', gap: 4 }}
            >
              {MONTHS[selectedMonth].slice(0,3)} {selectedYear}
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M6 9l6 6 6-6" stroke="#fff" strokeWidth="2" strokeLinecap="round"/></svg>
            </button>
          </div>
        </div>
      </div>

      {/* SECTION 1 — Bar Chart */}
      <div style={{ padding: '16px 16px 0' }}>
        <SpendingBarChart
          months6={months6}
          currentMonthLabel={currentMonthLabel}
          onSeeAllTransactions={() => {}}
        />
      </div>

      {/* SECTION 2 + 3 — Donut / Budgeting toggle */}
      <div style={{ padding: '14px 16px 0' }}>
        <SpendingDonut
          currentMonthLabel={currentMonthLabel}
          onSetBudget={() => setView('set-budget-picker')}
          onDownloadReport={() => setShowDownloadModal(true)}
          onBudgetingView={() => {}}
          renderBudgeting={(_active: boolean) => (
            <BudgetingView
              currentMonthLabel={currentMonthLabel}
              onSetBudget={() => setView('set-budget-picker')}
              onCategoryDetail={(cat: string) => { setSelectedCategory(cat); setView('budget-amount'); }}
            />
          )}
        />
      </div>

      {/* SECTION 4 — Spending by Merchant */}
      <div style={{ padding: '14px 16px 0' }}>
        <SpendingByMerchant currentMonthLabel={currentMonthLabel} />
      </div>

      <div style={{ height: 40 }} />

      {/* ACCOUNT BOTTOM SHEET */}
      {showAccountSheet && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 200, display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
          <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.4)' }} onClick={() => setShowAccountSheet(false)} />
          <div style={{ position: 'relative', background: '#fff', borderRadius: '16px 16px 0 0', padding: '20px 24px 40px', zIndex: 1 }}>
            <div style={{ width: 40, height: 4, background: '#ccc', borderRadius: 2, margin: '0 auto 20px' }} />
            <div style={{ fontSize: 16, fontWeight: 700, color: '#111', marginBottom: 16 }}>Choose Account</div>
            {['All accounts', 'HIGH SCHOOL CHECKING (...8721)', 'SAVINGS (...4521)'].map(acc => (
              <button key={acc} onClick={() => { setSelectedAccount(acc); setShowAccountSheet(false); }}
                style={{ display: 'flex', alignItems: 'center', width: '100%', background: 'none', border: 'none', padding: '14px 0', borderBottom: '1px solid #f0f0f0', cursor: 'pointer', gap: 12 }}>
                <div style={{ width: 20, height: 20, borderRadius: '50%', border: `2px solid ${selectedAccount === acc ? blue : '#ccc'}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  {selectedAccount === acc && <div style={{ width: 10, height: 10, borderRadius: '50%', background: blue }} />}
                </div>
                <span style={{ fontSize: 15, color: '#111' }}>{acc}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* TIMEFRAME BOTTOM SHEET */}
      {showTimeframeSheet && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 200, display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
          <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.4)' }} onClick={() => setShowTimeframeSheet(false)} />
          <div style={{ position: 'relative', background: '#fff', borderRadius: '16px 16px 0 0', padding: '20px 0 0', zIndex: 1, maxHeight: '70vh', overflow: 'auto' }}>
            <div style={{ width: 40, height: 4, background: '#ccc', borderRadius: 2, margin: '0 auto 16px' }} />
            <div style={{ padding: '0 24px', fontSize: 16, fontWeight: 700, color: '#111', marginBottom: 12 }}>Choose Time Frame</div>
            <div style={{ background: '#f5f5f5', padding: '6px 24px', fontSize: 11, fontWeight: 700, color: '#888', letterSpacing: 0.5, textTransform: 'uppercase' }}>MONTH</div>
            {MONTHS.map((m, i) => (
              <button key={m} onClick={() => setTempMonth(i)}
                style={{ display: 'flex', alignItems: 'center', width: '100%', background: 'none', border: 'none', padding: '13px 24px', borderBottom: '1px solid #f0f0f0', cursor: 'pointer', gap: 12 }}>
                <div style={{ width: 20, height: 20, borderRadius: '50%', border: `2px solid ${tempMonth === i ? blue : '#ccc'}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  {tempMonth === i && <div style={{ width: 10, height: 10, borderRadius: '50%', background: blue }} />}
                </div>
                <span style={{ fontSize: 15, color: '#111' }}>{m}</span>
              </button>
            ))}
            <div style={{ background: '#f5f5f5', padding: '6px 24px', fontSize: 11, fontWeight: 700, color: '#888', letterSpacing: 0.5, textTransform: 'uppercase' }}>YEAR</div>
            {[now.getFullYear(), now.getFullYear() - 1, now.getFullYear() - 2].map(y => (
              <button key={y} onClick={() => setTempYear(y)}
                style={{ display: 'flex', alignItems: 'center', width: '100%', background: 'none', border: 'none', padding: '13px 24px', borderBottom: '1px solid #f0f0f0', cursor: 'pointer', gap: 12 }}>
                <div style={{ width: 20, height: 20, borderRadius: '50%', border: `2px solid ${tempYear === y ? blue : '#ccc'}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  {tempYear === y && <div style={{ width: 10, height: 10, borderRadius: '50%', background: blue }} />}
                </div>
                <span style={{ fontSize: 15, color: '#111' }}>{y}</span>
              </button>
            ))}
            <div style={{ padding: '16px 24px 32px' }}>
              <button onClick={() => { setSelectedMonth(tempMonth); setSelectedYear(tempYear); setShowTimeframeSheet(false); }}
                style={{ width: '100%', background: blue, color: '#fff', border: 'none', borderRadius: 8, padding: '15px', fontSize: 16, fontWeight: 700, cursor: 'pointer' }}>
                Apply
              </button>
            </div>
          </div>
        </div>
      )}

      {showDownloadModal && <DownloadReportModal onClose={() => setShowDownloadModal(false)} />}
    </div>
  );
}
