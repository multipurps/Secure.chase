import { useState, useEffect } from 'react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Cell,
} from 'recharts';

const blue = '#2558b5';
const green = '#4caf50';

// Demo spending + income per month (last 6 months)
const DEMO_DATA = [
  { spending: 3200, income: 4200 },
  { spending: 2800, income: 3900 },
  { spending: 4100, income: 5100 },
  { spending: 3650, income: 4800 },
  { spending: 2900, income: 4100 },
  { spending: 1400, income: 2000 },  // current month (partial)
];

interface Month { label: string; short: string; year: number; monthIdx: number }

interface Props {
  months6: Month[];
  currentMonthLabel: string;
  onSeeAllTransactions: () => void;
}

function formatYAxis(v: number) {
  if (v === 0) return '0';
  return `${v / 1000}K`;
}

// Custom tooltip
function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload || !payload.length) return null;
  return (
    <div style={{ background: '#fff', border: '1px solid #ddd', borderRadius: 8, padding: '10px 14px', fontSize: 13 }}>
      <div style={{ fontWeight: 700, marginBottom: 4, color: '#111' }}>{label}</div>
      {payload.map((p: any) => (
        <div key={p.name} style={{ color: p.color, marginBottom: 2 }}>
          {p.name}: <strong>${p.value.toLocaleString()}</strong>
        </div>
      ))}
    </div>
  );
}

export default function SpendingBarChart({ months6, currentMonthLabel, onSeeAllTransactions }: Props) {
  const [showIncome, setShowIncome] = useState(false);
  const [animated, setAnimated] = useState(false);
  const [showTable, setShowTable] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setAnimated(true), 100);
    return () => clearTimeout(t);
  }, []);

  const chartData = months6.map((m, i) => ({
    name: i === months6.length - 1
      ? `${m.short}\n${m.year}`
      : i === 0 ? `${m.short}\n${m.year}` : m.short,
    spending: DEMO_DATA[i].spending,
    income: DEMO_DATA[i].income,
    isCurrent: i === months6.length - 1,
  }));

  const currentSpending = DEMO_DATA[5].spending;
  const currentIncome = DEMO_DATA[5].income;
  const avgSpending = Math.round(DEMO_DATA.reduce((a, b) => a + b.spending, 0) / DEMO_DATA.length);

  return (
    <div style={{ background: '#fff', borderRadius: 12, padding: '20px 16px', boxShadow: '0 2px 8px rgba(0,0,0,0.06)' }}>
      {/* Header row */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 6 }}>
        <div>
          <div style={{ fontSize: 17, fontWeight: 700, color: '#111', marginBottom: 2 }}>
            {currentMonthLabel} spending{showIncome ? ' and income' : ''}
          </div>
          <div style={{ fontSize: 28, fontWeight: 800, color: '#111' }}>
            ${currentSpending.toLocaleString()}.00
          </div>
          <div style={{ fontSize: 13, color: '#888', marginTop: 2 }}>Spent so far</div>
        </div>
        {/* Income toggle */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 6 }}>
          <span style={{ fontSize: 14, color: '#555' }}>Income</span>
          <button
            onClick={() => setShowIncome(v => !v)}
            style={{
              width: 44, height: 26, borderRadius: 13, border: 'none', cursor: 'pointer',
              background: showIncome ? blue : '#ccc',
              position: 'relative', transition: 'background 0.25s',
              outline: 'none',
            }}
          >
            <div style={{
              position: 'absolute', top: 3, left: showIncome ? 21 : 3,
              width: 20, height: 20, borderRadius: '50%', background: '#fff',
              boxShadow: '0 1px 3px rgba(0,0,0,0.3)',
              transition: 'left 0.25s',
            }} />
          </button>
        </div>
      </div>

      {/* Chart */}
      <div style={{ height: 200, marginTop: 16 }}>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={chartData} barCategoryGap="30%" barGap={3} margin={{ top: 4, right: 4, bottom: 0, left: -20 }}>
            <CartesianGrid vertical={false} stroke="#f0f0f0" />
            <XAxis
              dataKey="name"
              tick={({ x, y, payload }: any) => {
                const isCur = payload.value.includes('\n') && chartData[chartData.length - 1].name === payload.value;
                const parts = payload.value.split('\n');
                return (
                  <g transform={`translate(${x},${y})`}>
                    <text
                      x={0} y={0} dy={12}
                      textAnchor="middle"
                      fontSize={11}
                      fontWeight={isCur ? 700 : 400}
                      fill={isCur ? blue : '#888'}
                      style={{ textDecoration: isCur ? 'underline' : 'none' }}
                    >
                      {parts[0]}
                    </text>
                    {parts[1] && (
                      <text x={0} y={0} dy={24} textAnchor="middle" fontSize={10} fill="#aaa">{parts[1]}</text>
                    )}
                  </g>
                );
              }}
              tickLine={false}
              axisLine={false}
              interval={0}
            />
            <YAxis tickFormatter={formatYAxis} tick={{ fontSize: 11, fill: '#aaa' }} tickLine={false} axisLine={false} />
            <Tooltip content={<CustomTooltip />} />
            <Bar dataKey="spending" name="Spending" fill={blue} radius={[3,3,0,0]} isAnimationActive={animated} animationDuration={600} animationEasing="ease-out">
              {chartData.map((entry, i) => (
                <Cell key={i} fill={entry.isCurrent ? '#1a3a6b' : blue} />
              ))}
            </Bar>
            {showIncome && (
              <Bar dataKey="income" name="Income" fill={green} radius={[3,3,0,0]} isAnimationActive={true} animationDuration={400} animationEasing="ease-out" />
            )}
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Legend + summary */}
      <div style={{ marginTop: 14, borderTop: '1px solid #f0f0f0', paddingTop: 12 }}>
        {showIncome && (
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <div style={{ width: 10, height: 10, borderRadius: '50%', background: green }} />
              <button style={{ background: 'none', border: 'none', color: blue, fontSize: 14, cursor: 'pointer', padding: 0, fontWeight: 500 }}>Income ›</button>
            </div>
            <div style={{ fontSize: 14, fontWeight: 700, color: '#111' }}>${currentIncome.toLocaleString()}.00</div>
          </div>
        )}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ width: 10, height: 10, borderRadius: '50%', background: blue }} />
            <button style={{ background: 'none', border: 'none', color: blue, fontSize: 14, cursor: 'pointer', padding: 0, fontWeight: 500 }}>Spending ›</button>
          </div>
          <div style={{ fontSize: 14, fontWeight: 700, color: '#111' }}>${currentSpending.toLocaleString()}.00</div>
        </div>
        {!showIncome && (
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
            <div style={{ fontSize: 14, fontWeight: 700, color: '#111' }}>Average spending</div>
            <div style={{ fontSize: 14, fontWeight: 700, color: '#111' }}>${avgSpending.toLocaleString()}.00</div>
          </div>
        )}
        {/* Bottom row */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 8, borderTop: '1px solid #f0f0f0', paddingTop: 10 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            <div style={{ width: 18, height: 18, borderRadius: '50%', border: `1.5px solid ${blue}`, display: 'flex', alignItems: 'center', justifyContent: 'center', color: blue, fontSize: 11, fontWeight: 700 }}>?</div>
          </div>
          <button onClick={() => setShowTable(v => !v)}
            style={{ background: 'none', border: 'none', color: blue, fontSize: 13, cursor: 'pointer', padding: 0, display: 'flex', alignItems: 'center', gap: 4 }}>
            <span style={{ fontSize: 14 }}>&#8801;</span> See chart as table
          </button>
        </div>
      </div>

      {/* Table view */}
      {showTable && (
        <div style={{ marginTop: 12, overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
            <thead>
              <tr style={{ background: '#f5f7fa' }}>
                <th style={{ padding: '8px 10px', textAlign: 'left', color: '#555', fontWeight: 600, borderBottom: '1px solid #eee' }}>Month</th>
                <th style={{ padding: '8px 10px', textAlign: 'right', color: '#555', fontWeight: 600, borderBottom: '1px solid #eee' }}>Spending</th>
                {showIncome && <th style={{ padding: '8px 10px', textAlign: 'right', color: '#555', fontWeight: 600, borderBottom: '1px solid #eee' }}>Income</th>}
              </tr>
            </thead>
            <tbody>
              {months6.map((m, i) => (
                <tr key={i} style={{ background: i === 5 ? '#f0f6ff' : 'transparent' }}>
                  <td style={{ padding: '8px 10px', color: '#333', borderBottom: '1px solid #f0f0f0', fontWeight: i === 5 ? 700 : 400 }}>{m.label} {m.year}</td>
                  <td style={{ padding: '8px 10px', textAlign: 'right', color: '#333', borderBottom: '1px solid #f0f0f0' }}>${DEMO_DATA[i].spending.toLocaleString()}</td>
                  {showIncome && <td style={{ padding: '8px 10px', textAlign: 'right', color: green, borderBottom: '1px solid #f0f0f0' }}>${DEMO_DATA[i].income.toLocaleString()}</td>}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* See all transactions */}
      <button
        onClick={onSeeAllTransactions}
        style={{
          width: '100%', marginTop: 16, padding: '13px', borderRadius: 999,
          border: `1.5px solid #ddd`, background: '#fff',
          color: blue, fontSize: 15, fontWeight: 600, cursor: 'pointer',
        }}
      >
        See all transactions
      </button>
    </div>
  );
}
