import { useState } from 'react';
import ChaseCreditCardThumbnail from './ChaseCreditCardThumbnail';
import PreferencesSheet from './PreferencesSheet';
import DashboardOffersWidget from './DashboardOffersWidget';
import CreditJourneyWidget from './CreditJourneyWidget';
import TrackSpendingWidget from './TrackSpendingWidget';
import TransactionsWidget from './TransactionsWidget';
import CreditCardDetail from './CreditCardDetail';
import CreditJourneyPage from './CreditJourneyPage';
import FullTransactionHistory from './FullTransactionHistory';
import SnapshotPage from './SnapshotPage';
import AccountDetail from './AccountDetail';
import UltimateRewards from './UltimateRewards';
import OpenAccountProducts from './OpenAccountProducts';
import QuickActionsSheet from './QuickActionsSheet';
import AddCardSheet from './AddCardSheet';
import LockUnlockCard from './LockUnlockCard';

interface AccountsDashboardProps {
  onProfile: () => void;
  onZelle?: () => void;
  onDeposit?: () => void;
  onPayTransfer?: () => void;
  onWires?: () => void;
  onOffers?: () => void;
  onPlanTrack?: () => void;
  onAccountDetail?: () => void;
  onChat?: () => void;
}

function getGreeting() {
  const h = new Date().getHours();
  if (h < 12) return 'Good morning';
  if (h < 17) return 'Good afternoon';
  return 'Good evening';
}

function getFormattedDate() {
  return new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
}

type SubView =
  | 'main'
  | 'card-detail-0'
  | 'credit-journey'
  | 'transactions'
  | 'snapshot'
  | 'account-detail-0'
  | 'account-detail-1'
  | 'account-detail-2'
  | 'account-detail-3'
  | 'rewards'
  | 'open-account'
  | 'lock-unlock';

const blue = '#2558b5';

// Single credit card (SS1 — only one card shown)
const CREDIT_CARDS = [
  {
    name: 'Amazon Prime Visa',
    last4: '4421',
    balance: '$0.00',
    paymentDate: '',
    imageUrl: 'https://creditcards.chase.com/K-Marketplace/images/cardbucket/amazonprimevisa/credit_card.png',
  },
];

const BANK_ACCOUNTS = [
  { name: 'CHASE TOTAL CHECKING', last4: '4892', balance: '$358,760,439.69', type: 'checking' },
  { name: 'CHASE SAVINGS', last4: '7231', balance: '$250,045,000.00', type: 'savings' },
  { name: 'CHASE BUSINESS COMPLETE', last4: '3156', balance: '$358,760,439.69', type: 'business' },
  { name: 'CHASE SAPPHIRE RESERVE', last4: '9847', balance: '$43,000.00', type: 'credit' },
];

const TOTAL_BANK = BANK_ACCOUNTS.reduce((sum, a) => {
  const num = parseFloat(a.balance.replace(/[$,]/g, ''));
  return sum + num;
}, 0);

const TOTAL_CREDIT = parseFloat(CREDIT_CARDS[0].balance.replace(/[$,]/g, ''));

// Illustrated open-account icons (matching SS6–SS17)
function CreditCardIcon() {
  return (
    <svg width="28" height="28" viewBox="0 0 52 52" fill="none">
      <rect x="4" y="10" width="44" height="32" rx="4" fill="#2558b5" />
      <polygon points="30,10 48,10 48,28" fill="rgba(255,255,255,0.1)" />
      <rect x="8" y="27" width="10" height="8" rx="1.5" fill="#d4af37" />
      <rect x="4" y="34" width="44" height="8" rx="0" fill="rgba(0,0,30,0.35)" />
    </svg>
  );
}
function CheckingIcon() {
  return (
    <svg width="28" height="28" viewBox="0 0 52 52" fill="none">
      <rect x="4" y="12" width="44" height="28" rx="4" fill="#2558b5" />
      <polygon points="28,12 48,12 48,30" fill="rgba(255,255,255,0.1)" />
      <rect x="10" y="20" width="32" height="4" rx="2" fill="rgba(255,255,255,0.85)" />
      <rect x="10" y="28" width="20" height="4" rx="2" fill="rgba(255,255,255,0.6)" />
    </svg>
  );
}
function SavingsIcon() {
  return (
    <svg width="28" height="28" viewBox="0 0 52 52" fill="none">
      <ellipse cx="26" cy="32" rx="16" ry="14" fill="#4472c4" />
      <circle cx="40" cy="26" r="8" fill="#4472c4" />
      <circle cx="26" cy="15" r="6" fill="#d4af37" />
      <text x="26" y="18.5" textAnchor="middle" fontSize="8" fontWeight="800" fill="#fff" fontFamily="Helvetica Neue, Arial, sans-serif">$</text>
    </svg>
  );
}
function BusinessIcon() {
  return (
    <svg width="28" height="28" viewBox="0 0 52 52" fill="none">
      <rect x="6" y="26" width="40" height="22" rx="3" fill="#1a3a6b" />
      <rect x="6" y="18" width="40" height="12" rx="3" fill="#5b9bd5" />
      <rect x="17" y="27" width="6" height="5" rx="1" fill="#d4af37" />
      <rect x="29" y="27" width="6" height="5" rx="1" fill="#d4af37" />
    </svg>
  );
}

const openAcctItems = [
  { label: 'Credit cards', icon: <CreditCardIcon /> },
  { label: 'Checking', icon: <CheckingIcon /> },
  { label: 'Savings', icon: <SavingsIcon /> },
  { label: 'Business', icon: <BusinessIcon /> },
];

export default function AccountsDashboard({
  onProfile, onZelle, onDeposit, onPayTransfer, onWires, onOffers, onPlanTrack, onChat,
}: AccountsDashboardProps) {
  const [showPrefs, setShowPrefs] = useState(false);
  const [defaultDisplay, setDefaultDisplay] = useState<'expanded' | 'collapsed'>('expanded');
  const [showSubtotals, setShowSubtotals] = useState(false);
  const [bankExpanded, setBankExpanded] = useState(true);
  const [creditExpanded, setCreditExpanded] = useState(true);
  const [subView, setSubView] = useState<SubView>('main');
  const [showQuickActions, setShowQuickActions] = useState(false);
  const [showAddCard, setShowAddCard] = useState(false);

  // Quick-action pill buttons
  const quickActions = [
    { icon: '+', label: '', action: () => setShowQuickActions(true) },
    { icon: null, label: 'Send | Zelle\u00ae', action: onZelle },
    { icon: null, label: 'Deposit checks', action: onDeposit },
    { icon: null, label: 'Pay bills', action: onPayTransfer },
    { icon: null, label: 'Wire transfer', action: onWires },
  ];

  // SUB-VIEWS
  if (subView === 'snapshot') return <SnapshotPage onBack={() => setSubView('main')} />;
  if (subView === 'card-detail-0') return <CreditCardDetail card={CREDIT_CARDS[0]} onBack={() => setSubView('main')} />;
  if (subView === 'credit-journey') return <CreditJourneyPage onBack={() => setSubView('main')} />;
  if (subView === 'transactions') return <FullTransactionHistory onBack={() => setSubView('main')} />;
  if (subView === 'rewards') return <UltimateRewards onBack={() => setSubView('main')} />;
  if (subView === 'open-account') return <OpenAccountProducts onBack={() => setSubView('main')} />;
  if (subView === 'lock-unlock') return <LockUnlockCard onBack={() => setSubView('main')} />;
  if (subView.startsWith('account-detail-')) {
    const idx = parseInt(subView.split('-').pop()!);
    return <AccountDetail account={BANK_ACCOUNTS[idx]} onBack={() => setSubView('main')} />;
  }

  return (
    <div style={{
      width: '100%', height: '100%', overflowY: 'auto', overflowX: 'hidden',
      background: '#f0f4f8', paddingBottom: 80,
      fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
    }}>
      {/* TOP BAR */}
      <div style={{ background: '#fff', padding: '50px 18px 14px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 18 }}>
          {/* Chat icon */}
          <button
            onClick={onChat}
            style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}
            title="Contact Support"
          >
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
              <path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"
                stroke="#555" strokeWidth="1.8" fill="none" strokeLinejoin="round" />
            </svg>
          </button>
          {/* Wallet + card icon */}
          <button
            onClick={() => setShowAddCard(true)}
            style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0, position: 'relative' }}
            title="Add a card"
          >
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
              <rect x="2" y="5" width="20" height="14" rx="2" stroke="#555" strokeWidth="1.8" />
              <rect x="2" y="9" width="20" height="2.5" fill="#555" />
              <line x1="15" y1="14" x2="19" y2="14" stroke="#555" strokeWidth="1.8" strokeLinecap="round" />
              <line x1="17" y1="12" x2="17" y2="16" stroke="#555" strokeWidth="1.8" strokeLinecap="round" />
            </svg>
          </button>
        </div>
        {/* Profile icon */}
        <button onClick={onProfile} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0, position: 'relative' }}>
          <svg width="34" height="34" viewBox="0 0 34 34" fill="none">
            <circle cx="17" cy="17" r="16" stroke="#ccc" strokeWidth="1.5" fill="#f2f4f6" />
            <circle cx="17" cy="13" r="5" stroke="#888" strokeWidth="1.5" fill="none" />
            <path d="M6 29c0-6.075 4.925-11 11-11s11 4.925 11 11" stroke="#888" strokeWidth="1.5" fill="none" />
          </svg>
          <div style={{ position: 'absolute', top: 1, right: 1, width: 9, height: 9, borderRadius: '50%', background: blue, border: '2px solid #fff' }} />
        </button>
      </div>

      {/* GREETING */}
      <div style={{ background: '#fff', padding: '16px 20px 0' }}>
        <div style={{ fontSize: 30, fontWeight: 700, color: '#111', lineHeight: 1.2 }}>{getGreeting()}</div>
        <div style={{ fontSize: 15, color: '#666', marginTop: 4 }}>{getFormattedDate()}</div>

        {/* QUICK ACTIONS */}
        <div style={{ display: 'flex', gap: 10, overflowX: 'auto', padding: '16px 0', scrollbarWidth: 'none' }}>
          {quickActions.map((qa, i) => (
            <button key={i} onClick={() => qa.action?.()} style={{
              flexShrink: 0, background: '#fff', border: '1px solid #ddd',
              borderRadius: 999, padding: qa.label ? '9px 18px' : '9px 14px',
              fontSize: 14, color: blue, fontWeight: 500, cursor: 'pointer',
              display: 'flex', alignItems: 'center', gap: 4, whiteSpace: 'nowrap',
            }}>
              {qa.icon === '+' ? (
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                  <line x1="8" y1="2" x2="8" y2="14" stroke={blue} strokeWidth="2" strokeLinecap="round" />
                  <line x1="2" y1="8" x2="14" y2="8" stroke={blue} strokeWidth="2" strokeLinecap="round" />
                </svg>
              ) : qa.label}
            </button>
          ))}
        </div>
      </div>

      {/* TODAY'S SNAPSHOT */}
      <div style={{ padding: '12px 16px 0' }}>
        <div
          onClick={() => setSubView('snapshot')}
          style={{
            background: '#fff', borderRadius: 12, padding: '16px 18px',
            boxShadow: '0 2px 10px rgba(0,0,0,0.07)',
            display: 'flex', alignItems: 'center', gap: 14, cursor: 'pointer',
          }}>
          <div style={{ width: 44, height: 44, borderRadius: '50%', background: '#e8f0fb', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
              <path d="M9 21h6M12 3a6 6 0 016 6c0 2.4-1.4 4.5-3.5 5.6V17H9.5v-2.4C7.4 13.5 6 11.4 6 9a6 6 0 016-6z" fill="#f5c842" stroke="#e6a800" strokeWidth="1.2" />
            </svg>
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 700, fontSize: 15, color: '#111' }}>Today's Snapshot</div>
            <div style={{ fontSize: 13, color: '#777', marginTop: 2 }}>Insights about your money, at-a-glance</div>
          </div>
          <svg width="9" height="16" viewBox="0 0 9 16" fill="none">
            <polyline points="1,1 8,8 1,15" stroke="#bbb" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      </div>

      {/* ACCOUNTS SECTION */}
      <div style={{ padding: '20px 16px 0' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
          <span style={{ fontSize: 20, fontWeight: 700, color: '#111' }}>Accounts</span>
          <button onClick={() => setShowPrefs(true)} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
            <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
              <circle cx="11" cy="11" r="10" stroke="#bbb" strokeWidth="1.5" fill="none" />
              <circle cx="7" cy="11" r="1.3" fill="#999" />
              <circle cx="11" cy="11" r="1.3" fill="#999" />
              <circle cx="15" cy="11" r="1.3" fill="#999" />
            </svg>
          </button>
        </div>

        {/* BANK ACCOUNTS */}
        <button
          onClick={() => setBankExpanded(!bankExpanded)}
          style={{
            width: '100%', background: '#1a3a6b', borderRadius: bankExpanded ? '10px 10px 0 0' : 10,
            padding: '12px 16px', border: 'none', cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          }}
        >
          <span style={{ color: '#fff', fontWeight: 700, fontSize: 15 }}>Bank accounts ({BANK_ACCOUNTS.length})</span>
          {showSubtotals && (
            <span style={{ color: 'rgba(255,255,255,0.85)', fontSize: 13 }}>
              ${TOTAL_BANK.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
          )}
        </button>

        {bankExpanded && (
          <>
            {BANK_ACCOUNTS.map((acct, idx) => (
              <div
                key={acct.last4}
                onClick={() => setSubView(`account-detail-${idx}` as SubView)}
                style={{
                  background: '#fff',
                  borderBottom: idx < BANK_ACCOUNTS.length - 1 ? '1px solid #eee' : 'none',
                  padding: '14px 16px', cursor: 'pointer',
                }}
              >
                <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 13, color: '#777', fontWeight: 500, letterSpacing: 0.3, lineHeight: 1.4 }}>
                      {acct.name} (…{acct.last4})
                      <span style={{ color: blue, marginLeft: 4 }}>›</span>
                    </div>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <div style={{ textAlign: 'right' }}>
                      <div style={{ fontSize: 22, fontWeight: 700, color: '#111', lineHeight: 1 }}>{acct.balance}</div>
                      <div style={{ fontSize: 12, color: '#888', marginTop: 3 }}>Available balance</div>
                    </div>
                    <div style={{ width: 3, height: 36, background: '#e8e8e8', borderRadius: 2 }} />
                  </div>
                </div>
              </div>
            ))}
            <div style={{
              background: '#fff', borderRadius: '0 0 10px 10px', padding: '14px 16px',
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              cursor: 'pointer', borderTop: '1px solid #f0f0f0',
            }}>
              <span style={{ fontSize: 15, color: '#111' }}>Link external accounts</span>
              <svg width="9" height="16" viewBox="0 0 9 16" fill="none">
                <polyline points="1,1 8,8 1,15" stroke="#bbb" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
          </>
        )}

        {/* CREDIT CARDS (SS1 — single card only) */}
        <div style={{ marginTop: 16 }}>
          <button
            onClick={() => setCreditExpanded(!creditExpanded)}
            style={{
              width: '100%', background: '#1a3a6b', borderRadius: creditExpanded ? '10px 10px 0 0' : 10,
              padding: '12px 16px', border: 'none', cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            }}
          >
            <span style={{ color: '#fff', fontWeight: 700, fontSize: 15 }}>Credit cards (1)</span>
            {showSubtotals && (
              <span style={{ color: 'rgba(255,255,255,0.85)', fontSize: 13 }}>
                ${TOTAL_CREDIT.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            )}
          </button>

          {creditExpanded && (
            <div
              onClick={() => setSubView('card-detail-0')}
              style={{
                background: '#fff', padding: '14px 16px',
                borderRadius: '0 0 10px 10px', cursor: 'pointer',
              }}
            >
              {/* Top label */}
              <div style={{ fontSize: 12, color: '#777', fontWeight: 500, letterSpacing: 0.3, marginBottom: 10 }}>
                CREDIT CARD (...{CREDIT_CARDS[0].last4}) <span style={{ color: blue }}>›</span>
              </div>

                {/* Card image + balance row */}
                <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14 }}>
                  <ChaseCreditCardThumbnail variant="amazon-prime" width={80} height={52} />
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 12, justifyContent: 'flex-end' }}>
                    <div style={{ textAlign: 'right' }}>
                      <div style={{ fontSize: 26, fontWeight: 700, color: '#111', lineHeight: 1 }}>{CREDIT_CARDS[0].balance}</div>
                      <div style={{ fontSize: 12, color: '#888', marginTop: 3 }}>Current balance</div>
                    </div>
                    <div style={{ width: 3, height: 36, background: '#e8e8e8', borderRadius: 2 }} />
                  </div>
                </div>
              </div>

              {/* No scheduled payment */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 10 }}>
                <div style={{ width: 18, height: 18, borderRadius: '50%', background: '#2a9d4e', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <svg width="9" height="9" viewBox="0 0 9 9" fill="none">
                    <polyline points="1.5,4.5 3.5,6.5 7.5,2" stroke="#fff" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
                <span style={{ fontSize: 12, color: '#555' }}>No schedule payment.</span>
              </div>
            </div>
          )}
        </div>

        {/* ULTIMATE REWARDS CARD (SS2) */}
        <div style={{ marginTop: 16 }}>
          <div
            onClick={() => setSubView('rewards')}
            style={{
              background: '#fff', borderRadius: 12, padding: '16px',
              boxShadow: '0 2px 8px rgba(0,0,0,0.06)', cursor: 'pointer',
            }}
          >
            {/* Header row */}
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
              <span style={{ fontSize: 16, fontWeight: 700, color: '#111' }}>Ultimate Rewards®</span>
              <svg width="9" height="16" viewBox="0 0 9 16" fill="none">
                <polyline points="1,1 8,8 1,15" stroke="#bbb" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>

            {/* Two-column points row */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 0 }}>
              <div style={{ flex: 1, textAlign: 'center' }}>
                <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Available Points</div>
                <div style={{ fontSize: 28, fontWeight: 700, color: '#111' }}>2,099</div>
              </div>
              <div style={{ width: 1, height: 48, background: '#e0e0e0' }} />
              <div style={{ flex: 1, textAlign: 'center' }}>
                <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Pending Points</div>
                <div style={{ fontSize: 28, fontWeight: 700, color: '#111' }}>155</div>
              </div>
            </div>

            {/* Learn more row */}
            <div style={{ marginTop: 14, paddingTop: 12, borderTop: '1px solid #f0f0f0', display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{
                width: 20, height: 20, borderRadius: '50%', border: `1.5px solid ${blue}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
              }}>
                <span style={{ fontSize: 11, color: blue, fontWeight: 700 }}>?</span>
              </div>
              <span style={{ fontSize: 14, color: blue, fontWeight: 500 }}>Learn more</span>
            </div>
          </div>
        </div>
      </div>

      {/* OPEN AN ACCOUNT */}
      <div style={{ padding: '22px 16px 0' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
          <div style={{ fontSize: 18, fontWeight: 700, color: '#111' }}>Open an account</div>
          <button
            onClick={() => setSubView('open-account')}
            style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 14, color: blue, fontWeight: 600 }}
          >
            Explore all
          </button>
        </div>
        <div style={{ display: 'flex', gap: 16, overflowX: 'auto', scrollbarWidth: 'none', paddingBottom: 4 }}>
          {openAcctItems.map((item, i) => (
            <div key={i} onClick={() => setSubView('open-account')} style={{ flexShrink: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, cursor: 'pointer' }}>
              <div style={{ width: 60, height: 60, borderRadius: '50%', background: '#e8f0fb', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                {item.icon}
              </div>
              <span style={{ fontSize: 13, color: blue, fontWeight: 500, textAlign: 'center' }}>{item.label}</span>
            </div>
          ))}
          {/* Explore all products tile */}
          <div onClick={() => setSubView('open-account')} style={{ flexShrink: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, cursor: 'pointer' }}>
            <div style={{ width: 60, height: 60, borderRadius: '50%', background: '#e8f0fb', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
                <circle cx="12" cy="12" r="10" stroke={blue} strokeWidth="1.8" fill="none" />
                <path d="M12 8l4 4-4 4M8 12h8" stroke={blue} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
            <span style={{ fontSize: 13, color: blue, fontWeight: 500, textAlign: 'center', maxWidth: 64 }}>All products</span>
          </div>
        </div>
      </div>

      {/* CHASE OFFERS WIDGET */}
      <DashboardOffersWidget onSeeAll={onOffers || (() => {})} />

      {/* CREDIT JOURNEY WIDGET */}
      <CreditJourneyWidget onSeeDetails={() => setSubView('credit-journey')} />

      {/* TRACK SPENDING */}
      <TrackSpendingWidget onManage={onPlanTrack || (() => {})} />

      {/* TRANSACTIONS WIDGET */}
      <TransactionsWidget
        onSeeAll={() => setSubView('transactions')}
        onStatements={() => setSubView('transactions')}
      />

      <div style={{ height: 16 }} />

      {/* PREFERENCES SHEET */}
      {showPrefs && (
        <PreferencesSheet
          onClose={() => setShowPrefs(false)}
          defaultDisplay={defaultDisplay}
          showSubtotals={showSubtotals}
          onDisplayChange={(v) => {
            setDefaultDisplay(v);
            setBankExpanded(v === 'expanded');
            setCreditExpanded(v === 'expanded');
          }}
          onSubtotalsChange={setShowSubtotals}
        />
      )}

      {/* QUICK ACTIONS SHEET */}
      {showQuickActions && (
        <QuickActionsSheet
          onClose={() => setShowQuickActions(false)}
          onNavigate={(action) => {
            if (action === 'zelle') onZelle?.();
            else if (action === 'deposit') onDeposit?.();
            else if (action === 'transfer' || action === 'pay-bills') onPayTransfer?.();
            else if (action === 'lock-card') setSubView('lock-unlock');
            else if (action === 'statements') setSubView('transactions');
          }}
        />
      )}

      {/* ADD CARD SHEET */}
      {showAddCard && <AddCardSheet onClose={() => setShowAddCard(false)} />}
    </div>
  );
}
