import { useState } from 'react';

interface Props {
  onClose: () => void;
  onNavigate: (action: string) => void;
}

const BLUE = '#2558b5';
const BORDER = '#e5e7eb';

const ALL_ACTIONS = [
  { id: 'zelle', label: 'Send | Zelle®', desc: 'Send money to friends & family', zelle: true },
  { id: 'deposit', label: 'Deposit checks', desc: 'Deposit a check with your camera' },
  { id: 'transfer', label: 'Transfer money', desc: 'Move money between accounts' },
  { id: 'pay-bills', label: 'Pay bills', desc: 'Pay your bills and payees' },
  { id: 'lock-card', label: 'Lock/Unlock card', desc: 'Instantly lock or unlock your card' },
  { id: 'statements', label: 'View statements', desc: 'See your account statements' },
  { id: 'atm', label: 'Find ATM', desc: 'Locate Chase ATMs near you' },
];

export default function QuickActionsSheet({ onClose, onNavigate }: Props) {
  const [pinned, setPinned] = useState<string[]>(['zelle', 'deposit', 'pay-bills']);

  function togglePin(id: string) {
    setPinned(prev => prev.includes(id) ? prev.filter(p => p !== id) : [...prev, id]);
  }

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 500,
      background: 'rgba(0,0,0,0.4)',
      display: 'flex', alignItems: 'flex-end',
    }} onClick={onClose}>
      <div
        onClick={e => e.stopPropagation()}
        style={{
          width: '100%', background: '#fff',
          borderRadius: '16px 16px 0 0',
          padding: '0 0 40px',
          maxHeight: '80vh', overflowY: 'auto',
          animation: 'slideUp 0.3s ease',
        }}
      >
        {/* drag handle */}
        <div style={{ display: 'flex', justifyContent: 'center', padding: '12px 0 0' }}>
          <div style={{ width: 40, height: 4, borderRadius: 2, background: '#ddd' }} />
        </div>

        {/* header */}
        <div style={{ padding: '16px 20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span style={{ fontSize: 17, fontWeight: 700, color: '#111' }}>Quick actions</span>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 22, color: '#999' }}>×</button>
        </div>

        <div style={{ padding: '0 0 8px', borderTop: `1px solid ${BORDER}` }} />
        <div style={{ padding: '8px 20px 0', fontSize: 13, color: '#888', marginBottom: 4 }}>
          Tap an action to use it, or tap the pin icon to add/remove it from your quick bar.
        </div>

        {ALL_ACTIONS.map(action => (
          <div key={action.id} style={{
            display: 'flex', alignItems: 'center', gap: 14,
            padding: '14px 20px',
            borderBottom: `1px solid ${BORDER}`,
          }}>
            <button
              onClick={() => { onNavigate(action.id); onClose(); }}
              style={{ flex: 1, background: 'none', border: 'none', cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: 2, padding: 0 }}
            >
              <span style={{ fontSize: 15, fontWeight: 600, color: '#111' }}>
                {action.label}
                {action.zelle && <span style={{ color: '#6d1ed4', fontStyle: 'italic', marginLeft: 4 }}>®</span>}
              </span>
              <span style={{ fontSize: 13, color: '#888' }}>{action.desc}</span>
            </button>
            {/* pin toggle */}
            <button
              onClick={() => togglePin(action.id)}
              style={{
                background: 'none', border: 'none', cursor: 'pointer',
                width: 32, height: 32, borderRadius: '50%',
                display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
                backgroundColor: pinned.includes(action.id) ? '#e8f0fb' : '#f5f5f5',
              } as React.CSSProperties}
              title={pinned.includes(action.id) ? 'Remove from quick bar' : 'Add to quick bar'}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"
                  stroke={pinned.includes(action.id) ? BLUE : '#aaa'}
                  fill={pinned.includes(action.id) ? BLUE : 'none'}
                  strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </button>
          </div>
        ))}

        <style>{`@keyframes slideUp { from { transform: translateY(100%); } to { transform: translateY(0); } }`}</style>
      </div>
    </div>
  );
}
