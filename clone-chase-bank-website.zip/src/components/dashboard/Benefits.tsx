const blue = '#2558b5';

const benefits = [
  { title: 'Chase Ultimate Rewards®', sub: '61,080 points available', tag: 'Sapphire Preferred' },
  { title: 'No foreign transaction fees', sub: 'Use your card abroad with no added fees', tag: 'Sapphire Reserve' },
  { title: 'Purchase Protection', sub: 'Up to $500 per claim, $50,000 per year', tag: 'Freedom Unlimited' },
  { title: 'Trip Cancellation Insurance', sub: 'Up to $10,000 per person', tag: 'Sapphire Preferred' },
  { title: 'Auto Rental Insurance', sub: 'Primary coverage on eligible rentals', tag: 'Sapphire Reserve' },
  { title: 'DoorDash DashPass', sub: '$0 delivery fees on eligible orders', tag: 'Sapphire Reserve' },
];

export default function Benefits() {
  return (
    <div style={{
      width: '100%',
      height: '100%',
      overflowY: 'auto',
      background: '#f0f4f8',
      paddingBottom: 80,
      fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
    }}>
      <div style={{ background: '#fff', padding: '20px 20px 16px' }}>
        <div style={{ fontSize: 26, fontWeight: 700, color: '#111' }}>Benefits</div>
        <div style={{ fontSize: 14, color: '#777', marginTop: 4 }}>Your active card benefits</div>
      </div>

      {/* Rewards card */}
      <div style={{ padding: '16px 16px 0' }}>
        <div style={{
          background: blue,
          borderRadius: 12,
          padding: '20px 18px',
          marginBottom: 14,
          color: '#fff',
        }}>
          <div style={{ fontSize: 13, opacity: 0.85, marginBottom: 4 }}>Total rewards points</div>
          <div style={{ fontSize: 36, fontWeight: 700 }}>61,080</div>
          <div style={{ fontSize: 13, opacity: 0.85, marginTop: 4 }}>Worth approximately <strong>$610.80</strong> in travel</div>
          <button style={{
            marginTop: 16,
            background: '#fff',
            color: blue,
            border: 'none',
            borderRadius: 6,
            padding: '10px 22px',
            fontWeight: 700,
            fontSize: 14,
            cursor: 'pointer',
          }}>
            Redeem rewards
          </button>
        </div>

        {/* Benefits list */}
        <div style={{ background: '#fff', borderRadius: 12, overflow: 'hidden', boxShadow: '0 2px 8px rgba(0,0,0,0.06)' }}>
          {benefits.map((b, i) => (
            <div key={i} style={{
              padding: '16px 18px',
              borderBottom: i < benefits.length - 1 ? '1px solid #f0f0f0' : 'none',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'flex-start',
              cursor: 'pointer',
            }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14, fontWeight: 600, color: '#111', marginBottom: 3 }}>{b.title}</div>
                <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>{b.sub}</div>
                <span style={{
                  fontSize: 11,
                  background: '#e8f0fb',
                  color: blue,
                  padding: '2px 8px',
                  borderRadius: 999,
                  fontWeight: 600,
                }}>
                  {b.tag}
                </span>
              </div>
              <svg width="9" height="16" viewBox="0 0 9 16" fill="none" style={{ marginTop: 4 }}>
                <polyline points="1,1 8,8 1,15" stroke="#bbb" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
