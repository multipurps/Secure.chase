import { useState } from 'react';
import ChaseCreditCardThumbnail from './ChaseCreditCardThumbnail';

interface Props {
  card: {
    name: string;
    last4: string;
    balance: string;
    paymentDate: string;
    imageUrl: string;
    cardBrand?: string;
  };
  onBack: () => void;
}

const blue = '#2558b5';

const TRANSACTIONS = [
  { merchant: 'AMAZON.COM', date: 'Sep 10, 2024', status: 'Posted', amount: '-$89.99' },
  { merchant: 'STARBUCKS #4521', date: 'Sep 09, 2024', status: 'Posted', amount: '-$7.45' },
  { merchant: 'SOUTHWEST AIRLINES', date: 'Sep 08, 2024', status: 'Posted', amount: '-$312.00' },
];

export default function CreditCardDetail({ card, onBack }: Props) {
  const [showDetails, setShowDetails] = useState(false);

  return (
    <div style={{
      width: '100%', height: '100%', overflowY: 'auto',
      background: '#f0f4f8',
      fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
      paddingBottom: 80,
    }}>
      {/* Back arrow */}
      <div style={{ padding: '16px 16px 0' }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
            <polyline points="15,4 7,12 15,20" stroke="#555" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
      </div>

      {/* Title */}
      <div style={{ padding: '8px 20px 0', fontSize: 22, fontWeight: 700, color: '#111' }}>
        CREDIT CARD (...{card.last4})
      </div>

      {/* Main card detail */}
      <div style={{ margin: 16, background: '#fff', borderRadius: 14, padding: 20, boxShadow: '0 2px 12px rgba(0,0,0,0.08)' }}>
        {/* Card image + balance */}
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 16, marginBottom: 16 }}>
          <ChaseCreditCardThumbnail variant="amazon-prime" width={120} height={76} />
          <div>
            <div style={{ fontSize: 28, fontWeight: 700, color: '#111', lineHeight: 1 }}>{card.balance}</div>
            <div style={{ fontSize: 13, color: '#888', marginTop: 4 }}>Current balance</div>
          </div>
        </div>

        <div style={{ borderTop: '1px solid #f0f0f0', paddingTop: 14, marginBottom: 14 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
            <div style={{
              width: 22, height: 22, borderRadius: '50%', background: '#2a9d4e',
              display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
            }}>
              <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                <polyline points="2,6 5,9 10,3" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
            <span style={{ fontSize: 14, color: '#111', fontWeight: 600 }}>You don't have a minimum payment due right now.</span>
          </div>

          {/* Detail rows */}
          {[
            { label: 'Payment due date', value: card.paymentDate },
            { label: 'Minimum payment due', value: '$0.00' },
            { label: 'Remaining statement balance', value: card.balance },
          ].map((row, i) => (
            <div key={i} style={{
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              padding: '12px 0', borderTop: '1px solid #f0f0f0',
            }}>
              <span style={{ fontSize: 14, color: '#555' }}>{row.label}</span>
              <span style={{ fontSize: 14, fontWeight: 600, color: '#111' }}>{row.value}</span>
            </div>
          ))}

          {/* Automatic payments */}
          <div style={{
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            padding: '12px 0', borderTop: '1px solid #f0f0f0',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <div style={{ width: 10, height: 10, borderRadius: '50%', background: '#bbb' }} />
              <span style={{ fontSize: 14, color: '#555' }}>Automatic payments: Off</span>
            </div>
            <button style={{ background: 'none', border: 'none', cursor: 'pointer', color: blue, fontSize: 14, fontWeight: 600 }}>
              Set up ›
            </button>
          </div>
        </div>

        {/* Show details button */}
        <button
          onClick={() => setShowDetails(!showDetails)}
          style={{
            display: 'block', margin: '0 auto',
            background: '#fff', border: `1.5px solid #ddd`,
            borderRadius: 999, padding: '10px 24px',
            color: blue, fontSize: 14, fontWeight: 600, cursor: 'pointer',
          }}
        >
          {showDetails ? 'Hide details ∧' : 'Show details ∨'}
        </button>

        {showDetails && (
          <div style={{ marginTop: 14 }}>
            {[
              { label: 'Credit limit', value: '$20,000.00' },
              { label: 'Available credit', value: '$12,156.00' },
              { label: 'Last statement balance', value: '$5,200.00' },
              { label: 'Last payment', value: 'Aug 15, 2024 — $200.00' },
              { label: 'Next closing date', value: 'Sep 25, 2024' },
            ].map((row, i) => (
              <div key={i} style={{
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                padding: '10px 0', borderTop: '1px solid #f0f0f0',
              }}>
                <span style={{ fontSize: 14, color: '#555' }}>{row.label}</span>
                <span style={{ fontSize: 14, fontWeight: 600, color: '#111' }}>{row.value}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Action buttons */}
      <div style={{ display: 'flex', justifyContent: 'center', gap: 32, padding: '0 16px 16px' }}>
        {[
          { label: 'Pay card', icon: <svg width="26" height="26" viewBox="0 0 24 24" fill="none"><rect x="2" y="5" width="20" height="14" rx="2" stroke={blue} strokeWidth="1.8" fill="none" /><rect x="2" y="9" width="20" height="3" fill={blue} /></svg> },
          { label: 'View payment activity', icon: <svg width="26" height="26" viewBox="0 0 24 24" fill="none"><rect x="4" y="4" width="13" height="16" rx="1.5" stroke={blue} strokeWidth="1.7" fill="none" /><rect x="7" y="6" width="13" height="16" rx="1.5" stroke={blue} strokeWidth="1.7" fill="none" /><line x1="9" y1="11" x2="16" y2="11" stroke={blue} strokeWidth="1.3" strokeLinecap="round" /><line x1="9" y1="14" x2="14" y2="14" stroke={blue} strokeWidth="1.3" strokeLinecap="round" /></svg> },
          { label: 'Pay over time', icon: <svg width="26" height="26" viewBox="0 0 24 24" fill="none"><path d="M12 2a10 10 0 100 20A10 10 0 0012 2z" stroke={blue} strokeWidth="1.7" fill="none" /><path d="M12 6v6l4 2" stroke={blue} strokeWidth="1.7" strokeLinecap="round" /></svg> },
        ].map((btn, i) => (
          <div key={i} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, cursor: 'pointer', flex: 1, maxWidth: 90 }}>
            <div style={{
              width: 56, height: 56, borderRadius: '50%',
              background: '#e8f0fb',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              {btn.icon}
            </div>
            <span style={{ fontSize: 12, color: blue, fontWeight: 500, textAlign: 'center', lineHeight: 1.3 }}>{btn.label}</span>
          </div>
        ))}
      </div>

      {/* Manage account */}
      <div style={{
        margin: '0 16px 16px', background: '#fff', borderRadius: 12,
        padding: '16px 18px', boxShadow: '0 1px 6px rgba(0,0,0,0.06)',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between', cursor: 'pointer',
      }}>
        <div>
          <div style={{ fontWeight: 700, fontSize: 16, color: '#111' }}>Manage account</div>
          <div style={{ fontSize: 13, color: '#888', marginTop: 2 }}>Access tools & services for your account</div>
        </div>
        <svg width="9" height="16" viewBox="0 0 9 16" fill="none">
          <polyline points="1,1 8,8 1,15" stroke="#bbb" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </div>

      {/* Transactions */}
      <div style={{ margin: '0 16px 16px', background: '#fff', borderRadius: 12, overflow: 'hidden', boxShadow: '0 1px 6px rgba(0,0,0,0.06)' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 18px', borderBottom: '1px solid #f0f0f0' }}>
          <span style={{ fontWeight: 700, fontSize: 16, color: '#111' }}>See all transactions</span>
          <svg width="9" height="16" viewBox="0 0 9 16" fill="none">
            <polyline points="1,1 8,8 1,15" stroke="#bbb" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>

        {TRANSACTIONS.map((tx, i) => (
          <div key={i} style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            padding: '14px 18px',
            borderBottom: i < TRANSACTIONS.length - 1 ? '1px solid #f0f0f0' : 'none',
          }}>
            <div>
              <div style={{ fontSize: 14, fontWeight: 600, color: '#222' }}>{tx.merchant}</div>
              <div style={{ fontSize: 12, color: '#888', marginTop: 2 }}>{tx.date}</div>
              <div style={{ fontSize: 11, color: '#aaa', marginTop: 1 }}>{tx.status}</div>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ fontSize: 16, fontWeight: 600, color: tx.amount.startsWith('+') ? blue : '#d32f2f' }}>
                {tx.amount}
              </span>
              <svg width="7" height="13" viewBox="0 0 7 13" fill="none">
                <polyline points="1,1 6,6.5 1,12" stroke="#bbb" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
          </div>
        ))}

        {/* Pill buttons */}
        <div style={{ display: 'flex', gap: 12, padding: 16 }}>
          {['See statements', 'See all transactions'].map((label, i) => (
            <button key={i} style={{
              flex: 1, background: '#fff', border: `1.5px solid ${blue}`,
              borderRadius: 999, padding: '10px 8px',
              color: blue, fontSize: 13, fontWeight: 600, cursor: 'pointer',
            }}>
              {label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
