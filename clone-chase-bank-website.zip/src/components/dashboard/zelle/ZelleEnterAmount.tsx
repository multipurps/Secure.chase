import { useState } from 'react';
import { Recipient } from './ZelleRecipients';
import { useAccounts, formatBalance } from '../../../hooks/useAccounts';
import { isTransferRestricted, getCurrentUser } from '../../../lib/supabase';
import TransferRestrictionModal from '../../TransferRestrictionModal';

const blue = '#2558b5';
const purple = '#6d1ed4';
const gray = '#999';

function ZelleBadge() {
  return (
    <div style={{
      position: 'absolute', bottom: -2, right: -2,
      width: 18, height: 18, borderRadius: '50%',
      background: purple, border: '2px solid #fff',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}>
      <span style={{ color: '#fff', fontSize: 9, fontWeight: 900, fontStyle: 'italic' }}>Z</span>
    </div>
  );
}

interface Props {
  recipient: Recipient;
  onBack: () => void;
  onCancel: () => void;
  onReviewSend: (amount: number, message: string, fromAccountId: string) => void;
}

export default function ZelleEnterAmount({ recipient, onBack, onCancel, onReviewSend }: Props) {
  const { accounts } = useAccounts();
  const [amountStr, setAmountStr] = useState('');
  const amountCents = Math.round(parseFloat(amountStr || '0') * 100);
  const [message, setMessage] = useState('');
  const [repeatOn, setRepeatOn] = useState(false);
  const [copied, setCopied] = useState(false);
  const [fromAccountId, setFromAccountId] = useState<string | null>(null);
  const [showAccountSheet, setShowAccountSheet] = useState(false);
  const [restricted, setRestricted] = useState(false);
  const LIMIT = 200000; // $2000.00 in cents

  const fromAccount = (fromAccountId ? accounts.find(a => a.id === fromAccountId) : null) ?? accounts[0];

  const isValid = amountCents > 0 && amountCents <= LIMIT && !!fromAccount;
  const charsLeft = 140 - message.length;

  function handleCopy() {
    navigator.clipboard?.writeText(recipient.contact).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  async function handleReviewSend() {
    if (!isValid || !fromAccount) return;
    const user = await getCurrentUser();
    if (user) {
      const r = await isTransferRestricted(user.id);
      if (r) { setRestricted(true); return; }
    }
    onReviewSend(amountCents / 100, message, fromAccount.id);
  }

  if (restricted) return <TransferRestrictionModal onClose={() => setRestricted(false)} />;

  return (
    <div style={{
      width: '100%', height: '100%', display: 'flex', flexDirection: 'column',
      background: '#fff', fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
      overflow: 'hidden',
    }}>
      {/* Top nav */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '14px 16px', borderBottom: '1px solid #eee', flexShrink: 0,
      }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path d="M15 18l-6-6 6-6" stroke="#333" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
        <span style={{ fontSize: 17, fontWeight: 700, color: '#111' }}>Enter Amount</span>
        <button onClick={onCancel} style={{ background: 'none', border: 'none', cursor: 'pointer', color: blue, fontSize: 16, fontWeight: 600 }}>
          Cancel
        </button>
      </div>

      {/* Scrollable body */}
      <div style={{ flex: 1, overflowY: 'auto', paddingBottom: 100 }}>
        {/* Recipient info */}
        <div style={{
          display: 'flex', alignItems: 'center', gap: 14, padding: '18px 16px',
          borderBottom: '1px solid #f0f0f0',
        }}>
          <div style={{ position: 'relative', width: 64, height: 64, flexShrink: 0 }}>
            <div style={{
              width: 64, height: 64, borderRadius: '50%', background: recipient.color,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: '#fff', fontWeight: 700, fontSize: 22,
            }}>{recipient.initials}</div>
            <ZelleBadge />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 16, fontWeight: 700, color: '#111' }}>{recipient.name}</div>
            <div style={{ fontSize: 12, color: gray, marginTop: 2 }}>
              Registered as <span style={{ fontWeight: 600 }}>{recipient.name.toUpperCase()}</span>
            </div>
            <div style={{ fontSize: 12, color: gray }}>{recipient.contact}</div>
            <div style={{ fontSize: 12, color: '#555', marginTop: 4, display: 'flex', alignItems: 'center', gap: 4 }}>
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none">
                <circle cx="12" cy="8" r="4" stroke="#555" strokeWidth="1.8" />
                <path d="M4 20c0-4 3.6-7 8-7s8 3 8 7" stroke="#555" strokeWidth="1.8" strokeLinecap="round" />
              </svg>
              Personal account
            </div>
            <div style={{
              display: 'inline-flex', alignItems: 'center', gap: 4,
              background: '#f5f5f5', borderRadius: 20, padding: '3px 10px', marginTop: 6,
              fontSize: 11, color: gray,
            }}>
              <svg width="11" height="11" viewBox="0 0 24 24" fill="none">
                <rect x="4" y="4" width="16" height="16" rx="2" stroke={gray} strokeWidth="1.8" />
                <line x1="8" y1="10" x2="16" y2="10" stroke={gray} strokeWidth="1.5" />
                <line x1="8" y1="14" x2="12" y2="14" stroke={gray} strokeWidth="1.5" />
              </svg>
              <span style={{ color: purple, fontStyle: 'italic', fontWeight: 700 }}>Zelle®</span> ID active since Nov 2024
            </div>
          </div>
          <button onClick={handleCopy} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4, position: 'relative' }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
              <rect x="9" y="9" width="11" height="11" rx="2" stroke={gray} strokeWidth="1.6" />
              <path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1" stroke={gray} strokeWidth="1.6" strokeLinecap="round" />
            </svg>
            {copied && (
              <span style={{ position: 'absolute', top: -22, right: 0, fontSize: 11, color: '#2a9d4e', whiteSpace: 'nowrap', background: '#fff', padding: '2px 6px', borderRadius: 4, boxShadow: '0 1px 4px rgba(0,0,0,0.15)' }}>Copied!</span>
            )}
          </button>
        </div>

        {/* Amount section */}
        <div style={{ padding: '24px 16px 16px', textAlign: 'center' }}>
          <div style={{ fontSize: 14, color: gray, marginBottom: 12, fontWeight: 500 }}>Amount</div>
          <div style={{ position: 'relative', display: 'inline-block' }}>
            <input
              type="number"
              min="0"
              max="2000"
              step="0.01"
              value={amountStr}
              onChange={e => setAmountStr(e.target.value)}
              placeholder="0.00"
              style={{
                fontSize: 52, fontWeight: 300, color: amountCents > LIMIT ? '#e74c3c' : '#111',
                letterSpacing: -1, lineHeight: 1, border: 'none', outline: 'none',
                background: 'none', textAlign: 'center', width: 200,
                fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
              }}
            />
          </div>
          <div style={{ height: 1, background: '#ddd', margin: '16px 0' }} />
          <div style={{ fontSize: 13, color: gray }}>
            Today's limit for this recipient is <strong style={{ color: '#333' }}>$2,000.00</strong>
          </div>
          <div style={{ marginTop: 6, fontSize: 13, color: blue, cursor: 'pointer', fontWeight: 500 }}>
            Learn more &gt;
          </div>
        </div>

        {/* Message field */}
        <div style={{ padding: '0 16px 16px', borderBottom: '1px solid #f0f0f0' }}>
          <div style={{ fontSize: 13, color: '#555', marginBottom: 8, fontWeight: 500 }}>
            Message to recipient <span style={{ color: gray }}>(optional)</span>
          </div>
          <input
            value={message}
            onChange={e => setMessage(e.target.value.slice(0, 140))}
            placeholder="What's this for?"
            style={{
              width: '100%', border: 'none', borderBottom: '1px solid #ddd',
              fontSize: 15, color: '#333', outline: 'none', padding: '8px 0',
              background: 'none', boxSizing: 'border-box',
            }}
          />
          <div style={{
            fontSize: 12, marginTop: 6, textAlign: 'right',
            color: charsLeft < 20 ? (charsLeft < 0 ? '#e74c3c' : '#e67e22') : gray,
          }}>
            {charsLeft} of 140 characters remaining
          </div>
        </div>

        {/* Payment settings */}
        <div style={{ padding: '16px', borderBottom: '1px solid #f0f0f0' }}>
          {/* Pay from — real Supabase accounts */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
            <span style={{ fontSize: 14, color: '#555', fontWeight: 500 }}>Pay From</span>
            <div onClick={() => setShowAccountSheet(true)} style={{ display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer' }}>
              <span style={{ fontSize: 14, color: '#111', fontWeight: 600 }}>
                {fromAccount ? `${fromAccount.account_name} (...${fromAccount.last4})` : 'Select account'}
              </span>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                <path d="M6 9l6 6 6-6" stroke={gray} strokeWidth="1.8" strokeLinecap="round" />
              </svg>
            </div>
          </div>

          {showAccountSheet && (
            <>
              <div onClick={() => setShowAccountSheet(false)} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', zIndex: 300 }} />
              <div style={{ position: 'fixed', bottom: 0, left: 0, right: 0, background: '#fff', borderRadius: '16px 16px 0 0', zIndex: 301, paddingBottom: 40 }}>
                <div style={{ width: 40, height: 4, background: '#ddd', borderRadius: 2, margin: '12px auto 16px' }} />
                <div style={{ fontWeight: 700, fontSize: 17, color: '#111', textAlign: 'center', marginBottom: 12 }}>Pay From</div>
                {accounts.length === 0 ? (
                  <div style={{ padding: 24, textAlign: 'center', color: '#888' }}>No accounts found. Please set up accounts in Supabase.</div>
                ) : accounts.map(acct => (
                  <div key={acct.id} onClick={() => { setFromAccountId(acct.id); setShowAccountSheet(false); }}
                    style={{ padding: '14px 24px', borderBottom: '1px solid #f0f0f0', cursor: 'pointer', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div>
                      <div style={{ fontSize: 15, fontWeight: 600, color: '#111' }}>{acct.account_name} (...{acct.last4})</div>
                      <div style={{ fontSize: 13, color: '#888', marginTop: 2 }}>{formatBalance(acct.balance)}</div>
                    </div>
                    {fromAccount?.id === acct.id && (
                      <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M5 13l4 4L19 7" stroke={blue} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" /></svg>
                    )}
                  </div>
                ))}
              </div>
            </>
          )}

          {/* Send on */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
            <span style={{ fontSize: 14, color: '#555', fontWeight: 500 }}>Send On</span>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer' }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                <rect x="3" y="4" width="18" height="17" rx="2" stroke={blue} strokeWidth="1.6" />
                <line x1="3" y1="9" x2="21" y2="9" stroke={blue} strokeWidth="1.6" />
                <line x1="8" y1="2" x2="8" y2="6" stroke={blue} strokeWidth="1.6" strokeLinecap="round" />
                <line x1="16" y1="2" x2="16" y2="6" stroke={blue} strokeWidth="1.6" strokeLinecap="round" />
              </svg>
              <span style={{ fontSize: 14, color: blue, fontWeight: 600 }}>Today</span>
            </div>
          </div>

          {/* Help link */}
          <div style={{ fontSize: 13, color: blue, cursor: 'pointer', marginBottom: 20, display: 'flex', alignItems: 'center', gap: 4 }}>
            Delivery time and sending limits
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none">
              <circle cx="12" cy="12" r="9" stroke={blue} strokeWidth="1.6" />
              <line x1="12" y1="11" x2="12" y2="17" stroke={blue} strokeWidth="1.6" strokeLinecap="round" />
              <circle cx="12" cy="8" r="1" fill={blue} />
            </svg>
          </div>

          {/* Repeat payment toggle */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span style={{ fontSize: 14, color: '#555', fontWeight: 500 }}>Repeat Payment</span>
            <div
              onClick={() => setRepeatOn(v => !v)}
              style={{
                width: 48, height: 26, borderRadius: 13,
                background: repeatOn ? blue : '#ccc',
                position: 'relative', cursor: 'pointer',
                transition: 'background 0.2s',
              }}
            >
              <div style={{
                position: 'absolute', top: 3, left: repeatOn ? 25 : 3,
                width: 20, height: 20, borderRadius: '50%', background: '#fff',
                boxShadow: '0 1px 3px rgba(0,0,0,0.2)',
                transition: 'left 0.2s',
              }} />
            </div>
          </div>

          {repeatOn && (
            <div style={{ marginTop: 16, padding: 14, background: '#f8f8f8', borderRadius: 8 }}>
              <div style={{ fontSize: 14, color: '#555', marginBottom: 10 }}>Repeat frequency</div>
              <div style={{ display: 'flex', gap: 10 }}>
                {['Weekly', 'Monthly'].map(f => (
                  <button key={f} style={{
                    flex: 1, padding: '10px 0', border: `1px solid ${blue}`, borderRadius: 6,
                    background: '#fff', color: blue, fontWeight: 600, fontSize: 14, cursor: 'pointer',
                  }}>{f}</button>
                ))}
              </div>
              <div style={{ marginTop: 12, fontSize: 13, color: '#555' }}>End date</div>
              <input type="date" style={{
                marginTop: 6, width: '100%', border: 'none', borderBottom: '1px solid #ddd',
                fontSize: 14, color: '#333', padding: '6px 0', background: 'none',
                outline: 'none', boxSizing: 'border-box',
              }} />
            </div>
          )}
        </div>
      </div>

      {/* CTA button — fixed at bottom */}
      <div style={{
        position: 'absolute', bottom: 0, left: 0, right: 0,
        padding: '12px 16px 28px', background: '#fff',
        borderTop: '1px solid #f0f0f0',
      }}>
        <button
          onClick={handleReviewSend}
          disabled={!isValid}
          style={{
            width: '100%', padding: 16, borderRadius: 8, border: 'none',
            background: isValid ? blue : '#b0c4e8',
            color: '#fff', fontSize: 17, fontWeight: 600, cursor: isValid ? 'pointer' : 'not-allowed',
            opacity: isValid ? 1 : 0.6,
            transition: 'background 0.2s, opacity 0.2s',
          }}
        >
          Review &amp; send
        </button>
      </div>
    </div>
  );
}
