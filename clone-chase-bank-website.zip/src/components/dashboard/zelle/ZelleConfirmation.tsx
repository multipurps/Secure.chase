import { useEffect, useState } from 'react';
import { Recipient } from './ZelleRecipients';

const blue = '#2558b5';
const purple = '#6d1ed4';

type AnimStep = 'spinner' | 'checkmark' | 'checkmark-up' | 'content' | 'done-btn' | 'error';

interface Props {
  recipient: Recipient;
  amount: number;
  onDone: () => void;
  onRetry?: () => void;
}

function ZelleBadge() {
  return (
    <div style={{
      position: 'absolute', bottom: -2, right: -2,
      width: 20, height: 20, borderRadius: '50%',
      background: purple, border: '2px solid #fff',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}>
      <span style={{ color: '#fff', fontSize: 10, fontWeight: 900, fontStyle: 'italic' }}>Z</span>
    </div>
  );
}

export default function ZelleConfirmation({ recipient, amount, onDone }: Props) {
  const [step, setStep] = useState<AnimStep>('spinner');
  const [contentItems, setContentItems] = useState([false, false, false, false]);

  // Random wait between 1000–2000ms
  const spinnerDuration = 1000 + Math.random() * 1000;

  useEffect(() => {
    // Step 1: spinner → checkmark
    const t1 = setTimeout(() => setStep('checkmark'), spinnerDuration);
    // Step 2: checkmark animates in (300ms scale + 200ms bounce = 500ms) → move up
    const t2 = setTimeout(() => setStep('checkmark-up'), spinnerDuration + 700);
    // Step 3: stagger content items
    const t3 = setTimeout(() => {
      setStep('content');
      // stagger each item 100ms apart
      [0, 1, 2, 3].forEach(i => {
        setTimeout(() => {
          setContentItems(prev => {
            const next = [...prev];
            next[i] = true;
            return next;
          });
        }, i * 150);
      });
    }, spinnerDuration + 1050);
    // Step 4: done button
    const t4 = setTimeout(() => setStep('done-btn'), spinnerDuration + 1400);

    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); clearTimeout(t4); };
  }, []);

  const showCheckmark = step !== 'spinner';
  const checkmarkMoved = step === 'checkmark-up' || step === 'content' || step === 'done-btn' || step === 'error';
  const showContent = step === 'content' || step === 'done-btn' || step === 'error';
  const showDoneBtn = step === 'done-btn';

  return (
    <div style={{
      width: '100%', height: '100%', display: 'flex', flexDirection: 'column',
      background: '#fff', fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
      position: 'relative',
    }}>
      {/* Static page title */}
      <div style={{
        padding: '14px 16px', borderBottom: '1px solid #eee', textAlign: 'center', flexShrink: 0,
      }}>
        <span style={{ fontSize: 17, fontWeight: 700, color: '#111' }}>Confirmation</span>
      </div>

      {/* Animation area */}
      <div style={{
        flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center',
        paddingTop: 60, paddingBottom: 120, overflow: 'hidden',
      }}>
        {/* Spinner */}
        {step === 'spinner' && (
          <div style={{
            width: 64, height: 64,
            border: '4px solid #f0f0f0',
            borderTop: `4px solid ${blue}`,
            borderRadius: '50%',
            animation: 'zelleSpinner 0.8s linear infinite',
          }} />
        )}

        {/* Checkmark circle */}
        {showCheckmark && (
          <div style={{
            width: 64, height: 64, borderRadius: '50%', background: '#2a9d4e',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            transform: checkmarkMoved
              ? 'translateY(-40px) scale(1)'
              : 'translateY(0) scale(1)',
            animation: !checkmarkMoved ? 'zelleCheckIn 0.5s cubic-bezier(0.34,1.56,0.64,1) forwards' : 'none',
            transition: checkmarkMoved ? 'transform 0.35s ease-out' : 'none',
          }}>
            <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
              <path
                d="M8 16l6 6 10-12"
                stroke="#fff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"
                strokeDasharray="30"
                strokeDashoffset="0"
                style={{ animation: 'zelleCheckDraw 0.4s ease-out 0.2s both' }}
              />
            </svg>
          </div>
        )}

        {/* Content items — stagger fade in */}
        {showContent && (
          <div style={{
            display: 'flex', flexDirection: 'column', alignItems: 'center',
            marginTop: 16, gap: 0, width: '100%', padding: '0 24px',
          }}>
            {/* Item 1: description */}
            <div style={{
              opacity: contentItems[0] ? 1 : 0,
              transform: contentItems[0] ? 'translateY(0)' : 'translateY(10px)',
              transition: 'opacity 0.3s ease-out, transform 0.3s ease-out',
              textAlign: 'center', marginBottom: 16,
            }}>
              <p style={{ fontSize: 15, color: '#555', lineHeight: 1.5, margin: 0 }}>
                We're sending your money now.<br />
                <strong style={{ color: '#111' }}>{recipient.name}</strong> will get it in a few moments.
              </p>
            </div>

            {/* Item 2: amount */}
            <div style={{
              opacity: contentItems[1] ? 1 : 0,
              transform: contentItems[1] ? 'translateY(0)' : 'translateY(10px)',
              transition: 'opacity 0.3s ease-out, transform 0.3s ease-out',
              marginBottom: 24,
            }}>
              <span style={{ fontSize: 48, fontWeight: 700, color: '#111' }}>
                ${amount.toFixed(2)}
              </span>
            </div>

            {/* Item 3: avatar */}
            <div style={{
              opacity: contentItems[2] ? 1 : 0,
              transform: contentItems[2] ? 'translateY(0)' : 'translateY(10px)',
              transition: 'opacity 0.3s ease-out, transform 0.3s ease-out',
              position: 'relative', marginBottom: 12,
            }}>
              <div style={{
                width: 48, height: 48, borderRadius: '50%', background: recipient.color,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: '#fff', fontWeight: 700, fontSize: 18,
              }}>{recipient.initials}</div>
              <ZelleBadge />
            </div>

            {/* Item 4: recipient info */}
            <div style={{
              opacity: contentItems[3] ? 1 : 0,
              transform: contentItems[3] ? 'translateY(0)' : 'translateY(10px)',
              transition: 'opacity 0.3s ease-out, transform 0.3s ease-out',
              textAlign: 'center',
            }}>
              <div style={{ fontSize: 16, fontWeight: 700, color: '#111' }}>{recipient.name}</div>
              <div style={{ fontSize: 13, color: '#777', marginTop: 2 }}>
                Registered as <span style={{ fontWeight: 600 }}>{recipient.name.toUpperCase()}</span>
              </div>
              <div style={{ fontSize: 13, color: '#777' }}>{recipient.contact}</div>
            </div>
          </div>
        )}
      </div>

      {/* Done button — fades in at end */}
      <div style={{
        position: 'absolute', bottom: 0, left: 0, right: 0,
        padding: '12px 16px 32px', background: '#fff', borderTop: '1px solid #f0f0f0',
        opacity: showDoneBtn ? 1 : 0,
        transition: 'opacity 0.4s ease-out',
        pointerEvents: showDoneBtn ? 'auto' : 'none',
      }}>
        <button
          onClick={onDone}
          style={{
            width: '100%', padding: 16, borderRadius: 8, border: 'none',
            background: blue, color: '#fff', fontSize: 17, fontWeight: 600, cursor: 'pointer',
          }}
        >
          Done
        </button>
      </div>

      <style>{`
        @keyframes zelleSpinner {
          to { transform: rotate(360deg); }
        }
        @keyframes zelleCheckIn {
          0% { transform: scale(0); }
          70% { transform: scale(1.1); }
          100% { transform: scale(1); }
        }
        @keyframes zelleCheckDraw {
          from { stroke-dashoffset: 30; }
          to { stroke-dashoffset: 0; }
        }
      `}</style>
    </div>
  );
}
