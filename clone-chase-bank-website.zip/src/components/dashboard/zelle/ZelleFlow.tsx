import { useState } from 'react';
import ZelleRecipients, { Recipient } from './ZelleRecipients';
import ZelleEnterAmount from './ZelleEnterAmount';
import ZelleConfirmation from './ZelleConfirmation';
import { saveTransaction } from '../../../hooks/useAccounts';
import { getCurrentUser } from '../../../lib/supabase';

type ZelleScreen = 'recipients' | 'amount' | 'confirmation';

interface Props {
  onBack: () => void;
}

export default function ZelleFlow({ onBack }: Props) {
  const [screen, setScreen] = useState<ZelleScreen>('recipients');
  const [selectedRecipient, setSelectedRecipient] = useState<Recipient | null>(null);
  const [transferAmount, setTransferAmount] = useState(0);
  const [fromAccountId, setFromAccountId] = useState<string>('');

  if (screen === 'recipients') {
    return (
      <ZelleRecipients
        onSelectRecipient={(r) => {
          setSelectedRecipient(r);
          setScreen('amount');
        }}
        onBack={onBack}
      />
    );
  }

  if (screen === 'amount' && selectedRecipient) {
    return (
      <ZelleEnterAmount
        recipient={selectedRecipient}
        onBack={() => setScreen('recipients')}
        onCancel={onBack}
        onReviewSend={async (amount, _msg, accountId) => {
          setTransferAmount(amount);
          setFromAccountId(accountId);
          setScreen('confirmation');
        }}
      />
    );
  }

  if (screen === 'confirmation' && selectedRecipient) {
    return (
      <ZelleConfirmation
        recipient={selectedRecipient}
        amount={transferAmount}
        onDone={async () => {
          // Save transaction to Supabase
          if (fromAccountId) {
            try {
              const user = await getCurrentUser();
              if (user && fromAccountId) {
                await saveTransaction({
                  account_id: fromAccountId,
                  description: `ZELLE PAYMENT TO ${selectedRecipient.name.toUpperCase()} (${selectedRecipient.contact})`,
                  amount: -transferAmount,
                  type: 'debit',
                  category: 'zelle',
                  status: 'Posted',
                  tx_type: 'zelle',
                  recipient: selectedRecipient.name,
                });
              }
            } catch (e) {
              console.error('Save Zelle tx error', e);
            }
          }
          setScreen('recipients');
          setSelectedRecipient(null);
          setTransferAmount(0);
          setFromAccountId('');
        }}
      />
    );
  }

  return null;
}
