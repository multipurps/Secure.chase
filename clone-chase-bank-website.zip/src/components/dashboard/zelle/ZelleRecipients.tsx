import { useState } from 'react';

const blue = '#2558b5';
const purple = '#6d1ed4';
const gray = '#999';

export interface Recipient {
  id: string;
  name: string;
  contact: string;
  type: 'registered' | 'not_registered' | 'bill' | 'external';
  initials: string;
  color: string;
}

const DEFAULT_RECENT: Recipient[] = [
  { id: '1', name: 'Amber Davis', contact: 'adavis@gmail.com', type: 'registered', initials: 'AD', color: '#e8563a' },
  { id: '2', name: 'Travis Taylor', contact: '(555) 234-5678', type: 'not_registered', initials: 'TT', color: '#2558b5' },
  { id: '3', name: 'Daniel Jones', contact: '(555) 345-1123', type: 'registered', initials: 'DJ', color: '#2a9d4e' },
  { id: '4', name: 'Brinn Lo', contact: 'brinnlo@gmail.com', type: 'not_registered', initials: 'BL', color: '#9b59b6' },
  { id: '5', name: 'Chase External', contact: 'Bank Transfer', type: 'external', initials: 'CE', color: '#117ACA' },
  { id: '6', name: 'Bill Payees', contact: 'Saved payees', type: 'bill', initials: 'BP', color: '#e67e22' },
];

const AVATAR_COLORS = ['#e8563a', '#2558b5', '#2a9d4e', '#9b59b6', '#e67e22', '#117ACA', '#c0392b', '#16a085'];

function ZelleBadge() {
  return (
    <div style={{
      position: 'absolute', bottom: -2, right: -2,
      width: 16, height: 16, borderRadius: '50%',
      background: purple, border: '2px solid #fff',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}>
      <span style={{ color: '#fff', fontSize: 8, fontWeight: 900, fontStyle: 'italic' }}>Z</span>
    </div>
  );
}

function Avatar({ r, size = 48, showZelle = false }: { r: Recipient; size?: number; showZelle?: boolean }) {
  return (
    <div style={{ position: 'relative', width: size, height: size, flexShrink: 0 }}>
      <div style={{
        width: size, height: size, borderRadius: '50%',
        background: r.color, display: 'flex', alignItems: 'center', justifyContent: 'center',
        color: '#fff', fontWeight: 700, fontSize: size * 0.33,
      }}>{r.initials}</div>
      {showZelle && r.type === 'registered' && <ZelleBadge />}
    </div>
  );
}

// Add Recipient sub-screen
function AddRecipientScreen({ onSave, onCancel }: { onSave: (r: Recipient) => void; onCancel: () => void }) {
  const [name, setName] = useState('');
  const [contact, setContact] = useState('');
  const [type, setType] = useState<'registered' | 'not_registered'>('registered');

  function handleSave() {
    if (!name.trim() || !contact.trim()) return;
    const initials = name.trim().split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
    const color = AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)];
    const r: Recipient = {
      id: Date.now().toString(),
      name: name.trim(),
      contact: contact.trim(),
      type,
      initials,
      color,
    };
    onSave(r);
  }

  const inputStyle: React.CSSProperties = {
    width: '100%', border: 'none', borderBottom: '1.5px solid #ddd',
    outline: 'none', fontSize: 16, padding: '6px 0',
    background: 'transparent', fontFamily: "'Helvetica Neue', Arial, sans-serif",
  };

  return (
    <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', background: '#fff', fontFamily: "'Helvetica Neue', Arial, sans-serif" }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 16px', borderBottom: '1px solid #eee', flexShrink: 0 }}>
        <button onClick={onCancel} style={{ background: 'none', border: 'none', color: blue, fontSize: 15, cursor: 'pointer', fontWeight: 500, fontFamily: 'inherit' }}>Cancel</button>
        <div style={{ fontSize: 16, fontWeight: 700, color: '#111' }}>Add Recipient</div>
        <div style={{ width: 60 }} />
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: 24 }}>
        {/* Name */}
        <div style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 12, color: '#888', marginBottom: 6 }}>Full name</div>
          <input
            value={name}
            onChange={e => setName(e.target.value)}
            placeholder="e.g. John Smith"
            style={inputStyle}
          />
        </div>

        {/* Contact */}
        <div style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 12, color: '#888', marginBottom: 6 }}>Email or phone number</div>
          <input
            value={contact}
            onChange={e => setContact(e.target.value)}
            placeholder="email@example.com or (555) 123-4567"
            style={inputStyle}
          />
        </div>

        {/* Type */}
        <div style={{ marginBottom: 32 }}>
          <div style={{ fontSize: 12, color: '#888', marginBottom: 10 }}>Zelle® registration status</div>
          {(['registered', 'not_registered'] as const).map(t => (
            <button
              key={t}
              onClick={() => setType(t)}
              style={{
                display: 'flex', alignItems: 'center', gap: 12,
                width: '100%', background: 'none', border: 'none', cursor: 'pointer',
                padding: '12px 0', fontFamily: 'inherit', borderBottom: '1px solid #f0f0f0',
              }}
            >
              <div style={{
                width: 20, height: 20, borderRadius: '50%',
                border: `2px solid ${type === t ? blue : '#ccc'}`,
                background: type === t ? blue : 'transparent',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                flexShrink: 0,
              }}>
                {type === t && <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#fff' }} />}
              </div>
              <span style={{ fontSize: 15, color: '#111', fontWeight: type === t ? 600 : 400 }}>
                {t === 'registered' ? (
                  <>Registered with <span style={{ color: purple, fontStyle: 'italic', fontWeight: 700 }}>Zelle®</span></>
                ) : 'Not registered'}
              </span>
            </button>
          ))}
        </div>

        <button
          onClick={handleSave}
          disabled={!name.trim() || !contact.trim()}
          style={{
            width: '100%', background: name.trim() && contact.trim() ? blue : '#ccc',
            color: '#fff', border: 'none', borderRadius: 8,
            padding: '15px', fontSize: 16, fontWeight: 600, cursor: name.trim() && contact.trim() ? 'pointer' : 'not-allowed',
          }}
        >
          Add Recipient
        </button>
      </div>
    </div>
  );
}

interface Props {
  onSelectRecipient: (r: Recipient) => void;
  onBack: () => void;
}

export default function ZelleRecipients({ onSelectRecipient, onBack }: Props) {
  const [search, setSearch] = useState('');
  const [billOpen, setBillOpen] = useState(false);
  const [regOpen, setRegOpen] = useState(true);
  const [notRegOpen, setNotRegOpen] = useState(true);
  const [activeTab, setActiveTab] = useState<'pay' | 'due'>('pay');
  const [showAdd, setShowAdd] = useState(false);
  const [recipients, setRecipients] = useState<Recipient[]>(DEFAULT_RECENT);

  const registered = recipients.filter(r => r.type === 'registered');
  const notRegistered = recipients.filter(r => r.type === 'not_registered');
  const recentAll = recipients.slice(0, 6);

  const filtered = (list: Recipient[]) =>
    search ? list.filter(r => r.name.toLowerCase().includes(search.toLowerCase()) || r.contact.toLowerCase().includes(search.toLowerCase())) : list;

  function handleAddSave(r: Recipient) {
    setRecipients(prev => [r, ...prev]);
    setShowAdd(false);
  }

  if (showAdd) {
    return <AddRecipientScreen onSave={handleAddSave} onCancel={() => setShowAdd(false)} />;
  }

  return (
    <div style={{
      width: '100%', height: '100%', display: 'flex', flexDirection: 'column',
      background: '#fff', fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
      overflow: 'hidden',
    }}>
      {/* Top nav */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '14px 16px', borderBottom: '1px solid #eee', background: '#fff', flexShrink: 0,
      }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path d="M15 18l-6-6 6-6" stroke="#333" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
        <div style={{ textAlign: 'center', flex: 1 }}>
          <div style={{ fontSize: 15, fontWeight: 700, color: '#111', lineHeight: 1.2 }}>
            Pay Bills &amp; send money with{' '}
            <span style={{ color: purple, fontStyle: 'italic', fontWeight: 800 }}>Zelle®</span>
          </div>
        </div>
        <button style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="12" r="3" stroke="#333" strokeWidth="1.8" />
            <path d="M12 2v2M12 20v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M2 12h2M20 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42" stroke="#333" strokeWidth="1.8" strokeLinecap="round" />
          </svg>
        </button>
      </div>

      {/* Tab bar */}
      <div style={{ display: 'flex', borderBottom: '1px solid #eee', flexShrink: 0 }}>
        {(['pay', 'due'] as const).map(tab => (
          <button key={tab} onClick={() => setActiveTab(tab)} style={{
            flex: 1, height: 48, background: 'none', border: 'none', cursor: 'pointer',
            fontSize: 15, fontWeight: activeTab === tab ? 700 : 400,
            color: activeTab === tab ? blue : '#666',
            borderBottom: activeTab === tab ? `3px solid ${blue}` : '3px solid transparent',
          }}>
            {tab === 'pay' ? 'Pay' : 'Payments due'}
          </button>
        ))}
      </div>

      {/* Scrollable content */}
      <div style={{ flex: 1, overflowY: 'auto' }}>
        {/* Search bar */}
        <div style={{ display: 'flex', alignItems: 'center', margin: '12px 16px', background: '#f5f5f5', borderRadius: 8, padding: '0 12px', gap: 8 }}>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
            <circle cx="11" cy="11" r="7" stroke={gray} strokeWidth="1.8" />
            <path d="M20 20l-3-3" stroke={gray} strokeWidth="2" strokeLinecap="round" />
          </svg>
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search your recipients"
            style={{ flex: 1, border: 'none', background: 'none', fontSize: 15, color: '#333', outline: 'none', padding: '12px 0' }}
          />
          <div style={{ width: 1, height: 20, background: '#ddd' }} />
          <button
            onClick={() => setShowAdd(true)}
            style={{ display: 'flex', alignItems: 'center', gap: 4, background: 'none', border: 'none', cursor: 'pointer', color: blue, fontSize: 14, fontWeight: 600 }}
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
              <circle cx="12" cy="12" r="9" stroke={blue} strokeWidth="1.8" />
              <line x1="12" y1="8" x2="12" y2="16" stroke={blue} strokeWidth="1.8" strokeLinecap="round" />
              <line x1="8" y1="12" x2="16" y2="12" stroke={blue} strokeWidth="1.8" strokeLinecap="round" />
            </svg>
            Add
          </button>
        </div>

        {/* QR code row */}
        <div style={{ display: 'flex', alignItems: 'center', padding: '14px 16px', borderBottom: '1px solid #f0f0f0', cursor: 'pointer', gap: 12 }}>
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
            <rect x="3" y="3" width="7" height="7" rx="1" stroke="#333" strokeWidth="1.6" />
            <rect x="14" y="3" width="7" height="7" rx="1" stroke="#333" strokeWidth="1.6" />
            <rect x="3" y="14" width="7" height="7" rx="1" stroke="#333" strokeWidth="1.6" />
            <rect x="5" y="5" width="3" height="3" fill="#333" />
            <rect x="16" y="5" width="3" height="3" fill="#333" />
            <rect x="5" y="16" width="3" height="3" fill="#333" />
            <path d="M14 14h3v3M17 17v3h3M14 17h.01" stroke="#333" strokeWidth="1.6" strokeLinecap="round" />
          </svg>
          <span style={{ flex: 1, fontSize: 15, color: '#222' }}>
            Scan QR code to pay with <span style={{ color: purple, fontStyle: 'italic', fontWeight: 700 }}>Zelle®</span>
          </span>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
            <path d="M9 18l6-6-6-6" stroke={gray} strokeWidth="1.8" strokeLinecap="round" />
          </svg>
        </div>

        {/* Recent recipients */}
        <div style={{ padding: '12px 0 8px 16px', fontSize: 14, fontWeight: 600, color: '#333' }}>Recent recipients</div>
        <div style={{ overflowX: 'auto', display: 'flex', gap: 12, padding: '4px 16px 16px', scrollbarWidth: 'none' }}>
          {recentAll.map(r => (
            <div key={r.id} onClick={() => onSelectRecipient(r)} style={{ width: 80, flexShrink: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, cursor: 'pointer' }}>
              <Avatar r={r} size={56} showZelle />
              <div style={{ fontSize: 12, color: '#333', fontWeight: 500, textAlign: 'center', width: '100%', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {r.name.split(' ')[0]}
              </div>
              <div style={{ fontSize: 11, color: gray, textAlign: 'center', width: '100%', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {r.contact.slice(0, 10)}..
              </div>
            </div>
          ))}
        </div>

        {/* Bill Pay section */}
        <CollapsibleSection title="Bill Pay recipients" isOpen={billOpen} onToggle={() => setBillOpen(v => !v)} zelleTitle={false}>
          <div style={{ padding: '12px 16px', color: gray, fontSize: 14 }}>No saved bill pay recipients</div>
        </CollapsibleSection>

        {/* Registered with Zelle */}
        <CollapsibleSection title="Registered with" zelleTitle isOpen={regOpen} onToggle={() => setRegOpen(v => !v)}>
          {filtered(registered).map(r => (
            <RecipientRow key={r.id} r={r} showZelle onSelect={() => onSelectRecipient(r)} />
          ))}
        </CollapsibleSection>

        {/* Not registered */}
        <CollapsibleSection title="Not registered with" zelleTitle isOpen={notRegOpen} onToggle={() => setNotRegOpen(v => !v)} helperText="You can still send money, and they'll get it once they register.">
          {filtered(notRegistered).map(r => (
            <RecipientRow key={r.id} r={r} showZelle={false} onSelect={() => onSelectRecipient(r)} />
          ))}
        </CollapsibleSection>

        <div style={{ height: 24 }} />
      </div>
    </div>
  );
}

function CollapsibleSection({ title, zelleTitle = false, isOpen, onToggle, children, helperText }: {
  title: string; zelleTitle?: boolean; isOpen: boolean; onToggle: () => void;
  children: React.ReactNode; helperText?: string;
}) {
  return (
    <div style={{ borderTop: '1px solid #f0f0f0' }}>
      <div onClick={onToggle} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 16px', cursor: 'pointer', background: '#fafafa' }}>
        <span style={{ fontSize: 15, fontWeight: 600, color: '#222' }}>
          {title}{' '}
          {zelleTitle && <span style={{ color: purple, fontStyle: 'italic', fontWeight: 800 }}>Zelle®</span>}
        </span>
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" style={{ transform: isOpen ? 'rotate(180deg)' : 'rotate(0deg)', transition: 'transform 0.2s' }}>
          <path d="M6 9l6 6 6-6" stroke={gray} strokeWidth="2" strokeLinecap="round" />
        </svg>
      </div>
      <div style={{ maxHeight: isOpen ? 1000 : 0, overflow: 'hidden', transition: 'max-height 0.3s ease' }}>
        {helperText && <div style={{ padding: '8px 16px 4px', fontSize: 13, color: gray }}>{helperText}</div>}
        {children}
      </div>
    </div>
  );
}

function RecipientRow({ r, showZelle, onSelect }: { r: Recipient; showZelle: boolean; onSelect: () => void }) {
  return (
    <div onClick={onSelect} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '12px 16px', borderBottom: '1px solid #f5f5f5', cursor: 'pointer', minHeight: 72 }}>
      <Avatar r={r} size={48} showZelle={showZelle} />
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 15, fontWeight: 600, color: '#111' }}>{r.name}</div>
        <div style={{ fontSize: 13, color: gray, marginTop: 2 }}>{r.contact}</div>
      </div>
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
        <path d="M9 18l6-6-6-6" stroke={gray} strokeWidth="1.8" strokeLinecap="round" />
      </svg>
    </div>
  );
}
