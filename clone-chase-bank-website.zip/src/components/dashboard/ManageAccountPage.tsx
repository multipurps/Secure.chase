const blue = '#2558b5';
const chaseBlue = '#E8F0FB';

const ICON_ITEMS = [
  {
    label: 'Stored cards',
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
        <rect x="2" y="6" width="20" height="13" rx="2" stroke={blue} strokeWidth="1.8" fill="none" />
        <rect x="4" y="10" width="20" height="13" rx="2" stroke={blue} strokeWidth="1.8" fill={chaseBlue} />
        <rect x="6" y="14" width="8" height="2" rx="1" fill={blue} />
      </svg>
    ),
  },
  {
    label: 'View payment activity',
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
        <rect x="3" y="4" width="18" height="16" rx="2" stroke={blue} strokeWidth="1.8" fill="none" />
        <line x1="7" y1="9" x2="17" y2="9" stroke={blue} strokeWidth="1.6" strokeLinecap="round" />
        <line x1="7" y1="13" x2="13" y2="13" stroke={blue} strokeWidth="1.6" strokeLinecap="round" />
        <circle cx="18" cy="17" r="4" fill={blue} />
        <line x1="18" y1="15" x2="18" y2="19" stroke="#fff" strokeWidth="1.4" strokeLinecap="round" />
        <line x1="16" y1="17" x2="20" y2="17" stroke="#fff" strokeWidth="1.4" strokeLinecap="round" />
      </svg>
    ),
  },
  {
    label: 'Pay over time',
    icon: (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
        <path d="M12 2C8 2 4 5.5 4 10c0 5.5 8 12 8 12s8-6.5 8-12c0-4.5-4-8-8-8z" stroke={blue} strokeWidth="1.8" fill="none" />
        <circle cx="12" cy="10" r="3" stroke={blue} strokeWidth="1.6" fill="none" />
        <line x1="12" y1="7.5" x2="12" y2="9" stroke={blue} strokeWidth="1.4" strokeLinecap="round" />
        <text x="10" y="10.8" fontSize="4" fill={blue} fontWeight="700">$</text>
      </svg>
    ),
  },
];

const LIST_ITEMS = [
  'Refer a friend',
  'Transfer a balance',
  'Credit limit increase',
  'Update income',
  'Request a new due date',
  'Digital wallets',
  'Authorized users',
  'Freeze card',
  'Dispute a charge',
  'Request replacement card',
  'Add travel notice',
  'Redeem rewards',
];

interface Props {
  onClose: () => void;
}

export default function ManageAccountPage({ onClose }: Props) {
  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 800,
      background: '#fff', display: 'flex', flexDirection: 'column',
      fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
      overflowY: 'auto',
    }}>
      {/* Header */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '16px 20px', borderBottom: '1px solid #f0f0f0', flexShrink: 0,
        paddingTop: 52,
      }}>
        <div style={{ width: 32 }} />
        <div style={{ fontWeight: 700, fontSize: 17, color: '#111' }}>Manage account</div>
        <button
          onClick={onClose}
          style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 22, color: '#666', lineHeight: 1, fontFamily: 'inherit', padding: 0, width: 32, display: 'flex', alignItems: 'center', justifyContent: 'center' }}
        >
          ×
        </button>
      </div>

      {/* Top icon grid */}
      <div style={{ display: 'flex', justifyContent: 'space-around', padding: '28px 20px 20px', borderBottom: '1px solid #f0f0f0' }}>
        {ICON_ITEMS.map(item => (
          <button key={item.label} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10, background: 'none', border: 'none', cursor: 'pointer', flex: 1 }}>
            <div style={{
              width: 72, height: 72, borderRadius: '50%',
              background: '#E8F0FB',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              {item.icon}
            </div>
            <span style={{ fontSize: 13, fontWeight: 600, color: blue, textAlign: 'center', lineHeight: 1.3, maxWidth: 80 }}>
              {item.label}
            </span>
          </button>
        ))}
      </div>

      {/* List items */}
      <div style={{ flex: 1 }}>
        {LIST_ITEMS.map((item, i) => (
          <button
            key={item}
            style={{
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              width: '100%', padding: '19px 20px',
              background: 'none', border: 'none',
              borderBottom: i < LIST_ITEMS.length - 1 ? '1px solid #E5E5EA' : 'none',
              cursor: 'pointer', fontFamily: 'inherit',
              textAlign: 'left',
            }}
          >
            <span style={{ fontSize: 16, color: '#111', fontWeight: 400 }}>{item}</span>
            <svg width="8" height="14" viewBox="0 0 8 14" fill="none">
              <polyline points="1,1 7,7 1,13" stroke="#bbb" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
        ))}
      </div>
    </div>
  );
}
