interface BottomNavProps {
  active: 'accounts' | 'pay' | 'plan' | 'benefits' | 'investments';
  onChange: (tab: 'accounts' | 'pay' | 'plan' | 'benefits' | 'investments') => void;
}

export default function BottomNav({ active, onChange }: BottomNavProps) {
  const blue = '#2558b5';
  const gray = '#999';

  const tabs = [
    {
      id: 'accounts' as const,
      label: 'Accounts',
      icon: (isActive: boolean) => (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
          <rect x="2" y="5" width="20" height="14" rx="2" ry="2"
            stroke={isActive ? blue : gray} strokeWidth="1.8"
            fill={isActive ? blue : 'none'} />
          <rect x="2" y="9" width="20" height="3"
            fill={isActive ? '#fff' : 'none'}
            stroke={isActive ? blue : gray} strokeWidth={isActive ? 0 : 1.8} />
          <rect x="5" y="14" width="5" height="2" rx="1"
            fill={isActive ? '#fff' : gray} />
        </svg>
      ),
    },
    {
      id: 'pay' as const,
      label: 'Pay & transfer',
      icon: (isActive: boolean) => (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="12" r="9" stroke={isActive ? blue : gray} strokeWidth="1.8" fill="none" />
          <text x="12" y="16" textAnchor="middle" fontSize="11" fontWeight="700"
            fill={isActive ? blue : gray} fontFamily="Helvetica Neue, Arial, sans-serif">$</text>
          <path d="M7 8 Q12 4 17 8" stroke={isActive ? blue : gray} strokeWidth="1.6" fill="none" strokeLinecap="round" />
          <path d="M17 16 Q12 20 7 16" stroke={isActive ? blue : gray} strokeWidth="1.6" fill="none" strokeLinecap="round" />
          <polyline points="15,5 17,8 14,8" fill={isActive ? blue : gray} stroke="none" />
          <polyline points="9,19 7,16 10,16" fill={isActive ? blue : gray} stroke="none" />
        </svg>
      ),
    },
    {
      id: 'plan' as const,
      label: 'Plan & track',
      icon: (isActive: boolean) => (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
          <rect x="4" y="3" width="13" height="17" rx="2"
            stroke={isActive ? blue : gray} strokeWidth="1.8"
            fill={isActive ? blue : 'none'} />
          <line x1="7" y1="8" x2="14" y2="8" stroke={isActive ? '#fff' : gray} strokeWidth="1.6" strokeLinecap="round" />
          <line x1="7" y1="12" x2="14" y2="12" stroke={isActive ? '#fff' : gray} strokeWidth="1.6" strokeLinecap="round" />
          <line x1="7" y1="16" x2="11" y2="16" stroke={isActive ? '#fff' : gray} strokeWidth="1.6" strokeLinecap="round" />
          <circle cx="18" cy="18" r="4" fill={isActive ? blue : gray} />
          <line x1="18" y1="15.5" x2="18" y2="18" stroke="white" strokeWidth="1.4" strokeLinecap="round" />
          <line x1="18" y1="18" x2="19.5" y2="19.5" stroke="white" strokeWidth="1.4" strokeLinecap="round" />
        </svg>
      ),
    },
    {
      id: 'benefits' as const,
      label: 'Benefits',
      icon: (isActive: boolean) => (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
          <polygon
            points="12,2 15.09,8.26 22,9.27 17,14.14 18.18,21.02 12,17.77 5.82,21.02 7,14.14 2,9.27 8.91,8.26"
            stroke={isActive ? blue : gray} strokeWidth="1.8"
            fill={isActive ? blue : 'none'}
            strokeLinejoin="round"
          />
        </svg>
      ),
    },
    {
      id: 'investments' as const,
      label: 'Investments',
      icon: (isActive: boolean) => (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
          {/* Baseline */}
          <line x1="2" y1="20" x2="22" y2="20" stroke={isActive ? blue : gray} strokeWidth="1.8" strokeLinecap="round" />
          {/* Chart line with upward trend */}
          <polyline
            points="2,16 6,12 10,14 14,8 18,5 22,7"
            stroke={isActive ? blue : gray}
            strokeWidth="2"
            fill="none"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          {/* Up arrow at end */}
          <polyline
            points="19,4 22,7 19,7"
            stroke={isActive ? blue : gray}
            strokeWidth="2"
            fill="none"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      ),
    },
  ];

  return (
    <div style={{
      position: 'fixed',
      bottom: 0,
      left: 0,
      right: 0,
      height: 60,
      background: '#fff',
      borderTop: '1px solid #e0e0e0',
      display: 'flex',
      alignItems: 'stretch',
      zIndex: 100,
      paddingBottom: 'env(safe-area-inset-bottom)',
    }}>
      {tabs.map(tab => {
        const isActive = active === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => onChange(tab.id)}
            style={{
              flex: 1,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 3,
              border: 'none',
              background: 'transparent',
              cursor: 'pointer',
              padding: '4px 2px',
            }}
          >
            {tab.icon(isActive)}
            <span style={{
              fontSize: 10,
              fontWeight: isActive ? 700 : 400,
              color: isActive ? blue : gray,
              textAlign: 'center',
              lineHeight: 1.2,
              maxWidth: 64,
            }}>
              {tab.label}
            </span>
          </button>
        );
      })}
    </div>
  );
}
