import { useState } from 'react';
import BottomNav from './BottomNav';
import AccountsDashboard from './AccountsDashboard';
import PayTransfer from './PayTransfer';
import PlanTrack from './PlanTrack';
import ChaseOffers from './ChaseOffers';
import More from './More';
import ProfileSettings from '../profile/ProfileSettings';
import FraudMonitoringAI from '../profile/FraudMonitoringAI';
import ChaseDigitalAssistant from '../profile/ChaseDigitalAssistant';
import ZelleFlow from './zelle/ZelleFlow';
import CheckDeposit from './CheckDeposit';
import WiresFlow from './paytransfer/wires/WiresFlow';
import UltimateRewards from './UltimateRewards';
import InvestmentsByJPM from './investments/InvestmentsByJPM';
import PayBillsFlow from './investments/PayBillsFlow';

type Tab = 'accounts' | 'pay' | 'plan' | 'benefits' | 'investments';
type SubPage =
  | 'none'
  | 'profile'
  | 'zelle'
  | 'check-deposit'
  | 'offers'
  | 'fraud-ai'
  | 'digital-assistant'
  | 'wires'
  | 'rewards'
  | 'paybills';

interface DashboardProps {
  onSignOut: () => void;
}

const pageWrap: React.CSSProperties = {
  width: '100%',
  minHeight: '100dvh',
  position: 'relative',
  fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
  background: '#f0f4f8',
  display: 'flex',
  flexDirection: 'column',
};

const contentStyle: React.CSSProperties = {
  width: '100%',
  flex: 1,
  overflow: 'hidden',
  position: 'relative',
  paddingBottom: 60,
};

const scrollContentStyle: React.CSSProperties = {
  width: '100%',
  height: '100%',
  overflowY: 'auto',
  overflowX: 'hidden',
};

export default function Dashboard({ onSignOut }: DashboardProps) {
  const [activeTab, setActiveTab] = useState<Tab>('accounts');
  const [subPage, setSubPage] = useState<SubPage>('none');

  function goToTab(tab: Tab) {
    setSubPage('none');
    setActiveTab(tab);
  }

  function renderSubPage() {
    if (subPage === 'profile') {
      return <ProfileSettings onBack={() => setSubPage('none')} onSignOut={onSignOut} />;
    }
    if (subPage === 'zelle') {
      return <ZelleFlow onBack={() => setSubPage('none')} />;
    }
    if (subPage === 'check-deposit') {
      return <CheckDeposit onBack={() => setSubPage('none')} />;
    }
    if (subPage === 'offers') {
      return <ChaseOffers onBack={() => setSubPage('none')} />;
    }
    if (subPage === 'fraud-ai') {
      return <FraudMonitoringAI onBack={() => setSubPage('none')} userFirstName="Demo" />;
    }
    if (subPage === 'digital-assistant') {
      return <ChaseDigitalAssistant onBack={() => setSubPage('none')} userFirstName="Demo" />;
    }
    if (subPage === 'wires') {
      return <WiresFlow onBack={() => setSubPage('none')} />;
    }
    if (subPage === 'rewards') {
      return <UltimateRewards onBack={() => setSubPage('none')} />;
    }
    if (subPage === 'paybills') {
      return <PayBillsFlow onBack={() => setSubPage('none')} />;
    }
    return null;
  }

  const sub = renderSubPage();
  if (sub) {
    return (
      <div style={pageWrap}>
        <div style={{ ...contentStyle, paddingBottom: 60 }}>
          <div style={scrollContentStyle}>
            {sub}
          </div>
        </div>
        <BottomNav active={activeTab} onChange={goToTab} />
      </div>
    );
  }

  return (
    <div style={pageWrap}>
      <div style={contentStyle}>
        <div style={scrollContentStyle}>
          {activeTab === 'accounts' && (
            <AccountsDashboard
              onProfile={() => setSubPage('profile')}
              onZelle={() => setSubPage('zelle')}
              onDeposit={() => setSubPage('check-deposit')}
              onPayTransfer={() => setActiveTab('pay')}
              onWires={() => setSubPage('wires')}
              onOffers={() => setSubPage('offers')}
              onPlanTrack={() => setActiveTab('plan')}
              onChat={() => setSubPage('digital-assistant')}
            />
          )}
          {activeTab === 'pay' && (
            <PayTransfer
              onZelle={() => setSubPage('zelle')}
              onDeposit={() => setSubPage('check-deposit')}
              onPayBills={() => setSubPage('paybills')}
            />
          )}
          {activeTab === 'plan' && <PlanTrack />}
          {activeTab === 'benefits' && (
            <ChaseOffers onBack={() => setActiveTab('accounts')} />
          )}
          {activeTab === 'investments' && (
            <InvestmentsByJPM onBack={() => setActiveTab('accounts')} />
          )}
        </div>
      </div>

      {/* FIXED BOTTOM NAV */}
      <BottomNav active={activeTab} onChange={goToTab} />

      {/* More — unused, kept for future reference */}
      {false && <More onProfile={() => {}} onFraudAI={() => {}} onDigitalAssistant={() => {}} />}
    </div>
  );
}
