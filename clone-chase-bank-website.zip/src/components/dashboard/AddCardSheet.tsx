interface Props {
  onClose: () => void;
}

const BLUE = '#2558b5';

const CHASE_CARDS = [
  {
    id: 'sapphire-preferred',
    name: 'Chase Sapphire Preferred®',
    reward: 'Earn 75,000 bonus points',
    sub: 'After $4,000 in purchases in the first 3 months',
    annualFee: '$95 annual fee',
    img: 'https://creditcards.chase.com/K-Marketplace/images/cardbucket/sapphirepreferred/credit_card.png',
    color: '#1c2d5a',
  },
  {
    id: 'sapphire-reserve',
    name: 'Chase Sapphire Reserve®',
    reward: 'Earn 75,000 bonus points',
    sub: 'After $4,000 in purchases in the first 3 months',
    annualFee: '$550 annual fee',
    img: 'https://creditcards.chase.com/K-Marketplace/images/cardbucket/sapphirereserve/credit_card.png',
    color: '#222',
  },
  {
    id: 'freedom-unlimited',
    name: 'Chase Freedom Unlimited®',
    reward: 'Earn $250 cash back',
    sub: 'After $500 in purchases in the first 3 months',
    annualFee: 'No annual fee',
    img: 'https://creditcards.chase.com/K-Marketplace/images/cardbucket/freedomunlimited/credit_card.png',
    color: '#1a5ba8',
  },
  {
    id: 'amazon-prime',
    name: 'Amazon Prime Rewards Visa',
    reward: '5% back at Amazon & Whole Foods',
    sub: 'Plus earn up to $150 Amazon Gift Card instantly',
    annualFee: 'No annual fee (Prime required)',
    img: 'https://creditcards.chase.com/K-Marketplace/images/cardbucket/amazonprimevisa/credit_card.png',
    color: '#131921',
  },
  {
    id: 'ink-business',
    name: 'Ink Business Cash®',
    reward: 'Earn $750 bonus cash back',
    sub: 'After $6,000 in purchases in the first 3 months',
    annualFee: 'No annual fee',
    img: 'https://creditcards.chase.com/K-Marketplace/images/cardbucket/inkbusinesscash/credit_card.png',
    color: '#003087',
  },
];

export default function AddCardSheet({ onClose }: Props) {
  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 500,
      background: 'rgba(0,0,0,0.4)',
      display: 'flex', alignItems: 'flex-end',
    }} onClick={onClose}>
      <div
        onClick={e => e.stopPropagation()}
        style={{
          width: '100%', background: '#f5f5f5',
          borderRadius: '16px 16px 0 0',
          maxHeight: '88vh', overflowY: 'auto',
          animation: 'slideUp 0.3s ease',
        }}
      >
        {/* drag handle */}
        <div style={{ display: 'flex', justifyContent: 'center', padding: '12px 0 0' }}>
          <div style={{ width: 40, height: 4, borderRadius: 2, background: '#ddd' }} />
        </div>

        {/* header */}
        <div style={{ padding: '16px 20px', background: '#f5f5f5', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span style={{ fontSize: 17, fontWeight: 700, color: '#111' }}>Add a Card</span>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 22, color: '#999' }}>×</button>
        </div>

        <div style={{ padding: '4px 16px 0', fontSize: 14, color: '#666', marginBottom: 12 }}>
          Choose a Chase card to add to your account or wallet.
        </div>

        {CHASE_CARDS.map(card => (
          <div key={card.id} style={{
            background: '#fff', margin: '0 16px 12px', borderRadius: 14,
            overflow: 'hidden', boxShadow: '0 2px 10px rgba(0,0,0,0.07)',
          }}>
            {/* card image banner */}
            <div style={{ background: card.color, padding: '20px', display: 'flex', justifyContent: 'center', height: 100, alignItems: 'center' }}>
              <img src={card.img} alt={card.name}
                style={{ height: 80, objectFit: 'contain', borderRadius: 6 }}
                onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }} />
            </div>
            <div style={{ padding: '14px 16px' }}>
              <div style={{ fontSize: 15, fontWeight: 700, color: '#111', marginBottom: 4 }}>{card.name}</div>
              <div style={{ fontSize: 14, color: '#2e7d32', fontWeight: 600, marginBottom: 2 }}>{card.reward}</div>
              <div style={{ fontSize: 13, color: '#666', marginBottom: 4 }}>{card.sub}</div>
              <div style={{ fontSize: 12, color: '#888', marginBottom: 14 }}>{card.annualFee}</div>
              <button style={{
                width: '100%', padding: '13px 0',
                background: BLUE, color: '#fff',
                border: 'none', borderRadius: 8,
                fontSize: 15, fontWeight: 700, cursor: 'pointer',
              }}>
                Apply now
              </button>
            </div>
          </div>
        ))}

        <div style={{ height: 20 }} />
        <style>{`@keyframes slideUp { from { transform: translateY(100%); } to { transform: translateY(0); } }`}</style>
      </div>
    </div>
  );
}
