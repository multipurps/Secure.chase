import { useState } from 'react';

interface Props {
  onClose: () => void;
  defaultDisplay: 'expanded' | 'collapsed';
  showSubtotals: boolean;
  onDisplayChange: (v: 'expanded' | 'collapsed') => void;
  onSubtotalsChange: (v: boolean) => void;
}

export default function PreferencesSheet({ onClose, defaultDisplay, showSubtotals, onDisplayChange, onSubtotalsChange }: Props) {
  const [display, setDisplay] = useState<'expanded' | 'collapsed'>(defaultDisplay);
  const [subtotals, setSubtotals] = useState(showSubtotals);
  const blue = '#2558b5';

  function handleDisplayChange(v: 'expanded' | 'collapsed') {
    setDisplay(v);
    onDisplayChange(v);
  }

  function handleSubtotalsChange(v: boolean) {
    setSubtotals(v);
    onSubtotalsChange(v);
  }

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 9999,
      display: 'flex', flexDirection: 'column', justifyContent: 'flex-end',
    }}>
      {/* Overlay */}
      <div
        onClick={onClose}
        style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.45)' }}
      />
      {/* Sheet */}
      <div style={{
        position: 'relative', background: '#fff',
        borderRadius: '16px 16px 0 0',
        padding: '0 0 40px',
        animation: 'slideUp 0.3s ease',
        fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
        maxHeight: '85vh', overflowY: 'auto',
      }}>
        <style>{`@keyframes slideUp { from { transform: translateY(100%); } to { transform: translateY(0); } }`}</style>

        {/* Drag handle */}
        <div style={{ display: 'flex', justifyContent: 'center', paddingTop: 10, paddingBottom: 4 }}>
          <div style={{ width: 40, height: 4, background: '#ccc', borderRadius: 2 }} />
        </div>

        {/* Header */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          padding: '12px 20px 16px', position: 'relative',
        }}>
          <span style={{ fontWeight: 700, fontSize: 17, color: '#111' }}>Preferences</span>
          <button
            onClick={onClose}
            style={{
              position: 'absolute', right: 20, top: 12,
              background: 'none', border: 'none', cursor: 'pointer',
              fontSize: 22, color: '#999', lineHeight: 1,
            }}
          >×</button>
        </div>

        {/* Account wallet section */}
        <div style={{ padding: '0 20px 16px', borderBottom: '1px solid #f0f0f0' }}>
          <div style={{ fontWeight: 700, fontSize: 15, color: '#111', textAlign: 'center', marginBottom: 16 }}>
            Account wallet
          </div>

          {/* Show subtotals toggle */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span style={{ fontSize: 15, color: '#111' }}>Show subtotals by account type</span>
            <div
              onClick={() => handleSubtotalsChange(!subtotals)}
              style={{
                width: 51, height: 31, borderRadius: 999,
                background: subtotals ? blue : '#ddd',
                cursor: 'pointer', position: 'relative',
                transition: 'background 0.2s',
                flexShrink: 0,
              }}
            >
              <div style={{
                position: 'absolute', top: 3,
                left: subtotals ? 23 : 3,
                width: 25, height: 25, borderRadius: '50%',
                background: '#fff',
                boxShadow: '0 1px 4px rgba(0,0,0,0.3)',
                transition: 'left 0.2s',
              }} />
            </div>
          </div>
        </div>

        {/* Default display section */}
        <div style={{ padding: '16px 20px 0' }}>
          <div style={{ fontWeight: 700, fontSize: 15, color: '#111', textAlign: 'center', marginBottom: 20 }}>
            Default display
          </div>

          <div style={{ display: 'flex', gap: 20, justifyContent: 'center' }}>
            {/* All expanded */}
            <div
              onClick={() => handleDisplayChange('expanded')}
              style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10, cursor: 'pointer', flex: 1 }}
            >
              <div style={{
                width: '100%', maxWidth: 130, height: 80, borderRadius: 10,
                background: '#fff', border: `2px solid ${display === 'expanded' ? blue : '#e0e0e0'}`,
                padding: '10px 12px',
                display: 'flex', flexDirection: 'column', gap: 8,
              }}>
                {[0, 1, 2, 3].map(i => (
                  <div key={i} style={{ height: 8, borderRadius: 4, background: blue, width: '100%' }} />
                ))}
              </div>
              <span style={{ fontSize: 14, fontWeight: 700, color: display === 'expanded' ? blue : '#111' }}>
                All expanded
              </span>
              <div style={{
                width: 22, height: 22, borderRadius: '50%',
                background: display === 'expanded' ? blue : 'transparent',
                border: `2px solid ${display === 'expanded' ? blue : '#ccc'}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                {display === 'expanded' && (
                  <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                    <polyline points="2,6 5,9 10,3" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                )}
              </div>
            </div>

            {/* All collapsed */}
            <div
              onClick={() => handleDisplayChange('collapsed')}
              style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10, cursor: 'pointer', flex: 1 }}
            >
              <div style={{
                width: '100%', maxWidth: 130, height: 80, borderRadius: 10,
                background: '#f5f5f5', border: `2px solid ${display === 'collapsed' ? blue : '#e0e0e0'}`,
                padding: '10px 12px',
                display: 'flex', flexDirection: 'column', gap: 10, justifyContent: 'center',
              }}>
                {[0, 1].map(i => (
                  <div key={i} style={{ height: 6, borderRadius: 4, background: '#ccc', width: '80%', margin: '0 auto' }} />
                ))}
              </div>
              <span style={{ fontSize: 14, fontWeight: 700, color: display === 'collapsed' ? blue : '#111' }}>
                All collapsed
              </span>
              <div style={{
                width: 22, height: 22, borderRadius: '50%',
                background: display === 'collapsed' ? blue : 'transparent',
                border: `2px solid ${display === 'collapsed' ? blue : '#ccc'}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                {display === 'collapsed' && (
                  <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                    <polyline points="2,6 5,9 10,3" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
