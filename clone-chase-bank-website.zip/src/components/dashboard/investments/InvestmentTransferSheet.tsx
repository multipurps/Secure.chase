interface Props {
  onClose: () => void;
  onFunding: () => void;
}

const BLUE = '#2558b5';
const BORDER = '#e5e7eb';

export default function InvestmentTransferSheet({ onClose, onFunding }: Props) {
  const rows = [
    { title: 'Transfer money', desc: 'Move cash between your investment accounts.', action: onFunding, hasIcon: false },
    { title: 'Transfer securities', desc: 'Move assets between your investment accounts.', action: onFunding, hasIcon: false },
    { title: 'Roll over to an IRA', desc: 'Move your retirement plan into a J.P. Morgan IRA.', action: () => {}, hasIcon: false },
    { title: 'Money transfer activity', desc: '', action: () => {}, hasIcon: true },
    { title: 'Securities transfer activity', desc: '', action: () => {}, hasIcon: true },
  ];

  return (
    <div style={{ position: 'fixed', inset: 0, zIndex: 300, display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
      <div style={{ flex: 1, background: 'rgba(0,0,0,0.4)' }} onClick={onClose} />
      <div style={{ background: '#fff', borderRadius: '16px 16px 0 0', maxHeight: '80vh', overflow: 'auto' }}>
        <div style={{ width: 40, height: 4, background: '#ccc', borderRadius: 2, margin: '16px auto 8px' }} />
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 20px 16px' }}>
          <span style={{ fontSize: 17, fontWeight: 700, color: '#111', flex: 1, textAlign: 'center' }}>Transfer</span>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#888', fontSize: 22 }}>×</button>
        </div>

        <div style={{ background: '#f5f5f5', padding: '6px 16px' }}>
          <span style={{ fontSize: 11, color: '#888', letterSpacing: 1, textTransform: 'uppercase' as const, fontWeight: 600 }}>INVESTMENT ACCOUNTS</span>
        </div>

        {rows.map((row, i) => (
          <div key={i} onClick={row.action}
            style={{ padding: '16px 20px', borderTop: `1px solid ${BORDER}`, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 12 }}>
            {row.hasIcon && (
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
                <rect x="3" y="3" width="18" height="18" rx="2" fill={BLUE} />
                <line x1="7" y1="8" x2="17" y2="8" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" />
                <line x1="7" y1="12" x2="17" y2="12" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" />
                <line x1="7" y1="16" x2="13" y2="16" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" />
              </svg>
            )}
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 15, fontWeight: 600, color: '#111' }}>{row.title}</div>
              {row.desc && <div style={{ fontSize: 13, color: '#888', marginTop: 2 }}>{row.desc}</div>}
            </div>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
              <path d="M9 18l6-6-6-6" stroke="#999" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
        ))}
      </div>
    </div>
  );
}
