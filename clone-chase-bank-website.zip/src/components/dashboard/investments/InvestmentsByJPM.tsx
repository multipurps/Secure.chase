import { useState, useEffect } from 'react';
import InvestmentDashboard from './InvestmentDashboard';
import InvestmentTransferSheet from './InvestmentTransferSheet';
import TransferFundingPage from './TransferFundingPage';
import LinkExternalAccount from './LinkExternalAccount';
import TradeScreen from './TradeScreen';

interface InvestmentsByJPMProps {
  onBack: () => void;
}

const NAVY = '#0d1f3c';
const BLUE = '#2558b5';
const POS_GREEN = '#2e7d32';
const NEG_RED = '#c0392b';
const BORDER = '#e5e7eb';

interface MarketData {
  djia: { value: number; change: number; pct: number; up: boolean };
  nasdaq: { value: number; change: number; pct: number; up: boolean };
  sp500: { value: number; change: number; pct: number; up: boolean };
}

const DEMO_MARKET: MarketData = {
  djia: { value: 39387.76, change: 253.58, pct: 0.65, up: true },
  nasdaq: { value: 16346.26, change: 169.30, pct: 1.05, up: true },
  sp500: { value: 5248.49, change: 43.37, pct: 0.83, up: true },
};

const STOCKS = [
  { ticker: 'AAPL', name: 'Apple', price: 189.30, change: 1.25, changePct: 0.66, logo: 'https://logo.clearbit.com/apple.com' },
  { ticker: 'TSLA', name: 'Tesla', price: 248.50, change: -3.80, changePct: -1.51, logo: 'https://logo.clearbit.com/tesla.com' },
  { ticker: 'SPY', name: 'S&P 500 ETF', price: 452.18, change: 2.10, changePct: 0.47, logo: 'https://logo.clearbit.com/ssga.com' },
  { ticker: 'MSFT', name: 'Microsoft', price: 378.85, change: 3.45, changePct: 0.92, logo: 'https://logo.clearbit.com/microsoft.com' },
  { ticker: 'AMZN', name: 'Amazon', price: 186.40, change: -1.20, changePct: -0.64, logo: 'https://logo.clearbit.com/amazon.com' },
  { ticker: 'NVDA', name: 'Nvidia', price: 875.39, change: 12.50, changePct: 1.45, logo: 'https://logo.clearbit.com/nvidia.com' },
];

type SubPage = 'main' | 'detail' | 'transfer-sheet' | 'transfer-funding' | 'link-external' | 'trade';

export default function InvestmentsByJPM({ onBack }: InvestmentsByJPMProps) {
  const [subPage, setSubPage] = useState<SubPage>('main');
  const [marketData] = useState<MarketData>(DEMO_MARKET);
  const [marketTime, setMarketTime] = useState('');
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStock, setSelectedStock] = useState(STOCKS[0]);

  useEffect(() => {
    function updateTime() {
      const now = new Date();
      const h = now.getHours();
      const m = now.getMinutes().toString().padStart(2, '0');
      const ampm = h >= 12 ? 'PM' : 'AM';
      const h12 = h % 12 || 12;
      setMarketTime(`${h12}:${m} ${ampm} ET`);
    }
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  if (subPage === 'detail') {
    return <InvestmentDashboard
      onBack={() => setSubPage('main')}
      onTrade={() => setSubPage('trade')}
      onTransfer={() => setSubPage('transfer-sheet')}
      onMore={() => setSubPage('main')}
      onLinkExternal={() => setSubPage('link-external')}
    />;
  }
  if (subPage === 'transfer-sheet') {
    return <InvestmentTransferSheet onClose={() => setSubPage('main')} onFunding={() => setSubPage('transfer-funding')} />;
  }
  if (subPage === 'transfer-funding') {
    return <TransferFundingPage onBack={() => setSubPage('main')} onLinkExternal={() => setSubPage('link-external')} />;
  }
  if (subPage === 'link-external') {
    return <LinkExternalAccount onBack={() => setSubPage('main')} />;
  }
  if (subPage === 'trade') {
    return <TradeScreen stock={selectedStock} onBack={() => setSubPage('main')} />;
  }

  const filteredStocks = STOCKS.filter(s =>
    s.ticker.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div style={{ minHeight: '100dvh', width: '100%', display: 'flex', flexDirection: 'column', fontFamily: "'Helvetica Neue', Arial, sans-serif", paddingBottom: 80 }}>

      {/* TOP NAVY BAR */}
      <div style={{ background: NAVY, padding: '50px 16px 24px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
          <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
              <path d="M19 12H5M12 5l-7 7 7 7" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
          <button onClick={() => setShowSearch(!showSearch)} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
              <circle cx="11" cy="11" r="8" stroke="#fff" strokeWidth="2" />
              <path d="M21 21l-4.35-4.35" stroke="#fff" strokeWidth="2" strokeLinecap="round" />
            </svg>
          </button>
        </div>
        <div style={{ color: '#fff', fontSize: 22, fontWeight: 700 }}>Investments by J.P. Morgan</div>
      </div>

      {/* SEARCH BAR (conditional) */}
      {showSearch && (
        <div style={{ background: NAVY, padding: '0 16px 16px' }}>
          <div style={{ background: 'rgba(255,255,255,0.15)', borderRadius: 10, display: 'flex', alignItems: 'center', padding: '10px 14px', gap: 10 }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
              <circle cx="11" cy="11" r="8" stroke="#fff" strokeWidth="2" />
              <path d="M21 21l-4.35-4.35" stroke="#fff" strokeWidth="2" strokeLinecap="round" />
            </svg>
            <input value={searchQuery} onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search stocks, ETFs, funds..."
              style={{ background: 'none', border: 'none', outline: 'none', color: '#fff', fontSize: 15, flex: 1 }}
              autoFocus
            />
          </div>
          {searchQuery && (
            <div style={{ background: '#fff', borderRadius: 8, marginTop: 8, overflow: 'hidden' }}>
              {filteredStocks.map(s => (
                <div key={s.ticker} onClick={() => { setSelectedStock(s); setSubPage('trade'); setShowSearch(false); }}
                  style={{ padding: '12px 16px', borderBottom: `1px solid ${BORDER}`, cursor: 'pointer', display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ fontWeight: 600 }}>{s.ticker}</span>
                  <span style={{ color: '#666', fontSize: 13 }}>{s.name}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* BODY */}
      <div style={{ background: '#f0f4f8', flex: 1 }}>

        {/* PORTFOLIO CARD */}
        <div style={{ margin: '16px 16px 0', background: '#fff', borderRadius: 12, padding: '20px', boxShadow: '0 2px 8px rgba(0,0,0,0.07)' }}>
          <div onClick={() => setSubPage('detail')}
            style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', marginBottom: 12 }}>
            <span style={{ fontSize: 16, fontWeight: 700, color: '#111' }}>My Main (...8927)</span>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
              <path d="M9 18l6-6-6-6" stroke="#999" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
          <div style={{ fontSize: 32, fontWeight: 700, color: '#111' }}>$20,691.92</div>
          <div style={{ fontSize: 13, color: '#888', marginBottom: 12 }}>Value</div>
          {[
            { label: "Day's gain/loss", value: '+$15.97 (1.13%)', color: POS_GREEN },
            { label: 'Gain/loss', value: '+$1,245.50', color: POS_GREEN },
            { label: 'Cash & sweep funds', value: '$259.11', color: '#111' },
          ].map((row, i) => (
            <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0', borderTop: `1px solid ${BORDER}` }}>
              <span style={{ fontSize: 14, color: '#555' }}>{row.label}</span>
              <span style={{ fontSize: 14, fontWeight: 600, color: row.color }}>{row.value}</span>
            </div>
          ))}
        </div>

        {/* 4 ACTION BUTTONS */}
        <div style={{ background: '#fff', marginTop: 8, padding: '16px', display: 'flex', justifyContent: 'space-around' }}>
          {[
            { label: 'Explore', action: () => setSubPage('detail'), icon: (
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                <circle cx="12" cy="12" r="9" stroke={BLUE} strokeWidth="1.8" />
                <path d="M12 3v2M12 19v2M3 12h2M19 12h2" stroke={BLUE} strokeWidth="1.8" strokeLinecap="round" />
                <circle cx="12" cy="12" r="3" fill={BLUE} />
              </svg>
            )},
            { label: 'Trade', action: () => setSubPage('trade'), icon: (
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                <rect x="3" y="7" width="7" height="9" rx="1" stroke={BLUE} strokeWidth="1.8" />
                <rect x="14" y="3" width="7" height="13" rx="1" stroke={BLUE} strokeWidth="1.8" />
                <text x="6.5" y="14" textAnchor="middle" fontSize="8" fill={BLUE} fontWeight="700">$</text>
              </svg>
            )},
            { label: 'Transfer', action: () => setSubPage('transfer-sheet'), icon: (
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                <rect x="2" y="5" width="8" height="6" rx="1" stroke={BLUE} strokeWidth="1.8" />
                <rect x="14" y="13" width="8" height="6" rx="1" stroke={BLUE} strokeWidth="1.8" />
                <path d="M10 8h4M14 8l-2-2M14 8l-2 2M14 16H10M10 16l2-2M10 16l2 2" stroke={BLUE} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            )},
            { label: 'More', action: () => {}, icon: (
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                <circle cx="5" cy="12" r="1.5" fill={BLUE} />
                <circle cx="12" cy="12" r="1.5" fill={BLUE} />
                <circle cx="19" cy="12" r="1.5" fill={BLUE} />
              </svg>
            )},
          ].map(btn => (
            <button key={btn.label} onClick={btn.action} style={{ background: 'none', border: 'none', cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
              <div style={{ width: 56, height: 56, borderRadius: 999, border: `1.5px solid ${BORDER}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                {btn.icon}
              </div>
              <span style={{ fontSize: 12, fontWeight: 500, color: BLUE }}>{btn.label}</span>
            </button>
          ))}
        </div>

        {/* MARKETS CARD */}
        <div style={{ margin: '12px 16px 0', background: '#fff', borderRadius: 12, padding: '16px', boxShadow: '0 1px 4px rgba(0,0,0,0.06)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
            <span style={{ fontSize: 16, fontWeight: 700, color: '#111' }}>Markets</span>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
              <path d="M9 18l6-6-6-6" stroke="#999" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
          <div style={{ fontSize: 12, color: '#888', marginBottom: 12 }}>As of {marketTime}</div>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            {[
              { label: 'DJIA', data: marketData.djia },
              { label: 'NASDAQ', data: marketData.nasdaq },
              { label: 'S&P 500', data: marketData.sp500 },
            ].map(col => (
              <div key={col.label} style={{ textAlign: 'center', flex: 1 }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4, marginBottom: 4 }}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
                    <path d={col.data.up ? "M12 19V5M5 12l7-7 7 7" : "M12 5v14M5 12l7 7 7-7"}
                      stroke={col.data.up ? POS_GREEN : NEG_RED} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  <span style={{ fontSize: 12, fontWeight: 600, color: '#333' }}>{col.label}</span>
                </div>
                <div style={{ fontSize: 15, fontWeight: 700, color: '#111' }}>
                  {col.data.value.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </div>
                <div style={{ fontSize: 12, color: col.data.up ? POS_GREEN : NEG_RED }}>
                  {col.data.up ? '+' : ''}{col.data.change.toFixed(2)} ({col.data.up ? '+' : ''}{col.data.pct.toFixed(2)}%)
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ORDER STATUS */}
        <div style={{ margin: '12px 16px 0', background: '#fff', borderRadius: 12, padding: '16px', boxShadow: '0 1px 4px rgba(0,0,0,0.06)', display: 'flex', alignItems: 'center', gap: 12, cursor: 'pointer' }}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
            <rect x="3" y="3" width="18" height="18" rx="2" fill={BLUE} />
            <line x1="7" y1="8" x2="17" y2="8" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" />
            <line x1="7" y1="12" x2="17" y2="12" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" />
            <line x1="7" y1="16" x2="13" y2="16" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" />
          </svg>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 15, fontWeight: 600, color: '#111' }}>Order status</div>
            <div style={{ fontSize: 13, color: '#888' }}>See orders here.</div>
          </div>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <path d="M9 18l6-6-6-6" stroke="#999" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>

        {/* EXPLORE INVESTMENTS */}
        <div style={{ padding: '20px 16px 8px' }}>
          <div style={{ fontSize: 18, fontWeight: 700, color: '#111', marginBottom: 12 }}>Explore investments</div>
          <div style={{ display: 'flex', gap: 12, overflowX: 'auto', paddingBottom: 8 }}>
            {STOCKS.map(stock => (
              <div key={stock.ticker} style={{
                minWidth: 152, background: '#fff', borderRadius: 12, padding: '14px',
                flexShrink: 0, boxShadow: '0 1px 6px rgba(0,0,0,0.08)',
              }}>
                <img src={stock.logo} alt={stock.name}
                  style={{ width: 36, height: 36, objectFit: 'contain', borderRadius: 8, marginBottom: 8, border: `1px solid ${BORDER}` }}
                  onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }}
                />
                <div style={{ fontSize: 14, fontWeight: 700, color: '#111' }}>{stock.ticker}</div>
                <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>{stock.name}</div>
                <div style={{ fontSize: 15, fontWeight: 600, color: '#111' }}>${stock.price.toFixed(2)}</div>
                <div style={{ fontSize: 12, marginBottom: 10, color: stock.change >= 0 ? POS_GREEN : NEG_RED }}>
                  {stock.change >= 0 ? '+' : ''}{stock.change.toFixed(2)} ({stock.changePct >= 0 ? '+' : ''}{stock.changePct.toFixed(2)}%)
                </div>
                <button onClick={() => { setSelectedStock(stock); setSubPage('trade'); }}
                  style={{ width: '100%', padding: '8px 0', background: BLUE, color: '#fff', border: 'none', borderRadius: 999, fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>
                  Buy
                </button>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}
