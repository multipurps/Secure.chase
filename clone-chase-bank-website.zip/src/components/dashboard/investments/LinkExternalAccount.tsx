import { useState } from 'react';

interface Props {
  onBack: () => void;
}

const BLUE = '#0078D4';
const BORDER = '#D1D5DB';
const GRAY = '#6B7280';
const DARK = '#1F2937';

const INSTITUTIONS = [
  { name: 'Bank of America', url: 'https://www.bankofamerica.com', logo: 'https://logo.clearbit.com/bankofamerica.com' },
  { name: 'Wells Fargo', url: 'https://www.wellsfargo.com', logo: 'https://logo.clearbit.com/wellsfargo.com' },
  { name: 'Citibank', url: 'https://www.citibank.com', logo: 'https://logo.clearbit.com/citibank.com' },
  { name: 'Capital One', url: 'https://www.capitalone.com', logo: 'https://logo.clearbit.com/capitalone.com' },
  { name: 'US Bank', url: 'https://www.usbank.com', logo: 'https://logo.clearbit.com/usbank.com' },
  { name: 'PNC Bank', url: 'https://www.pnc.com', logo: 'https://logo.clearbit.com/pnc.com' },
  { name: 'TD Bank', url: 'https://www.td.com', logo: 'https://logo.clearbit.com/td.com' },
  { name: 'Ally Bank', url: 'https://www.ally.com', logo: 'https://logo.clearbit.com/ally.com' },
  { name: 'SunTrust', url: 'https://www.suntrust.com', logo: 'https://logo.clearbit.com/truist.com' },
  { name: 'Regions Bank', url: 'https://www.regions.com', logo: 'https://logo.clearbit.com/regions.com' },
  { name: 'Fifth Third Bank', url: 'https://www.53.com', logo: 'https://logo.clearbit.com/53.com' },
  { name: 'KeyBank', url: 'https://www.key.com', logo: 'https://logo.clearbit.com/key.com' },
  { name: 'Huntington Bank', url: 'https://www.huntington.com', logo: 'https://logo.clearbit.com/huntington.com' },
  { name: 'M&T Bank', url: 'https://www.mtb.com', logo: 'https://logo.clearbit.com/mtb.com' },
  { name: 'Citizens Bank', url: 'https://www.citizensbank.com', logo: 'https://logo.clearbit.com/citizensbank.com' },
  { name: 'Santander Bank', url: 'https://www.santander.com', logo: 'https://logo.clearbit.com/santander.com' },
  { name: 'BMO Harris', url: 'https://www.bmoharris.com', logo: 'https://logo.clearbit.com/bmo.com' },
  { name: 'Discover Bank', url: 'https://www.discover.com', logo: 'https://logo.clearbit.com/discover.com' },
  { name: 'American Express', url: 'https://www.americanexpress.com', logo: 'https://logo.clearbit.com/americanexpress.com' },
  { name: 'Schwab Bank', url: 'https://www.schwab.com', logo: 'https://logo.clearbit.com/schwab.com' },
  { name: 'Fidelity', url: 'https://www.fidelity.com', logo: 'https://logo.clearbit.com/fidelity.com' },
  { name: 'Vanguard', url: 'https://www.vanguard.com', logo: 'https://logo.clearbit.com/vanguard.com' },
  { name: 'E*TRADE', url: 'https://www.etrade.com', logo: 'https://logo.clearbit.com/etrade.com' },
  { name: 'Robinhood', url: 'https://www.robinhood.com', logo: 'https://logo.clearbit.com/robinhood.com' },
  { name: 'Wyoming Credit Union', url: 'https://www.wyomingcu.com', logo: 'https://logo.clearbit.com/wyomingcu.com' },
  { name: 'Navy Federal Credit Union', url: 'https://www.navyfederal.org', logo: 'https://logo.clearbit.com/navyfederal.org' },
  { name: 'USAA', url: 'https://www.usaa.com', logo: 'https://logo.clearbit.com/usaa.com' },
  { name: 'Pentagon Federal Credit Union', url: 'https://www.penfed.org', logo: 'https://logo.clearbit.com/penfed.org' },
  { name: 'Chime', url: 'https://www.chime.com', logo: 'https://logo.clearbit.com/chime.com' },
  { name: 'SoFi', url: 'https://www.sofi.com', logo: 'https://logo.clearbit.com/sofi.com' },
];

export default function LinkExternalAccount({ onBack }: Props) {
  const [searchQuery, setSearchQuery] = useState('');
  const [linkedBank, setLinkedBank] = useState<string | null>(null);
  const [showSuccess, setShowSuccess] = useState(false);

  const filtered = INSTITUTIONS.filter(inst =>
    inst.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    inst.url.toLowerCase().includes(searchQuery.toLowerCase())
  );

  function handleSelect(inst: typeof INSTITUTIONS[0]) {
    setLinkedBank(inst.name);
    setShowSuccess(true);
  }

  if (showSuccess) {
    return (
      <div style={{ minHeight: '100dvh', background: '#fff', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: 32, fontFamily: "'Helvetica Neue', Arial, sans-serif" }}>
        <div style={{ width: 72, height: 72, borderRadius: 999, background: '#e8f5e9', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 20 }}>
          <svg width="36" height="36" viewBox="0 0 24 24" fill="none">
            <path d="M5 13l4 4L19 7" stroke="#2e7d32" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
        <div style={{ fontSize: 22, fontWeight: 700, color: '#111', textAlign: 'center', marginBottom: 10 }}>Account linked!</div>
        <div style={{ fontSize: 15, color: '#666', textAlign: 'center', lineHeight: 1.5, marginBottom: 32 }}>
          {linkedBank} has been successfully connected to your Chase account.
        </div>
        <button onClick={onBack} style={{ width: '100%', maxWidth: 320, padding: 16, background: BLUE, color: '#fff', border: 'none', borderRadius: 8, fontSize: 16, fontWeight: 600, cursor: 'pointer' }}>
          Done
        </button>
      </div>
    );
  }

  return (
    <div style={{ minHeight: '100dvh', background: '#fff', fontFamily: "'Helvetica Neue', Arial, sans-serif", paddingBottom: 80 }}>

      {/* HEADER */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '50px 16px 16px', borderBottom: `1px solid ${BORDER}` }}>
        <div style={{ width: 60 }} />
        <span style={{ fontSize: 17, fontWeight: 600, color: DARK }}>Link an external account</span>
        <button onClick={onBack} style={{ background: 'none', border: 'none', color: BLUE, fontSize: 15, fontWeight: 600, cursor: 'pointer' }}>
          Cancel
        </button>
      </div>

      <div style={{ padding: '24px 16px 16px' }}>
        <div style={{ fontSize: 22, fontWeight: 600, color: DARK, marginBottom: 20 }}>Find your external financial institution</div>

        {/* SEARCH */}
        <div style={{ display: 'flex', alignItems: 'center', border: `1px solid ${BORDER}`, borderRadius: 8, padding: '10px 14px', gap: 10, marginBottom: 20 }}>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
            <circle cx="11" cy="11" r="8" stroke={GRAY} strokeWidth="2" />
            <path d="M21 21l-4.35-4.35" stroke={GRAY} strokeWidth="2" strokeLinecap="round" />
          </svg>
          <input
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search for an institution"
            style={{ border: 'none', outline: 'none', fontSize: 15, flex: 1, color: DARK, background: 'transparent' }}
          />
        </div>

        {/* INSTITUTIONS LIST */}
        {filtered.map((inst, i) => (
          <div key={i} onClick={() => handleSelect(inst)}
            style={{
              display: 'flex', alignItems: 'center', gap: 14,
              padding: '12px 0', borderBottom: `1px solid #F3F4F6`, cursor: 'pointer',
            }}>
            <img src={inst.logo} alt={inst.name}
              style={{ width: 44, height: 44, borderRadius: 8, objectFit: 'contain', border: `1px solid #F3F4F6`, flexShrink: 0 }}
              onError={e => {
                const target = e.target as HTMLImageElement;
                target.style.display = 'none';
                const parent = target.parentElement;
                if (parent) {
                  const div = document.createElement('div');
                  div.style.cssText = `width:44px;height:44px;border-radius:8px;background:#e8f0fe;display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:700;color:${BLUE};flex-shrink:0`;
                  div.textContent = inst.name[0];
                  parent.insertBefore(div, target);
                }
              }}
            />
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 15, fontWeight: 600, color: DARK }}>{inst.name}</div>
              <div style={{ fontSize: 12, color: GRAY, marginTop: 2 }}>{inst.url}</div>
            </div>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
              <path d="M9 18l6-6-6-6" stroke={GRAY} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
        ))}

        {filtered.length === 0 && (
          <div style={{ textAlign: 'center', color: GRAY, padding: 40, fontSize: 15 }}>
            No institutions found for "{searchQuery}"
          </div>
        )}
      </div>
    </div>
  );
}
