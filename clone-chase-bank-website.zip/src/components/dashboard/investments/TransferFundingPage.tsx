interface Props {
  onBack: () => void;
  onLinkExternal: () => void;
}

const BLUE = '#2558b5';
const BORDER = '#e5e7eb';

export default function TransferFundingPage({ onBack, onLinkExternal }: Props) {
  const cards = [
    {
      icon: (
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
          <rect x="2" y="7" width="20" height="14" rx="2" fill="none" stroke={BLUE} strokeWidth="1.8" />
          <path d="M16 7V5a2 2 0 00-4 0v2M8 7V5a2 2 0 00-4 0v2" stroke={BLUE} strokeWidth="1.8" />
          <line x1="2" y1="11" x2="22" y2="11" stroke={BLUE} strokeWidth="1.8" />
        </svg>
      ),
      title: 'External account transfer',
      desc: 'Move securities and cash from an external investment account.',
      action: onLinkExternal,
    },
    {
      icon: (
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
          <rect x="2" y="5" width="8" height="7" rx="1" stroke={BLUE} strokeWidth="1.8" />
          <rect x="14" y="12" width="8" height="7" rx="1" stroke={BLUE} strokeWidth="1.8" />
          <path d="M10 8.5h4M14 8.5l-2-2M14 8.5l-2 2M14 15.5H10M10 15.5l2-2M10 15.5l2 2" stroke={BLUE} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      ),
      title: 'J.P. Morgan account transfer',
      desc: 'Move securities and cash between investment accounts held with us.',
      action: () => {},
    },
    {
      icon: (
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
          <rect x="2" y="6" width="20" height="13" rx="2" fill="none" stroke={BLUE} strokeWidth="1.8" />
          <circle cx="12" cy="12.5" r="3" fill={BLUE} />
          <path d="M6 12.5h3M15 12.5h3" stroke={BLUE} strokeWidth="1.8" strokeLinecap="round" />
        </svg>
      ),
      title: 'Cash transfer',
      desc: 'Move cash between bank and J.P. Morgan investment accounts.',
      action: () => {},
    },
    {
      icon: (
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
          <rect x="2" y="5" width="20" height="14" rx="2" fill="none" stroke={BLUE} strokeWidth="1.8" />
          <path d="M12 19v2M8 21h8" stroke={BLUE} strokeWidth="1.8" strokeLinecap="round" />
          <path d="M12 10v5M12 10l-2 2M12 10l2 2" stroke={BLUE} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      ),
      title: 'Check deposit',
      desc: 'Deposit checks into a general investment account or IRA (including rollovers).',
      action: () => {},
    },
  ];

  return (
    <div style={{ minHeight: '100dvh', background: '#fff', fontFamily: "'Helvetica Neue', Arial, sans-serif" }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '50px 16px 16px' }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer' }}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path d="M19 12H5M12 5l-7 7 7 7" stroke="#555" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
        <span style={{ fontSize: 17, fontWeight: 700, color: '#111' }}>Transfer & funding</span>
        <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', color: BLUE, fontSize: 15, fontWeight: 600 }}>
          Cancel
        </button>
      </div>

      <div style={{ padding: '4px 16px 20px' }}>
        <div style={{ fontSize: 24, fontWeight: 700, color: '#111' }}>Transfers & funding</div>
      </div>

      {cards.map((card, i) => (
        <div key={i} onClick={card.action}
          style={{
            margin: '0 16px 12px', background: '#fff', border: `1px solid ${BORDER}`,
            borderRadius: 12, padding: '16px', cursor: 'pointer',
            display: 'flex', alignItems: 'center', gap: 14,
            boxShadow: '0 1px 4px rgba(0,0,0,0.06)',
          }}>
          <div style={{ width: 52, height: 52, borderRadius: 999, background: '#e8f0fe', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            {card.icon}
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 15, fontWeight: 600, color: '#111' }}>{card.title}</div>
            <div style={{ fontSize: 13, color: '#888', marginTop: 3, lineHeight: 1.4 }}>{card.desc}</div>
          </div>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <path d="M9 18l6-6-6-6" stroke="#999" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      ))}

      <div style={{ margin: '8px 16px', background: '#fff', border: `1px solid ${BORDER}`, borderRadius: 12, padding: '14px 16px', cursor: 'pointer', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <span style={{ fontSize: 14, color: '#666', lineHeight: 1.4, flex: 1 }}>
          Learn about transferring an employer-sponsored retirement plan.
        </span>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
          <path d="M9 18l6-6-6-6" stroke="#999" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </div>
    </div>
  );
}
