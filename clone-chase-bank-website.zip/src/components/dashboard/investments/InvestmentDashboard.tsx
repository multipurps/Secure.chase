import { useState, useEffect, useRef } from 'react';

interface InvestmentDashboardProps {
  onBack: () => void;
  onTrade?: () => void;
  onTransfer?: () => void;
  onMore?: () => void;
  onLinkExternal?: () => void;
}

const INV_BLUE = '#0078D4';
const POS_GREEN = '#10B981';
const NEG_RED = '#EF4444';
const DARK = '#111827';
const GRAY = '#6B7280';
const LIGHT_GRAY = '#9CA3AF';
const BORDER = '#E5E7EB';

interface AccountOption {
  id: string;
  name: string;
  last4: string;
  balance: number;
  dayChange: number;
  dayChangePct: number;
  cash: number;
}

const ACCOUNTS: AccountOption[] = [
  { id: 'self', name: 'Self-Directed', last4: '8473', balance: 20691.92, dayChange: 15.97, dayChangePct: 1.13, cash: 259.11 },
  { id: 'roth', name: 'Roth IRA', last4: '1234', balance: 45230.00, dayChange: 88.45, dayChangePct: 0.20, cash: 1200.00 },
  { id: 'brokerage', name: 'Brokerage', last4: '5678', balance: 112450.75, dayChange: -342.18, dayChangePct: -0.30, cash: 5800.00 },
];

type Timeframe = '1D' | '1W' | '1M' | '3M' | '1Y' | 'ALL';

function generateChartData(timeframe: Timeframe, baseBalance: number): { x: number; value: number }[] {
  const points = timeframe === '1D' ? 48 : timeframe === '1W' ? 42 : timeframe === '1M' ? 30 : timeframe === '3M' ? 60 : timeframe === '1Y' ? 52 : 60;
  const data: { x: number; value: number }[] = [];
  let val = baseBalance * 0.92;
  for (let i = 0; i < points; i++) {
    val += (Math.random() - 0.45) * (baseBalance * 0.008);
    val = Math.max(baseBalance * 0.85, Math.min(baseBalance * 1.08, val));
    data.push({ x: i / (points - 1), value: val });
  }
  data[data.length - 1].value = baseBalance;
  return data;
}

function InteractiveChart({ data, width, height, onScrub, onScrubEnd }: {
  data: { x: number; value: number }[];
  width: number;
  height: number;
  onScrub: (val: number) => void;
  onScrubEnd: () => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number>(0);
  const [scrubX, setScrubX] = useState<number | null>(null);
  const [animProgress, setAnimProgress] = useState(0);

  useEffect(() => {
    setAnimProgress(0);
    const start = performance.now();
    const duration = 800;

    function animate(now: number) {
      const p = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      setAnimProgress(eased);
      if (p < 1) animRef.current = requestAnimationFrame(animate);
    }
    animRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animRef.current);
  }, [data]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !data.length) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, width, height);

    const pad = { left: 8, right: 8, top: 12, bottom: 8 };
    const W = width - pad.left - pad.right;
    const H = height - pad.top - pad.bottom;

    const vals = data.map(d => d.value);
    const minV = Math.min(...vals) * 0.998;
    const maxV = Math.max(...vals) * 1.002;

    function toX(i: number) { return pad.left + (i / (data.length - 1)) * W; }
    function toY(v: number) { return pad.top + H - ((v - minV) / (maxV - minV)) * H; }

    const cutIndex = Math.floor(animProgress * (data.length - 1));

    // Gradient fill
    const gradFill = ctx.createLinearGradient(0, pad.top, 0, pad.top + H);
    gradFill.addColorStop(0, 'rgba(0,120,212,0.18)');
    gradFill.addColorStop(1, 'rgba(0,120,212,0)');

    ctx.beginPath();
    ctx.moveTo(toX(0), toY(data[0].value));
    for (let i = 1; i <= cutIndex; i++) {
      ctx.lineTo(toX(i), toY(data[i].value));
    }
    ctx.lineTo(toX(cutIndex), pad.top + H);
    ctx.lineTo(toX(0), pad.top + H);
    ctx.closePath();
    ctx.fillStyle = gradFill;
    ctx.fill();

    // Line
    ctx.beginPath();
    ctx.moveTo(toX(0), toY(data[0].value));
    for (let i = 1; i <= cutIndex; i++) {
      ctx.lineTo(toX(i), toY(data[i].value));
    }
    ctx.strokeStyle = INV_BLUE;
    ctx.lineWidth = 2;
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    ctx.stroke();

    // Scrubber
    if (scrubX !== null && animProgress >= 1) {
      const rel = (scrubX - pad.left) / W;
      const idx = Math.min(Math.max(0, Math.round(rel * (data.length - 1))), data.length - 1);
      const sx = toX(idx);
      const sy = toY(data[idx].value);

      // Dotted vertical line
      ctx.setLineDash([4, 4]);
      ctx.beginPath();
      ctx.moveTo(sx, pad.top);
      ctx.lineTo(sx, pad.top + H);
      ctx.strokeStyle = 'rgba(0,120,212,0.5)';
      ctx.lineWidth = 1.5;
      ctx.stroke();
      ctx.setLineDash([]);

      // Circle handle
      ctx.beginPath();
      ctx.arc(sx, sy, 5, 0, Math.PI * 2);
      ctx.fillStyle = INV_BLUE;
      ctx.fill();
      ctx.beginPath();
      ctx.arc(sx, sy, 7, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(0,120,212,0.3)';
      ctx.lineWidth = 2;
      ctx.stroke();
    }
  }, [data, width, height, animProgress, scrubX]);

  function handlePointer(e: React.PointerEvent<HTMLCanvasElement>) {
    if (!data.length) return;
    const rect = canvasRef.current!.getBoundingClientRect();
    const px = e.clientX - rect.left;
    setScrubX(px);
    const pad = { left: 8, right: 8 };
    const W = width - pad.left - pad.right;
    const rel = Math.min(Math.max(0, (px - pad.left) / W), 1);
    const idx = Math.min(Math.max(0, Math.round(rel * (data.length - 1))), data.length - 1);
    onScrub(data[idx].value);
  }

  return (
    <canvas
      ref={canvasRef}
      style={{ width, height, cursor: 'crosshair', display: 'block' }}
      onPointerMove={handlePointer}
      onPointerLeave={() => { setScrubX(null); onScrubEnd(); }}
      onPointerDown={handlePointer}
    />
  );
}

export default function InvestmentDashboard({ onTrade, onMore, onLinkExternal }: InvestmentDashboardProps) {
  const [activeTab, setActiveTab] = useState<'explore' | 'trade' | 'transfer' | 'more'>('explore');
  const [selectedAccount, setSelectedAccount] = useState(ACCOUNTS[0]);
  const [showAccountPicker, setShowAccountPicker] = useState(false);
  const [timeframe, setTimeframe] = useState<Timeframe>('1D');
  const [chartData, setChartData] = useState(() => generateChartData('1D', ACCOUNTS[0].balance));
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [timestamp, setTimestamp] = useState('');
  const [scrubBalance, setScrubBalance] = useState<number | null>(null);
  const [flashColor, setFlashColor] = useState<string | null>(null);
  const [showContextMenu, setShowContextMenu] = useState(false);
  const [chartWidth, setChartWidth] = useState(360);
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const refreshIntervalRef = useRef<ReturnType<typeof setInterval> | undefined>(undefined);

  function formatTime() {
    const now = new Date();
    const h = now.getHours();
    const m = now.getMinutes().toString().padStart(2, '0');
    const ampm = h >= 12 ? 'PM' : 'AM';
    const h12 = h % 12 || 12;
    const dateStr = now.toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: 'numeric' });
    return `As of ${h12}:${m} ${ampm} ET ${dateStr}`;
  }

  useEffect(() => {
    setTimestamp(formatTime());
    if (chartContainerRef.current) {
      setChartWidth(chartContainerRef.current.clientWidth || 360);
    }
    refreshIntervalRef.current = setInterval(() => {
      setTimestamp(formatTime());
    }, 30000);
    return () => clearInterval(refreshIntervalRef.current);
  }, []);

  useEffect(() => {
    if (chartContainerRef.current) {
      const ro = new ResizeObserver(entries => {
        setChartWidth(entries[0].contentRect.width);
      });
      ro.observe(chartContainerRef.current);
      return () => ro.disconnect();
    }
  }, []);

  function handleRefresh() {
    setIsRefreshing(true);
    setTimeout(() => {
      const newBalance = selectedAccount.balance + (Math.random() - 0.5) * 200;
      const newChange = selectedAccount.dayChange + (Math.random() - 0.5) * 10;
      setSelectedAccount(prev => ({ ...prev, balance: newBalance, dayChange: newChange }));
      setChartData(generateChartData(timeframe, newBalance));
      setFlashColor(newChange >= 0 ? 'rgba(16,185,129,0.15)' : 'rgba(239,68,68,0.15)');
      setTimeout(() => setFlashColor(null), 300);
      setTimestamp(formatTime());
      setIsRefreshing(false);
    }, 1200);
  }

  function handleTimeframe(tf: Timeframe) {
    setTimeframe(tf);
    setChartData(generateChartData(tf, selectedAccount.balance));
  }

  function handleAccountSelect(acc: AccountOption) {
    setSelectedAccount(acc);
    setChartData(generateChartData(timeframe, acc.balance));
    setShowAccountPicker(false);
  }

  const displayBalance = scrubBalance ?? selectedAccount.balance;
  const isPositive = selectedAccount.dayChange >= 0;

  const STOCKS = [
    { ticker: 'AAPL', name: 'Apple', price: 189.30, change: 1.25, changePct: 0.66, logo: 'https://logo.clearbit.com/apple.com' },
    { ticker: 'TSLA', name: 'Tesla', price: 248.50, change: -3.80, changePct: -1.51, logo: 'https://logo.clearbit.com/tesla.com' },
    { ticker: 'SPY', name: 'S&P 500 ETF', price: 452.18, change: 2.10, changePct: 0.47, logo: 'https://logo.clearbit.com/ssga.com' },
    { ticker: 'MSFT', name: 'Microsoft', price: 378.85, change: 3.45, changePct: 0.92, logo: 'https://logo.clearbit.com/microsoft.com' },
    { ticker: 'AMZN', name: 'Amazon', price: 186.40, change: -1.20, changePct: -0.64, logo: 'https://logo.clearbit.com/amazon.com' },
    { ticker: 'NVDA', name: 'Nvidia', price: 875.39, change: 12.50, changePct: 1.45, logo: 'https://logo.clearbit.com/nvidia.com' },
  ];

  return (
    <div style={{ minHeight: '100dvh', width: '100%', background: '#fff', display: 'flex', flexDirection: 'column', fontFamily: "'Helvetica Neue', Arial, sans-serif", paddingBottom: 120 }}>

      {/* TOP ACCOUNT SELECTOR */}
      <div style={{ padding: '16px 16px 0', background: '#fff', borderBottom: `1px solid ${BORDER}` }}>
        <div
          onClick={() => setShowAccountPicker(true)}
          style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', cursor: 'pointer', padding: '8px 0', active: { opacity: 0.7 } } as React.CSSProperties}
        >
          <div>
            <div style={{ fontSize: 12, color: GRAY, fontWeight: 400 }}>Choose account</div>
            <div style={{ fontSize: 18, color: DARK, fontWeight: 500, marginTop: 2 }}>
              {selectedAccount.name} (...{selectedAccount.last4})
            </div>
          </div>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
            <path d="M6 9l6 6 6-6" stroke={GRAY} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>

        {/* Timestamp + Refresh */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 0 12px' }}>
          <div
            onClick={handleRefresh}
            style={{ cursor: 'pointer', animation: isRefreshing ? 'spin360 1s linear infinite' : 'none' }}
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
              <path d="M21 12a9 9 0 11-9-9c2.52 0 4.8 1.02 6.45 2.67L21 8" stroke={INV_BLUE} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M21 3v5h-5" stroke={INV_BLUE} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
          <span style={{ fontSize: 12, color: LIGHT_GRAY }}>{timestamp}</span>
        </div>
      </div>

      {/* BALANCE CARD */}
      <div style={{
        margin: '16px 16px 0',
        border: `1px solid ${BORDER}`,
        borderRadius: 12,
        padding: '16px',
        background: flashColor ?? '#fff',
        transition: 'background 0.3s ease',
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <span style={{ fontSize: 14, color: GRAY, fontWeight: 500 }}>
            {selectedAccount.name} (...{selectedAccount.last4})
          </span>
          <div style={{ position: 'relative' }}>
            <div onClick={() => setShowContextMenu(!showContextMenu)} style={{ cursor: 'pointer', padding: 4 }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                <circle cx="5" cy="12" r="2" fill={GRAY} />
                <circle cx="12" cy="12" r="2" fill={GRAY} />
                <circle cx="19" cy="12" r="2" fill={GRAY} />
              </svg>
            </div>
            {showContextMenu && (
              <div style={{
                position: 'absolute', right: 0, top: 28, background: '#fff',
                border: `1px solid ${BORDER}`, borderRadius: 8, zIndex: 100, minWidth: 160,
                boxShadow: '0 4px 16px rgba(0,0,0,0.12)',
              }}>
                {['Account Details', 'Statements', 'Settings'].map(item => (
                  <div key={item} onClick={() => setShowContextMenu(false)}
                    style={{ padding: '12px 16px', fontSize: 14, color: DARK, cursor: 'pointer', borderBottom: `1px solid ${BORDER}` }}>
                    {item}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <div style={{ fontSize: 36, fontWeight: 600, color: DARK, letterSpacing: '-0.5px' }}>
          ${displayBalance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 6 }}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
            <path d={isPositive ? "M12 19V5M5 12l7-7 7 7" : "M12 5v14M19 12l-7 7-7-7"}
              stroke={isPositive ? POS_GREEN : NEG_RED} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          <span style={{ fontSize: 14, fontWeight: 500, color: isPositive ? POS_GREEN : NEG_RED }}>
            {isPositive ? '+' : ''}${Math.abs(selectedAccount.dayChange).toFixed(2)} ({isPositive ? '+' : ''}{selectedAccount.dayChangePct.toFixed(2)}%)
          </span>
        </div>
      </div>

      {/* INTERACTIVE CHART */}
      <div ref={chartContainerRef} style={{ margin: '16px 0 0', padding: '0 0' }}>
        <InteractiveChart
          data={chartData}
          width={chartWidth}
          height={180}
          onScrub={(val) => setScrubBalance(val)}
          onScrubEnd={() => setScrubBalance(null)}
        />
      </div>

      {/* TIMEFRAME TABS */}
      <div style={{ display: 'flex', justifyContent: 'space-around', padding: '8px 16px', borderBottom: `1px solid ${BORDER}` }}>
        {(['1D', '1W', '1M', '3M', '1Y', 'ALL'] as Timeframe[]).map(tf => (
          <button key={tf} onClick={() => handleTimeframe(tf)}
            style={{
              border: 'none', background: tf === timeframe ? '#F3F4F6' : 'transparent',
              padding: '6px 10px', borderRadius: 6,
              fontSize: 13, fontWeight: tf === timeframe ? 700 : 400,
              color: tf === timeframe ? DARK : GRAY,
              cursor: 'pointer',
              textDecoration: tf === timeframe ? 'underline' : 'none',
            }}>
            {tf}
          </button>
        ))}
      </div>

      {/* AVAILABLE FUNDS */}
      <div
        onClick={onLinkExternal}
        style={{
          display: 'flex', alignItems: 'center', padding: '14px 16px',
          borderBottom: `1px solid ${BORDER}`, cursor: 'pointer', background: '#fff',
        }}
      >
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" style={{ marginRight: 12 }}>
          <rect x="2" y="7" width="20" height="14" rx="2" fill="none" stroke={GRAY} strokeWidth="1.8" />
          <path d="M16 7V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v2" stroke={GRAY} strokeWidth="1.8" />
          <circle cx="12" cy="14" r="2" fill={GRAY} />
        </svg>
        <span style={{ flex: 1, fontSize: 14, fontWeight: 500, color: DARK }}>Available funds</span>
        <span style={{ fontSize: 14, fontWeight: 600, color: INV_BLUE, marginRight: 8 }}>
          ${selectedAccount.cash.toLocaleString('en-US', { minimumFractionDigits: 2 })}
        </span>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
          <path d="M9 18l6-6-6-6" stroke={GRAY} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </div>

      {/* INNER NAV — Explore / Trade / Transfer / More */}
      <div style={{
        display: 'flex', background: '#fff', borderBottom: `1px solid ${BORDER}`,
        position: 'sticky', top: 0, zIndex: 10,
      }}>
        {(['explore', 'trade', 'transfer', 'more'] as const).map(tab => (
          <button key={tab} onClick={() => {
            setActiveTab(tab);
            if (tab === 'trade' && onTrade) onTrade();
            if (tab === 'transfer') setActiveTab('transfer');
            if (tab === 'more' && onMore) onMore();
          }}
            style={{
              flex: 1, border: 'none', background: 'transparent',
              padding: '14px 4px 10px',
              borderBottom: tab === activeTab ? `3px solid ${INV_BLUE}` : '3px solid transparent',
              fontSize: 13, fontWeight: tab === activeTab ? 600 : 400,
              color: tab === activeTab ? INV_BLUE : GRAY,
              cursor: 'pointer', textTransform: 'capitalize',
            }}>
            {tab === 'explore' ? '🌐' : tab === 'trade' ? '📊' : tab === 'transfer' ? '🔄' : '···'} {tab.charAt(0).toUpperCase() + tab.slice(1)}
          </button>
        ))}
      </div>

      {/* EXPLORE TAB — Market + Stocks */}
      {activeTab === 'explore' && (
        <div style={{ padding: '16px', background: '#f9fafb' }}>
          <div style={{ fontSize: 16, fontWeight: 700, color: DARK, marginBottom: 12 }}>Markets to explore</div>
          <div style={{ display: 'flex', gap: 12, overflowX: 'auto', paddingBottom: 8 }}>
            {STOCKS.map(stock => (
              <div key={stock.ticker} style={{
                minWidth: 140, background: '#fff', border: `1px solid ${BORDER}`,
                borderRadius: 12, padding: 14, flexShrink: 0,
                boxShadow: '0 1px 4px rgba(0,0,0,0.06)',
              }}>
                <img src={stock.logo} alt={stock.name}
                  style={{ width: 36, height: 36, objectFit: 'contain', borderRadius: 8, marginBottom: 8 }}
                  onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }}
                />
                <div style={{ fontSize: 13, fontWeight: 700, color: DARK }}>{stock.ticker}</div>
                <div style={{ fontSize: 11, color: GRAY, marginBottom: 6 }}>{stock.name}</div>
                <div style={{ fontSize: 15, fontWeight: 600, color: DARK }}>${stock.price.toFixed(2)}</div>
                <div style={{ fontSize: 12, color: stock.change >= 0 ? POS_GREEN : NEG_RED, marginBottom: 10 }}>
                  {stock.change >= 0 ? '+' : ''}{stock.change.toFixed(2)} ({stock.changePct >= 0 ? '+' : ''}{stock.changePct.toFixed(2)}%)
                </div>
                <button onClick={() => onTrade && onTrade()} style={{
                  width: '100%', padding: '7px 0', background: INV_BLUE,
                  color: '#fff', border: 'none', borderRadius: 999, fontSize: 13, fontWeight: 600, cursor: 'pointer',
                }}>
                  Buy
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TRANSFER TAB */}
      {activeTab === 'transfer' && (
        <div style={{ padding: 16 }}>
          <div style={{ fontSize: 18, fontWeight: 700, color: DARK, marginBottom: 16 }}>Transfer & Funding</div>
          {[
            { label: 'Cash transfer', desc: 'Move cash between bank and investment accounts.' },
            { label: 'Link external account', desc: 'Connect an outside bank or brokerage.', action: onLinkExternal },
            { label: 'Transfer securities', desc: 'Move assets between investment accounts.' },
            { label: 'Roll over to IRA', desc: 'Move your retirement plan into J.P. Morgan.' },
          ].map(item => (
            <div key={item.label}
              onClick={item.action}
              style={{
                background: '#fff', border: `1px solid ${BORDER}`, borderRadius: 10,
                padding: '14px 16px', marginBottom: 10, cursor: 'pointer',
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              }}>
              <div>
                <div style={{ fontSize: 15, fontWeight: 600, color: DARK }}>{item.label}</div>
                <div style={{ fontSize: 13, color: GRAY, marginTop: 3 }}>{item.desc}</div>
              </div>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                <path d="M9 18l6-6-6-6" stroke={GRAY} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
          ))}
        </div>
      )}

      {/* ACCOUNT PICKER BOTTOM SHEET */}
      {showAccountPicker && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 200, display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
          <div style={{ flex: 1, background: 'rgba(0,0,0,0.4)' }} onClick={() => setShowAccountPicker(false)} />
          <div style={{ background: '#fff', borderRadius: '16px 16px 0 0', padding: '20px 0 32px' }}>
            <div style={{ width: 40, height: 4, background: '#ccc', borderRadius: 2, margin: '0 auto 20px' }} />
            <div style={{ fontSize: 17, fontWeight: 700, textAlign: 'center', marginBottom: 16, color: DARK }}>Choose account</div>
            {ACCOUNTS.map(acc => (
              <div key={acc.id} onClick={() => handleAccountSelect(acc)}
                style={{
                  padding: '16px 20px', cursor: 'pointer', borderTop: `1px solid ${BORDER}`,
                  display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                }}>
                <div>
                  <div style={{ fontSize: 15, fontWeight: 600, color: DARK }}>{acc.name} (...{acc.last4})</div>
                  <div style={{ fontSize: 13, color: GRAY }}>${acc.balance.toLocaleString('en-US', { minimumFractionDigits: 2 })}</div>
                </div>
                {selectedAccount.id === acc.id && (
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                    <path d="M5 13l4 4L19 7" stroke={INV_BLUE} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      <style>{`
        @keyframes spin360 { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}
