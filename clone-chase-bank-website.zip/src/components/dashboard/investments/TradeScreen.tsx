import { useState } from 'react';

interface StockData {
  ticker: string;
  name: string;
  price: number;
  change: number;
  changePct: number;
  logo: string;
}

interface Props {
  stock: StockData;
  onBack: () => void;
}

const BLUE = '#0078D4';
const POS_GREEN = '#10B981';
const NEG_RED = '#EF4444';
const DARK = '#111827';
const GRAY = '#6B7280';
const BORDER = '#E5E7EB';

const ACCOUNTS = [
  { name: 'Self-Directed', last4: '8473', cash: 259.11 },
  { name: 'Roth IRA', last4: '1234', cash: 1200.00 },
  { name: 'Brokerage', last4: '5678', cash: 5800.00 },
];

type Side = 'buy' | 'sell';

export default function TradeScreen({ stock, onBack }: Props) {
  const [side, setSide] = useState<Side>('buy');
  const [qty, setQty] = useState('');
  const [selectedAccount, setSelectedAccount] = useState(ACCOUNTS[0]);
  const [showAccountPicker, setShowAccountPicker] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [activeTimeframe, setActiveTimeframe] = useState('1D');

  const isPositive = stock.change >= 0;
  const quantity = parseFloat(qty) || 0;
  const estimatedCost = quantity * stock.price;
  const canTrade = quantity > 0 && (side === 'buy' ? estimatedCost <= selectedAccount.cash : quantity > 0);

  const stockInfo = [
    { label: 'Market Cap', value: '$2.94T' },
    { label: 'P/E Ratio', value: '29.4' },
    { label: '52W High', value: `$${(stock.price * 1.18).toFixed(2)}` },
    { label: '52W Low', value: `$${(stock.price * 0.74).toFixed(2)}` },
    { label: 'Dividend Yield', value: '0.56%' },
    { label: 'Volume', value: '52.3M' },
  ];

  if (showSuccess) {
    return (
      <div style={{ minHeight: '100dvh', background: '#fff', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: 32, fontFamily: "'Helvetica Neue', Arial, sans-serif" }}>
        <div style={{ width: 72, height: 72, borderRadius: 999, background: '#e8f5e9', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 20 }}>
          <svg width="36" height="36" viewBox="0 0 24 24" fill="none">
            <path d="M5 13l4 4L19 7" stroke="#2e7d32" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
        <div style={{ fontSize: 22, fontWeight: 700, color: '#111', marginBottom: 10 }}>Order placed!</div>
        <div style={{ fontSize: 15, color: '#666', textAlign: 'center', lineHeight: 1.5, marginBottom: 8 }}>
          {side === 'buy' ? 'Buy' : 'Sell'} {qty} share{quantity !== 1 ? 's' : ''} of {stock.ticker}
        </div>
        <div style={{ fontSize: 24, fontWeight: 700, color: '#111', marginBottom: 32 }}>
          ${estimatedCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </div>
        <button onClick={onBack} style={{ width: '100%', maxWidth: 320, padding: 16, background: BLUE, color: '#fff', border: 'none', borderRadius: 8, fontSize: 16, fontWeight: 600, cursor: 'pointer' }}>
          Done
        </button>
      </div>
    );
  }

  return (
    <div style={{ minHeight: '100dvh', background: '#fff', fontFamily: "'Helvetica Neue', Arial, sans-serif", paddingBottom: 100 }}>

      {/* HEADER */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '50px 16px 16px', borderBottom: `1px solid ${BORDER}` }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer' }}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path d="M19 12H5M12 5l-7 7 7 7" stroke="#555" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
        <img src={stock.logo} alt={stock.name} style={{ width: 36, height: 36, objectFit: 'contain', borderRadius: 8, border: `1px solid ${BORDER}` }}
          onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }} />
        <div>
          <div style={{ fontSize: 17, fontWeight: 700, color: DARK }}>{stock.ticker}</div>
          <div style={{ fontSize: 13, color: GRAY }}>{stock.name}</div>
        </div>
      </div>

      {/* PRICE HEADER */}
      <div style={{ padding: '16px 16px 0' }}>
        <div style={{ fontSize: 32, fontWeight: 600, color: DARK }}>${stock.price.toFixed(2)}</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 4, marginBottom: 16 }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
            <path d={isPositive ? "M12 19V5M5 12l7-7 7 7" : "M12 5v14M5 12l7 7 7-7"}
              stroke={isPositive ? POS_GREEN : NEG_RED} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          <span style={{ fontSize: 14, color: isPositive ? POS_GREEN : NEG_RED, fontWeight: 500 }}>
            {isPositive ? '+' : ''}${Math.abs(stock.change).toFixed(2)} ({isPositive ? '+' : ''}{stock.changePct.toFixed(2)}%) today
          </span>
        </div>

        {/* TIMEFRAME */}
        <div style={{ display: 'flex', gap: 4, marginBottom: 16 }}>
          {['1D', '1W', '1M', '3M', '1Y', 'ALL'].map(tf => (
            <button key={tf} onClick={() => setActiveTimeframe(tf)} style={{
              padding: '5px 10px', borderRadius: 6,
              background: tf === activeTimeframe ? '#F3F4F6' : 'transparent',
              border: 'none', fontSize: 13,
              fontWeight: tf === activeTimeframe ? 700 : 400,
              color: tf === activeTimeframe ? DARK : GRAY,
              cursor: 'pointer',
            }}>{tf}</button>
          ))}
        </div>

        {/* MINI CHART PLACEHOLDER */}
        <div style={{ height: 80, background: '#f0f7ff', borderRadius: 8, marginBottom: 16, display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative', overflow: 'hidden' }}>
          <svg width="100%" height="80" viewBox="0 0 400 80" preserveAspectRatio="none">
            <defs>
              <linearGradient id="miniGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={BLUE} stopOpacity="0.2" />
                <stop offset="100%" stopColor={BLUE} stopOpacity="0" />
              </linearGradient>
            </defs>
            <path d="M0,60 C50,45 100,55 150,35 S250,20 300,30 S360,15 400,10 L400,80 L0,80 Z" fill="url(#miniGrad)" />
            <path d="M0,60 C50,45 100,55 150,35 S250,20 300,30 S360,15 400,10" fill="none" stroke={BLUE} strokeWidth="2" />
          </svg>
        </div>

        {/* STOCK INFO */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 20 }}>
          {stockInfo.map(item => (
            <div key={item.label} style={{ background: '#f9fafb', borderRadius: 8, padding: '10px 12px' }}>
              <div style={{ fontSize: 11, color: GRAY, marginBottom: 4 }}>{item.label}</div>
              <div style={{ fontSize: 14, fontWeight: 600, color: DARK }}>{item.value}</div>
            </div>
          ))}
        </div>
      </div>

      {/* TRADE CARD */}
      <div style={{ margin: '0 16px', border: `1px solid ${BORDER}`, borderRadius: 12, padding: 16 }}>
        {/* BUY/SELL TOGGLE */}
        <div style={{ display: 'flex', background: '#f3f4f6', borderRadius: 8, padding: 3, marginBottom: 16 }}>
          {(['buy', 'sell'] as Side[]).map(s => (
            <button key={s} onClick={() => setSide(s)} style={{
              flex: 1, padding: '10px 0', border: 'none', borderRadius: 6,
              background: side === s ? (s === 'buy' ? POS_GREEN : NEG_RED) : 'transparent',
              color: side === s ? '#fff' : GRAY,
              fontSize: 15, fontWeight: 600, cursor: 'pointer', textTransform: 'capitalize' as const,
            }}>
              {s.charAt(0).toUpperCase() + s.slice(1)}
            </button>
          ))}
        </div>

        {/* ACCOUNT SELECTOR */}
        <div onClick={() => setShowAccountPicker(true)} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 0', borderBottom: `1px solid ${BORDER}`, cursor: 'pointer', marginBottom: 12 }}>
          <div>
            <div style={{ fontSize: 12, color: GRAY }}>Account</div>
            <div style={{ fontSize: 14, fontWeight: 600, color: DARK }}>{selectedAccount.name} (...{selectedAccount.last4})</div>
            <div style={{ fontSize: 12, color: GRAY }}>Cash: ${selectedAccount.cash.toFixed(2)}</div>
          </div>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <path d="M6 9l6 6 6-6" stroke={GRAY} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>

        {/* QUANTITY */}
        <div style={{ marginBottom: 12 }}>
          <div style={{ fontSize: 12, color: GRAY, marginBottom: 6 }}>Number of shares</div>
          <input
            type="number"
            value={qty}
            onChange={e => setQty(e.target.value)}
            placeholder="0"
            min="0"
            step="1"
            style={{ width: '100%', border: 'none', borderBottom: `2px solid ${BLUE}`, outline: 'none', fontSize: 24, fontWeight: 600, color: DARK, padding: '4px 0', background: 'transparent' }}
          />
        </div>

        {/* ESTIMATED COST */}
        {quantity > 0 && (
          <div style={{ background: '#f0f7ff', borderRadius: 8, padding: '10px 12px', marginBottom: 12 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span style={{ fontSize: 13, color: GRAY }}>Estimated {side === 'buy' ? 'cost' : 'proceeds'}</span>
              <span style={{ fontSize: 15, fontWeight: 600, color: DARK }}>
                ${estimatedCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
            <div style={{ fontSize: 11, color: GRAY, marginTop: 4 }}>
              {quantity} shares × ${stock.price.toFixed(2)}
            </div>
          </div>
        )}

        <button
          onClick={() => canTrade && setShowConfirm(true)}
          style={{
            width: '100%', padding: '15px 0', background: canTrade ? (side === 'buy' ? POS_GREEN : NEG_RED) : '#e0e0e0',
            color: canTrade ? '#fff' : '#999', border: 'none', borderRadius: 8,
            fontSize: 16, fontWeight: 600, cursor: canTrade ? 'pointer' : 'not-allowed',
          }}>
          Review & {side === 'buy' ? 'Buy' : 'Sell'}
        </button>
      </div>

      {/* ACCOUNT PICKER SHEET */}
      {showAccountPicker && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 300, display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
          <div style={{ flex: 1, background: 'rgba(0,0,0,0.4)' }} onClick={() => setShowAccountPicker(false)} />
          <div style={{ background: '#fff', borderRadius: '16px 16px 0 0', padding: '20px 0 32px' }}>
            <div style={{ width: 40, height: 4, background: '#ccc', borderRadius: 2, margin: '0 auto 16px' }} />
            <div style={{ fontSize: 17, fontWeight: 700, textAlign: 'center', color: DARK, marginBottom: 12 }}>Select account</div>
            {ACCOUNTS.map(acc => (
              <div key={acc.last4} onClick={() => { setSelectedAccount(acc); setShowAccountPicker(false); }}
                style={{ padding: '14px 20px', borderTop: `1px solid ${BORDER}`, cursor: 'pointer', display: 'flex', justifyContent: 'space-between' }}>
                <div>
                  <div style={{ fontSize: 15, fontWeight: 600, color: DARK }}>{acc.name} (...{acc.last4})</div>
                  <div style={{ fontSize: 13, color: GRAY }}>Cash: ${acc.cash.toFixed(2)}</div>
                </div>
                {selectedAccount.last4 === acc.last4 && (
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                    <path d="M5 13l4 4L19 7" stroke={BLUE} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* CONFIRM MODAL */}
      {showConfirm && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 400, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(0,0,0,0.4)' }}>
          <div style={{ background: '#fff', borderRadius: 12, margin: 24, padding: 24, width: '100%', maxWidth: 340 }}>
            <div style={{ fontSize: 17, fontWeight: 700, color: DARK, textAlign: 'center', marginBottom: 16 }}>
              Confirm {side === 'buy' ? 'purchase' : 'sale'}
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
              <span style={{ color: GRAY, fontSize: 14 }}>Stock</span>
              <span style={{ fontWeight: 600, fontSize: 14, color: DARK }}>{stock.ticker}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
              <span style={{ color: GRAY, fontSize: 14 }}>Shares</span>
              <span style={{ fontWeight: 600, fontSize: 14, color: DARK }}>{qty}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
              <span style={{ color: GRAY, fontSize: 14 }}>Price</span>
              <span style={{ fontWeight: 600, fontSize: 14, color: DARK }}>${stock.price.toFixed(2)}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', paddingTop: 8, borderTop: `1px solid ${BORDER}`, marginBottom: 20 }}>
              <span style={{ color: DARK, fontSize: 15, fontWeight: 600 }}>Total</span>
              <span style={{ fontWeight: 700, fontSize: 15, color: DARK }}>
                ${estimatedCost.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
            <button onClick={() => { setShowConfirm(false); setShowSuccess(true); }}
              style={{ width: '100%', padding: 14, background: BLUE, color: '#fff', border: 'none', borderRadius: 8, fontSize: 15, fontWeight: 600, cursor: 'pointer', marginBottom: 10 }}>
              Place Order
            </button>
            <button onClick={() => setShowConfirm(false)}
              style={{ width: '100%', padding: 14, background: '#f3f4f6', color: DARK, border: 'none', borderRadius: 8, fontSize: 15, cursor: 'pointer' }}>
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
