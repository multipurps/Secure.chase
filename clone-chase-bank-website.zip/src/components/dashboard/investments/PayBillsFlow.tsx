import { useState } from 'react';
import { useAccounts } from '../../../hooks/useAccounts';

interface Props {
  onBack: () => void;
}

const NAVY = '#1a3a6b';
const BLUE = '#2558b5';
const BORDER = '#e5e7eb';

interface Payee {
  id: string;
  name: string;
  logo: string;
  amount: string;
  dueDate: string;
  autoPayOn?: boolean;
  section: 'todo' | 'favorites';
}

const PAYEES: Payee[] = [
  { id: 'verizon', name: 'Verizon', logo: 'https://logo.clearbit.com/verizon.com', amount: '$79.99', dueDate: 'due ' + new Date(Date.now() + 7 * 86400000).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }), section: 'todo' },
  { id: 'att', name: 'AT&T', logo: 'https://logo.clearbit.com/att.com', amount: '$155.50', dueDate: 'scheduled ' + new Date(Date.now() + 14 * 86400000).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }), autoPayOn: true, section: 'todo' },
  { id: 'att-fav', name: 'AT&T', logo: 'https://logo.clearbit.com/att.com', amount: '$155.50', dueDate: '', autoPayOn: true, section: 'favorites' },
  { id: 'verizon-fav', name: 'Verizon', logo: 'https://logo.clearbit.com/verizon.com', amount: '$79.99', dueDate: '', section: 'favorites' },
  { id: 'netflix', name: 'Netflix', logo: 'https://logo.clearbit.com/netflix.com', amount: '$22.99', dueDate: '', section: 'favorites' },
  { id: 'spectrum', name: 'Spectrum', logo: 'https://logo.clearbit.com/spectrum.com', amount: '$89.99', dueDate: '', section: 'favorites' },
  { id: 'tmobile', name: 'T-Mobile', logo: 'https://logo.clearbit.com/t-mobile.com', amount: '$85.00', dueDate: '', section: 'favorites' },
  { id: 'xfinity', name: 'Xfinity', logo: 'https://logo.clearbit.com/xfinity.com', amount: '$65.00', dueDate: '', section: 'favorites' },
  { id: 'coned', name: 'Con Edison', logo: 'https://logo.clearbit.com/coned.com', amount: '$120.00', dueDate: '', section: 'favorites' },
];

type View = 'list' | 'form' | 'confirm' | 'addPayee';

export default function PayBillsFlow({ onBack }: Props) {
  const { accounts } = useAccounts();
  const [view, setView] = useState<View>('list');
  const [activeTab, setActiveTab] = useState<'schedule' | 'activity'>('schedule');
  const [search, setSearch] = useState('');
  const [selectedPayee, setSelectedPayee] = useState<Payee | null>(null);
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [selectedAccountId, setSelectedAccountId] = useState<string | null>(null);
  const [transactionNum, setTransactionNum] = useState('');
  const [addPayeeName, setAddPayeeName] = useState('');
  const [addPayeeEmail, setAddPayeeEmail] = useState('');
  const [addPayeeAccount, setAddPayeeAccount] = useState('');

  const fromAccount = (selectedAccountId ? accounts.find(a => a.id === selectedAccountId) : null) ?? accounts[0];
  const payFrom = fromAccount ? `${fromAccount.account_name} (...${fromAccount.last4})` : 'Select account';

  const deliverDate = new Date(Date.now() + 2 * 86400000).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  const sendDate = new Date(Date.now() + 1 * 86400000).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });

  const todoPayees = PAYEES.filter(p => p.section === 'todo' && (p.name.toLowerCase().includes(search.toLowerCase())));
  const favPayees = PAYEES.filter(p => p.section === 'favorites' && (p.name.toLowerCase().includes(search.toLowerCase())));

  function handlePayeeSelect(payee: Payee) {
    setSelectedPayee(payee);
    setAmount(payee.amount.replace('$', ''));
    setView('form');
  }

  function handlePay() {
    setTransactionNum(Math.floor(100000000 + Math.random() * 900000000).toString());
    setView('confirm');
  }

  if (view === 'addPayee') {
    return (
      <div style={{ minHeight: '100dvh', background: '#fff', fontFamily: "'Helvetica Neue', Arial, sans-serif", paddingBottom: 80 }}>
        <div style={{ background: NAVY, padding: '50px 16px 16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <button onClick={() => setView('list')} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#fff', fontSize: 15 }}>Cancel</button>
          <span style={{ color: '#fff', fontSize: 17, fontWeight: 600 }}>Add Payee</span>
          <div style={{ width: 60 }} />
        </div>
        <div style={{ padding: 20 }}>
          <div style={{ marginBottom: 20 }}>
            <div style={{ fontSize: 12, color: '#888', marginBottom: 8 }}>Payee name</div>
            <input value={addPayeeName} onChange={e => setAddPayeeName(e.target.value)}
              style={{ width: '100%', border: 'none', borderBottom: `2px solid ${BLUE}`, outline: 'none', fontSize: 16, padding: '6px 0', boxSizing: 'border-box' as const }} />
          </div>
          <div style={{ marginBottom: 20 }}>
            <div style={{ fontSize: 12, color: '#888', marginBottom: 8 }}>Email or phone</div>
            <input value={addPayeeEmail} onChange={e => setAddPayeeEmail(e.target.value)}
              style={{ width: '100%', border: 'none', borderBottom: `2px solid ${BLUE}`, outline: 'none', fontSize: 16, padding: '6px 0', boxSizing: 'border-box' as const }} />
          </div>
          <div style={{ marginBottom: 32 }}>
            <div style={{ fontSize: 12, color: '#888', marginBottom: 8 }}>Account number (optional)</div>
            <input value={addPayeeAccount} onChange={e => setAddPayeeAccount(e.target.value)}
              style={{ width: '100%', border: 'none', borderBottom: `2px solid ${BLUE}`, outline: 'none', fontSize: 16, padding: '6px 0', boxSizing: 'border-box' as const }} />
          </div>
          <button
            onClick={() => setView('list')}
            disabled={!addPayeeName}
            style={{ width: '100%', padding: 16, background: addPayeeName ? BLUE : '#ccc', color: '#fff', border: 'none', borderRadius: 8, fontSize: 16, fontWeight: 600, cursor: addPayeeName ? 'pointer' : 'not-allowed' }}>
            Save Payee
          </button>
        </div>
      </div>
    );
  }

  if (view === 'form' && selectedPayee) {
    return (
      <div style={{ minHeight: '100dvh', background: '#fff', fontFamily: "'Helvetica Neue', Arial, sans-serif", paddingBottom: 80 }}>
        {/* HEADER */}
        <div style={{ background: NAVY, padding: '50px 16px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <button onClick={() => setView('list')} style={{ background: 'none', border: 'none', cursor: 'pointer' }}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M19 12H5M12 5l-7 7 7 7" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
          </button>
          <span style={{ color: '#fff', fontSize: 17, fontWeight: 700, letterSpacing: 1 }}>PAY</span>
          <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#fff', fontSize: 15 }}>CANCEL</button>
        </div>

        <div style={{ background: NAVY, display: 'flex', borderBottom: '2px solid rgba(255,255,255,0.2)' }}>
          {['Schedule a payment', 'View activity'].map(tab => (
            <button key={tab} onClick={() => {}}
              style={{ flex: 1, padding: '14px 0', background: 'none', border: 'none', cursor: 'pointer',
                color: '#fff', fontSize: 14, fontWeight: tab === 'Schedule a payment' ? 700 : 400,
                borderBottom: tab === 'Schedule a payment' ? '3px solid #fff' : '3px solid transparent',
              }}>
              {tab}
            </button>
          ))}
        </div>

        <div style={{ padding: 20 }}>
          {/* PAYEE INFO */}
          <div style={{ textAlign: 'center', marginBottom: 24 }}>
            <div style={{ width: 52, height: 52, borderRadius: 999, background: '#f0f4f8', margin: '0 auto 10px', overflow: 'hidden', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <img src={selectedPayee.logo} alt={selectedPayee.name} style={{ width: 40, height: 40, objectFit: 'contain' }}
                onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }} />
            </div>
            <div style={{ fontSize: 18, fontWeight: 700, color: '#111' }}>{selectedPayee.name}</div>
            {selectedPayee.dueDate && <div style={{ fontSize: 14, color: '#888', marginTop: 4 }}>${selectedPayee.amount} {selectedPayee.dueDate}</div>}
          </div>

          {/* AMOUNT */}
          <div style={{ textAlign: 'center', marginBottom: 24 }}>
            <input
              type="number"
              value={amount}
              onChange={e => setAmount(e.target.value)}
              style={{ fontSize: 40, fontWeight: 700, color: '#111', border: 'none', borderBottom: `2px solid ${BLUE}`, outline: 'none', textAlign: 'center', width: '80%', background: 'transparent' }}
            />
          </div>

          {/* PAY FROM */}
          <div style={{ borderBottom: `1px solid ${BORDER}`, padding: '12px 0', marginBottom: 12 }}>
            <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Pay from:</div>
            <select
              value={selectedAccountId ?? ''}
              onChange={e => setSelectedAccountId(e.target.value)}
              style={{ width: '100%', border: 'none', outline: 'none', fontSize: 15, fontWeight: 600, color: BLUE, background: 'transparent', cursor: 'pointer' }}
            >
              {accounts.map(a => (
                <option key={a.id} value={a.id}>{a.account_name} (...{a.last4})</option>
              ))}
            </select>
          </div>

          {/* SEND ON / DELIVER BY */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '12px 0', borderBottom: `1px solid ${BORDER}`, marginBottom: 12 }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 12, color: '#888' }}>Send on</div>
              <div style={{ fontSize: 14, fontWeight: 600, color: '#111', marginTop: 2 }}>{sendDate}</div>
            </div>
            <div style={{ width: 40, height: 2, background: '#ddd', position: 'relative' }}>
              <div style={{ width: 10, height: 10, borderRadius: 999, background: BLUE, position: 'absolute', top: -4, left: '50%', transform: 'translateX(-50%)' }} />
            </div>
            <div style={{ flex: 1, textAlign: 'right' }}>
              <div style={{ fontSize: 12, color: '#888' }}>Deliver by</div>
              <div style={{ fontSize: 14, fontWeight: 600, color: BLUE, marginTop: 2 }}>{deliverDate}</div>
            </div>
          </div>

          {/* NOTE */}
          <div style={{ borderBottom: `1px solid ${BORDER}`, padding: '12px 0', marginBottom: 32 }}>
            <input
              value={note}
              onChange={e => setNote(e.target.value)}
              placeholder="Note for your records (optional)"
              style={{ width: '100%', border: 'none', outline: 'none', fontSize: 14, color: '#111', background: 'transparent' }}
            />
          </div>

          <button
            onClick={handlePay}
            disabled={!amount || parseFloat(amount) <= 0}
            style={{ width: '100%', padding: 16, background: amount && parseFloat(amount) > 0 ? BLUE : '#ccc', color: '#fff', border: 'none', borderRadius: 999, fontSize: 17, fontWeight: 700, cursor: amount && parseFloat(amount) > 0 ? 'pointer' : 'not-allowed' }}>
            Pay
          </button>
        </div>
      </div>
    );
  }

  if (view === 'confirm' && selectedPayee) {
    return (
      <div style={{ minHeight: '100dvh', background: '#fff', fontFamily: "'Helvetica Neue', Arial, sans-serif", paddingBottom: 80 }}>
        <div style={{ background: NAVY, padding: '50px 16px 16px', textAlign: 'center' }}>
          <span style={{ color: '#fff', fontSize: 17, fontWeight: 700, letterSpacing: 1 }}>PAY</span>
        </div>

        {/* SUCCESS ANIMATION */}
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '40px 24px 0' }}>
          <div style={{ width: 64, height: 64, borderRadius: 999, background: '#e8f5e9', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 24, animation: 'scaleIn 0.4s ease' }}>
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
              <path d="M5 13l4 4L19 7" stroke="#2e7d32" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>

          <div style={{ fontSize: 16, color: '#888', marginBottom: 16 }}>We've scheduled your payment.</div>

          <div style={{ width: 52, height: 52, borderRadius: 999, background: '#f0f4f8', margin: '0 auto 8px', overflow: 'hidden', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <img src={selectedPayee.logo} alt={selectedPayee.name} style={{ width: 40, height: 40, objectFit: 'contain' }}
              onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }} />
          </div>
          <div style={{ fontSize: 16, fontWeight: 600, color: '#111', marginBottom: 6 }}>{selectedPayee.name}</div>
          <div style={{ fontSize: 14, color: '#888', marginBottom: 4 }}>Scheduled for {deliverDate}</div>

          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', margin: '12px 0' }}>
            <div style={{ color: '#888', fontSize: 20 }}>···</div>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
              <path d="M6 9l6 6 6-6" stroke={BLUE} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>

          <div style={{ fontSize: 36, fontWeight: 700, color: '#111', marginBottom: 24 }}>
            ${parseFloat(amount).toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </div>

          <div style={{ width: '100%', borderTop: `1px solid ${BORDER}` }}>
            {[
              { label: 'Transaction number', value: transactionNum },
              { label: 'Note', value: note || 'None' },
            ].map((row, i) => (
              <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '12px 0', borderBottom: `1px solid ${BORDER}` }}>
                <span style={{ fontSize: 14, color: '#888' }}>{row.label}</span>
                <span style={{ fontSize: 14, fontWeight: 600, color: '#111' }}>{row.value}</span>
              </div>
            ))}
          </div>

          <button onClick={onBack}
            style={{ width: '100%', padding: 16, background: BLUE, color: '#fff', border: 'none', borderRadius: 8, fontSize: 16, fontWeight: 600, cursor: 'pointer', marginTop: 32 }}>
            Done
          </button>
        </div>
        <style>{`@keyframes scaleIn { from { transform: scale(0); opacity: 0; } to { transform: scale(1); opacity: 1; } }`}</style>
      </div>
    );
  }

  // MAIN LIST VIEW
  return (
    <div style={{ minHeight: '100dvh', background: '#fff', fontFamily: "'Helvetica Neue', Arial, sans-serif", paddingBottom: 80 }}>

      {/* HEADER */}
      <div style={{ background: NAVY, padding: '50px 16px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer' }}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M19 12H5M12 5l-7 7 7 7" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
        </button>
        <span style={{ color: '#fff', fontSize: 17, fontWeight: 700, letterSpacing: 1 }}>PAY</span>
        <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#fff', fontSize: 15 }}>CANCEL</button>
      </div>

      <div style={{ background: NAVY, display: 'flex', borderBottom: '2px solid rgba(255,255,255,0.2)' }}>
        {['schedule', 'activity'].map(tab => (
          <button key={tab} onClick={() => setActiveTab(tab as typeof activeTab)}
            style={{ flex: 1, padding: '14px 0', background: 'none', border: 'none', cursor: 'pointer',
              color: '#fff', fontSize: 14, fontWeight: activeTab === tab ? 700 : 400,
              borderBottom: activeTab === tab ? '3px solid #fff' : '3px solid transparent',
            }}>
            {tab === 'schedule' ? 'Schedule a payment' : 'View activity'}
          </button>
        ))}
      </div>

      <div style={{ padding: '16px' }}>
        {/* SEARCH */}
        <div style={{ display: 'flex', alignItems: 'center', border: `1px solid ${BORDER}`, borderRadius: 8, padding: '10px 14px', gap: 10, marginBottom: 16 }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <circle cx="11" cy="11" r="8" stroke="#999" strokeWidth="2" />
            <path d="M21 21l-4.35-4.35" stroke="#999" strokeWidth="2" strokeLinecap="round" />
          </svg>
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Enter a name, email or mobile number"
            style={{ border: 'none', outline: 'none', fontSize: 14, flex: 1, color: '#111', background: 'transparent' }} />
        </div>

        {/* TO DO */}
        {todoPayees.length > 0 && (
          <>
            <div style={{ fontSize: 14, fontWeight: 700, color: '#888', padding: '4px 0 8px' }}>To do</div>
            {todoPayees.map(payee => (
              <div key={payee.id} onClick={() => handlePayeeSelect(payee)}
                style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 0', borderBottom: `1px solid ${BORDER}`, cursor: 'pointer' }}>
                <div style={{ width: 44, height: 44, borderRadius: 999, background: '#f0f4f8', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, overflow: 'hidden' }}>
                  <img src={payee.logo} alt={payee.name} style={{ width: 36, height: 36, objectFit: 'contain' }}
                    onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 15, fontWeight: 600, color: '#111' }}>{payee.name}</div>
                  <div style={{ fontSize: 13, color: '#888' }}>{payee.amount} {payee.dueDate}</div>
                  {payee.autoPayOn && <div style={{ fontSize: 12, color: '#2e7d32', marginTop: 2 }}>Automatic payments: On</div>}
                </div>
              </div>
            ))}
          </>
        )}

        {/* FAVORITES */}
        <div style={{ fontSize: 14, fontWeight: 700, color: '#888', padding: '12px 0 8px' }}>Favorites</div>
        {favPayees.map(payee => (
          <div key={payee.id} onClick={() => handlePayeeSelect(payee)}
            style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 0', borderBottom: `1px solid ${BORDER}`, cursor: 'pointer' }}>
            <div style={{ width: 44, height: 44, borderRadius: 999, background: '#f0f4f8', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, overflow: 'hidden' }}>
              <img src={payee.logo} alt={payee.name} style={{ width: 36, height: 36, objectFit: 'contain' }}
                onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }} />
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 15, fontWeight: 600, color: '#111' }}>{payee.name}</div>
              {payee.autoPayOn && <div style={{ fontSize: 12, color: '#2e7d32' }}>Automatic payments: On</div>}
            </div>
          </div>
        ))}

        {/* ADD PAYEE */}
        <div onClick={() => setView('addPayee')}
          style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 0', cursor: 'pointer' }}>
          <div style={{ width: 44, height: 44, borderRadius: 999, border: `2px solid ${BLUE}`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
              <path d="M12 5v14M5 12h14" stroke={BLUE} strokeWidth="2.5" strokeLinecap="round" />
            </svg>
          </div>
          <span style={{ fontSize: 15, fontWeight: 600, color: BLUE }}>Add payee</span>
        </div>
      </div>
    </div>
  );
}
