const blue = '#2558b5';

interface Props {
  onSeeAll: () => void;
  onStatements: () => void;
}

const PREVIEW_TXS = [
  { desc: 'ONLINE TRANSFER FROM CHK ...8626', date: 'Jan 30, 2025', status: 'Pending', amount: '+$13,000.00', type: 'credit' as const },
  { desc: 'FEDWIRE CREDIT VIA: WELLS FARGO BANK, N.A./121000248', date: 'Jan 30, 2025', status: 'Posted', amount: '+$45,000.00', type: 'credit' as const },
  { desc: 'AMAZON.COM*RT5K92Y14 AMZN.COM/BILL WA', date: 'Jan 15, 2025', status: 'Posted', amount: '-$89.99', type: 'debit' as const },
];

export default function TransactionsWidget({ onSeeAll, onStatements }: Props) {
  return (
    <div style={{
      margin: '16px 16px 0',
      background: '#fff', borderRadius: 14, overflow: 'hidden',
      boxShadow: '0 2px 10px rgba(0,0,0,0.07)',
      fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
    }}>
      {/* Header */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '16px 18px',
        borderBottom: '1px solid #f0f0f0',
      }}>
        <span style={{ fontWeight: 700, fontSize: 18, color: '#111' }}>See all transactions</span>
        <button onClick={onSeeAll} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
          <svg width="9" height="16" viewBox="0 0 9 16" fill="none">
            <polyline points="1,1 8,8 1,15" stroke="#bbb" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
      </div>

      {/* Transaction rows */}
      {PREVIEW_TXS.map((tx, i) => (
        <div
          key={i}
          onClick={onSeeAll}
          style={{
            padding: '13px 18px',
            borderBottom: '1px solid #f0f0f0',
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            cursor: 'pointer',
          }}
        >
          <div style={{ flex: 1, paddingRight: 12 }}>
            <div style={{ fontSize: 15, fontWeight: 600, color: '#222', lineHeight: 1.3 }}>{tx.desc}</div>
            <div style={{ fontSize: 13, color: '#888', marginTop: 2 }}>{tx.date}</div>
            <div style={{ fontSize: 12, color: '#aaa', marginTop: 1 }}>{tx.status}</div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexShrink: 0 }}>
            <span style={{ fontSize: 16, fontWeight: 600, color: tx.type === 'credit' ? blue : '#d32f2f' }}>
              {tx.amount}
            </span>
            <svg width="7" height="13" viewBox="0 0 7 13" fill="none">
              <polyline points="1,1 6,6.5 1,12" stroke="#bbb" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
        </div>
      ))}

      {/* Two pill buttons */}
      <div style={{ display: 'flex', gap: 12, padding: '14px 18px' }}>
        <button
          onClick={onStatements}
          style={{
            flex: 1, background: '#fff', border: `1.5px solid ${blue}`,
            borderRadius: 999, padding: '10px 8px',
            color: blue, fontSize: 13, fontWeight: 600, cursor: 'pointer',
          }}
        >
          See statements
        </button>
        <button
          onClick={onSeeAll}
          style={{
            flex: 1, background: '#fff', border: `1.5px solid ${blue}`,
            borderRadius: 999, padding: '10px 8px',
            color: blue, fontSize: 13, fontWeight: 600, cursor: 'pointer',
          }}
        >
          See all transactions
        </button>
      </div>
    </div>
  );
}
