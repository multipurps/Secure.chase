import { useState } from 'react';

interface Props {
  onBack: () => void;
}

const BLUE = '#2558b5';
const NAVY = '#1a3a6b';

export default function LockUnlockCard({ onBack }: Props) {
  const [card1Locked, setCard1Locked] = useState(false); // DEBIT ...7349 — unlocked
  const [card2Locked, setCard2Locked] = useState(true);  // DEBIT ...5799 — locked

  function Toggle({ locked, onToggle }: { locked: boolean; onToggle: () => void }) {
    return (
      <button
        onClick={onToggle}
        style={{
          width: 50, height: 28, borderRadius: 14,
          background: locked ? BLUE : '#ccc',
          border: 'none', cursor: 'pointer', position: 'relative',
          transition: 'background 0.25s',
          flexShrink: 0,
        }}
      >
        <div style={{
          width: 22, height: 22, borderRadius: '50%', background: '#fff',
          position: 'absolute', top: 3,
          left: locked ? 25 : 3,
          transition: 'left 0.25s',
          boxShadow: '0 1px 4px rgba(0,0,0,0.2)',
        }} />
      </button>
    );
  }

  // Padlock icons
  function OpenLock() {
    return (
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
        <rect x="3" y="11" width="18" height="11" rx="2" stroke="#aaa" strokeWidth="1.8" fill="none" />
        <path d="M7 11V7a5 5 0 0110 0" stroke="#aaa" strokeWidth="1.8" strokeLinecap="round" fill="none" />
        <circle cx="12" cy="16" r="1.5" fill="#aaa" />
      </svg>
    );
  }

  function ClosedLock() {
    return (
      <svg width="28" height="28" viewBox="0 0 24 24" fill={BLUE}>
        <rect x="3" y="11" width="18" height="11" rx="2" fill={BLUE} />
        <path d="M7 11V7a5 5 0 0110 0v4" stroke={BLUE} strokeWidth="1.8" strokeLinecap="round" fill="none" />
        <circle cx="12" cy="16.5" r="1.8" fill="#fff" />
      </svg>
    );
  }

  return (
    <div style={{
      minHeight: '100dvh', background: '#f5f5f5',
      fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
      paddingBottom: 80,
    }}>
      {/* HEADER */}
      <div style={{
        background: NAVY, padding: '52px 16px 16px',
        display: 'flex', alignItems: 'center', gap: 16,
      }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path d="M19 12H5M12 5l-7 7 7 7" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
        <span style={{ color: '#fff', fontSize: 17, fontWeight: 700, flex: 1, textAlign: 'center', marginRight: 40 }}>
          Lock & Unlock Your Card
        </span>
      </div>

      {/* CARD 1 — DEBIT ...7349 (Unlocked) */}
      <div style={{ background: '#fff', margin: '20px 0 0', borderRadius: 0 }}>
        <div style={{ padding: '18px 20px' }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: '#111', letterSpacing: 0.5, marginBottom: 12 }}>
            DEBIT/ATM CARD (...7349)
          </div>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <Toggle locked={card1Locked} onToggle={() => setCard1Locked(!card1Locked)} />
              <span style={{ fontSize: 15, color: card1Locked ? '#111' : '#888', fontWeight: card1Locked ? 700 : 400 }}>
                {card1Locked ? 'Locked' : 'Unlocked'}
              </span>
            </div>
            {card1Locked ? <ClosedLock /> : <OpenLock />}
          </div>
          {card1Locked && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 10 }}>
              <div style={{ width: 20, height: 20, borderRadius: '50%', background: '#2a9d4e', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
                  <polyline points="2,5 4.5,7.5 8.5,2.5" stroke="#fff" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </div>
              <span style={{ fontSize: 13, color: '#555' }}>You've locked your card.</span>
            </div>
          )}
        </div>
        <div style={{ borderTop: '1px solid #f0f0f0' }} />

        {/* CARD 2 — DEBIT ...5799 (Locked) */}
        <div style={{ padding: '18px 20px' }}>
          <div style={{ fontSize: 16, fontWeight: 700, color: '#111', letterSpacing: 0.5, marginBottom: 12 }}>
            DEBIT/ATM CARD (...5799)
          </div>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <Toggle locked={card2Locked} onToggle={() => setCard2Locked(!card2Locked)} />
              <span style={{ fontSize: 15, color: card2Locked ? '#111' : '#888', fontWeight: card2Locked ? 700 : 400 }}>
                {card2Locked ? 'Locked' : 'Unlocked'}
              </span>
            </div>
            {card2Locked ? <ClosedLock /> : <OpenLock />}
          </div>
          {card2Locked && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 10 }}>
              <div style={{ width: 20, height: 20, borderRadius: '50%', background: '#2a9d4e', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
                  <polyline points="2,5 4.5,7.5 8.5,2.5" stroke="#fff" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </div>
              <span style={{ fontSize: 13, color: '#555' }}>You've locked your card.</span>
            </div>
          )}
        </div>
      </div>

      {/* BOTTOM INFO PANEL */}
      <div style={{
        margin: '24px 0 0',
        background: '#f9f9f9',
        borderRadius: '16px 16px 0 0',
        padding: '24px 20px',
        boxShadow: '0 -2px 12px rgba(0,0,0,0.06)',
      }}>
        <div style={{ fontSize: 16, fontWeight: 700, color: '#111', marginBottom: 12 }}>Misplaced your card?</div>
        <div style={{ fontSize: 14, color: '#555', lineHeight: 1.7, marginBottom: 14 }}>
          Locking your card instantly blocks new purchases and ATM withdrawals. It does not affect fees, credits, or repeating transactions like gym memberships or TV subscriptions.
        </div>
        <div style={{ fontSize: 14, color: '#555', lineHeight: 1.7 }}>
          Once you find your card, you can unlock it and use it right away. However, if the card was stolen or your card information was compromised, request a new card immediately.
        </div>
      </div>
    </div>
  );
}
