import { useState } from 'react';
import FullTransactionHistory from './FullTransactionHistory';
import ManageAccountPage from './ManageAccountPage';

interface AccountDetailProps {
  onBack: () => void;
  account?: {
    name: string;
    last4: string;
    balance: string;
    type: string;
  };
}

const blue = '#2558b5';

const DEFAULT_ACCOUNT = {
  name: 'CHASE TOTAL CHECKING',
  last4: '4892',
  balance: '$358,760,439.69',
  type: 'checking',
};

const TRANSACTIONS = [
  {
    id: 1,
    desc: 'FEDWIRE CREDIT VIA: WELLS FARGO BANK, N.A./121000248 B/O: WFG NATIONAL TITLE INSURANC...',
    date: 'Jan 30, 2025',
    balance: '$358,760,439.69',
    amount: '+$62,000.00',
    debit: false,
  },
  {
    id: 2,
    desc: 'VIRGINIA TECH REG SALARY PPD ID: 6546001805',
    date: 'Jan 15, 2025',
    balance: '$358,698,439.69',
    amount: '+$4,581.23',
    debit: false,
  },
  {
    id: 3,
    desc: 'ROBINHOOD FUNDS 111471264 WEB ID: 1464364776',
    date: 'Jan 6, 2025',
    balance: '$358,693,858.46',
    amount: '-$50.00',
    debit: true,
  },
];

export default function AccountDetail({ onBack, account = DEFAULT_ACCOUNT }: AccountDetailProps) {
  const [showDetails, setShowDetails] = useState(false);
  const [showTxHistory, setShowTxHistory] = useState(false);
  const [showMoreMenu, setShowMoreMenu] = useState(false);
  const [showManage, setShowManage] = useState(false);

  if (showTxHistory) {
    return <FullTransactionHistory onBack={() => setShowTxHistory(false)} />;
  }

  return (
    <div style={{
      width: '100%', minHeight: '100dvh', overflowY: 'auto', overflowX: 'hidden',
      background: '#f0f4f8', paddingBottom: 80,
      fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
    }}>
      {/* TOP NAV */}
      <div style={{ background: '#f0f4f8', padding: '52px 20px 0' }}>
        <button
          onClick={onBack}
          style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0, display: 'flex', alignItems: 'center', gap: 6 }}
        >
          <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
            <polyline points="14,3 7,11 14,19" stroke="#555" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
      </div>

      {/* PAGE TITLE */}
      <div style={{ padding: '12px 20px 0' }}>
        <div style={{ fontSize: 22, fontWeight: 700, color: '#111', lineHeight: 1.3 }}>
          {account.name} (...{account.last4})
        </div>
      </div>

      {/* BALANCE CARD */}
      <div style={{ padding: '14px 16px 0' }}>
        <div style={{
          background: '#fff', borderRadius: 12, padding: '20px 18px',
          boxShadow: '0 2px 10px rgba(0,0,0,0.07)',
        }}>
          {/* Right-aligned balance */}
          <div style={{ textAlign: 'right', marginBottom: 16 }}>
            <div style={{ fontSize: 30, fontWeight: 700, color: '#111', lineHeight: 1 }}>{account.balance}</div>
            <div style={{ fontSize: 13, color: '#888', marginTop: 4 }}>Available balance</div>
          </div>

          <div style={{ height: 1, background: '#f0f0f0', margin: '0 0 16px' }} />

          {/* ACCOUNT DETAILS */}
          <div style={{ fontWeight: 700, fontSize: 16, color: '#111', marginBottom: 14 }}>Account details</div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
            <span style={{ color: '#777', fontSize: 14 }}>Available balance</span>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <span style={{ fontWeight: 600, fontSize: 14, color: '#111' }}>{account.balance}</span>
              <button style={{ background: '#e8f0fb', border: 'none', borderRadius: '50%', width: 20, height: 20, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: blue, fontWeight: 700, fontSize: 11 }}>?</button>
            </div>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <span style={{ color: '#777', fontSize: 14 }}>Present balance</span>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <span style={{ fontWeight: 600, fontSize: 14, color: '#111' }}>{account.balance}</span>
              <button style={{ background: '#e8f0fb', border: 'none', borderRadius: '50%', width: 20, height: 20, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: blue, fontWeight: 700, fontSize: 11 }}>?</button>
            </div>
          </div>

          {/* SHOW DETAILS BUTTON */}
          <div style={{ display: 'flex', justifyContent: 'center' }}>
            <button
              onClick={() => setShowDetails(!showDetails)}
              style={{
                background: '#fff', border: '1px solid #ddd', borderRadius: 999,
                padding: '10px 24px', color: blue, fontSize: 14, fontWeight: 600, cursor: 'pointer',
              }}
            >
              {showDetails ? 'Hide details ∧' : 'Show details ∨'}
            </button>
          </div>

          {showDetails && (
            <div style={{ marginTop: 16, borderTop: '1px solid #f0f0f0', paddingTop: 16 }}>
              {[
                { label: 'Routing number', value: '021000021' },
                { label: 'Account number', value: '••••' + account.last4 },
                { label: 'Account opened', value: 'March 14, 2019' },
                { label: 'Interest rate (APY)', value: '0.01%' },
              ].map(row => (
                <div key={row.label} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
                  <span style={{ color: '#777', fontSize: 14 }}>{row.label}</span>
                  <span style={{ fontWeight: 600, fontSize: 14, color: '#111' }}>{row.value}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* 3 ACTION BUTTONS */}
      <div style={{ padding: '18px 16px 0', display: 'flex', justifyContent: 'space-around' }}>
        {[
          {
            label: 'Pay',
            icon: (
              <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
                <rect x="2" y="5" width="20" height="14" rx="2" stroke={blue} strokeWidth="1.8" />
                <rect x="2" y="9" width="20" height="3" fill={blue} />
              </svg>
            ),
          },
          {
            label: 'Transfer',
            icon: (
              <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
                <polyline points="17,4 21,8 17,12" stroke={blue} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                <line x1="3" y1="8" x2="21" y2="8" stroke={blue} strokeWidth="2" strokeLinecap="round" />
                <polyline points="7,12 3,16 7,20" stroke={blue} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                <line x1="21" y1="16" x2="3" y2="16" stroke={blue} strokeWidth="2" strokeLinecap="round" />
              </svg>
            ),
          },
          {
            label: 'More',
            icon: (
              <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
                <circle cx="5" cy="12" r="1.5" fill={blue} />
                <circle cx="12" cy="12" r="1.5" fill={blue} />
                <circle cx="19" cy="12" r="1.5" fill={blue} />
              </svg>
            ),
            action: () => setShowMoreMenu(true),
          },
        ].map(btn => (
          <button
            key={btn.label}
            onClick={btn.action}
            style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, background: 'none', border: 'none', cursor: 'pointer' }}
          >
            <div style={{ width: 56, height: 56, borderRadius: '50%', background: '#ddeeff', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {btn.icon}
            </div>
            <span style={{ fontSize: 13, color: blue, fontWeight: 500 }}>{btn.label}</span>
          </button>
        ))}
      </div>

      {/* MANAGE ACCOUNT */}
      <div style={{ margin: '14px 16px 0' }}>
        <div
          onClick={() => setShowManage(true)}
          style={{
            background: '#fff', borderRadius: 12, padding: '16px 18px',
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            cursor: 'pointer', boxShadow: '0 1px 6px rgba(0,0,0,0.05)',
          }}
        >
          <div>
            <div style={{ fontWeight: 700, fontSize: 15, color: '#111' }}>Manage account</div>
            <div style={{ fontSize: 13, color: '#888', marginTop: 2 }}>Access tools &amp; services for your account</div>
          </div>
          <svg width="9" height="16" viewBox="0 0 9 16" fill="none">
            <polyline points="1,1 8,8 1,15" stroke="#bbb" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
        {showManage && <ManageAccountPage onClose={() => setShowManage(false)} />}
      </div>

      {/* SEE ALL TRANSACTIONS */}
      <div style={{ margin: '12px 16px 0', background: '#fff', borderRadius: 12, overflow: 'hidden', boxShadow: '0 1px 6px rgba(0,0,0,0.05)' }}>
        <div
          onClick={() => setShowTxHistory(true)}
          style={{ padding: '16px 18px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', cursor: 'pointer', borderBottom: '1px solid #f0f0f0' }}
        >
          <span style={{ fontWeight: 700, fontSize: 15, color: '#111' }}>See all transactions</span>
          <svg width="9" height="16" viewBox="0 0 9 16" fill="none">
            <polyline points="1,1 8,8 1,15" stroke="#bbb" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>

        {/* TRANSACTION ROWS */}
        {TRANSACTIONS.map((tx, i) => (
          <div key={tx.id} style={{
            padding: '14px 18px',
            borderBottom: i < TRANSACTIONS.length - 1 ? '1px solid #f5f5f5' : 'none',
            display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', cursor: 'pointer',
          }}>
            <div style={{ flex: 1, paddingRight: 12 }}>
              <div style={{ fontWeight: 600, fontSize: 13, color: '#111', lineHeight: 1.4 }}>{tx.desc}</div>
              <div style={{ fontSize: 12, color: '#888', marginTop: 3 }}>{tx.date}</div>
              <div style={{ fontSize: 12, color: '#888', marginTop: 2 }}>{tx.balance}</div>
            </div>
            <div style={{ fontWeight: 700, fontSize: 15, color: tx.debit ? '#d32f2f' : blue, flexShrink: 0 }}>
              {tx.amount}
            </div>
          </div>
        ))}
      </div>

      {/* MORE MENU */}
      {showMoreMenu && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.45)', zIndex: 500, display: 'flex', alignItems: 'flex-end' }} onClick={() => setShowMoreMenu(false)}>
          <div style={{ background: '#fff', width: '100%', borderRadius: '16px 16px 0 0', padding: '20px 0 40px' }} onClick={e => e.stopPropagation()}>
            <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 16 }}>
              <div style={{ width: 40, height: 4, background: '#ccc', borderRadius: 2 }} />
            </div>
            {['Freeze account', 'Dispute a charge', 'Order checks', 'View statements', 'Set up alerts'].map(item => (
              <button key={item} onClick={() => setShowMoreMenu(false)} style={{ width: '100%', padding: '15px 20px', background: 'none', border: 'none', borderBottom: '1px solid #f0f0f0', textAlign: 'left', fontSize: 15, color: '#111', cursor: 'pointer' }}>
                {item}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
