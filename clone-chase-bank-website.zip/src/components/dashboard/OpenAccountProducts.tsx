import { useState } from 'react';

interface Props {
  onBack: () => void;
}

const BLUE = '#2558b5';
const NAVY = '#1a3a6b';

// All illustrated icons exactly as specified SS7–SS17
const CREDIT_CARD_ICON = (
  <svg width="52" height="52" viewBox="0 0 52 52" fill="none">
    {/* card body */}
    <rect x="4" y="10" width="44" height="32" rx="4" fill="#2558b5" />
    {/* glossy highlight */}
    <polygon points="30,10 48,10 48,28" fill="rgba(255,255,255,0.1)" />
    {/* Chase octagon — simplified */}
    <rect x="8" y="14" width="10" height="10" rx="2" fill="rgba(255,255,255,0.25)" />
    <rect x="10" y="16" width="6" height="6" rx="1" fill="#fff" opacity="0.6" />
    {/* EMV chip */}
    <rect x="8" y="27" width="10" height="8" rx="1.5" fill="#d4af37" />
    <line x1="8" y1="30" x2="18" y2="30" stroke="#b8941f" strokeWidth="0.8" />
    <line x1="13" y1="27" x2="13" y2="35" stroke="#b8941f" strokeWidth="0.8" />
    {/* dark stripe near bottom */}
    <rect x="4" y="34" width="44" height="8" rx="0" fill="rgba(0,0,30,0.35)" />
    {/* bokeh dots */}
    <circle cx="40" cy="14" r="2" fill="rgba(255,255,255,0.2)" />
    <circle cx="45" cy="18" r="1.2" fill="rgba(255,255,255,0.15)" />
    <circle cx="42" cy="22" r="1.5" fill="rgba(255,255,255,0.12)" />
  </svg>
);

const CHECKING_ICON = (
  <svg width="52" height="52" viewBox="0 0 52 52" fill="none">
    <rect x="4" y="12" width="44" height="28" rx="4" fill="#2558b5" />
    {/* gloss */}
    <polygon points="28,12 48,12 48,30" fill="rgba(255,255,255,0.1)" />
    {/* two white bars */}
    <rect x="10" y="20" width="32" height="4" rx="2" fill="rgba(255,255,255,0.85)" />
    <rect x="10" y="28" width="20" height="4" rx="2" fill="rgba(255,255,255,0.6)" />
  </svg>
);

const CD_ICON = (
  <svg width="52" height="52" viewBox="0 0 52 52" fill="none">
    {/* green bill behind */}
    <rect x="6" y="16" width="36" height="24" rx="3" fill="#43a047" transform="rotate(-5 6 16)" />
    {/* blue bill on top */}
    <rect x="10" y="13" width="36" height="24" rx="3" fill="#2558b5" />
    {/* white circle with $ */}
    <circle cx="28" cy="25" r="8" fill="#fff" />
    <text x="28" y="29.5" textAnchor="middle" fontSize="11" fontWeight="800" fill={NAVY} fontFamily="Helvetica Neue, Arial, sans-serif">$</text>
    {/* dark dash */}
    <rect x="37" y="24" width="5" height="2.5" rx="1.2" fill="rgba(255,255,255,0.7)" />
  </svg>
);

const AUTO_ICON = (
  <svg width="52" height="52" viewBox="0 0 52 52" fill="none">
    {/* car body */}
    <rect x="6" y="26" width="40" height="16" rx="4" fill="#2558b5" />
    {/* roof */}
    <path d="M14 26 L18 16 L34 16 L38 26Z" fill="#1a4a9a" />
    {/* windshield glare */}
    <line x1="21" y1="17" x2="19" y2="25" stroke="rgba(255,255,255,0.5)" strokeWidth="1.2" />
    <line x1="25" y1="16" x2="23" y2="25" stroke="rgba(255,255,255,0.3)" strokeWidth="0.8" />
    {/* headlights */}
    <circle cx="12" cy="34" r="3.5" fill="#ffe066" />
    <circle cx="40" cy="34" r="3.5" fill="#ffe066" />
    {/* wheels */}
    <circle cx="15" cy="42" r="4" fill="#222" />
    <circle cx="15" cy="42" r="2" fill="#555" />
    <circle cx="37" cy="42" r="4" fill="#222" />
    <circle cx="37" cy="42" r="2" fill="#555" />
    {/* shadow */}
    <ellipse cx="26" cy="46" rx="18" ry="2" fill="rgba(0,0,0,0.12)" />
  </svg>
);

const MORTGAGE_ICON = (
  <svg width="52" height="52" viewBox="0 0 52 52" fill="none">
    {/* house body */}
    <rect x="10" y="26" width="32" height="22" rx="2" fill="#2558b5" />
    {/* roof */}
    <path d="M6 28 L26 10 L46 28Z" fill="#1a3a6b" />
    {/* chimney */}
    <rect x="12" y="14" width="5" height="10" fill="#1a3a6b" />
    {/* arch interior */}
    <path d="M15 48 L15 35 A11 11 0 0 1 37 35 L37 48Z" fill="rgba(255,255,255,0.15)" />
    {/* door */}
    <rect x="21" y="36" width="10" height="12" rx="5" fill="#4caf50" />
    {/* roof gloss */}
    <polygon points="26,10 46,28 40,28" fill="rgba(255,255,255,0.08)" />
  </svg>
);

const ADVISORS_ICON = (
  <svg width="52" height="52" viewBox="0 0 52 52" fill="none">
    {/* ground */}
    <ellipse cx="26" cy="44" rx="20" ry="2.5" fill="rgba(0,0,0,0.1)" />
    {/* back figure — dark navy */}
    <circle cx="30" cy="20" r="6" fill={NAVY} />
    <path d="M18 44 Q20 32 30 32 Q40 32 40 44" fill={NAVY} />
    {/* front figure — medium blue */}
    <circle cx="22" cy="22" r="7" fill="#4472c4" />
    <path d="M8 44 Q11 31 22 31 Q33 31 36 44" fill="#4472c4" />
  </svg>
);

const INVEST_OWN_ICON = (
  <svg width="52" height="52" viewBox="0 0 52 52" fill="none">
    {/* panel with pinstripes */}
    <rect x="6" y="20" width="40" height="26" rx="3" fill="#2558b5" />
    {/* subtle pinstripes */}
    {[22, 25, 28, 31, 34, 37, 40].map(y => (
      <line key={y} x1="6" y1={y} x2="46" y2={y} stroke="rgba(255,255,255,0.08)" strokeWidth="1" />
    ))}
    {/* 3D depth left edge */}
    <rect x="3" y="23" width="3" height="23" rx="1" fill="#1a4a9a" />
    {/* stock line — white then gold */}
    <polyline points="8,38 15,34 20,36 26,28 30,22 35,25 42,16"
      stroke="#fff" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
    <polyline points="30,22 35,25 42,16"
      stroke="#d4af37" strokeWidth="2.2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const CREDIT_SCORE_ICON = (
  <svg width="52" height="52" viewBox="0 0 52 52" fill="none">
    {/* arc segments */}
    {[
      { start: 180, end: 225, color: '#d32f2f' },
      { start: 225, end: 258, color: '#f57c00' },
      { start: 258, end: 291, color: '#fbc02d' },
      { start: 291, end: 324, color: '#8bc34a' },
      { start: 324, end: 360, color: '#2e7d32' },
    ].map((seg, i) => {
      const cx = 26, cy = 34, r = 20;
      const toRad = (d: number) => (d * Math.PI) / 180;
      const x1 = cx + r * Math.cos(toRad(seg.start));
      const y1 = cy + r * Math.sin(toRad(seg.start));
      const x2 = cx + r * Math.cos(toRad(seg.end));
      const y2 = cy + r * Math.sin(toRad(seg.end));
      return (
        <path key={i}
          d={`M ${x1.toFixed(1)} ${y1.toFixed(1)} A ${r} ${r} 0 0 1 ${x2.toFixed(1)} ${y2.toFixed(1)}`}
          stroke={seg.color} strokeWidth="8" fill="none" strokeLinecap="butt" />
      );
    })}
    {/* needle */}
    <line x1="26" y1="34" x2="40" y2="16" stroke="#2558b5" strokeWidth="2.5" strokeLinecap="round" />
    {/* needle ball joint */}
    <circle cx="26" cy="34" r="3.5" fill="#9e9e9e" />
    <circle cx="26" cy="34" r="2" fill="#bdbdbd" />
  </svg>
);

const BUSINESS_ICON = (
  <svg width="52" height="52" viewBox="0 0 52 52" fill="none">
    {/* briefcase bottom */}
    <rect x="6" y="26" width="40" height="22" rx="3" fill={NAVY} />
    {/* briefcase top */}
    <rect x="6" y="18" width="40" height="12" rx="3" fill="#5b9bd5" />
    {/* gloss on top */}
    <polygon points="6,18 46,18 46,22 6,22" fill="rgba(255,255,255,0.12)" />
    {/* dashed stitch border on top */}
    <rect x="8" y="20" width="36" height="8" rx="2" fill="none" stroke="rgba(255,255,255,0.4)" strokeWidth="1" strokeDasharray="3,2" />
    {/* gold clasps */}
    <rect x="17" y="27" width="6" height="5" rx="1" fill="#d4af37" />
    <rect x="29" y="27" width="6" height="5" rx="1" fill="#d4af37" />
    {/* handle */}
    <path d="M18 18 Q18 10 26 10 Q34 10 34 18" stroke="#d4af37" strokeWidth="2.5" fill="none" strokeLinecap="round" />
    <rect x="22" y="9" width="8" height="3" rx="1.5" fill="#d4af37" />
    {/* handle attachment caps */}
    <circle cx="18" cy="18" r="2" fill="#d4af37" />
    <circle cx="34" cy="18" r="2" fill="#d4af37" />
  </svg>
);

const HOME_EQUITY_ICON = (
  <svg width="52" height="52" viewBox="0 0 52 52" fill="none">
    {/* roller frame */}
    <rect x="18" y="8" width="18" height="12" rx="2" fill="#d4af37" />
    {/* foam roller — yellow paint */}
    <rect x="16" y="10" width="22" height="8" rx="4" fill="#f5c842" />
    {/* yellow drip */}
    <ellipse cx="27" cy="9" rx="4" ry="2" fill="#f5c842" />
    {/* handle */}
    <rect x="25" y="20" width="3" height="22" rx="1.5" fill="#2558b5" />
    <rect x="24" y="38" width="5" height="8" rx="2" fill="#2558b5" />
    {/* roller frame */}
    <line x1="18" y1="14" x2="35" y2="14" stroke="#2558b5" strokeWidth="1.5" />
    {/* shadow */}
    <ellipse cx="27" cy="47" rx="10" ry="2" fill="rgba(0,0,0,0.1)" />
  </svg>
);

const SAVINGS_ICON = (
  <svg width="52" height="52" viewBox="0 0 52 52" fill="none">
    {/* pig body */}
    <ellipse cx="26" cy="32" rx="16" ry="14" fill="#4472c4" />
    {/* pig head */}
    <circle cx="40" cy="26" r="8" fill="#4472c4" />
    {/* snout */}
    <ellipse cx="44" cy="28" rx="4" ry="3" fill="#3461ad" />
    <circle cx="43" cy="27.5" r="1" fill="#1a3a6b" />
    <circle cx="45" cy="27.5" r="1" fill="#1a3a6b" />
    {/* eye */}
    <circle cx="40" cy="23" r="1.5" fill="#1a3a6b" />
    {/* ear */}
    <ellipse cx="36" cy="19" rx="3" ry="4" fill="#3461ad" />
    {/* coin slot */}
    <rect x="22" y="18" width="8" height="2.5" rx="1.2" fill="#1a3a6b" />
    {/* gold coin */}
    <circle cx="26" cy="15" r="6" fill="#d4af37" />
    <text x="26" y="18.5" textAnchor="middle" fontSize="8" fontWeight="800" fill="#fff" fontFamily="Helvetica Neue, Arial, sans-serif">$</text>
    {/* legs */}
    <rect x="14" y="43" width="4" height="5" rx="2" fill="#3461ad" />
    <rect x="20" y="44" width="4" height="5" rx="2" fill="#3461ad" />
    <rect x="28" y="44" width="4" height="5" rx="2" fill="#3461ad" />
    <rect x="34" y="43" width="4" height="5" rx="2" fill="#3461ad" />
    {/* tail */}
    <path d="M10 34 Q6 30 10 26" stroke="#3461ad" strokeWidth="2" fill="none" strokeLinecap="round" />
    {/* shadow */}
    <ellipse cx="26" cy="49" rx="14" ry="2" fill="rgba(0,0,0,0.1)" />
  </svg>
);

const PRODUCTS = [
  { id: 'credit-cards', label: 'Credit cards', icon: CREDIT_CARD_ICON, description: 'Earn rewards on every purchase with Chase credit cards.' },
  { id: 'checking', label: 'Checking', icon: CHECKING_ICON, description: 'Open a Chase checking account with no hidden fees.' },
  { id: 'savings', label: 'Savings', icon: SAVINGS_ICON, description: 'Grow your savings with competitive interest rates.' },
  { id: 'cds', label: 'CDs', icon: CD_ICON, description: 'Lock in a guaranteed rate with a Certificate of Deposit.' },
  { id: 'auto', label: 'Auto', icon: AUTO_ICON, description: 'Finance your next vehicle with Chase auto loans.' },
  { id: 'mortgage', label: 'Mortgage', icon: MORTGAGE_ICON, description: 'Buy or refinance your home with competitive rates.' },
  { id: 'home-equity', label: 'Home Equity', icon: HOME_EQUITY_ICON, description: 'Use your home\'s equity for major expenses.' },
  { id: 'advisors', label: 'Work with Our Advisors', icon: ADVISORS_ICON, description: 'Get personalized financial guidance from our advisors.' },
  { id: 'invest-own', label: 'Invest on Your Own', icon: INVEST_OWN_ICON, description: 'Self-directed investing with J.P. Morgan.' },
  { id: 'credit-score', label: 'Free Credit Score', icon: CREDIT_SCORE_ICON, description: 'Monitor your credit score for free with Chase Credit Journey.' },
  { id: 'business', label: 'Business', icon: BUSINESS_ICON, description: 'Banking solutions built for your business.' },
];

export default function OpenAccountProducts({ onBack }: Props) {
  const [selected, setSelected] = useState<string | null>(null);

  if (selected) {
    const product = PRODUCTS.find(p => p.id === selected);
    return (
      <div style={{ minHeight: '100dvh', background: '#fff', fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", paddingBottom: 80 }}>
        <div style={{ background: NAVY, padding: '52px 16px 16px', display: 'flex', alignItems: 'center', gap: 16 }}>
          <button onClick={() => setSelected(null)} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
              <path d="M19 12H5M12 5l-7 7 7 7" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
          <span style={{ color: '#fff', fontSize: 17, fontWeight: 700, flex: 1, textAlign: 'center', marginRight: 40 }}>{product?.label}</span>
        </div>
        <div style={{ padding: '40px 24px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 24 }}>
          <div style={{ width: 90, height: 90, borderRadius: '50%', background: '#e8f0fb', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            {product?.icon}
          </div>
          <div style={{ fontSize: 22, fontWeight: 700, color: '#111', textAlign: 'center' }}>{product?.label}</div>
          <div style={{ fontSize: 16, color: '#555', lineHeight: 1.7, textAlign: 'center' }}>{product?.description}</div>
          <button style={{ width: '100%', padding: 16, background: BLUE, color: '#fff', border: 'none', borderRadius: 8, fontSize: 17, fontWeight: 700, cursor: 'pointer', marginTop: 16 }}>
            Apply now
          </button>
          <button style={{ width: '100%', padding: 14, background: '#fff', color: BLUE, border: `2px solid ${BLUE}`, borderRadius: 8, fontSize: 16, fontWeight: 600, cursor: 'pointer' }}>
            Learn more
          </button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ minHeight: '100dvh', background: '#f5f5f5', fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", paddingBottom: 80 }}>
      {/* HEADER */}
      <div style={{ background: NAVY, padding: '52px 16px 16px', display: 'flex', alignItems: 'center', gap: 16 }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path d="M19 12H5M12 5l-7 7 7 7" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
        <span style={{ color: '#fff', fontSize: 17, fontWeight: 700, flex: 1, textAlign: 'center', marginRight: 40 }}>
          Open an Account
        </span>
      </div>

      <div style={{ padding: '20px 16px' }}>
        <div style={{ fontSize: 22, fontWeight: 700, color: '#111', marginBottom: 6 }}>Explore all products</div>
        <div style={{ fontSize: 14, color: '#666', marginBottom: 20 }}>Choose a product to learn more and apply.</div>

        {/* Product grid */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          {PRODUCTS.map(product => (
            <button
              key={product.id}
              onClick={() => setSelected(product.id)}
              style={{
                background: '#fff', border: 'none', borderRadius: 16, padding: '20px 12px',
                cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10,
                boxShadow: '0 2px 10px rgba(0,0,0,0.07)', textAlign: 'center',
              }}
            >
              <div style={{ width: 72, height: 72, borderRadius: '50%', background: '#e8f0fb', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                {product.icon}
              </div>
              <span style={{ fontSize: 13, fontWeight: 600, color: BLUE, lineHeight: 1.3 }}>{product.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// Export the icon components for use in the dashboard widget
export const OPEN_ACCT_ITEMS = [
  { id: 'credit-cards', label: 'Credit cards', icon: CREDIT_CARD_ICON },
  { id: 'checking', label: 'Checking', icon: CHECKING_ICON },
  { id: 'savings', label: 'Savings', icon: SAVINGS_ICON },
  { id: 'business', label: 'Business', icon: BUSINESS_ICON },
];
