import SpendingPlanner from './plantrack/SpendingPlanner';

interface Props {
  onBack?: () => void;
}

export default function PlanTrack({ onBack }: Props) {
  return (
    <SpendingPlanner onBack={onBack ?? (() => {})} />
  );
}
