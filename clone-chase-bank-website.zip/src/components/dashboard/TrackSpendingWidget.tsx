const blue = '#2558b5';

interface Props {
  onManage: () => void;
}

export default function TrackSpendingWidget({ onManage }: Props) {
  return (
    <div style={{
      margin: '16px 16px 0',
      background: '#fff', borderRadius: 14,
      padding: 20, boxShadow: '0 2px 10px rgba(0,0,0,0.07)',
      display: 'flex', alignItems: 'center', gap: 16,
      fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
    }}>
      {/* Text */}
      <div style={{ flex: 1 }}>
        <div style={{ fontWeight: 700, fontSize: 17, color: '#111', marginBottom: 6 }}>
          Track your spending habits
        </div>
        <div style={{ fontSize: 14, color: '#666', lineHeight: 1.5, marginBottom: 14 }}>
          See where your money is going and budget so you can save more.
        </div>
        <button
          onClick={onManage}
          style={{
            background: '#fff', border: '1.5px solid #333',
            borderRadius: 999, padding: '9px 18px',
            fontSize: 13, fontWeight: 600, color: '#111', cursor: 'pointer',
          }}
        >
          Manage spending
        </button>
      </div>

      {/* Illustrated icon */}
      <div style={{ flexShrink: 0 }}>
        <svg width="68" height="68" viewBox="0 0 68 68" fill="none">
          {/* Outer blue circle */}
          <circle cx="34" cy="34" r="30" fill={blue} />
          {/* Dollar sign */}
          <text x="27" y="42" fontSize="26" fontWeight="700" fill="#fff" fontFamily="Helvetica, Arial, sans-serif">$</text>
          {/* Yellow ticket/coupon shapes */}
          <rect x="38" y="22" width="20" height="13" rx="3" fill="#f7d100" />
          <circle cx="38" cy="28.5" r="2.5" fill="#fff" />
          <line x1="42" y1="26" x2="56" y2="26" stroke="#fff" strokeWidth="1.5" strokeLinecap="round" />
          <line x1="42" y1="29" x2="56" y2="29" stroke="#fff" strokeWidth="1.5" strokeLinecap="round" />
          <line x1="42" y1="32" x2="52" y2="32" stroke="#fff" strokeWidth="1.5" strokeLinecap="round" />
          {/* Second ticket */}
          <rect x="40" y="37" width="18" height="12" rx="3" fill="#f7d100" opacity="0.85" />
          <circle cx="40" cy="43" r="2" fill="#fff" />
          <line x1="44" y1="41" x2="56" y2="41" stroke="#fff" strokeWidth="1.3" strokeLinecap="round" />
          <line x1="44" y1="44" x2="54" y2="44" stroke="#fff" strokeWidth="1.3" strokeLinecap="round" />
        </svg>
      </div>
    </div>
  );
}
