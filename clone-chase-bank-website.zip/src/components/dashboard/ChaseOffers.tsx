import { useState } from 'react';

const blue = '#2558b5';

type Category = 'all' | 'food' | 'gas' | 'groceries' | 'shopping' | 'travel';

interface Offer {
  id: string;
  merchant: string;
  cashback: string;
  spend?: string;
  badge?: string;
  badgeColor?: string;
  category: Category;
  added: boolean;
  bgColor: string;
  logoColor: string;
  logoInitials: string;
  expires: string;
}

const INITIAL_OFFERS: Offer[] = [
  {
    id: '1', merchant: "McDonald's", cashback: '10% cash back', spend: 'Spend $15 or more',
    badge: 'Flash deal', badgeColor: '#2a9d4e', category: 'food', added: false,
    bgColor: '#da0000', logoColor: '#ffbc0d', logoInitials: 'Mc', expires: 'Oct 12',
  },
  {
    id: '2', merchant: 'Target', cashback: '$5 cash back', spend: 'Spend $30 or more',
    badge: 'New', badgeColor: '#2a9d4e', category: 'shopping', added: true,
    bgColor: '#cc0000', logoColor: '#fff', logoInitials: 'T', expires: 'Oct 18',
  },
  {
    id: '3', merchant: 'Crepevine', cashback: '15% cash back', spend: 'Spend $20 or more',
    badge: '5d left', badgeColor: '#2a9d4e', category: 'food', added: false,
    bgColor: '#5c3317', logoColor: '#e8c070', logoInitials: 'CV', expires: 'Oct 10',
  },
  {
    id: '4', merchant: 'Farfetch', cashback: '$20 cash back', spend: 'Spend $100 or more',
    badge: 'New', badgeColor: '#2a9d4e', category: 'shopping', added: false,
    bgColor: '#111', logoColor: '#fff', logoInitials: 'FF', expires: 'Nov 01',
  },
  {
    id: '5', merchant: 'Shell', cashback: '5% cash back', spend: 'Any purchase',
    badge: 'Flash deal', badgeColor: '#2a9d4e', category: 'gas', added: false,
    bgColor: '#e8072e', logoColor: '#f7cf00', logoInitials: 'SH', expires: 'Oct 20',
  },
  {
    id: '6', merchant: 'Whole Foods', cashback: '8% cash back', spend: 'Spend $50 or more',
    badge: '3d left', badgeColor: '#2a9d4e', category: 'groceries', added: false,
    bgColor: '#00674b', logoColor: '#fff', logoInitials: 'WF', expires: 'Oct 08',
  },
  {
    id: '7', merchant: 'Corner Roastery', cashback: '10% cash back', spend: 'Spend $45 or more',
    badge: 'New', badgeColor: '#2a9d4e', category: 'food', added: true,
    bgColor: '#7a2020', logoColor: '#e8c8a0', logoInitials: 'CR', expires: 'Oct 16',
  },
  {
    id: '8', merchant: 'United Airlines', cashback: '$30 cash back', spend: 'Spend $200 or more',
    badge: 'New', badgeColor: '#2a9d4e', category: 'travel', added: false,
    bgColor: '#003580', logoColor: '#fff', logoInitials: 'UA', expires: 'Nov 15',
  },
];

interface AboutSheetProps {
  offer: Offer;
  onClose: () => void;
  onToggle: () => void;
}

function AboutSheet({ offer, onClose, onToggle }: AboutSheetProps) {
  return (
    <>
      {/* Dim overlay */}
      <div
        onClick={onClose}
        style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.45)', zIndex: 100,
        }}
      />
      {/* Sheet */}
      <div style={{
        position: 'fixed', bottom: 0, left: '50%', transform: 'translateX(-50%)',
        width: '100%', maxWidth: 430,
        background: '#fff', borderRadius: '16px 16px 0 0',
        zIndex: 101, padding: '0 0 40px',
        animation: 'slideUpSheet 0.3s ease-out',
      }}>
        {/* Drag handle */}
        <div style={{ display: 'flex', justifyContent: 'center', padding: '12px 0 8px' }}>
          <div style={{ width: 40, height: 4, borderRadius: 2, background: '#ddd' }} />
        </div>

        {/* Header */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          padding: '8px 16px 16px', position: 'relative',
          borderBottom: '1px solid #f0f0f0',
        }}>
          <span style={{ fontSize: 16, color: '#888' }}>About this deal</span>
          <button
            onClick={onClose}
            style={{
              position: 'absolute', right: 16, background: 'none', border: 'none',
              cursor: 'pointer', padding: 4,
            }}
          >
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
              <path d="M18 6L6 18M6 6l12 12" stroke="#888" strokeWidth="2" strokeLinecap="round" />
            </svg>
          </button>
        </div>

        {/* Merchant header */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '20px 20px 0' }}>
          <div style={{
            width: 56, height: 56, borderRadius: '50%',
            border: `2px solid ${offer.bgColor}`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            flexShrink: 0, background: offer.bgColor,
          }}>
            <span style={{ color: offer.logoColor, fontWeight: 800, fontSize: 16 }}>{offer.logoInitials}</span>
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 18, fontWeight: 700, color: '#111' }}>{offer.merchant}</div>
            <div style={{ marginTop: 6 }}>
              {offer.added ? (
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, color: '#2a9d4e', fontSize: 14, fontWeight: 600 }}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                    <path d="M20 6L9 17l-5-5" stroke="#2a9d4e" strokeWidth="2.5" strokeLinecap="round" />
                  </svg>
                  Added to card
                </div>
              ) : (
                <button
                  onClick={onToggle}
                  style={{
                    display: 'flex', alignItems: 'center', gap: 6,
                    background: 'none', border: 'none', cursor: 'pointer',
                    color: blue, fontSize: 14, fontWeight: 600, padding: 0,
                  }}
                >
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                    <circle cx="12" cy="12" r="9" stroke={blue} strokeWidth="1.8" />
                    <line x1="12" y1="8" x2="12" y2="16" stroke={blue} strokeWidth="1.8" strokeLinecap="round" />
                    <line x1="8" y1="12" x2="16" y2="12" stroke={blue} strokeWidth="1.8" strokeLinecap="round" />
                  </svg>
                  Add to card
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Cashback amount */}
        <div style={{ textAlign: 'center', padding: '24px 20px 8px' }}>
          <div style={{ fontSize: 30, fontWeight: 700, color: '#111' }}>{offer.cashback}</div>
          {offer.spend && (
            <div style={{ fontSize: 15, color: '#888', marginTop: 4 }}>{offer.spend}</div>
          )}
        </div>

        {/* 3 info columns */}
        <div style={{ display: 'flex', padding: '24px 16px', gap: 8 }}>
          {[
            {
              icon: (
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
                  <rect x="3" y="4" width="18" height="17" rx="2" stroke={blue} strokeWidth="1.6" />
                  <line x1="3" y1="9" x2="21" y2="9" stroke={blue} strokeWidth="1.6" />
                  <line x1="8" y1="2" x2="8" y2="6" stroke={blue} strokeWidth="1.6" strokeLinecap="round" />
                  <line x1="16" y1="2" x2="16" y2="6" stroke={blue} strokeWidth="1.6" strokeLinecap="round" />
                </svg>
              ),
              label: `Expires on ${offer.expires}`,
            },
            {
              icon: (
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
                  <rect x="2" y="5" width="20" height="14" rx="2" stroke={blue} strokeWidth="1.6" />
                  <line x1="2" y1="10" x2="22" y2="10" stroke={blue} strokeWidth="1.6" />
                  <line x1="6" y1="15" x2="10" y2="15" stroke={blue} strokeWidth="1.4" strokeLinecap="round" />
                </svg>
              ),
              label: 'Pay with CREDIT CARD (...1234)',
            },
            {
              icon: (
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
                  <circle cx="12" cy="12" r="9" stroke={blue} strokeWidth="1.6" />
                  <text x="12" y="16" textAnchor="middle" fontSize="11" fontWeight="800" fill={blue} fontFamily="Helvetica Neue, Arial, sans-serif">$</text>
                </svg>
              ),
              label: 'Cash back within 14 business days',
            },
          ].map((col, i) => (
            <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
              <div style={{
                width: 48, height: 48, borderRadius: '50%', background: '#e8f0fd',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                {col.icon}
              </div>
              <div style={{ fontSize: 11, color: '#555', textAlign: 'center', lineHeight: 1.4 }}>{col.label}</div>
            </div>
          ))}
        </div>
      </div>

      <style>{`
        @keyframes slideUpSheet {
          from { transform: translateX(-50%) translateY(100%); }
          to { transform: translateX(-50%) translateY(0); }
        }
      `}</style>
    </>
  );
}

const CREDIT_CARDS = [
  { name: 'CREDIT CARD', last4: '4421', label: 'Amazon Prime Visa' },
  { name: 'CREDIT CARD', last4: '9847', label: 'Chase Sapphire Reserve' },
];

export default function ChaseOffers({ onBack }: { onBack: () => void }) {
  const [activeCategory, setActiveCategory] = useState<Category>('all');
  const [offers, setOffers] = useState<Offer[]>(INITIAL_OFFERS);
  const [selectedOffer, setSelectedOffer] = useState<Offer | null>(null);
  const [selectedCard, setSelectedCard] = useState(CREDIT_CARDS[0]);
  const [showCardPicker, setShowCardPicker] = useState(false);

  const categories: { id: Category; label: string }[] = [
    { id: 'all', label: 'All' },
    { id: 'food', label: 'Food & drink' },
    { id: 'gas', label: 'Gas & auto' },
    { id: 'groceries', label: 'Groceries' },
    { id: 'shopping', label: 'Shopping' },
    { id: 'travel', label: 'Travel' },
  ];

  const filtered = activeCategory === 'all' ? offers : offers.filter(o => o.category === activeCategory);
  const totalSaved = 175.75;

  function toggleOffer(id: string) {
    setOffers(prev => prev.map(o => o.id === id ? { ...o, added: !o.added } : o));
    if (selectedOffer?.id === id) {
      setSelectedOffer(prev => prev ? { ...prev, added: !prev.added } : null);
    }
  }

  return (
    <div style={{
      width: '100%', height: '100%', display: 'flex', flexDirection: 'column',
      background: '#f0f4f8', fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
      overflow: 'hidden', position: 'relative',
    }}>
      {/* Header */}
      <div style={{
        background: '#f0f4f8', padding: '20px 16px 12px',
        display: 'flex', alignItems: 'center', gap: 12, flexShrink: 0,
      }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
            <path d="M15 18l-6-6 6-6" stroke="#555" strokeWidth="2" strokeLinecap="round" />
          </svg>
        </button>
        <span style={{ fontSize: 28, fontWeight: 700, color: '#111' }}>Chase Offers</span>
      </div>

      {/* Scrollable body */}
      <div style={{ flex: 1, overflowY: 'auto', paddingBottom: 80 }}>
        {/* Account selector */}
        <div style={{ padding: '0 16px 14px' }}>
          <div style={{ fontSize: 12, color: '#888', marginBottom: 6 }}>Choose account</div>
          <div
            onClick={() => setShowCardPicker(true)}
            style={{
              display: 'flex', alignItems: 'center', gap: 10,
              background: '#fff', border: '1px solid #ddd', borderRadius: 8, padding: '12px 14px',
              cursor: 'pointer',
            }}
          >
            <svg width="24" height="16" viewBox="0 0 36 22" fill="none">
              <rect width="36" height="22" rx="3" fill="#1a3a6b" />
              <rect x="0" y="7" width="36" height="5" fill="#c8a84b" />
            </svg>
            <span style={{ flex: 1, fontSize: 14, color: blue, fontWeight: 600 }}>
              {selectedCard.name} (...{selectedCard.last4})
            </span>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
              <path d="M6 9l6 6 6-6" stroke="#333" strokeWidth="2" strokeLinecap="round" />
            </svg>
          </div>
        </div>

        {/* Card picker bottom sheet */}
        {showCardPicker && (
          <>
            <div onClick={() => setShowCardPicker(false)} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', zIndex: 200 }} />
            <div style={{ position: 'fixed', bottom: 0, left: 0, right: 0, background: '#fff', borderRadius: '16px 16px 0 0', zIndex: 201, padding: '0 0 40px' }}>
              <div style={{ display: 'flex', justifyContent: 'center', padding: '12px 0 8px' }}>
                <div style={{ width: 40, height: 4, borderRadius: 2, background: '#ddd' }} />
              </div>
              <div style={{ textAlign: 'center', fontWeight: 700, fontSize: 17, color: '#111', paddingBottom: 16, borderBottom: '1px solid #eee' }}>Choose account</div>
              {CREDIT_CARDS.map(card => (
                <div
                  key={card.last4}
                  onClick={() => { setSelectedCard(card); setShowCardPicker(false); }}
                  style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '16px 20px', borderBottom: '1px solid #f0f0f0', cursor: 'pointer' }}
                >
                  <svg width="36" height="24" viewBox="0 0 36 22" fill="none">
                    <rect width="36" height="22" rx="3" fill="#1a3a6b" />
                    <rect x="0" y="7" width="36" height="5" fill="#c8a84b" />
                  </svg>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 600, fontSize: 15, color: '#111' }}>{card.name} (...{card.last4})</div>
                    <div style={{ fontSize: 13, color: '#888' }}>{card.label}</div>
                  </div>
                  {selectedCard.last4 === card.last4 && (
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                      <path d="M5 12l5 5L20 7" stroke={blue} strokeWidth="2.5" strokeLinecap="round" />
                    </svg>
                  )}
                </div>
              ))}
            </div>
          </>
        )}

        {/* Savings summary */}
        <div style={{ margin: '0 16px 16px' }}>
          <div style={{
            background: '#fff', borderRadius: 12, padding: '16px 16px',
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
          }}>
            <div>
              <div style={{ fontSize: 22, fontWeight: 700, color: '#111' }}>${totalSaved.toFixed(2)}</div>
              <div style={{ fontSize: 13, color: '#888', marginTop: 2 }}>Total amount saved</div>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button style={{
                width: 40, height: 40, border: `1px solid ${blue}`, borderRadius: 8,
                background: '#fff', cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                  <rect x="2" y="5" width="20" height="14" rx="2" stroke={blue} strokeWidth="1.6" />
                  <line x1="2" y1="10" x2="22" y2="10" stroke={blue} strokeWidth="1.6" />
                  <line x1="6" y1="15" x2="10" y2="15" stroke={blue} strokeWidth="1.4" strokeLinecap="round" />
                </svg>
              </button>
              <button style={{
                width: 40, height: 40, border: `1px solid ${blue}`, borderRadius: 8,
                background: '#fff', cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                  <circle cx="5" cy="12" r="1.5" fill={blue} />
                  <circle cx="12" cy="12" r="1.5" fill={blue} />
                  <circle cx="19" cy="12" r="1.5" fill={blue} />
                </svg>
              </button>
            </div>
          </div>
        </div>

        {/* Category filter tabs */}
        <div style={{
          display: 'flex', overflowX: 'auto', gap: 0,
          borderBottom: '1px solid #e0e0e0', background: '#fff',
          scrollbarWidth: 'none', flexShrink: 0,
        }}>
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              style={{
                flexShrink: 0, padding: '12px 16px', border: 'none', background: 'none',
                cursor: 'pointer', fontSize: 14, whiteSpace: 'nowrap',
                fontWeight: activeCategory === cat.id ? 700 : 400,
                color: activeCategory === cat.id ? blue : '#555',
                borderBottom: activeCategory === cat.id ? `3px solid ${blue}` : '3px solid transparent',
              }}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Offers grid */}
        <div style={{
          display: 'grid', gridTemplateColumns: '1fr 1fr',
          gap: 12, padding: 12,
        }}>
          {filtered.map(offer => (
            <div
              key={offer.id}
              onClick={() => setSelectedOffer(offer)}
              style={{
                background: '#fff', borderRadius: 12, overflow: 'hidden',
                boxShadow: '0 2px 8px rgba(0,0,0,0.08)', cursor: 'pointer',
              }}
            >
              {/* Card image area */}
              <div style={{
                height: 100, background: offer.bgColor,
                position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                {/* Logo circle */}
                <div style={{
                  position: 'absolute', bottom: -18, left: 12,
                  width: 40, height: 40, borderRadius: '50%',
                  background: offer.bgColor, border: '3px solid #fff',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  boxShadow: '0 2px 6px rgba(0,0,0,0.2)',
                }}>
                  <span style={{ color: offer.logoColor, fontWeight: 800, fontSize: 11 }}>{offer.logoInitials}</span>
                </div>
                {/* Badge */}
                {offer.badge && (
                  <div style={{
                    position: 'absolute', top: 8, right: 8,
                    background: offer.badgeColor, borderRadius: 999,
                    padding: '3px 8px', fontSize: 10, color: '#fff', fontWeight: 600,
                    display: 'flex', alignItems: 'center', gap: 3,
                  }}>
                    {offer.badge.includes('d left') && (
                      <svg width="10" height="10" viewBox="0 0 24 24" fill="none">
                        <circle cx="12" cy="12" r="9" stroke="#fff" strokeWidth="2" />
                        <path d="M12 7v5l3 3" stroke="#fff" strokeWidth="2" strokeLinecap="round" />
                      </svg>
                    )}
                    {offer.badge}
                  </div>
                )}
                {/* Large initials */}
                <span style={{ color: 'rgba(255,255,255,0.15)', fontSize: 48, fontWeight: 900, userSelect: 'none' }}>
                  {offer.logoInitials}
                </span>
              </div>

              {/* Card body */}
              <div style={{ padding: '24px 12px 12px' }}>
                <div style={{ fontSize: 11, color: '#888', marginBottom: 4 }}>{offer.merchant}</div>
                <div style={{ fontSize: 13, fontWeight: 700, color: '#111', marginBottom: 10 }}>{offer.cashback}</div>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  {offer.added ? (
                    <div style={{ display: 'flex', alignItems: 'center', gap: 4, color: '#2a9d4e', fontSize: 12, fontWeight: 600 }}>
                      <svg width="13" height="13" viewBox="0 0 24 24" fill="none">
                        <path d="M20 6L9 17l-5-5" stroke="#2a9d4e" strokeWidth="2.5" strokeLinecap="round" />
                      </svg>
                      Added
                    </div>
                  ) : (
                    <button
                      onClick={e => { e.stopPropagation(); toggleOffer(offer.id); }}
                      style={{
                        display: 'flex', alignItems: 'center', gap: 4,
                        background: 'none', border: 'none', cursor: 'pointer',
                        color: blue, fontSize: 12, fontWeight: 600, padding: 0,
                      }}
                    >
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
                        <circle cx="12" cy="12" r="9" stroke={blue} strokeWidth="1.8" />
                        <line x1="12" y1="8" x2="12" y2="16" stroke={blue} strokeWidth="1.8" strokeLinecap="round" />
                        <line x1="8" y1="12" x2="16" y2="12" stroke={blue} strokeWidth="1.8" strokeLinecap="round" />
                      </svg>
                      Add
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* About this deal sheet */}
      {selectedOffer && (
        <AboutSheet
          offer={selectedOffer}
          onClose={() => setSelectedOffer(null)}
          onToggle={() => toggleOffer(selectedOffer.id)}
        />
      )}
    </div>
  );
}
