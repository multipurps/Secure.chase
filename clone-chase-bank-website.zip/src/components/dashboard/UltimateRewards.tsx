import { useState } from 'react';

const blue = '#2558b5';

interface Props {
  onBack: () => void;
}

const CARDS = [
  { name: 'Chase Sapphire Reserve', last4: '4501', pts: 18500, pending: 240, since: 'Jan 2022', img: 'https://creditcards.chase.com/K-Marketplace/images/cardbucket/sapphirereserve/credit_card.png' },
  { name: 'Chase Sapphire Preferred', last4: '7823', pts: 10710, pending: 120, since: 'Mar 2021', img: 'https://creditcards.chase.com/K-Marketplace/images/cardbucket/sapphirepreferred/credit_card.png' },
];

const RECENT_ACTIVITY = [
  { merchant: 'UNITED AIRLINES', pts: 3200, amount: '$1,067.00', date: 'Jan 28', multiplier: '3' },
  { merchant: 'NOBU RESTAURANT', pts: 420, amount: '$140.00', date: 'Jan 25', multiplier: '3' },
  { merchant: 'AMAZON.COM', pts: 160, amount: '$160.00', date: 'Jan 22', multiplier: '1' },
  { merchant: 'MARRIOTT HOTELS', pts: 750, amount: '$250.00', date: 'Jan 18', multiplier: '3' },
  { merchant: 'STARBUCKS', pts: 45, amount: '$15.00', date: 'Jan 15', multiplier: '3' },
];

const FEATURED = [
  { category: 'Travel', desc: 'Book through Chase Travel℠', pts: '1.5x', color: '#1a3a6b' },
  { category: 'Cash back', desc: 'Redeem for statement credit', pts: '1¢/pt', color: '#2e7d32' },
  { category: 'Gift cards', desc: 'Over 150 brands available', pts: '1¢/pt', color: '#e65100' },
  { category: 'Amazon', desc: 'Shop with points at checkout', pts: '0.8¢/pt', color: '#ff9900' },
];

const REDEEM = [
  { label: 'Travel', icon: '✈' },
  { label: 'Cash back', icon: '$' },
  { label: 'Gift cards', icon: '🎁' },
  { label: 'Amazon', icon: 'A' },
  { label: 'Apple', icon: '' },
  { label: 'Experiences', icon: '★' },
];

export default function UltimateRewards({ onBack }: Props) {
  const [selectedCard, setSelectedCard] = useState(0);
  const [showCardSheet, setShowCardSheet] = useState(false);
  const [showBreakdown, setShowBreakdown] = useState(false);
  const [showHomeMenu, setShowHomeMenu] = useState(false);

  const card = CARDS[selectedCard];

  return (
    <div style={{
      width: '100%', minHeight: '100dvh', background: '#f0f4f8', overflowY: 'auto',
      paddingBottom: 80, fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
    }}>
      {/* HEADER */}
      <div style={{ background: '#fff', borderBottom: '1px solid #eee', padding: '52px 16px 12px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
          <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
            <polyline points="14,3 7,11 14,19" stroke="#555" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
        <span style={{ fontWeight: 700, fontSize: 17, color: '#111' }}>Ultimate Rewards®</span>
        <button onClick={() => setShowHomeMenu(!showHomeMenu)} style={{
          background: '#fff', border: `1.5px solid ${blue}`, borderRadius: 999,
          padding: '6px 14px', color: blue, fontWeight: 600, fontSize: 13, cursor: 'pointer',
          display: 'flex', alignItems: 'center', gap: 4,
        }}>
          Home ∨
        </button>
      </div>

      {/* HOME MENU DROPDOWN */}
      {showHomeMenu && (
        <div style={{ position: 'fixed', top: 100, right: 16, background: '#fff', borderRadius: 10, boxShadow: '0 4px 20px rgba(0,0,0,0.15)', zIndex: 200, overflow: 'hidden', minWidth: 200 }}>
          {['Earn points', 'Redeem points', 'Combine points', 'Transfer to partners', 'Travel portal'].map(item => (
            <button key={item} onClick={() => setShowHomeMenu(false)} style={{
              width: '100%', padding: '14px 18px', background: 'none', border: 'none',
              borderBottom: '1px solid #f0f0f0', textAlign: 'left', fontSize: 14, color: '#111', cursor: 'pointer',
            }}>{item}</button>
          ))}
        </div>
      )}

      {/* ACCOUNT SELECTOR */}
      <div style={{ margin: '16px 16px 0' }}>
        <button onClick={() => setShowCardSheet(true)} style={{
          width: '100%', background: '#fff', border: '1px solid #ddd', borderRadius: 10,
          padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 12, cursor: 'pointer',
        }}>
          <img src={card.img} alt={card.name} style={{ width: 48, height: 30, borderRadius: 4, objectFit: 'cover' }}
            onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }} />
          <span style={{ flex: 1, textAlign: 'left', fontSize: 14, color: '#111', fontWeight: 500 }}>
            {card.name.slice(0, 20)}...({card.last4})
          </span>
          <span style={{ color: '#2e7d32', fontWeight: 700, fontSize: 14 }}>{card.pts.toLocaleString()} pts</span>
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
            <polyline points="2,4 7,10 12,4" stroke="#555" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
      </div>

      {/* POINTS SUMMARY CARD */}
      <div style={{ margin: '12px 16px 0', background: '#fff', borderRadius: 12, padding: '18px 16px', boxShadow: '0 2px 8px rgba(0,0,0,0.06)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
          <img src={card.img} alt={card.name} style={{ width: 60, height: 38, borderRadius: 6, objectFit: 'cover' }}
            onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }} />
          <div>
            <div style={{ fontWeight: 700, fontSize: 14, color: '#111' }}>{card.name} (...{card.last4})</div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 0, borderTop: '1px solid #f0f0f0', paddingTop: 14 }}>
          <div style={{ flex: 1, paddingRight: 14, borderRight: '1px solid #e8e8e8' }}>
            <div style={{ fontWeight: 700, fontSize: 28, color: '#111' }}>{card.pts.toLocaleString()}</div>
            <div style={{ color: '#888', fontSize: 13, marginTop: 2 }}>Available points</div>
          </div>
          <div style={{ flex: 1, paddingLeft: 14 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <span style={{ fontWeight: 700, fontSize: 28, color: '#111' }}>{card.pending}</span>
              <button style={{ background: '#e8f0fb', border: 'none', borderRadius: '50%', width: 18, height: 18, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: blue, fontWeight: 700, fontSize: 11 }}>?</button>
            </div>
            <div style={{ color: '#888', fontSize: 13, marginTop: 2 }}>Pending points</div>
          </div>
        </div>
      </div>

      {/* EARNINGS CARD */}
      <div style={{ margin: '12px 16px 0', background: '#fff', borderRadius: 12, padding: '18px 16px', boxShadow: '0 2px 8px rgba(0,0,0,0.06)' }}>
        <div style={{ fontWeight: 700, fontSize: 16, color: '#111', marginBottom: 4 }}>Your earnings</div>
        <div style={{ fontWeight: 700, fontSize: 24, color: '#111', marginBottom: 2 }}>29,210 pts</div>
        <div style={{ color: '#888', fontSize: 13, marginBottom: 12 }}>Since account anniversary</div>

        <button onClick={() => setShowBreakdown(!showBreakdown)} style={{
          color: blue, fontSize: 14, background: 'none', border: 'none', cursor: 'pointer', fontWeight: 600, padding: 0,
        }}>
          See earnings breakdown {showBreakdown ? '∧' : '∨'}
        </button>

        {showBreakdown && (
          <div style={{ marginTop: 12, borderTop: '1px solid #f0f0f0', paddingTop: 12 }}>
            {[
              { cat: 'Travel', pts: 14200 },
              { cat: 'Dining', pts: 8160 },
              { cat: 'All other purchases', pts: 6850 },
            ].map(item => (
              <div key={item.cat} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: '1px solid #f8f8f8' }}>
                <span style={{ color: '#555', fontSize: 14 }}>{item.cat}</span>
                <span style={{ fontWeight: 600, color: '#111', fontSize: 14 }}>{item.pts.toLocaleString()} pts</span>
              </div>
            ))}
          </div>
        )}

        <div style={{ borderTop: '1px solid #f0f0f0', marginTop: 16, paddingTop: 16 }}>
          <div style={{ fontWeight: 700, fontSize: 16, color: '#111', marginBottom: 12 }}>Recent points activity</div>
          {RECENT_ACTIVITY.map((tx, i) => (
            <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', padding: '10px 0', borderBottom: '1px solid #f5f5f5' }}>
              <div>
                <div style={{ fontWeight: 700, fontSize: 13, color: '#111' }}>{tx.merchant}</div>
                <div style={{ color: '#888', fontSize: 12, marginTop: 2 }}>{tx.date} · {tx.multiplier}x earn</div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontWeight: 700, color: '#2e7d32', fontSize: 13 }}>+{tx.pts.toLocaleString()} pts</div>
                <div style={{ color: '#888', fontSize: 12 }}>{tx.amount}</div>
              </div>
            </div>
          ))}
          <button style={{ width: '100%', marginTop: 12, background: blue, color: '#fff', border: 'none', borderRadius: 8, padding: '14px 0', fontWeight: 700, fontSize: 15, cursor: 'pointer' }}>
            See rewards activity
          </button>
        </div>
      </div>

      {/* FEATURED REWARDS */}
      <div style={{ padding: '20px 16px 0' }}>
        <div style={{ fontWeight: 700, fontSize: 16, color: '#111', marginBottom: 12 }}>Featured rewards for you</div>
        <div style={{ display: 'flex', gap: 12, overflowX: 'auto', scrollbarWidth: 'none', paddingBottom: 4 }}>
          {FEATURED.map((f, i) => (
            <div key={i} style={{
              flexShrink: 0, width: 140, background: '#fff', borderRadius: 10, overflow: 'hidden',
              boxShadow: '0 2px 8px rgba(0,0,0,0.07)', cursor: 'pointer',
            }}>
              <div style={{ height: 70, background: f.color, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <span style={{ color: '#fff', fontSize: 28 }}>
                  {i === 0 ? '✈' : i === 1 ? '$' : i === 2 ? '🎁' : '🛍'}
                </span>
              </div>
              <div style={{ padding: '10px 10px 12px' }}>
                <div style={{ fontWeight: 700, fontSize: 13, color: '#111', marginBottom: 2 }}>{f.category}</div>
                <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>{f.desc}</div>
                <div style={{ color: blue, fontWeight: 700, fontSize: 13 }}>{f.pts}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* REDEEM OPTIONS */}
      <div style={{ margin: '20px 16px 0', background: '#fff', borderRadius: 12, padding: '18px 16px', boxShadow: '0 2px 8px rgba(0,0,0,0.06)' }}>
        <div style={{ fontWeight: 700, fontSize: 16, color: '#111', marginBottom: 16 }}>Redeem your points</div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
          {REDEEM.map((r, i) => (
            <button key={i} style={{
              background: '#f0f4f8', border: 'none', borderRadius: 10, padding: '14px 8px',
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, cursor: 'pointer',
            }}>
              <div style={{ width: 36, height: 36, background: '#e8f0fb', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, color: blue, fontWeight: 700 }}>
                {r.icon}
              </div>
              <span style={{ fontSize: 12, color: '#333', fontWeight: 600 }}>{r.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* CARD SELECTOR SHEET */}
      {showCardSheet && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.45)', zIndex: 500, display: 'flex', alignItems: 'flex-end' }} onClick={() => setShowCardSheet(false)}>
          <div style={{ background: '#fff', width: '100%', borderRadius: '16px 16px 0 0', padding: '20px 0 40px' }} onClick={e => e.stopPropagation()}>
            <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 20 }}>
              <div style={{ width: 40, height: 4, background: '#ccc', borderRadius: 2 }} />
            </div>
            <div style={{ fontWeight: 700, fontSize: 17, textAlign: 'center', marginBottom: 16, color: '#111' }}>Select a card</div>
            {CARDS.map((c, i) => (
              <button key={i} onClick={() => { setSelectedCard(i); setShowCardSheet(false); }} style={{
                width: '100%', padding: '14px 20px', background: 'none', border: 'none', borderBottom: '1px solid #f0f0f0',
                display: 'flex', alignItems: 'center', gap: 12, cursor: 'pointer', textAlign: 'left',
              }}>
                <img src={c.img} alt={c.name} style={{ width: 48, height: 30, borderRadius: 4, objectFit: 'cover' }}
                  onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600, fontSize: 14, color: '#111' }}>{c.name} (...{c.last4})</div>
                  <div style={{ color: '#2e7d32', fontSize: 13, fontWeight: 600 }}>{c.pts.toLocaleString()} pts available</div>
                </div>
                {selectedCard === i && (
                  <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                    <polyline points="3,9 7,13 15,5" stroke={blue} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                )}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
