import { useState, useEffect, useRef } from 'react';

const blue = '#2558b5';

interface Offer {
  id: string;
  merchant: string;
  cashback: string;
  badge?: string;
  badgeColor: string;
  added: boolean;
  bgColor: string;
  logoInitials: string;
  logoColor: string;
  logoUrl?: string;
}

const ALL_OFFERS: Offer[] = [
  // Food & drink (15)
  { id: 'f1', merchant: "McDonald's", cashback: '10% cash back', badge: 'Flash deal', badgeColor: '#2a9d4e', added: false, bgColor: '#da0000', logoInitials: 'Mc', logoColor: '#ffbc0d', logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/36/McDonald%27s_Golden_Arches.svg/200px-McDonald%27s_Golden_Arches.svg.png' },
  { id: 'f2', merchant: 'Starbucks', cashback: '15% cash back', badge: 'New', badgeColor: '#2a9d4e', added: false, bgColor: '#00704a', logoInitials: 'SB', logoColor: '#fff', logoUrl: 'https://upload.wikimedia.org/wikipedia/en/thumb/d/d3/Starbucks_Corporation_Logo_2011.svg/200px-Starbucks_Corporation_Logo_2011.svg.png' },
  { id: 'f3', merchant: 'Chick-fil-A', cashback: '10% cash back', badge: '5d left', badgeColor: '#2a9d4e', added: false, bgColor: '#e51837', logoInitials: 'CA', logoColor: '#fff' },
  { id: 'f4', merchant: 'Subway', cashback: '10% cash back', badge: 'New', badgeColor: '#2a9d4e', added: false, bgColor: '#008c15', logoInitials: 'SW', logoColor: '#ffcf00' },
  { id: 'f5', merchant: 'Chipotle', cashback: '15% cash back', badge: 'Flash deal', badgeColor: '#2a9d4e', added: false, bgColor: '#441d11', logoInitials: 'CH', logoColor: '#fff' },
  { id: 'f6', merchant: "Dunkin'", cashback: '10% cash back', badge: 'New', badgeColor: '#2a9d4e', added: false, bgColor: '#ff6319', logoInitials: "D'", logoColor: '#fff' },
  { id: 'f7', merchant: 'Panera Bread', cashback: '15% cash back', badge: 'Last day', badgeColor: '#e67e00', added: false, bgColor: '#44763e', logoInitials: 'PB', logoColor: '#fff' },
  { id: 'f8', merchant: "Domino's", cashback: '10% cash back', badge: 'New', badgeColor: '#2a9d4e', added: false, bgColor: '#006491', logoInitials: "DO", logoColor: '#fff' },
  { id: 'f9', merchant: 'Pizza Hut', cashback: '10% cash back', badge: '3d left', badgeColor: '#2a9d4e', added: false, bgColor: '#ee3124', logoInitials: 'PH', logoColor: '#fff' },
  { id: 'f10', merchant: 'Taco Bell', cashback: '10% cash back', badge: 'New', badgeColor: '#2a9d4e', added: false, bgColor: '#702082', logoInitials: 'TB', logoColor: '#fff' },
  { id: 'f11', merchant: "Wendy's", cashback: '10% cash back', badge: 'Flash deal', badgeColor: '#2a9d4e', added: false, bgColor: '#c8102e', logoInitials: "W'", logoColor: '#fff' },
  { id: 'f12', merchant: 'Olive Garden', cashback: '15% cash back', badge: 'New', badgeColor: '#2a9d4e', added: false, bgColor: '#5a3825', logoInitials: 'OG', logoColor: '#fff' },
  { id: 'f13', merchant: "Applebee's", cashback: '10% cash back', badge: '4d left', badgeColor: '#2a9d4e', added: false, bgColor: '#c00000', logoInitials: "AB", logoColor: '#fff' },
  { id: 'f14', merchant: 'IHOP', cashback: '10% cash back', badge: 'New', badgeColor: '#2a9d4e', added: false, bgColor: '#003087', logoInitials: 'IH', logoColor: '#fff' },
  { id: 'f15', merchant: 'La Madeleine', cashback: '15% cash back', badge: 'Flash deal', badgeColor: '#2a9d4e', added: false, bgColor: '#8b4513', logoInitials: 'LM', logoColor: '#fff' },
  // Gas & auto (8)
  { id: 'g1', merchant: 'Shell', cashback: '5% cash back', badge: 'Flash deal', badgeColor: '#2a9d4e', added: false, bgColor: '#e8072e', logoInitials: 'SH', logoColor: '#f7cf00' },
  { id: 'g2', merchant: 'BP', cashback: '5% cash back', badge: 'New', badgeColor: '#2a9d4e', added: false, bgColor: '#007a33', logoInitials: 'BP', logoColor: '#fff' },
  { id: 'g3', merchant: 'Chevron', cashback: '5% cash back', badge: '7d left', badgeColor: '#2a9d4e', added: false, bgColor: '#0a4fa6', logoInitials: 'CV', logoColor: '#fff' },
  { id: 'g4', merchant: 'ExxonMobil', cashback: '5% cash back', badge: 'New', badgeColor: '#2a9d4e', added: false, bgColor: '#cc0000', logoInitials: 'EM', logoColor: '#fff' },
  { id: 'g5', merchant: 'Valero', cashback: '5% cash back', badge: 'Flash deal', badgeColor: '#2a9d4e', added: false, bgColor: '#c00000', logoInitials: 'VL', logoColor: '#fff' },
  { id: 'g6', merchant: 'Jiffy Lube', cashback: '$20 cash back', badge: 'New', badgeColor: '#2a9d4e', added: false, bgColor: '#e30613', logoInitials: 'JL', logoColor: '#fff' },
  { id: 'g7', merchant: 'AutoZone', cashback: '10% cash back', badge: '5d left', badgeColor: '#2a9d4e', added: false, bgColor: '#e0100a', logoInitials: 'AZ', logoColor: '#fff' },
  { id: 'g8', merchant: 'Midas', cashback: '$15 cash back', badge: 'New', badgeColor: '#2a9d4e', added: false, bgColor: '#d4820a', logoInitials: 'MI', logoColor: '#fff' },
  // Groceries (8)
  { id: 'gr1', merchant: 'Whole Foods', cashback: '10% cash back', badge: 'New', badgeColor: '#2a9d4e', added: false, bgColor: '#00674b', logoInitials: 'WF', logoColor: '#fff' },
  { id: 'gr2', merchant: 'Kroger', cashback: '8% cash back', badge: 'Flash deal', badgeColor: '#2a9d4e', added: false, bgColor: '#003087', logoInitials: 'KR', logoColor: '#fff' },
  { id: 'gr3', merchant: 'Walmart Grocery', cashback: '5% cash back', badge: '3d left', badgeColor: '#2a9d4e', added: false, bgColor: '#0071ce', logoInitials: 'WG', logoColor: '#fff' },
  { id: 'gr4', merchant: 'Target Grocery', cashback: '10% cash back', badge: 'New', badgeColor: '#2a9d4e', added: false, bgColor: '#cc0000', logoInitials: 'TG', logoColor: '#fff' },
  { id: 'gr5', merchant: "Trader Joe's", cashback: '8% cash back', badge: 'Flash deal', badgeColor: '#2a9d4e', added: false, bgColor: '#b5181e', logoInitials: 'TJ', logoColor: '#fff' },
  { id: 'gr6', merchant: 'Instacart', cashback: '10% cash back', badge: 'New', badgeColor: '#2a9d4e', added: false, bgColor: '#43b02a', logoInitials: 'IC', logoColor: '#fff' },
  { id: 'gr7', merchant: 'Safeway', cashback: '8% cash back', badge: '6d left', badgeColor: '#2a9d4e', added: false, bgColor: '#cc0000', logoInitials: 'SF', logoColor: '#fff' },
  { id: 'gr8', merchant: 'Publix', cashback: '8% cash back', badge: 'New', badgeColor: '#2a9d4e', added: false, bgColor: '#006b3c', logoInitials: 'PX', logoColor: '#fff' },
  // Shopping (12)
  { id: 's1', merchant: 'Amazon', cashback: '5% cash back', badge: 'New', badgeColor: '#2a9d4e', added: false, bgColor: '#232f3e', logoInitials: 'AM', logoColor: '#ff9900', logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Amazon_logo.svg/200px-Amazon_logo.svg.png' },
  { id: 's2', merchant: 'Target', cashback: '15% cash back', badge: 'Flash deal', badgeColor: '#2a9d4e', added: true, bgColor: '#cc0000', logoInitials: 'T', logoColor: '#fff' },
  { id: 's3', merchant: 'Walmart', cashback: '5% cash back', badge: '4d left', badgeColor: '#2a9d4e', added: false, bgColor: '#0071ce', logoInitials: 'WM', logoColor: '#fff' },
  { id: 's4', merchant: 'Best Buy', cashback: '10% cash back', badge: 'New', badgeColor: '#2a9d4e', added: false, bgColor: '#003b8e', logoInitials: 'BB', logoColor: '#ffe000' },
  { id: 's5', merchant: 'Nike', cashback: '15% cash back', badge: 'Flash deal', badgeColor: '#2a9d4e', added: false, bgColor: '#111', logoInitials: 'NK', logoColor: '#fff' },
  { id: 's6', merchant: 'Adidas', cashback: '15% cash back', badge: 'New', badgeColor: '#2a9d4e', added: false, bgColor: '#000', logoInitials: 'AD', logoColor: '#fff' },
  { id: 's7', merchant: "Macy's", cashback: '15% cash back', badge: '5d left', badgeColor: '#2a9d4e', added: false, bgColor: '#e31837', logoInitials: 'MC', logoColor: '#fff' },
  { id: 's8', merchant: 'Gap', cashback: '20% cash back', badge: 'New', badgeColor: '#2a9d4e', added: false, bgColor: '#1c1c1c', logoInitials: 'GP', logoColor: '#fff' },
  { id: 's9', merchant: 'Old Navy', cashback: '20% cash back', badge: 'Flash deal', badgeColor: '#2a9d4e', added: false, bgColor: '#004990', logoInitials: 'ON', logoColor: '#fff' },
  { id: 's10', merchant: 'H&M', cashback: '15% cash back', badge: 'New', badgeColor: '#2a9d4e', added: false, bgColor: '#d0002a', logoInitials: 'HM', logoColor: '#fff' },
  { id: 's11', merchant: 'Farfetch', cashback: '$10 cash back', badge: '2d left', badgeColor: '#e67e00', added: false, bgColor: '#111', logoInitials: 'FF', logoColor: '#fff' },
  { id: 's12', merchant: 'Nordstrom', cashback: '10% cash back', badge: 'New', badgeColor: '#2a9d4e', added: false, bgColor: '#111', logoInitials: 'NO', logoColor: '#fff' },
  // Travel (8)
  { id: 't1', merchant: 'IHG Hotels', cashback: '15% cash back', badge: 'New', badgeColor: '#2a9d4e', added: false, bgColor: '#003087', logoInitials: 'IH', logoColor: '#fff' },
  { id: 't2', merchant: 'Marriott', cashback: '10% cash back', badge: 'Flash deal', badgeColor: '#2a9d4e', added: false, bgColor: '#8b0000', logoInitials: 'MA', logoColor: '#fff' },
  { id: 't3', merchant: 'Hilton', cashback: '10% cash back', badge: '4d left', badgeColor: '#2a9d4e', added: false, bgColor: '#003087', logoInitials: 'HI', logoColor: '#fff' },
  { id: 't4', merchant: 'Hyatt', cashback: '15% cash back', badge: 'New', badgeColor: '#2a9d4e', added: false, bgColor: '#6c3491', logoInitials: 'HY', logoColor: '#fff' },
  { id: 't5', merchant: 'United Airlines', cashback: '5% cash back', badge: 'Flash deal', badgeColor: '#2a9d4e', added: false, bgColor: '#002244', logoInitials: 'UA', logoColor: '#fff' },
  { id: 't6', merchant: 'Delta Airlines', cashback: '5% cash back', badge: 'New', badgeColor: '#2a9d4e', added: false, bgColor: '#c01933', logoInitials: 'DA', logoColor: '#fff' },
  { id: 't7', merchant: 'Hertz', cashback: '10% cash back', badge: '6d left', badgeColor: '#2a9d4e', added: false, bgColor: '#ffd700', logoInitials: 'HZ', logoColor: '#000' },
  { id: 't8', merchant: 'Enterprise', cashback: '10% cash back', badge: 'New', badgeColor: '#2a9d4e', added: false, bgColor: '#00843d', logoInitials: 'EN', logoColor: '#fff' },
  // Entertainment (5)
  { id: 'e1', merchant: 'AMC Theatres', cashback: '20% cash back', badge: 'Flash deal', badgeColor: '#2a9d4e', added: false, bgColor: '#c01933', logoInitials: 'AM', logoColor: '#fff' },
  { id: 'e2', merchant: 'Regal Cinemas', cashback: '20% cash back', badge: 'New', badgeColor: '#2a9d4e', added: false, bgColor: '#003087', logoInitials: 'RC', logoColor: '#fff' },
  { id: 'e3', merchant: 'Spotify', cashback: '$5 cash back', badge: '3d left', badgeColor: '#2a9d4e', added: false, bgColor: '#191414', logoInitials: 'SP', logoColor: '#1db954' },
  { id: 'e4', merchant: 'Hulu', cashback: '$5 cash back', badge: 'New', badgeColor: '#2a9d4e', added: false, bgColor: '#1ce783', logoInitials: 'HU', logoColor: '#000' },
  { id: 'e5', merchant: 'Penn Station Subs', cashback: '15% cash back', badge: 'Flash deal', badgeColor: '#2a9d4e', added: false, bgColor: '#c8102e', logoInitials: 'PS', logoColor: '#fff' },
  // Other (4)
  { id: 'o1', merchant: 'Crepevine', cashback: '20% cash back', badge: '5d left', badgeColor: '#2a9d4e', added: false, bgColor: '#5c3317', logoInitials: 'CV', logoColor: '#e8c070' },
  { id: 'o2', merchant: 'Corner Roastery', cashback: '10% cash back', badge: 'New', badgeColor: '#2a9d4e', added: true, bgColor: '#7a2020', logoInitials: 'CR', logoColor: '#e8c8a0' },
  { id: 'o3', merchant: 'Intercontinental', cashback: '15% cash back', badge: 'Flash deal', badgeColor: '#2a9d4e', added: false, bgColor: '#c8a400', logoInitials: 'IC', logoColor: '#fff' },
  { id: 'o4', merchant: 'CVS', cashback: '10% cash back', badge: 'New', badgeColor: '#2a9d4e', added: false, bgColor: '#cc0000', logoInitials: 'CV', logoColor: '#fff' },
];

interface Props {
  onSeeAll: () => void;
}

export default function DashboardOffersWidget({ onSeeAll }: Props) {
  const [offers, setOffers] = useState(ALL_OFFERS);
  const [modalOffer, setModalOffer] = useState<Offer | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    timerRef.current = setInterval(() => {
      if (scrollRef.current) {
        const el = scrollRef.current;
        el.scrollBy({ left: 172, behavior: 'smooth' });
        if (el.scrollLeft + el.clientWidth >= el.scrollWidth - 10) {
          el.scrollTo({ left: 0, behavior: 'smooth' });
        }
      }
    }, 2500);
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, []);

  function toggleAdded(id: string) {
    setOffers(prev => prev.map(o => o.id === id ? { ...o, added: !o.added } : o));
    setModalOffer(prev => prev?.id === id ? { ...prev!, added: !prev!.added } : prev);
  }

  return (
    <div style={{ padding: '20px 0 0', fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif" }}>
      {/* Header */}
      <div style={{ padding: '0 16px 10px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontWeight: 700, fontSize: 18, color: '#111' }}>Chase Offers</span>
            {/* Chase octagon mini */}
            <svg width="18" height="18" viewBox="0 0 32 32" fill={blue}>
              <polygon points="10,2 22,2 30,10 30,22 22,30 10,30 2,22 2,10" fill={blue} />
              <polygon points="10,2 22,2 30,10 30,22 22,30 10,30 2,22 2,10" fill="none" stroke={blue} strokeWidth="0" />
              <rect x="12" y="12" width="8" height="8" fill="#fff" />
            </svg>
          </div>
          <div style={{ fontSize: 13, color: '#888', marginTop: 2 }}>
            Add deals, shop and get cash back • CREDIT CARD (...1234)
          </div>
        </div>
        <button onClick={onSeeAll} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
          <svg width="9" height="16" viewBox="0 0 9 16" fill="none">
            <polyline points="1,1 8,8 1,15" stroke="#bbb" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
      </div>

      {/* Auto-scrolling offer cards */}
      <div
        ref={scrollRef}
        onMouseEnter={() => { if (timerRef.current) clearInterval(timerRef.current); }}
        onMouseLeave={() => {
          timerRef.current = setInterval(() => {
            if (scrollRef.current) {
              const el = scrollRef.current;
              el.scrollBy({ left: 172, behavior: 'smooth' });
              if (el.scrollLeft + el.clientWidth >= el.scrollWidth - 10) {
                el.scrollTo({ left: 0, behavior: 'smooth' });
              }
            }
          }, 2500);
        }}
        style={{
          display: 'flex', gap: 12, overflowX: 'auto', scrollbarWidth: 'none',
          padding: '0 16px 4px',
        }}
      >
        {offers.map(offer => (
          <div
            key={offer.id}
            onClick={() => setModalOffer(offer)}
            style={{
              flexShrink: 0, width: 160, background: '#fff',
              borderRadius: 12, overflow: 'hidden',
              boxShadow: '0 2px 10px rgba(0,0,0,0.09)',
              cursor: 'pointer',
            }}
          >
            {/* Image area */}
            <div style={{ position: 'relative', height: 90, background: offer.bgColor, overflow: 'hidden' }}>
              {offer.badge && (
                <div style={{
                  position: 'absolute', top: 8, right: 8,
                  background: offer.badgeColor, color: '#fff',
                  fontSize: 10, fontWeight: 700, borderRadius: 999,
                  padding: '3px 8px',
                }}>
                  {offer.badge}
                </div>
              )}
              {/* Logo circle overlapping */}
              <div style={{
                position: 'absolute', bottom: -18, left: 10,
                width: 36, height: 36, borderRadius: '50%',
                background: offer.logoColor === '#fff' ? offer.bgColor : '#fff',
                border: '2px solid #fff',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 11, fontWeight: 700, color: offer.logoColor,
                zIndex: 2,
                overflow: 'hidden',
              }}>
                {offer.logoUrl ? (
                  <img src={offer.logoUrl} alt={offer.merchant} style={{ width: '100%', height: '100%', objectFit: 'contain' }}
                    onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
                  />
                ) : offer.logoInitials}
              </div>
            </div>

            {/* Content */}
            <div style={{ padding: '22px 10px 12px' }}>
              <div style={{ fontSize: 11, color: '#888', marginBottom: 2 }}>{offer.merchant}</div>
              <div style={{ fontSize: 13, fontWeight: 700, color: '#111', marginBottom: 8 }}>{offer.cashback}</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                {offer.added ? (
                  <>
                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                      <circle cx="7" cy="7" r="7" fill="#2a9d4e" />
                      <polyline points="3,7 6,10 11,4" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                    <span style={{ fontSize: 11, color: '#2a9d4e', fontWeight: 600 }}>Added</span>
                  </>
                ) : (
                  <>
                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                      <circle cx="7" cy="7" r="6.5" stroke={blue} strokeWidth="1.5" fill="none" />
                      <line x1="7" y1="3.5" x2="7" y2="10.5" stroke={blue} strokeWidth="1.8" strokeLinecap="round" />
                      <line x1="3.5" y1="7" x2="10.5" y2="7" stroke={blue} strokeWidth="1.8" strokeLinecap="round" />
                    </svg>
                    <span style={{ fontSize: 11, color: blue, fontWeight: 600 }}>Add offer</span>
                  </>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* See all button */}
      <div style={{ padding: '14px 16px 0', textAlign: 'center' }}>
        <button
          onClick={onSeeAll}
          style={{
            background: '#fff', border: `1.5px solid #ddd`,
            borderRadius: 999, padding: '10px 24px',
            color: blue, fontSize: 14, fontWeight: 600, cursor: 'pointer',
          }}
        >
          See all available deals
        </button>
      </div>

      {/* About this deal modal */}
      {modalOffer && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 9999, display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
          <div onClick={() => setModalOffer(null)} style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.45)' }} />
          <div style={{
            position: 'relative', background: '#fff',
            borderRadius: '16px 16px 0 0',
            padding: '20px 20px 40px',
            animation: 'slideUp 0.3s ease',
          }}>
            <style>{`@keyframes slideUp { from { transform: translateY(100%); } to { transform: translateY(0); } }`}</style>
            {/* Header */}
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', marginBottom: 20, position: 'relative' }}>
              <span style={{ fontSize: 16, color: '#888', fontWeight: 600 }}>About this deal</span>
              <button onClick={() => setModalOffer(null)} style={{ position: 'absolute', right: 0, background: 'none', border: 'none', fontSize: 22, color: '#999', cursor: 'pointer' }}>×</button>
            </div>

            {/* Merchant info */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 20 }}>
              <div style={{
                width: 56, height: 56, borderRadius: '50%',
                background: modalOffer.bgColor,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 16, fontWeight: 700, color: modalOffer.logoColor, flexShrink: 0,
                overflow: 'hidden',
              }}>
                {modalOffer.logoUrl ? (
                  <img src={modalOffer.logoUrl} alt="" style={{ width: '80%', height: '80%', objectFit: 'contain' }}
                    onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
                  />
                ) : modalOffer.logoInitials}
              </div>
              <div>
                <div style={{ fontWeight: 700, fontSize: 18, color: '#111' }}>{modalOffer.merchant}</div>
                <button
                  onClick={() => toggleAdded(modalOffer.id)}
                  style={{
                    marginTop: 6,
                    background: modalOffer.added ? '#fff' : blue,
                    border: `1.5px solid ${modalOffer.added ? '#2a9d4e' : blue}`,
                    borderRadius: 8, padding: '6px 14px',
                    color: modalOffer.added ? '#2a9d4e' : '#fff',
                    fontSize: 13, fontWeight: 600, cursor: 'pointer',
                    display: 'flex', alignItems: 'center', gap: 6,
                  }}
                >
                  {modalOffer.added ? (
                    <>
                      <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                        <circle cx="7" cy="7" r="7" fill="#2a9d4e" />
                        <polyline points="3,7 6,10 11,4" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                      Added to card
                    </>
                  ) : '+ Add to card'}
                </button>
              </div>
            </div>

            {/* Cashback headline */}
            <div style={{ textAlign: 'center', fontSize: 28, fontWeight: 700, color: '#111', marginBottom: 4 }}>{modalOffer.cashback}</div>
            <div style={{ textAlign: 'center', fontSize: 14, color: '#888', marginBottom: 20 }}>Spend $45 or more</div>

            {/* 3 info columns */}
            <div style={{ display: 'flex', justifyContent: 'space-evenly', gap: 12 }}>
              {[
                { icon: <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><rect x="3" y="4" width="18" height="18" rx="2" stroke={blue} strokeWidth="1.7" fill="none" /><line x1="3" y1="9" x2="21" y2="9" stroke={blue} strokeWidth="1.5" /><line x1="8" y1="2" x2="8" y2="6" stroke={blue} strokeWidth="1.7" strokeLinecap="round" /><line x1="16" y1="2" x2="16" y2="6" stroke={blue} strokeWidth="1.7" strokeLinecap="round" /></svg>, label: 'Expires on Oct 16' },
                { icon: <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><rect x="2" y="5" width="20" height="14" rx="2" stroke={blue} strokeWidth="1.7" fill="none" /><rect x="2" y="9" width="20" height="3" fill={blue} /></svg>, label: 'Pay with CREDIT CARD (...1234)' },
                { icon: <svg width="22" height="22" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9" stroke={blue} strokeWidth="1.7" fill="none" /><line x1="12" y1="7" x2="12" y2="12" stroke={blue} strokeWidth="1.7" strokeLinecap="round" /><path d="M12 12l3 2" stroke={blue} strokeWidth="1.7" strokeLinecap="round" /></svg>, label: 'Cash back within 14 business days' },
              ].map((col, i) => (
                <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
                  <div style={{
                    width: 48, height: 48, borderRadius: '50%', background: '#e8f0fb',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>{col.icon}</div>
                  <span style={{ fontSize: 11, color: '#444', textAlign: 'center', lineHeight: 1.4 }}>{col.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
