import { useEffect, useRef } from 'react';

interface Props {
  onClose: () => void;
}

export default function DepositLimitsSheet({ onClose }: Props) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const t = setTimeout(() => {
      if (ref.current) ref.current.style.transform = 'translateY(0)';
    }, 10);
    return () => clearTimeout(t);
  }, []);

  function dismiss() {
    if (ref.current) ref.current.style.transform = 'translateY(100%)';
    setTimeout(onClose, 320);
  }

  return (
    <div
      onClick={dismiss}
      style={{
        position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.45)', zIndex: 999,
        display: 'flex', alignItems: 'flex-end',
      }}
    >
      <div
        ref={ref}
        onClick={e => e.stopPropagation()}
        style={{
          width: '100%', background: '#fff', borderRadius: '16px 16px 0 0',
          transform: 'translateY(100%)', transition: 'transform 0.3s ease',
          paddingBottom: 36, fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
        }}
      >
        {/* Handle */}
        <div style={{ display: 'flex', justifyContent: 'center', padding: '12px 0 0' }}>
          <div style={{ width: 40, height: 4, borderRadius: 2, background: '#ccc' }} />
        </div>

        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '16px 20px 12px', position: 'relative' }}>
          <span style={{ fontSize: 17, fontWeight: 700, color: '#111' }}>Mobile deposit limits</span>
          <button onClick={dismiss} style={{ position: 'absolute', right: 20, background: 'none', border: 'none', cursor: 'pointer', fontSize: 22, color: '#888', lineHeight: 1 }}>&times;</button>
        </div>
        <div style={{ borderTop: '1px solid #eee' }} />

        {/* Row 1 — Daily limit */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '20px 20px 16px' }}>
          <div>
            <div style={{ fontSize: 15, fontWeight: 700, color: '#111' }}>Remaining daily limit</div>
            <div style={{ fontSize: 13, color: '#888', marginTop: 3 }}>Daily limit: $7,500.00</div>
          </div>
          <div style={{ fontSize: 15, fontWeight: 700, color: '#111' }}>$7,025.00</div>
        </div>
        <div style={{ borderTop: '1px solid #eee', margin: '0 20px' }} />

        {/* Row 2 — 30-day limit */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '16px 20px' }}>
          <div>
            <div style={{ fontSize: 15, fontWeight: 700, color: '#111' }}>Remaining 30-day limit</div>
            <div style={{ fontSize: 13, color: '#888', marginTop: 3 }}>30-day limit: $15,000.00</div>
          </div>
          <div style={{ fontSize: 15, fontWeight: 700, color: '#111' }}>$13,730.00</div>
        </div>

        {/* Footer text */}
        <div style={{ textAlign: 'center', padding: '0 20px', fontSize: 12, color: '#999', lineHeight: 1.7 }}>
          <div>These limits may vary. See your terms for details.</div>
          <div>To make deposits for more than your limit, visit a Chase branch or ATM.</div>
        </div>
      </div>
    </div>
  );
}
