import { useState } from 'react';
import { supabase } from '../../../../lib/supabase';

const blue = '#2558b5';
const navy = '#1a3a6b';

const ACCOUNT_TYPES = ['Checking', 'Savings', 'Money Market'];

function UnderlineInput({ label, value, onChange, placeholder = '', type = 'text', inputMode, masked, note }: {
  label: string; value: string; onChange: (v: string) => void;
  placeholder?: string; type?: string; inputMode?: 'numeric' | 'text';
  masked?: boolean; note?: string;
}) {
  const [show, setShow] = useState(false);
  return (
    <div style={{ marginBottom: 24 }}>
      <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>{label}</div>
      <div style={{ display: 'flex', alignItems: 'center', borderBottom: '1.5px solid #ddd', paddingBottom: 6 }}>
        <input
          type={masked && !show ? 'password' : type}
          inputMode={inputMode}
          placeholder={placeholder}
          value={value}
          onChange={e => onChange(e.target.value)}
          style={{ flex: 1, border: 'none', outline: 'none', fontSize: 16, color: '#111', background: 'transparent', padding: 0 }}
        />
        {masked && (
          <button onClick={() => setShow(s => !s)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: blue, fontSize: 13, fontWeight: 600, flexShrink: 0 }}>
            {show ? 'Hide' : 'Show'}
          </button>
        )}
      </div>
      {note && <div style={{ fontSize: 12, color: '#aaa', marginTop: 4 }}>{note}</div>}
    </div>
  );
}

interface Props {
  onBack: () => void;
  onCancel: () => void;
  onSaved: () => void;
}

export default function AddRecipientDomestic({ onBack, onCancel, onSaved }: Props) {
  const [name, setName] = useState('');
  const [routing, setRouting] = useState('');
  const [account, setAccount] = useState('');
  const [confirmAccount, setConfirmAccount] = useState('');
  const [accountType, setAccountType] = useState('');
  const [group, setGroup] = useState('');
  const [nickname, setNickname] = useState('');
  const [showAccountType, setShowAccountType] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const canSave = name.trim() && routing.trim().length === 9 && account.trim() && account === confirmAccount && accountType;

  async function handleSave() {
    if (!canSave) return;
    setSaving(true);
    setError('');
    try {
      const { data: { user } } = await supabase.auth.getUser();
      const { error: err } = await supabase.from('wire_recipients').insert([{
        user_id: user?.id ?? null,
        name: name.toUpperCase(),
        routing_number: routing,
        account_last4: account.slice(-4),
        account_type: accountType,
        group_name: group || 'MY DOMESTIC GROUP',
        nickname: nickname || null,
        wire_type: 'domestic',
      }]);
      if (err) {
        // If table doesn't exist yet, still call onSaved for UI flow
        console.warn('Wire recipient save:', err.message);
      }
      onSaved();
    } catch {
      setError('Failed to save recipient. Please try again.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", background: '#fff', overflow: 'hidden' }}>
      {/* Header */}
      <div style={{ background: navy, padding: '16px', flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4, display: 'flex', alignItems: 'center', gap: 4 }}>
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
              <polyline points="12,3 6,9 12,15" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
          <span style={{ color: '#fff', fontWeight: 600, fontSize: 17 }}>Add recipient</span>
          <button onClick={onCancel} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#fff', fontSize: 15, fontWeight: 500 }}>Cancel</button>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '24px 20px', paddingBottom: 100 }}>
        <UnderlineInput label="Recipient name" value={name} onChange={setName} placeholder="Full legal name" />
        <UnderlineInput label="Bank routing number (ABA)" value={routing} onChange={setRouting} placeholder="9 digits" inputMode="numeric" note={routing.length > 0 && routing.length !== 9 ? 'Must be exactly 9 digits' : ''} />
        <UnderlineInput label="Account number" value={account} onChange={setAccount} placeholder="Account number" inputMode="numeric" masked />
        <UnderlineInput label="Confirm account number" value={confirmAccount} onChange={setConfirmAccount} placeholder="Re-enter account number" inputMode="numeric" masked note={confirmAccount && account !== confirmAccount ? 'Account numbers do not match' : ''} />

        {/* Account type */}
        <div style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Account type</div>
          <button
            onClick={() => setShowAccountType(true)}
            style={{ width: '100%', background: 'none', border: 'none', borderBottom: '1.5px solid #ddd', padding: '6px 0', textAlign: 'left', cursor: 'pointer', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}
          >
            <span style={{ fontSize: 16, color: accountType ? '#111' : '#bbb' }}>{accountType || 'Select account type'}</span>
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
              <polyline points="2,4 6,8 10,4" stroke="#999" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
        </div>

        <UnderlineInput label="Recipient group (optional)" value={group} onChange={setGroup} placeholder="e.g. My Domestic Group" />
        <UnderlineInput label="Nickname (optional)" value={nickname} onChange={setNickname} />

        {error && <div style={{ color: '#c00', fontSize: 13, marginBottom: 16 }}>{error}</div>}
      </div>

      <div style={{ padding: '16px 20px', borderTop: '1px solid #eee', background: '#fff', flexShrink: 0 }}>
        <button
          onClick={handleSave}
          disabled={!canSave || saving}
          style={{ width: '100%', background: canSave && !saving ? blue : '#a8c8f0', color: '#fff', border: 'none', borderRadius: 8, padding: '16px', fontSize: 16, fontWeight: 600, cursor: canSave && !saving ? 'pointer' : 'not-allowed' }}
        >
          {saving ? 'Saving...' : 'Save recipient'}
        </button>
      </div>

      {/* Account Type Bottom Sheet */}
      {showAccountType && (
        <>
          <div onClick={() => setShowAccountType(false)} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', zIndex: 200 }} />
          <div style={{ position: 'fixed', bottom: 0, left: 0, right: 0, background: '#fff', borderRadius: '16px 16px 0 0', zIndex: 201, paddingBottom: 40 }}>
            <div style={{ width: 40, height: 4, background: '#ddd', borderRadius: 2, margin: '12px auto 16px' }} />
            <p style={{ textAlign: 'center', fontWeight: 700, fontSize: 17, color: '#111', margin: '0 0 8px' }}>Account type</p>
            {ACCOUNT_TYPES.map((t, i) => (
              <div key={t}>
                <button
                  onClick={() => { setAccountType(t); setShowAccountType(false); }}
                  style={{ width: '100%', background: 'none', border: 'none', cursor: 'pointer', padding: '18px 24px', textAlign: 'center', fontSize: 20, fontWeight: accountType === t ? 700 : 400, color: accountType === t ? '#111' : '#666' }}
                >
                  {t}
                </button>
                {i < ACCOUNT_TYPES.length - 1 && <div style={{ borderTop: '1px solid #f0f0f0', margin: '0 24px' }} />}
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
