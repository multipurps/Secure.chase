export interface WireRecipient {
  id: string;
  name: string;
  accountLast4: string;
  routingNumber: string;
  accountType: string;
  group: string;
  nickname?: string;
  type: 'domestic' | 'international';
  country?: string;
  currency?: string;
  bankName?: string;
}

export interface WireTransferData {
  recipientId: string;
  recipientName: string;
  recipientLast4: string;
  fromAccount: string;
  fromLast4: string;
  amount: string;
  currency: string;
  foreignAmount?: string;
  foreignCurrency?: string;
  wireDate: Date;
  memo: string;
  msgToRecipientBank: string;
  msgToRecipient: string;
  paymentCode?: string;
  countryServicesProvided?: string;
  type: 'domestic' | 'international';
  fee: number;
  transactionNumber?: string;
}

export const DEMO_ACCOUNTS = [
  { id: 'chk1', name: 'CHASE CHECKING', last4: '3545', balance: '$900.00' },
  { id: 'sav1', name: 'CHASE SAVINGS', last4: '3546', balance: '$5,250.00' },
  { id: 'biz1', name: 'CHASE BUSINESS CHECKING', last4: '1212', balance: '$12,400.00' },
  { id: 'chk2', name: 'HIGH SCHOOL CHECKING', last4: '8721', balance: '$2,122.73' },
];
