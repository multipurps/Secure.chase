import { useState } from 'react';
import { supabase } from '../../../../lib/supabase';

const blue = '#2558b5';
const navy = '#1a3a6b';

const COUNTRIES = [
  { code: 'AU', name: 'Australia', flag: '🇦🇺', currency: 'AUD' },
  { code: 'BR', name: 'Brazil', flag: '🇧🇷', currency: 'BRL' },
  { code: 'CA', name: 'Canada', flag: '🇨🇦', currency: 'CAD' },
  { code: 'CN', name: 'China', flag: '🇨🇳', currency: 'CNY' },
  { code: 'DE', name: 'Germany', flag: '🇩🇪', currency: 'EUR' },
  { code: 'FR', name: 'France', flag: '🇫🇷', currency: 'EUR' },
  { code: 'GB', name: 'United Kingdom', flag: '🇬🇧', currency: 'GBP' },
  { code: 'IN', name: 'India', flag: '🇮🇳', currency: 'INR' },
  { code: 'IT', name: 'Italy', flag: '🇮🇹', currency: 'EUR' },
  { code: 'JP', name: 'Japan', flag: '🇯🇵', currency: 'JPY' },
  { code: 'KR', name: 'South Korea', flag: '🇰🇷', currency: 'KRW' },
  { code: 'MX', name: 'Mexico', flag: '🇲🇽', currency: 'MXN' },
  { code: 'NG', name: 'Nigeria', flag: '🇳🇬', currency: 'NGN' },
  { code: 'PH', name: 'Philippines', flag: '🇵🇭', currency: 'PHP' },
  { code: 'SG', name: 'Singapore', flag: '🇸🇬', currency: 'SGD' },
  { code: 'ZA', name: 'South Africa', flag: '🇿🇦', currency: 'ZAR' },
];

interface Props { onBack: () => void; onCancel: () => void; onSaved: () => void; }

export default function AddRecipientInternational({ onBack, onCancel, onSaved }: Props) {
  const [name, setName] = useState('');
  const [country, setCountry] = useState('');
  const [countrySearch, setCountrySearch] = useState('');
  const [iban, setIban] = useState('');
  const [swift, setSwift] = useState('');
  const [bankName, setBankName] = useState('');
  const [group, setGroup] = useState('');
  const [nickname, setNickname] = useState('');
  const [showCountry, setShowCountry] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const selectedCountry = COUNTRIES.find(c => c.code === country);
  const filteredCountries = COUNTRIES.filter(c => c.name.toLowerCase().includes(countrySearch.toLowerCase()));
  const canSave = name.trim() && country && (iban.trim() || swift.trim());

  async function handleSave() {
    if (!canSave) return;
    setSaving(true);
    setError('');
    try {
      const { data: { user } } = await supabase.auth.getUser();
      const { error: err } = await supabase.from('wire_recipients').insert([{
        user_id: user?.id ?? null,
        name: name.toUpperCase(),
        account_last4: iban.slice(-4) || '0000',
        swift_bic: swift,
        bank_name: bankName || null,
        group_name: group || 'MY INTERNATIONAL GROUP',
        nickname: nickname || null,
        wire_type: 'international',
        country: selectedCountry?.name,
        currency: selectedCountry?.currency,
      }]);
      if (err) {
        console.warn('Wire intl recipient save:', err.message);
      }
      onSaved();
    } catch {
      setError('Failed to save recipient. Please try again.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", background: '#fff', overflow: 'hidden' }}>
      <div style={{ background: navy, padding: '16px', flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
              <polyline points="12,3 6,9 12,15" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
          <span style={{ color: '#fff', fontWeight: 600, fontSize: 17 }}>Add recipient</span>
          <button onClick={onCancel} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#fff', fontSize: 15 }}>Cancel</button>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '24px 20px', paddingBottom: 100 }}>
        {/* Recipient Name */}
        <div style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Recipient name</div>
          <input value={name} onChange={e => setName(e.target.value)} placeholder="Full legal name"
            style={{ width: '100%', border: 'none', borderBottom: '1.5px solid #ddd', outline: 'none', fontSize: 16, color: '#111', padding: '6px 0', background: 'transparent', boxSizing: 'border-box' }} />
        </div>

        {/* Country */}
        <div style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Country</div>
          <button onClick={() => setShowCountry(true)} style={{ width: '100%', background: 'none', border: 'none', borderBottom: '1.5px solid #ddd', padding: '6px 0', textAlign: 'left', cursor: 'pointer', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontSize: 16, color: selectedCountry ? '#111' : '#bbb' }}>
              {selectedCountry ? `${selectedCountry.flag} ${selectedCountry.name}` : 'Select country'}
            </span>
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><polyline points="2,4 6,8 10,4" stroke="#999" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg>
          </button>
        </div>

        {/* IBAN */}
        <div style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>IBAN / Account number</div>
          <input value={iban} onChange={e => setIban(e.target.value)} placeholder="IBAN or account number"
            style={{ width: '100%', border: 'none', borderBottom: '1.5px solid #ddd', outline: 'none', fontSize: 16, color: '#111', padding: '6px 0', background: 'transparent', boxSizing: 'border-box' }} />
        </div>

        {/* SWIFT */}
        <div style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>SWIFT / BIC code</div>
          <input value={swift} onChange={e => setSwift(e.target.value)} placeholder="e.g. CHASUS33"
            style={{ width: '100%', border: 'none', borderBottom: '1.5px solid #ddd', outline: 'none', fontSize: 16, color: '#111', padding: '6px 0', background: 'transparent', boxSizing: 'border-box' }} />
        </div>

        {/* Bank Name */}
        <div style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Recipient bank name (optional)</div>
          <input value={bankName} onChange={e => setBankName(e.target.value)} placeholder="Bank name"
            style={{ width: '100%', border: 'none', borderBottom: '1.5px solid #ddd', outline: 'none', fontSize: 16, color: '#111', padding: '6px 0', background: 'transparent', boxSizing: 'border-box' }} />
        </div>

        <div style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Recipient group (optional)</div>
          <input value={group} onChange={e => setGroup(e.target.value)} placeholder="e.g. My International Group"
            style={{ width: '100%', border: 'none', borderBottom: '1.5px solid #ddd', outline: 'none', fontSize: 16, color: '#111', padding: '6px 0', background: 'transparent', boxSizing: 'border-box' }} />
        </div>

        <div style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Nickname (optional)</div>
          <input value={nickname} onChange={e => setNickname(e.target.value)} placeholder="Nickname"
            style={{ width: '100%', border: 'none', borderBottom: '1.5px solid #ddd', outline: 'none', fontSize: 16, color: '#111', padding: '6px 0', background: 'transparent', boxSizing: 'border-box' }} />
        </div>

        {error && <div style={{ color: '#c00', fontSize: 13, marginBottom: 16 }}>{error}</div>}
      </div>

      <div style={{ padding: '16px 20px', borderTop: '1px solid #eee', background: '#fff', flexShrink: 0 }}>
        <button onClick={handleSave} disabled={!canSave || saving}
          style={{ width: '100%', background: canSave && !saving ? blue : '#a8c8f0', color: '#fff', border: 'none', borderRadius: 8, padding: '16px', fontSize: 16, fontWeight: 600, cursor: canSave && !saving ? 'pointer' : 'not-allowed' }}>
          {saving ? 'Saving...' : 'Save recipient'}
        </button>
      </div>

      {/* Country Picker Sheet */}
      {showCountry && (
        <>
          <div onClick={() => setShowCountry(false)} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', zIndex: 200 }} />
          <div style={{ position: 'fixed', bottom: 0, left: 0, right: 0, background: '#fff', borderRadius: '16px 16px 0 0', zIndex: 201, maxHeight: '75%', display: 'flex', flexDirection: 'column' }}>
            <div style={{ width: 40, height: 4, background: '#ddd', borderRadius: 2, margin: '12px auto 8px' }} />
            <div style={{ padding: '0 16px 8px' }}>
              <input value={countrySearch} onChange={e => setCountrySearch(e.target.value)} placeholder="Search country..."
                style={{ width: '100%', border: 'none', borderBottom: '1.5px solid #ddd', outline: 'none', fontSize: 15, padding: '8px 0', background: 'transparent', boxSizing: 'border-box' }} />
            </div>
            <div style={{ overflowY: 'auto', flex: 1, paddingBottom: 32 }}>
              {filteredCountries.map((c, i) => (
                <div key={c.code}>
                  <button onClick={() => { setCountry(c.code); setShowCountry(false); setCountrySearch(''); }}
                    style={{ width: '100%', background: 'none', border: 'none', cursor: 'pointer', padding: '14px 20px', textAlign: 'left', fontSize: 16, color: '#111', display: 'flex', alignItems: 'center', gap: 12, fontWeight: country === c.code ? 700 : 400 }}>
                    <span style={{ fontSize: 22 }}>{c.flag}</span>
                    <span>{c.name}</span>
                    <span style={{ marginLeft: 'auto', color: '#888', fontSize: 13 }}>{c.currency}</span>
                  </button>
                  {i < filteredCountries.length - 1 && <div style={{ borderTop: '1px solid #f5f5f5', margin: '0 16px' }} />}
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
