import { useState, useEffect, useCallback } from 'react';
import { DEMO_ACCOUNTS } from './wireTypes';

const blue = '#2558b5';
const navy = '#1a3a6b';

const COUNTRIES = [
  { code: 'IN', name: 'India', flag: '🇮🇳', currency: 'INR' },
  { code: 'GB', name: 'United Kingdom', flag: '🇬🇧', currency: 'GBP' },
  { code: 'CA', name: 'Canada', flag: '🇨🇦', currency: 'CAD' },
  { code: 'MX', name: 'Mexico', flag: '🇲🇽', currency: 'MXN' },
  { code: 'EU', name: 'European Union', flag: '🇪🇺', currency: 'EUR' },
  { code: 'AU', name: 'Australia', flag: '🇦🇺', currency: 'AUD' },
  { code: 'JP', name: 'Japan', flag: '🇯🇵', currency: 'JPY' },
  { code: 'CN', name: 'China', flag: '🇨🇳', currency: 'CNY' },
  { code: 'BR', name: 'Brazil', flag: '🇧🇷', currency: 'BRL' },
  { code: 'PH', name: 'Philippines', flag: '🇵🇭', currency: 'PHP' },
  { code: 'NG', name: 'Nigeria', flag: '🇳🇬', currency: 'NGN' },
  { code: 'GH', name: 'Ghana', flag: '🇬🇭', currency: 'GHS' },
  { code: 'KR', name: 'South Korea', flag: '🇰🇷', currency: 'KRW' },
  { code: 'SG', name: 'Singapore', flag: '🇸🇬', currency: 'SGD' },
  { code: 'ZA', name: 'South Africa', flag: '🇿🇦', currency: 'ZAR' },
  { code: 'DE', name: 'Germany', flag: '🇩🇪', currency: 'EUR' },
  { code: 'FR', name: 'France', flag: '🇫🇷', currency: 'EUR' },
  { code: 'IT', name: 'Italy', flag: '🇮🇹', currency: 'EUR' },
  { code: 'PK', name: 'Pakistan', flag: '🇵🇰', currency: 'PKR' },
  { code: 'BD', name: 'Bangladesh', flag: '🇧🇩', currency: 'BDT' },
];

interface Props {
  onBack: () => void;
  onSendMoney: (params: { country: typeof COUNTRIES[0]; usdAmount: string; foreignAmount: string; rate: number; fromAccount: typeof DEMO_ACCOUNTS[0] }) => void;
}

export default function FxCalculator({ onBack, onSendMoney }: Props) {
  const [recipientType, setRecipientType] = useState<'individual' | 'business'>('individual');
  const [fromAccount, setFromAccount] = useState(DEMO_ACCOUNTS[2]);
  const [showFromSheet, setShowFromSheet] = useState(false);
  const [country, setCountry] = useState(COUNTRIES[0]);
  const [showCountrySheet, setShowCountrySheet] = useState(false);
  const [countrySearch, setCountrySearch] = useState('');
  const [usdAmount, setUsdAmount] = useState('');
  const [foreignAmount, setForeignAmount] = useState('');
  const [rate, setRate] = useState<number | null>(null);
  const [rateLoading, setRateLoading] = useState(false);
  const [lastEdited, setLastEdited] = useState<'usd' | 'foreign'>('usd');
  const [minutesLeft, setMinutesLeft] = useState(30);

  const [rateUpdatedAt, setRateUpdatedAt] = useState<string>('');

  const fetchRate = useCallback(async (currencyCode: string) => {
    setRateLoading(true);
    try {
      // Try open.er-api.com first (free, no key)
      const res = await fetch(`https://open.er-api.com/v6/latest/USD`);
      const json = await res.json();
      const r = json.rates?.[currencyCode];
      if (r) {
        setRate(r);
        setMinutesLeft(30);
        setRateUpdatedAt(new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }));
        return;
      }
    } catch { /* fall through */ }
    try {
      // Fallback to frankfurter
      const res2 = await fetch(`https://api.frankfurter.app/latest?from=USD&to=${currencyCode}`);
      const json2 = await res2.json();
      const r2 = json2.rates?.[currencyCode];
      if (r2) {
        setRate(r2);
        setMinutesLeft(30);
        setRateUpdatedAt(new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }));
        return;
      }
    } catch { /* fall through */ }
    // Static fallback rates
    const fallbacks: Record<string, number> = { INR: 83.5, GBP: 0.79, CAD: 1.37, MXN: 17.2, EUR: 0.92, AUD: 1.53, JPY: 149.8, CNY: 7.24, BRL: 4.97, PHP: 56.5, NGN: 1550, GHS: 15.2, KRW: 1320, SGD: 1.34, ZAR: 18.6, PKR: 278, BDT: 110 };
    setRate(fallbacks[currencyCode] || 1.0);
    setRateUpdatedAt('(cached)');
    setRateLoading(false);
  }, []);

  useEffect(() => { fetchRate(country.currency); }, [country.currency, fetchRate]);

  // Countdown timer
  useEffect(() => {
    const interval = setInterval(() => {
      setMinutesLeft(m => {
        if (m <= 1) { fetchRate(country.currency); return 30; }
        return m - 1;
      });
    }, 60000);
    return () => clearInterval(interval);
  }, [country.currency, fetchRate]);

  // Bidirectional calc
  useEffect(() => {
    if (!rate) return;
    if (lastEdited === 'usd') {
      const usd = parseFloat(usdAmount) || 0;
      setForeignAmount(usd > 0 ? (usd * rate).toFixed(2) : '');
    } else {
      const foreign = parseFloat(foreignAmount) || 0;
      setUsdAmount(foreign > 0 ? (foreign / rate).toFixed(2) : '');
    }
  }, [usdAmount, foreignAmount, rate, lastEdited]);

  const usdNum = parseFloat(usdAmount) || 0;
  const fee = usdNum >= 5000 ? 0 : 5;
  const total = usdNum + fee;
  const canSend = usdNum > 0 && usdNum <= 5000;

  const filteredCountries = COUNTRIES.filter(c => c.name.toLowerCase().includes(countrySearch.toLowerCase()) || c.currency.toLowerCase().includes(countrySearch.toLowerCase()));

  return (
    <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", background: '#fff', overflow: 'hidden' }}>
      {/* Header */}
      <div style={{ background: navy, padding: '16px', flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
          <button onClick={onBack} style={{ position: 'absolute', left: 0, background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
              <polyline points="12,3 6,9 12,15" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
          <span style={{ color: '#fff', fontWeight: 600, fontSize: 17 }}>Send money</span>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', paddingBottom: 100 }}>
        {/* FX banner */}
        <div style={{ background: '#fff', padding: '16px', borderBottom: '1px solid #f0f0f0' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
            <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
              <line x1="2" y1="7" x2="13" y2="7" stroke={blue} strokeWidth="1.5" strokeLinecap="round" />
              <line x1="2" y1="11" x2="13" y2="11" stroke={blue} strokeWidth="1.5" strokeLinecap="round" />
              <line x1="2" y1="15" x2="8" y2="15" stroke={blue} strokeWidth="1.5" strokeLinecap="round" />
              <circle cx="17" cy="14" r="4.5" stroke={blue} strokeWidth="1.4" fill="none" />
              <text x="17" y="17" textAnchor="middle" fontSize="6" fontWeight="800" fill={blue} fontFamily="Helvetica Neue, Arial, sans-serif">$</text>
            </svg>
            <span style={{ color: blue, fontWeight: 600, fontSize: 15 }}>Use our foreign exchange calculator</span>
            <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
              <polyline points="2,2 8,5 2,8" stroke="#555" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
          <p style={{ margin: 0, fontSize: 13, color: '#666', lineHeight: 1.5 }}>If you're sending money internationally, you can explore country and currency options and get a rate.</p>
        </div>

        <div style={{ padding: '16px 20px' }}>
          {/* Recipient type */}
          <div style={{ fontSize: 13, color: '#666', textAlign: 'center', marginBottom: 12 }}>I'm sending to a:</div>
          <div style={{ display: 'flex', gap: 0, marginBottom: 20, borderRadius: 8, overflow: 'hidden', border: `1px solid ${blue}` }}>
            {(['individual', 'business'] as const).map(type => (
              <button
                key={type}
                onClick={() => setRecipientType(type)}
                style={{ flex: 1, padding: '10px 0', background: recipientType === type ? blue : '#fff', color: recipientType === type ? '#fff' : '#666', border: 'none', cursor: 'pointer', fontSize: 14, fontWeight: recipientType === type ? 700 : 400, textTransform: 'capitalize' }}
              >
                {type}
              </button>
            ))}
          </div>

          {/* Pay from */}
          <div style={{ marginBottom: 20 }}>
            <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Pay from</div>
            <button onClick={() => setShowFromSheet(true)} style={{ width: '100%', background: 'none', border: 'none', borderBottom: '1.5px solid #ddd', padding: '6px 0', textAlign: 'left', cursor: 'pointer', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: 16, fontWeight: 700, color: '#111' }}>{fromAccount.name} (...{fromAccount.last4})</span>
              <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><polyline points="2,4 6,8 10,4" stroke="#999" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg>
            </button>
          </div>

          {/* Send to country */}
          <div style={{ marginBottom: 20 }}>
            <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Send to country</div>
            <button onClick={() => setShowCountrySheet(true)} style={{ width: '100%', background: 'none', border: 'none', borderBottom: '1.5px solid #ddd', padding: '6px 0', textAlign: 'left', cursor: 'pointer', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: 16, fontWeight: 700, color: '#111' }}>{country.flag} {country.name}</span>
              <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><polyline points="2,4 6,8 10,4" stroke="#999" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg>
            </button>
          </div>

          {/* You send */}
          <div style={{ marginBottom: 8 }}>
            <div style={{ fontSize: 16, fontWeight: 700, color: '#111', marginBottom: 6 }}>You send</div>
            <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Equivalent dollar amount (Transfer amount)</div>
            <div style={{ display: 'flex', alignItems: 'center', borderBottom: '1.5px solid #ddd', paddingBottom: 6 }}>
              <input
                type="text"
                inputMode="decimal"
                placeholder="0"
                value={usdAmount}
                onChange={e => { setLastEdited('usd'); setUsdAmount(e.target.value); }}
                style={{ flex: 1, border: 'none', outline: 'none', fontSize: 28, fontWeight: 700, color: '#111', background: 'transparent', padding: 0 }}
              />
              <span style={{ fontSize: 16, marginLeft: 8 }}>USD 🇺🇸</span>
            </div>
          </div>
          <div style={{ fontSize: 12, color: '#888', marginBottom: 20 }}>Your daily limit is $5,000.00</div>

          {/* They receive */}
          <div style={{ marginBottom: 8 }}>
            <div style={{ fontSize: 16, fontWeight: 700, color: '#111', marginBottom: 6 }}>They receive</div>
            <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Wire amount</div>
            <div style={{ display: 'flex', alignItems: 'center', borderBottom: '1.5px solid #ddd', paddingBottom: 6 }}>
              <input
                type="text"
                inputMode="decimal"
                placeholder="0"
                value={foreignAmount}
                onChange={e => { setLastEdited('foreign'); setForeignAmount(e.target.value); }}
                style={{ flex: 1, border: 'none', outline: 'none', fontSize: 28, fontWeight: 700, color: '#111', background: 'transparent', padding: 0 }}
              />
              <span style={{ fontSize: 16, marginLeft: 8 }}>{country.currency} {country.flag}</span>
            </div>
          </div>
          <div style={{ marginBottom: 20 }} />

          {/* Live exchange rate */}
          <div style={{ textAlign: 'center', marginBottom: 16 }}>
            {rateLoading ? (
              <span style={{ fontSize: 13, color: '#888' }}>Fetching live rate...</span>
            ) : rate ? (
              <>
                <div style={{ fontSize: 14, fontWeight: 700, color: '#111' }}>
                  JPMC rate $1.00 USD = {rate.toFixed(4)} {country.currency}
                  <span style={{ fontSize: 11, color: '#888', marginLeft: 4 }}>ⓘ</span>
                </div>
                <div style={{ fontSize: 12, color: '#888', marginTop: 4 }}>
                  &#128336; Expires in {minutesLeft} min
                  {rateUpdatedAt ? ` · Last updated: ${rateUpdatedAt}` : ''}
                </div>
              </>
            ) : null}
          </div>

          {/* Wire fee */}
          <div style={{ borderTop: '1px solid #f0f0f0', paddingTop: 16 }}>
            {[
              { label: 'Wire fee', value: fee === 0 ? 'No fee' : `$${fee.toFixed(2)} USD` },
              { label: 'Total debited:', value: `$${total.toFixed(2)} USD`, bold: true },
            ].map(row => (
              <div key={row.label} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
                <span style={{ fontSize: 14, color: '#555', textDecoration: row.label === 'Wire fee' ? 'underline dotted' : 'none' }}>{row.label}</span>
                <span style={{ fontSize: 14, fontWeight: row.bold ? 700 : 500, color: '#111' }}>{row.value}</span>
              </div>
            ))}
            <p style={{ fontSize: 12, color: '#888', marginTop: 8 }}>
              Tip: There is no Chase wire fee when you send a wire of $5,000 USD or more in foreign currency.
            </p>
          </div>
        </div>
      </div>

      {/* Send money button */}
      <div style={{ padding: '16px 20px', borderTop: '1px solid #eee', background: '#fff', flexShrink: 0 }}>
        <button
          onClick={() => {
            if (canSend && rate) {
              onSendMoney({ country, usdAmount, foreignAmount, rate, fromAccount });
            }
          }}
          disabled={!canSend}
          style={{ width: '100%', background: canSend ? blue : '#a8c8f0', color: '#fff', border: 'none', borderRadius: 8, padding: '16px', fontSize: 16, fontWeight: 600, cursor: canSend ? 'pointer' : 'not-allowed' }}
        >
          Send money
        </button>
      </div>

      {/* From Account Sheet */}
      {showFromSheet && (
        <>
          <div onClick={() => setShowFromSheet(false)} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', zIndex: 200 }} />
          <div style={{ position: 'fixed', bottom: 0, left: 0, right: 0, background: '#fff', borderRadius: '16px 16px 0 0', zIndex: 201, paddingBottom: 40 }}>
            <div style={{ width: 40, height: 4, background: '#ddd', borderRadius: 2, margin: '12px auto 8px' }} />
            <p style={{ textAlign: 'center', fontWeight: 700, fontSize: 17, padding: '0 0 8px' }}>Pay from</p>
            <div style={{ background: '#f5f5f5', padding: '6px 16px', fontSize: 11, color: '#888', letterSpacing: 1 }}>INTERNAL ACCOUNT</div>
            {DEMO_ACCOUNTS.map((acct, i) => (
              <div key={acct.id}>
                <button onClick={() => { setFromAccount(acct); setShowFromSheet(false); }}
                  style={{ width: '100%', background: 'none', border: 'none', cursor: 'pointer', padding: '16px 20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', textAlign: 'left' }}>
                  <div>
                    <div style={{ fontSize: 15, fontWeight: 600, color: '#111' }}>{acct.name} (...{acct.last4})</div>
                    <div style={{ fontSize: 13, color: '#888', marginTop: 2 }}>{acct.balance}</div>
                  </div>
                  {fromAccount.id === acct.id && (
                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                      <polyline points="3,9 7,13 15,5" stroke={blue} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  )}
                </button>
                {i < DEMO_ACCOUNTS.length - 1 && <div style={{ borderTop: '1px solid #f0f0f0', margin: '0 16px' }} />}
              </div>
            ))}
          </div>
        </>
      )}

      {/* Country Sheet */}
      {showCountrySheet && (
        <>
          <div onClick={() => setShowCountrySheet(false)} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', zIndex: 200 }} />
          <div style={{ position: 'fixed', bottom: 0, left: 0, right: 0, background: '#fff', borderRadius: '16px 16px 0 0', zIndex: 201, maxHeight: '75%', display: 'flex', flexDirection: 'column' }}>
            <div style={{ width: 40, height: 4, background: '#ddd', borderRadius: 2, margin: '12px auto 8px' }} />
            <div style={{ padding: '0 16px 8px' }}>
              <input value={countrySearch} onChange={e => setCountrySearch(e.target.value)} placeholder="Search country or currency..."
                style={{ width: '100%', border: 'none', borderBottom: '1.5px solid #ddd', outline: 'none', fontSize: 15, padding: '8px 0', background: 'transparent', boxSizing: 'border-box' }} />
            </div>
            <div style={{ overflowY: 'auto', flex: 1, paddingBottom: 32 }}>
              {filteredCountries.map((c, i) => (
                <div key={c.code + c.currency}>
                  <button onClick={() => { setCountry(c); setShowCountrySheet(false); setCountrySearch(''); }}
                    style={{ width: '100%', background: 'none', border: 'none', cursor: 'pointer', padding: '14px 20px', textAlign: 'left', display: 'flex', alignItems: 'center', gap: 12, fontWeight: country.code === c.code && country.currency === c.currency ? 700 : 400 }}>
                    <span style={{ fontSize: 22 }}>{c.flag}</span>
                    <span style={{ fontSize: 16, color: '#111' }}>{c.name}</span>
                    <span style={{ marginLeft: 'auto', color: '#888', fontSize: 13 }}>{c.currency}</span>
                  </button>
                  {i < filteredCountries.length - 1 && <div style={{ borderTop: '1px solid #f5f5f5', margin: '0 16px' }} />}
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
