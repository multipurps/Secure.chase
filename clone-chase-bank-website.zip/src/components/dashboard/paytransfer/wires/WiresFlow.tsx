import { useState } from 'react';
import { WireRecipient, WireTransferData } from './wireTypes';
import WireMain from './WireMain';
import AddRecipientDomestic from './AddRecipientDomestic';
import AddRecipientInternational from './AddRecipientInternational';
import DomesticWireForm from './DomesticWireForm';
import InternationalWireForm from './InternationalWireForm';
import VerifySender from './VerifySender';
import WireConfirmation from './WireConfirmation';
import FxCalculator from './FxCalculator';
import ChooseIntlRecipient from './ChooseIntlRecipient';
import { DEMO_ACCOUNTS } from './wireTypes';
import { supabase } from '../../../../lib/supabase';

type Screen =
  | 'main'
  | 'add-domestic'
  | 'add-international'
  | 'domestic-form'
  | 'fx-calc'
  | 'intl-recipients'
  | 'intl-form'
  | 'verify'
  | 'confirmation';

interface IntlParams {
  country: { code: string; name: string; flag: string; currency: string };
  usdAmount: string;
  foreignAmount: string;
  rate: number;
  fromAccount: typeof DEMO_ACCOUNTS[0];
}

interface Props {
  onBack: () => void;
}

export default function WiresFlow({ onBack }: Props) {
  const [screen, setScreen] = useState<Screen>('main');
  const [selectedRecipient, setSelectedRecipient] = useState<WireRecipient | null>(null);
  const [wireData, setWireData] = useState<WireTransferData | null>(null);
  const [intlParams, setIntlParams] = useState<IntlParams | null>(null);
  const [scheduling, setScheduling] = useState(false);
  const [confirmedData, setConfirmedData] = useState<WireTransferData | null>(null);

  async function handleScheduleWire() {
    if (!wireData) return;
    setScheduling(true);
    try {
      const txnNum = String(Math.floor(1000000000 + Math.random() * 9000000000));
      await supabase.from('wire_transfers').insert([{
        recipient_name: wireData.recipientName,
        recipient_last4: wireData.recipientLast4,
        from_account: wireData.fromAccount,
        from_last4: wireData.fromLast4,
        amount: wireData.amount,
        currency: wireData.currency,
        foreign_amount: wireData.foreignAmount || null,
        foreign_currency: wireData.foreignCurrency || null,
        wire_date: wireData.wireDate,
        memo: wireData.memo,
        msg_to_recipient_bank: wireData.msgToRecipientBank,
        msg_to_recipient: wireData.msgToRecipient,
        payment_code: wireData.paymentCode || null,
        type: wireData.type,
        fee: wireData.fee,
        transaction_number: txnNum,
        status: 'pending',
      }]);
      setConfirmedData({ ...wireData, transactionNumber: txnNum });
      setScreen('confirmation');
    } catch (err) {
      console.error('Wire save error:', err);
      // Still show confirmation even if DB fails
      const txnNum = String(Math.floor(1000000000 + Math.random() * 9000000000));
      setConfirmedData({ ...wireData, transactionNumber: txnNum });
      setScreen('confirmation');
    } finally {
      setScheduling(false);
    }
  }

  // Screen routing
  if (screen === 'add-domestic') {
    return <AddRecipientDomestic
      onBack={() => setScreen('main')}
      onCancel={() => setScreen('main')}
      onSaved={() => setScreen('main')}
    />;
  }

  if (screen === 'add-international') {
    return <AddRecipientInternational
      onBack={() => setScreen('main')}
      onCancel={() => setScreen('main')}
      onSaved={() => setScreen('main')}
    />;
  }

  if (screen === 'domestic-form' && selectedRecipient) {
    return <DomesticWireForm
      recipient={selectedRecipient}
      onBack={() => setScreen('main')}
      onCancel={() => setScreen('main')}
      onNext={(data) => { setWireData(data); setScreen('verify'); }}
    />;
  }

  if (screen === 'fx-calc') {
    return <FxCalculator
      onBack={() => setScreen('main')}
      onSendMoney={(params) => {
        setIntlParams(params);
        setScreen('intl-recipients');
      }}
    />;
  }

  if (screen === 'intl-recipients' && intlParams) {
    return <ChooseIntlRecipient
      intlParams={intlParams}
      onBack={() => setScreen('fx-calc')}
      onSelectRecipient={(r) => { setSelectedRecipient(r); setScreen('intl-form'); }}
      onAddRecipient={() => setScreen('add-international')}
    />;
  }

  if (screen === 'intl-form' && selectedRecipient && intlParams) {
    return <InternationalWireForm
      recipient={selectedRecipient}
      intlParams={intlParams}
      onBack={() => setScreen('intl-recipients')}
      onCancel={() => setScreen('main')}
      onNext={(data) => { setWireData(data); setScreen('verify'); }}
    />;
  }

  if (screen === 'verify' && wireData) {
    return <VerifySender
      data={wireData}
      onBack={() => setScreen(wireData.type === 'domestic' ? 'domestic-form' : 'intl-form')}
      onCancel={() => setScreen('main')}
      onSchedule={handleScheduleWire}
      scheduling={scheduling}
    />;
  }

  if (screen === 'confirmation' && confirmedData) {
    return <WireConfirmation
      data={confirmedData}
      onClose={onBack}
      onScheduleAnother={() => {
        setSelectedRecipient(null);
        setWireData(null);
        setIntlParams(null);
        setConfirmedData(null);
        setScreen('main');
      }}
    />;
  }

  // Main screen: handle recipient selection by type
  function handleSelectRecipient(r: WireRecipient) {
    setSelectedRecipient(r);
    if (r.type === 'domestic') {
      setScreen('domestic-form');
    } else {
      // For international without FX calc, go to FX first
      setScreen('fx-calc');
    }
  }

  return (
    <WireMain
      onBack={onBack}
      onSelectRecipient={handleSelectRecipient}
      onAddDomestic={() => setScreen('add-domestic')}
      onAddInternational={() => setScreen('add-international')}
      onFxCalc={() => setScreen('fx-calc')}
    />
  );
}
