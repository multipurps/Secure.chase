import { WireTransferData } from './wireTypes';

const blue = '#2558b5';
const navy = '#1a3a6b';

interface Props {
  data: WireTransferData;
  onBack: () => void;
  onCancel: () => void;
  onSchedule: () => void;
  scheduling: boolean;
}

function Row({ label, value, valueBold }: { label: string; value: string; valueBold?: boolean }) {
  return (
    <div style={{ paddingBottom: 16, marginBottom: 0 }}>
      <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>{label}</div>
      <div style={{ fontSize: 15, fontWeight: valueBold ? 700 : 600, color: '#111' }}>{value}</div>
    </div>
  );
}

function SectionHeader({ label }: { label: string }) {
  return (
    <div style={{ marginTop: 24, marginBottom: 12 }}>
      <div style={{ fontSize: 11, color: '#888', letterSpacing: 1.2, textTransform: 'uppercase', marginBottom: 8 }}>{label}</div>
      <div style={{ borderTop: '1px solid #e8e8e8' }} />
    </div>
  );
}

function InfoText({ children }: { children: React.ReactNode }) {
  return <p style={{ fontSize: 13, color: '#666', lineHeight: 1.7, margin: '0 0 12px' }}>{children}</p>;
}

export default function VerifySender({ data, onBack, onCancel, onSchedule, scheduling }: Props) {
  const wireDate = data.wireDate instanceof Date ? data.wireDate : new Date(data.wireDate);
  const formattedDate = wireDate.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
  const total = (parseFloat(data.amount) + data.fee).toFixed(2);
  const isIntl = data.type === 'international';

  return (
    <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", background: '#fff', overflow: 'hidden' }}>
      {/* Header */}
      <div style={{ background: navy, padding: '16px', flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
              <polyline points="12,3 6,9 12,15" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
          <span style={{ color: '#fff', fontWeight: 600, fontSize: 17 }}>Verify Sender</span>
          <button onClick={onCancel} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#fff', fontSize: 15 }}>Cancel</button>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '20px', paddingBottom: 120 }}>
        <div style={{ fontSize: 20, fontWeight: 700, color: '#111', marginBottom: 20 }}>Does everything look OK?</div>

        <SectionHeader label="Account details" />
        <Row label="Wire to" value={`${data.recipientName} (...${data.recipientLast4})`} />
        <div style={{ borderTop: '1px solid #f0f0f0', margin: '0 0 16px' }} />
        <Row label="Wire from" value={`${data.fromAccount} (...${data.fromLast4})`} />

        <SectionHeader label="Sender information" />
        <Row label="Wire date" value={formattedDate} />
        <div style={{ borderTop: '1px solid #f0f0f0', margin: '0 0 16px' }} />
        {isIntl && data.foreignAmount && data.foreignCurrency && (
          <>
            <Row label="Wire amount" value={`${Number(data.foreignAmount).toLocaleString()} ${data.foreignCurrency}`} />
            <div style={{ borderTop: '1px solid #f0f0f0', margin: '0 0 16px' }} />
            <Row label="Amount debited" value={`$${Number(data.amount).toFixed(2)} USD (U.S. Dollar)`} />
          </>
        )}
        {!isIntl && (
          <>
            <Row label="Wire amount" value={`$${Number(data.amount).toFixed(2)} USD (U.S. Dollar)`} />
          </>
        )}
        <div style={{ borderTop: '1px solid #f0f0f0', margin: '0 0 16px' }} />
        <Row label="Outgoing wire transfer fee" value={`$${data.fee.toFixed(2)} USD (U.S. Dollar)`} />
        <div style={{ borderTop: '1px solid #f0f0f0', margin: '0 0 16px' }} />
        <Row label="Total transfer cost" value={`$${total} USD`} valueBold />
        <p style={{ fontSize: 12, color: '#888', fontStyle: 'italic', marginBottom: 16 }}>
          Your account activity will show separate charges for wire amount and wire transfer fee.
        </p>

        <SectionHeader label="Additional information" />
        <Row label="Message to recipient bank" value={data.msgToRecipientBank || 'None'} />
        <div style={{ borderTop: '1px solid #f0f0f0', margin: '0 0 16px' }} />
        <Row label="Message to recipient" value={data.msgToRecipient || 'None'} />
        <div style={{ borderTop: '1px solid #f0f0f0', margin: '0 0 16px' }} />
        <Row label="Memo" value={data.memo || 'None'} />
        {data.paymentCode && (
          <>
            <div style={{ borderTop: '1px solid #f0f0f0', margin: '0 0 16px' }} />
            <Row label="Payment purpose" value={data.paymentCode} />
          </>
        )}

        {/* Legal text */}
        <div style={{ marginTop: 24 }}>
          <InfoText>
            You agree there's no content in either 'Message to recipient bank' or 'Message to recipient' that will forward this wire to an international bank or location.
          </InfoText>
          <InfoText>
            We'll start processing your wire the same business day if we receive it before 5PM ET. If we receive your request after that time, we'll process it the following business day.
          </InfoText>
          <InfoText>
            Before we send a wire, it goes through an internal review process, and in some cases we may need to contact you to verify your request. After we've sent the wire, the receiving bank may have its own review process, which could further delay delivery.
          </InfoText>
          {!isIntl && (
            <InfoText>Your recipient will typically get a domestic wire within 1 business day.</InfoText>
          )}
          <InfoText>
            Note: By continuing with this wire, you agree your wire will be governed by the terms of the Wire Transfer Service Addendum.
          </InfoText>
        </div>
      </div>

      <div style={{ padding: '16px 20px', borderTop: '1px solid #eee', background: '#fff', flexShrink: 0, display: 'flex', flexDirection: 'column', gap: 10 }}>
        <button
          onClick={onSchedule}
          disabled={scheduling}
          style={{ width: '100%', background: scheduling ? '#a8c8f0' : blue, color: '#fff', border: 'none', borderRadius: 8, padding: '16px', fontSize: 16, fontWeight: 600, cursor: scheduling ? 'not-allowed' : 'pointer' }}
        >
          {scheduling ? 'Processing...' : 'Schedule Wire'}
        </button>
        <button
          onClick={onBack}
          style={{ width: '100%', background: '#f0f0f0', color: '#333', border: 'none', borderRadius: 8, padding: '16px', fontSize: 16, fontWeight: 500, cursor: 'pointer' }}
        >
          Back
        </button>
      </div>
    </div>
  );
}
