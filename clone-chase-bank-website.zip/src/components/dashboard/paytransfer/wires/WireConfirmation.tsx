import { useEffect, useState } from 'react';
import { WireTransferData } from './wireTypes';

const navy = '#1a3a6b';
const blue = '#2558b5';

interface Props {
  data: WireTransferData;
  onClose: () => void;
  onScheduleAnother?: () => void;
}

export default function WireConfirmation({ data, onClose, onScheduleAnother }: Props) {
  const [phase, setPhase] = useState<'spinner' | 'check' | 'content'>('spinner');
  const [checkUp, setCheckUp] = useState(false);

  useEffect(() => {
    const spinDuration = 1200 + Math.random() * 800;
    const t1 = setTimeout(() => setPhase('check'), spinDuration);
    const t2 = setTimeout(() => setCheckUp(true), spinDuration + 600);
    const t3 = setTimeout(() => setPhase('content'), spinDuration + 950);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, []);

  const wireDate = data.wireDate instanceof Date ? data.wireDate : new Date(data.wireDate);
  const fmtDate = wireDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  const total = (parseFloat(data.amount) + data.fee).toFixed(2);
  const txnNum = data.transactionNumber || String(Math.floor(1000000000 + Math.random() * 9000000000));
  const isIntl = data.type === 'international';

  return (
    <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", background: '#fff', overflow: 'hidden' }}>
      {/* Header */}
      <div style={{ background: navy, padding: '16px', flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
              <line x1="3" y1="6" x2="17" y2="6" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" />
              <line x1="3" y1="10" x2="17" y2="10" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" />
              <line x1="3" y1="14" x2="17" y2="14" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" />
            </svg>
          </button>
          <span style={{ color: '#fff', fontWeight: 600, fontSize: 15, textTransform: 'uppercase', letterSpacing: 1 }}>Confirm Transfer</span>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
              <circle cx="10" cy="10" r="8" stroke="#fff" strokeWidth="1.5" fill="none" />
              <circle cx="10" cy="10" r="2" fill="#fff" />
            </svg>
          </button>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', paddingBottom: 100 }}>
        {/* Animation area */}
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', padding: '40px 0 20px', minHeight: 120 }}>
          {phase === 'spinner' && (
            <div style={{
              width: 64, height: 64, borderRadius: '50%',
              border: '4px solid #e8e8e8', borderTopColor: '#4caf50',
              animation: 'spin 0.8s linear infinite',
            }} />
          )}
          {(phase === 'check' || phase === 'content') && (
            <div style={{
              width: 64, height: 64, borderRadius: '50%', background: '#4caf50',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              transform: checkUp ? 'translateY(-20px) scale(1)' : 'scale(1)',
              transition: 'transform 0.35s ease-out',
              animation: phase === 'check' ? 'checkIn 0.5s ease-out forwards' : undefined,
              flexShrink: 0,
            }}>
              <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
                <polyline
                  points="6,14 12,20 22,8"
                  stroke="#fff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"
                  style={{ animation: phase === 'check' || phase === 'content' ? 'drawCheck 0.35s ease-out 0.15s forwards' : undefined, strokeDasharray: 30, strokeDashoffset: 0 }}
                />
              </svg>
            </div>
          )}
        </div>

        {/* Content */}
        {phase === 'content' && (
          <div style={{ padding: '0 20px', animation: 'fadeUp 0.4s ease-out forwards' }}>
            <p style={{ textAlign: 'center', color: '#555', fontSize: 16, margin: '0 0 20px' }}>We've scheduled your wire</p>

            {/* Account details */}
            <div style={{ fontSize: 11, color: '#888', letterSpacing: 1.2, textTransform: 'uppercase', marginBottom: 8 }}>Account details</div>
            <div style={{ borderTop: '1px solid #e8e8e8', marginBottom: 16 }} />

            {[
              { label: 'Wire to', value: `${data.recipientName} (...${data.recipientLast4})` },
              { label: 'Wire from', value: `${data.fromAccount} (...${data.fromLast4})` },
              { label: 'Wire status', value: 'Pending' },
              { label: 'Transaction number', value: txnNum },
            ].map(row => (
              <div key={row.label} style={{ paddingBottom: 16, borderBottom: '1px solid #f5f5f5', marginBottom: 16 }}>
                <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>{row.label}</div>
                <div style={{ fontSize: 15, fontWeight: 600, color: '#111' }}>{row.value}</div>
              </div>
            ))}

            {/* Sender information */}
            <div style={{ fontSize: 11, color: '#888', letterSpacing: 1.2, textTransform: 'uppercase', marginBottom: 8, marginTop: 8 }}>Sender information</div>
            <div style={{ borderTop: '1px solid #e8e8e8', marginBottom: 16 }} />

            {[
              { label: 'Wire date', value: fmtDate },
              ...(isIntl && data.foreignAmount && data.foreignCurrency
                ? [
                  { label: 'Wire amount', value: `${Number(data.foreignAmount).toLocaleString()} ${data.foreignCurrency}` },
                  { label: 'Amount debited', value: `$${Number(data.amount).toFixed(2)} USD` },
                ]
                : [{ label: 'Wire amount', value: `$${Number(data.amount).toFixed(2)} USD (U.S. Dollar)` }]),
              { label: 'Outgoing wire transfer fee', value: `$${data.fee.toFixed(2)} USD` },
              { label: 'Total', value: `$${total} USD` },
              { label: 'Memo', value: data.memo || 'None' },
            ].map(row => (
              <div key={row.label} style={{ paddingBottom: 16, borderBottom: '1px solid #f5f5f5', marginBottom: 16 }}>
                <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>{row.label}</div>
                <div style={{ fontSize: 15, fontWeight: 600, color: '#111' }}>{row.value}</div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Bottom buttons */}
      {phase === 'content' && (
        <div style={{ padding: '16px 20px', borderTop: '1px solid #eee', background: '#fff', flexShrink: 0, display: 'flex', flexDirection: 'column', gap: 10 }}>
          {onScheduleAnother && (
            <button
              onClick={onScheduleAnother}
              style={{ width: '100%', background: blue, color: '#fff', border: 'none', borderRadius: 8, padding: '16px', fontSize: 16, fontWeight: 600, cursor: 'pointer' }}
            >
              Schedule another transfer
            </button>
          )}
          <button
            onClick={onClose}
            style={{ width: '100%', background: '#f0f0f0', color: '#333', border: 'none', borderRadius: 8, padding: '16px', fontSize: 16, fontWeight: 500, cursor: 'pointer' }}
          >
            Close
          </button>
        </div>
      )}

      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes checkIn { from { transform: scale(0); } to { transform: scale(1); } }
        @keyframes fadeUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
      `}</style>
    </div>
  );
}
