import { useState } from 'react';
import { WireRecipient, WireTransferData, DEMO_ACCOUNTS } from './wireTypes';

const blue = '#2558b5';
const navy = '#1a3a6b';

interface Props {
  recipient: WireRecipient;
  onBack: () => void;
  onCancel: () => void;
  onNext: (data: WireTransferData) => void;
}

function InfoText({ children }: { children: React.ReactNode }) {
  return <p style={{ fontSize: 13, color: '#666', lineHeight: 1.6, margin: '0 0 16px' }}>{children}</p>;
}

export default function DomesticWireForm({ recipient, onBack, onCancel, onNext }: Props) {
  const [rawAmount, setRawAmount] = useState('');
  const [fromAccount, setFromAccount] = useState(DEMO_ACCOUNTS[0]);
  const [showFromSheet, setShowFromSheet] = useState(false);
  const [repeat, setRepeat] = useState(false);
  const [wireDate] = useState(new Date());
  const [msgBank, setMsgBank] = useState('');
  const [msgRecipient, setMsgRecipient] = useState('');
  const [memo, setMemo] = useState('');

  const amount = parseFloat(rawAmount.replace(/[^0-9.]/g, '')) || 0;
  const fee = 25;
  const total = amount + fee;
  const canNext = amount > 0 && amount <= 25000;

  const fmtDate = wireDate.toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: 'numeric' });

  function handleNext() {
    onNext({
      recipientId: recipient.id,
      recipientName: recipient.name,
      recipientLast4: recipient.accountLast4,
      fromAccount: fromAccount.name,
      fromLast4: fromAccount.last4,
      amount: amount.toFixed(2),
      currency: 'USD',
      wireDate,
      memo,
      msgToRecipientBank: msgBank,
      msgToRecipient: msgRecipient,
      type: 'domestic',
      fee,
    });
  }

  return (
    <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", background: '#fff', overflow: 'hidden' }}>
      {/* Header */}
      <div style={{ background: navy, padding: '16px', flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
              <polyline points="12,3 6,9 12,15" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
          <span style={{ color: '#fff', fontWeight: 600, fontSize: 17 }}>Schedule Transfer</span>
          <button onClick={onCancel} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#fff', fontSize: 15 }}>Cancel</button>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '20px', paddingBottom: 100 }}>
        {/* Wire to */}
        <div style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Wire to</div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1.5px solid #ddd', paddingBottom: 6 }}>
            <span style={{ fontSize: 16, fontWeight: 700, color: '#111' }}>{recipient.name} (...{recipient.accountLast4})</span>
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><polyline points="2,4 6,8 10,4" stroke="#999" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg>
          </div>
        </div>

        {/* Wire from */}
        <div style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Wire from</div>
          <button onClick={() => setShowFromSheet(true)} style={{ width: '100%', background: 'none', border: 'none', borderBottom: '1.5px solid #ddd', padding: '6px 0', textAlign: 'left', cursor: 'pointer', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontSize: 16, fontWeight: 700, color: '#111' }}>{fromAccount.name} (...{fromAccount.last4})</span>
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><polyline points="2,4 6,8 10,4" stroke="#999" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg>
          </button>
        </div>

        {/* Wire amount */}
        <div style={{ marginBottom: 8 }}>
          <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Wire amount</div>
          <div style={{ display: 'flex', alignItems: 'center', borderBottom: '1.5px solid #ddd', paddingBottom: 6 }}>
            <input
              type="text"
              inputMode="decimal"
              placeholder="0"
              value={rawAmount}
              onChange={e => setRawAmount(e.target.value)}
              style={{ flex: 1, border: 'none', outline: 'none', fontSize: 28, fontWeight: 700, color: '#111', background: 'transparent', padding: 0 }}
            />
            <span style={{ fontSize: 16, color: '#888', marginLeft: 8 }}>USD</span>
          </div>
        </div>
        <div style={{ fontSize: 12, color: '#888', marginBottom: 24 }}>Wire daily limit is $25,000.00</div>

        {/* Repeat wire */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24, borderBottom: '1px solid #f0f0f0', paddingBottom: 16 }}>
          <span style={{ fontSize: 15, color: '#333' }}>Make this a repeating wire</span>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontSize: 13, color: '#888' }}>{repeat ? 'On' : 'Off'}</span>
            <button
              onClick={() => setRepeat(r => !r)}
              style={{ width: 44, height: 26, borderRadius: 13, background: repeat ? blue : '#ccc', border: 'none', cursor: 'pointer', position: 'relative', transition: 'background 0.2s' }}
            >
              <div style={{ position: 'absolute', top: 3, left: repeat ? 21 : 3, width: 20, height: 20, borderRadius: '50%', background: '#fff', transition: 'left 0.2s' }} />
            </button>
          </div>
        </div>

        {/* Wire date */}
        <div style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Wire date</div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1.5px solid #ddd', paddingBottom: 6 }}>
            <span style={{ fontSize: 16, color: '#111' }}>{fmtDate}</span>
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
              <rect x="1" y="3" width="16" height="14" rx="2" stroke={blue} strokeWidth="1.5" fill="none" />
              <line x1="1" y1="7" x2="17" y2="7" stroke={blue} strokeWidth="1.4" />
              <line x1="5" y1="1" x2="5" y2="5" stroke={blue} strokeWidth="1.6" strokeLinecap="round" />
              <line x1="13" y1="1" x2="13" y2="5" stroke={blue} strokeWidth="1.6" strokeLinecap="round" />
            </svg>
          </div>
        </div>

        {/* Processing info */}
        <InfoText>We'll start processing your wire the same business day if we receive it before 5PM. If we receive your request after that time, we'll process it the following business day.</InfoText>
        <InfoText>Before we send a wire, it goes through an internal review process, and in some cases we may need to contact you to verify your request. After we've sent the wire, the receiving bank may have its own review process, which could delay delivery.</InfoText>

        {/* Additional information */}
        <div style={{ fontSize: 18, fontWeight: 700, color: '#111', margin: '24px 0 16px' }}>Additional information</div>

        {/* Message to recipient bank */}
        <div style={{ marginBottom: 20 }}>
          <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Message to recipient bank</div>
          <input
            value={msgBank}
            onChange={e => e.target.value.length <= 100 && setMsgBank(e.target.value)}
            style={{ width: '100%', border: 'none', borderBottom: '1.5px solid #ddd', outline: 'none', fontSize: 15, color: '#111', padding: '6px 0', background: 'transparent', boxSizing: 'border-box' }}
          />
          <div style={{ fontSize: 12, color: '#aaa', marginTop: 4 }}>Maximum 100 characters (optional) — {100 - msgBank.length} remaining</div>
        </div>

        {/* Message to recipient */}
        <div style={{ marginBottom: 20 }}>
          <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Message to recipient</div>
          <input
            value={msgRecipient}
            onChange={e => e.target.value.length <= 140 && setMsgRecipient(e.target.value)}
            style={{ width: '100%', border: 'none', borderBottom: '1.5px solid #ddd', outline: 'none', fontSize: 15, color: '#111', padding: '6px 0', background: 'transparent', boxSizing: 'border-box' }}
          />
          <div style={{ fontSize: 12, color: '#aaa', marginTop: 4 }}>Maximum 140 characters (optional) — {140 - msgRecipient.length} remaining</div>
        </div>

        {/* Memo */}
        <div style={{ marginBottom: 20 }}>
          <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Memo</div>
          <input
            value={memo}
            onChange={e => e.target.value.length <= 100 && setMemo(e.target.value)}
            style={{ width: '100%', border: 'none', borderBottom: '1.5px solid #ddd', outline: 'none', fontSize: 15, color: '#111', padding: '6px 0', background: 'transparent', boxSizing: 'border-box' }}
          />
          <div style={{ fontSize: 12, color: '#aaa', marginTop: 4 }}>Maximum 100 characters (optional) — {100 - memo.length} remaining</div>
        </div>

        <InfoText>We'll email the person who initiates the wire using the primary email address we have on file for that username. If the person doesn't receive an email, please have them check the activity page for the status. You can update the email address under 'Profile &amp; Settings' at any time.</InfoText>

        {/* Wire summary */}
        <div style={{ borderTop: '1px solid #eee', marginTop: 8 }}>
          {[
            { label: 'Wire amount', value: `$${amount.toFixed(2)} USD` },
            { label: 'Wire transfers', value: `$${fee.toFixed(2)} USD` },
            { label: 'Total', value: `$${total.toFixed(2)} USD`, bold: true },
          ].map(row => (
            <div key={row.label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '14px 0', borderBottom: '1px solid #f0f0f0' }}>
              <span style={{ fontSize: 14, color: '#555' }}>{row.label}</span>
              <span style={{ fontSize: 14, fontWeight: row.bold ? 700 : 500, color: '#111' }}>{row.value}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Next button */}
      <div style={{ padding: '16px 20px', borderTop: '1px solid #eee', background: '#fff', flexShrink: 0 }}>
        <button
          onClick={handleNext}
          disabled={!canNext}
          style={{ width: '100%', background: canNext ? blue : '#a8c8f0', color: '#fff', border: 'none', borderRadius: 8, padding: '16px', fontSize: 16, fontWeight: 600, cursor: canNext ? 'pointer' : 'not-allowed' }}
        >
          Next
        </button>
      </div>

      {/* From Account Sheet */}
      {showFromSheet && (
        <>
          <div onClick={() => setShowFromSheet(false)} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', zIndex: 200 }} />
          <div style={{ position: 'fixed', bottom: 0, left: 0, right: 0, background: '#fff', borderRadius: '16px 16px 0 0', zIndex: 201, paddingBottom: 40 }}>
            <div style={{ width: 40, height: 4, background: '#ddd', borderRadius: 2, margin: '12px auto 8px' }} />
            <p style={{ textAlign: 'center', fontWeight: 700, fontSize: 17, color: '#111', padding: '0 0 8px' }}>Wire from</p>
            <div style={{ background: '#f5f5f5', padding: '6px 16px', fontSize: 11, color: '#888', letterSpacing: 1 }}>INTERNAL ACCOUNT</div>
            {DEMO_ACCOUNTS.map((acct, i) => (
              <div key={acct.id}>
                <button
                  onClick={() => { setFromAccount(acct); setShowFromSheet(false); }}
                  style={{ width: '100%', background: 'none', border: 'none', cursor: 'pointer', padding: '16px 20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', textAlign: 'left' }}
                >
                  <div>
                    <div style={{ fontSize: 15, fontWeight: 600, color: '#111' }}>{acct.name} (...{acct.last4})</div>
                    <div style={{ fontSize: 13, color: '#888', marginTop: 2 }}>{acct.balance}</div>
                  </div>
                  {fromAccount.id === acct.id && (
                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                      <polyline points="3,9 7,13 15,5" stroke={blue} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  )}
                </button>
                {i < DEMO_ACCOUNTS.length - 1 && <div style={{ borderTop: '1px solid #f0f0f0', margin: '0 16px' }} />}
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
