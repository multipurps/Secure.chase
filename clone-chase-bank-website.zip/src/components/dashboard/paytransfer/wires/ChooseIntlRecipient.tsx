import { useState, useEffect } from 'react';
import { WireRecipient } from './wireTypes';
import { supabase } from '../../../../lib/supabase';

const blue = '#2558b5';
const navy = '#1a3a6b';

interface IntlParams {
  country: { code: string; name: string; flag: string; currency: string };
  usdAmount: string;
  foreignAmount: string;
  rate: number;
  fromAccount: { id: string; name: string; last4: string; balance: string };
}

interface Props {
  intlParams: IntlParams;
  onBack: () => void;
  onSelectRecipient: (r: WireRecipient) => void;
  onAddRecipient: () => void;
}

export default function ChooseIntlRecipient({ intlParams, onBack, onSelectRecipient, onAddRecipient }: Props) {
  const [recipients, setRecipients] = useState<WireRecipient[]>([]);
  const [search, setSearch] = useState('');
  const { country, rate } = intlParams;

  useEffect(() => {
    (async () => {
      try {
        const { data } = await supabase.from('wire_recipients').select('*').eq('type', 'international').eq('country', country.name);
        if (data) setRecipients(data as WireRecipient[]);
      } catch { /* no data */ }
    })();
  }, [country.name]);

  const filtered = recipients.filter(r =>
    !search || r.name.toLowerCase().includes(search.toLowerCase())
  );

  const groups: Record<string, WireRecipient[]> = {};
  filtered.forEach(r => {
    const g = r.group || 'MY INTERNATIONAL GROUP';
    if (!groups[g]) groups[g] = [];
    groups[g].push(r);
  });

  return (
    <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", background: '#fff', overflow: 'hidden' }}>
      <div style={{ background: navy, padding: '16px', flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
          <button onClick={onBack} style={{ position: 'absolute', left: 0, background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
              <polyline points="12,3 6,9 12,15" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
          <span style={{ color: '#fff', fontWeight: 600, fontSize: 17 }}>Choose recipient</span>
        </div>
      </div>

      {/* Rate reminder */}
      <div style={{ background: '#f7f9fc', padding: '10px 16px', borderBottom: '1px solid #e8e8e8', flexShrink: 0, textAlign: 'center' }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: '#111' }}>
          JPMC rate $1.00 USD = {rate.toFixed(4)} {country.currency} {country.flag} ⓘ
        </div>
        <div style={{ fontSize: 12, color: '#888', marginTop: 2 }}>&#128336; Expires in 30 min</div>
      </div>

      {/* Search + Add */}
      <div style={{ padding: '10px 16px', borderBottom: '1px solid #f0f0f0', flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 8, background: '#f7f7f7', borderRadius: 8, padding: '8px 12px' }}>
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <circle cx="7" cy="7" r="4.5" stroke="#999" strokeWidth="1.5" />
              <line x1="10.5" y1="10.5" x2="14" y2="14" stroke="#999" strokeWidth="1.6" strokeLinecap="round" />
            </svg>
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search recipient"
              style={{ flex: 1, border: 'none', background: 'transparent', outline: 'none', fontSize: 14, color: '#333' }} />
          </div>
          <button onClick={onAddRecipient} style={{ background: 'none', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4 }}>
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
              <circle cx="9" cy="9" r="8" stroke={blue} strokeWidth="1.6" />
              <line x1="9" y1="5" x2="9" y2="13" stroke={blue} strokeWidth="1.6" strokeLinecap="round" />
              <line x1="5" y1="9" x2="13" y2="9" stroke={blue} strokeWidth="1.6" strokeLinecap="round" />
            </svg>
            <span style={{ color: blue, fontWeight: 600, fontSize: 14 }}>Add</span>
          </button>
        </div>
      </div>

      {/* Info note */}
      <div style={{ padding: '12px 16px', background: '#f9f9f9', borderBottom: '1px solid #f0f0f0', flexShrink: 0, display: 'flex', gap: 10 }}>
        <div style={{ width: 8, height: 8, borderRadius: '50%', background: blue, marginTop: 5, flexShrink: 0 }} />
        <p style={{ margin: 0, fontSize: 13, color: '#666', lineHeight: 1.5 }}>
          This list is filtered by recipient type and country. If you don't see a recipient, go to 'Manage recipients,' then 'Edit' and choose a 'Recipient type,' either individual or business.
        </p>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', paddingBottom: 80 }}>
        {Object.keys(groups).length === 0 ? (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: 280, padding: 32, textAlign: 'center' }}>
            <p style={{ color: '#666', fontSize: 15, lineHeight: 1.5, marginBottom: 8 }}>No recipients found for {country.flag} {country.name}.</p>
            <p style={{ color: '#666', fontSize: 14 }}>Tap <strong>+ Add</strong> to create your first recipient.</p>
          </div>
        ) : (
          Object.entries(groups).map(([grpName, grpRecipients]) => (
            <div key={grpName}>
              <div style={{ background: '#f5f5f5', padding: '8px 16px', fontSize: 12, color: '#888', letterSpacing: 1, fontWeight: 600, textTransform: 'uppercase' }}>
                {grpName} ({grpRecipients.length})
              </div>
              {grpRecipients.map(r => (
                <button key={r.id} onClick={() => onSelectRecipient(r)}
                  style={{ width: '100%', background: '#fff', border: 'none', cursor: 'pointer', display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '16px', borderBottom: '1px solid #f0f0f0', textAlign: 'left' }}>
                  <div>
                    <div style={{ fontSize: 16, fontWeight: 700, color: '#111', textTransform: 'uppercase' }}>{r.name}</div>
                    {r.nickname && <div style={{ fontSize: 13, color: '#888', marginTop: 2 }}>{r.nickname}</div>}
                  </div>
                  <svg width="8" height="14" viewBox="0 0 8 14" fill="none">
                    <polyline points="1,1 7,7 1,13" stroke="#bbb" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </button>
              ))}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
