import { useState, useEffect } from 'react';
import { WireRecipient } from './wireTypes';
import { supabase } from '../../../../lib/supabase';

const blue = '#2558b5';
const navy = '#1a3a6b';


function SearchIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
      <circle cx="8" cy="8" r="5.5" stroke="#999" strokeWidth="1.7" />
      <line x1="12.5" y1="12.5" x2="16" y2="16" stroke="#999" strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
}
function ChevronRight({ color = '#bbb' }: { color?: string }) {
  return (
    <svg width="8" height="14" viewBox="0 0 8 14" fill="none">
      <polyline points="1,1 7,7 1,13" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

interface Props {
  onBack: () => void;
  onSelectRecipient: (r: WireRecipient) => void;
  onAddDomestic: () => void;
  onAddInternational: () => void;
  onFxCalc: () => void;
}

type FilterTab = 'all' | 'domestic' | 'international';

export default function WireMain({ onBack, onSelectRecipient, onAddDomestic, onAddInternational, onFxCalc }: Props) {
  const [filter, setFilter] = useState<FilterTab>('all');
  const [search, setSearch] = useState('');
  const [recipients, setRecipients] = useState<WireRecipient[]>([]);
  const [showAddSheet, setShowAddSheet] = useState(false);

  useEffect(() => {
    loadRecipients();
  }, []);

  async function loadRecipients() {
    try {
      const { data } = await supabase.from('wire_recipients').select('*').order('name');
      if (data && data.length > 0) {
        setRecipients(data as WireRecipient[]);
      }
    } catch {
      // no table yet — show empty state
    }
  }

  const filtered = recipients.filter(r => {
    const matchesFilter = filter === 'all' || r.type === filter;
    const matchesSearch = !search || r.name.toLowerCase().includes(search.toLowerCase()) ||
      (r.nickname && r.nickname.toLowerCase().includes(search.toLowerCase()));
    return matchesFilter && matchesSearch;
  });

  // Group recipients by their group field
  const groups: Record<string, WireRecipient[]> = {};
  filtered.forEach(r => {
    const grp = r.group || 'MY RECIPIENTS';
    if (!groups[grp]) groups[grp] = [];
    groups[grp].push(r);
  });

  const tabs: FilterTab[] = ['all', 'domestic', 'international'];

  return (
    <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", background: '#fff', overflow: 'hidden' }}>
      {/* Header */}
      <div style={{ background: navy, padding: '16px 16px 12px', flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
          <button onClick={onBack} style={{ position: 'absolute', left: 0, background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
              <polyline points="13,3 6,10 13,17" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
          <span style={{ color: '#fff', fontWeight: 600, fontSize: 17 }}>Send money</span>
        </div>
      </div>

      {/* FX Calculator Banner */}
      <div style={{ background: '#fff', padding: '16px 16px 12px', borderBottom: '1px solid #f0f0f0', flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
            <line x1="3" y1="8" x2="15" y2="8" stroke={blue} strokeWidth="1.6" strokeLinecap="round" />
            <line x1="3" y1="12" x2="15" y2="12" stroke={blue} strokeWidth="1.6" strokeLinecap="round" />
            <line x1="3" y1="16" x2="9" y2="16" stroke={blue} strokeWidth="1.6" strokeLinecap="round" />
            <circle cx="18" cy="15" r="5" stroke={blue} strokeWidth="1.5" fill="none" />
            <text x="18" y="18.5" textAnchor="middle" fontSize="7" fontWeight="800" fill={blue} fontFamily="Helvetica Neue, Arial, sans-serif">$</text>
          </svg>
          <button onClick={onFxCalc} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}>
            <span style={{ color: blue, fontWeight: 600, fontSize: 15 }}>Use our foreign exchange calculator</span>
          </button>
          <svg width="12" height="12" viewBox="0 0 12 12" fill="none" style={{ flexShrink: 0 }}>
            <polyline points="2,2 10,6 2,10" stroke="#555" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
        <p style={{ margin: 0, fontSize: 13, color: '#666', lineHeight: 1.5 }}>
          If you're sending money internationally, you can explore country and currency options and get a rate.
        </p>
      </div>

      {/* Search + Add */}
      <div style={{ padding: '10px 16px', borderBottom: '1px solid #f0f0f0', flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 8, background: '#f7f7f7', borderRadius: 8, padding: '8px 12px' }}>
            <SearchIcon />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search by recipient"
              style={{ flex: 1, border: 'none', background: 'transparent', outline: 'none', fontSize: 14, color: '#333' }}
            />
          </div>
          <button onClick={() => setShowAddSheet(true)} style={{ background: 'none', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4 }}>
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
              <circle cx="9" cy="9" r="8" stroke={blue} strokeWidth="1.6" />
              <line x1="9" y1="5" x2="9" y2="13" stroke={blue} strokeWidth="1.6" strokeLinecap="round" />
              <line x1="5" y1="9" x2="13" y2="9" stroke={blue} strokeWidth="1.6" strokeLinecap="round" />
            </svg>
            <span style={{ color: blue, fontWeight: 600, fontSize: 14 }}>Add</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div style={{ display: 'flex', borderBottom: '1px solid #e8e8e8', flexShrink: 0 }}>
        {tabs.map(tab => (
          <button
            key={tab}
            onClick={() => setFilter(tab)}
            style={{
              flex: 1, background: 'none', border: 'none', cursor: 'pointer',
              padding: '12px 0', fontSize: 14, fontWeight: filter === tab ? 700 : 400,
              color: filter === tab ? blue : '#666',
              borderBottom: filter === tab ? `3px solid ${blue}` : '3px solid transparent',
              textTransform: 'capitalize',
            }}
          >
            {tab === 'all' ? 'All' : tab === 'domestic' ? 'Domestic' : 'International'}
          </button>
        ))}
      </div>

      {/* Recipient List */}
      <div style={{ flex: 1, overflowY: 'auto', paddingBottom: 80 }}>
        {Object.keys(groups).length === 0 ? (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: 280, padding: 32, textAlign: 'center' }}>
            <svg width="48" height="48" viewBox="0 0 48 48" fill="none" style={{ marginBottom: 16 }}>
              <circle cx="24" cy="24" r="22" stroke="#ddd" strokeWidth="2" fill="none" />
              <circle cx="24" cy="19" r="6" stroke="#bbb" strokeWidth="2" fill="none" />
              <path d="M10 38c0-7.732 6.268-14 14-14s14 6.268 14 14" stroke="#bbb" strokeWidth="2" strokeLinecap="round" fill="none" />
            </svg>
            <p style={{ color: '#666', fontSize: 15, lineHeight: 1.5 }}>No recipients yet.</p>
            <p style={{ color: '#666', fontSize: 14, marginTop: 4 }}>Tap <strong>+ Add</strong> to create your first recipient.</p>
          </div>
        ) : (
          Object.entries(groups).map(([grpName, grpRecipients]) => (
            <div key={grpName}>
              <div style={{ background: '#f5f5f5', padding: '8px 16px', fontSize: 12, color: '#888', letterSpacing: 1, fontWeight: 600, textTransform: 'uppercase' }}>
                {grpName} ({grpRecipients.length})
              </div>
              {grpRecipients.map(r => (
                <button
                  key={r.id}
                  onClick={() => onSelectRecipient(r)}
                  style={{ width: '100%', background: '#fff', border: 'none', cursor: 'pointer', display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '16px', borderBottom: '1px solid #f0f0f0', textAlign: 'left' }}
                >
                  <div>
                    <div style={{ fontSize: 16, fontWeight: 700, color: '#111', textTransform: 'uppercase', letterSpacing: 0.5 }}>
                      {r.name}
                    </div>
                    {r.nickname && <div style={{ fontSize: 13, color: '#888', marginTop: 2 }}>{r.nickname}</div>}
                    <div style={{ fontSize: 12, color: '#aaa', marginTop: 2 }}>{r.type === 'international' ? r.country : 'Domestic'}</div>
                  </div>
                  <ChevronRight />
                </button>
              ))}
            </div>
          ))
        )}
      </div>

      {/* Add Recipient Sheet */}
      {showAddSheet && (
        <>
          <div onClick={() => setShowAddSheet(false)} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', zIndex: 100 }} />
          <div style={{ position: 'fixed', bottom: 0, left: 0, right: 0, background: '#fff', borderRadius: '16px 16px 0 0', zIndex: 101, padding: '20px 0 40px' }}>
            <div style={{ width: 40, height: 4, background: '#ddd', borderRadius: 2, margin: '0 auto 20px' }} />
            <p style={{ textAlign: 'center', fontWeight: 700, fontSize: 17, color: '#111', margin: '0 0 20px' }}>Add recipient</p>
            <button
              onClick={() => { setShowAddSheet(false); onAddDomestic(); }}
              style={{ width: '100%', background: 'none', border: 'none', cursor: 'pointer', padding: '16px 24px', display: 'flex', alignItems: 'center', gap: 16, borderBottom: '1px solid #f0f0f0' }}
            >
              <div style={{ width: 44, height: 44, borderRadius: '50%', background: '#e8f0fc', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
                  <rect x="1" y="7" width="20" height="12" rx="1.5" stroke={blue} strokeWidth="1.7" fill="none" />
                  <rect x="4" y="9" width="2.5" height="7" rx="0.3" fill={blue} />
                  <rect x="8" y="9" width="2.5" height="7" rx="0.3" fill={blue} />
                  <rect x="12" y="9" width="2.5" height="7" rx="0.3" fill={blue} />
                  <rect x="16" y="9" width="2.5" height="7" rx="0.3" fill={blue} />
                  <line x1="0" y1="7" x2="22" y2="7" stroke={blue} strokeWidth="1.4" />
                  <path d="M5 7 L5 4 L17 4 L17 7" stroke={blue} strokeWidth="1.5" fill="none" />
                  <path d="M8 4 L11 1 L14 4" stroke={blue} strokeWidth="1.4" fill="none" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </div>
              <div style={{ textAlign: 'left' }}>
                <div style={{ fontSize: 16, fontWeight: 600, color: '#111' }}>Domestic wire</div>
                <div style={{ fontSize: 13, color: '#888', marginTop: 2 }}>Send within the United States</div>
              </div>
            </button>
            <button
              onClick={() => { setShowAddSheet(false); onAddInternational(); }}
              style={{ width: '100%', background: 'none', border: 'none', cursor: 'pointer', padding: '16px 24px', display: 'flex', alignItems: 'center', gap: 16 }}
            >
              <div style={{ width: 44, height: 44, borderRadius: '50%', background: '#e8f0fc', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
                  <circle cx="11" cy="11" r="9.5" stroke={blue} strokeWidth="1.6" fill="none" />
                  <ellipse cx="11" cy="11" rx="4" ry="9.5" stroke={blue} strokeWidth="1.3" fill="none" />
                  <line x1="1.5" y1="8" x2="20.5" y2="8" stroke={blue} strokeWidth="1.2" />
                  <line x1="1.5" y1="14" x2="20.5" y2="14" stroke={blue} strokeWidth="1.2" />
                </svg>
              </div>
              <div style={{ textAlign: 'left' }}>
                <div style={{ fontSize: 16, fontWeight: 600, color: '#111' }}>International wire</div>
                <div style={{ fontSize: 13, color: '#888', marginTop: 2 }}>Send to 140+ countries</div>
              </div>
            </button>
          </div>
        </>
      )}
    </div>
  );
}
