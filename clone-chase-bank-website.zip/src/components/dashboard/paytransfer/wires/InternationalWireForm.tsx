import { useState } from 'react';
import { WireRecipient, WireTransferData, DEMO_ACCOUNTS } from './wireTypes';

const blue = '#2558b5';
const navy = '#1a3a6b';

const PAYMENT_CODES = [
  'Family support',
  'Trade payable',
  'Professional services',
  'Medical',
  'Education',
  'Real estate',
  'Other',
];

interface IntlParams {
  country: { code: string; name: string; flag: string; currency: string };
  usdAmount: string;
  foreignAmount: string;
  rate: number;
  fromAccount: typeof DEMO_ACCOUNTS[0];
}

interface Props {
  recipient: WireRecipient;
  intlParams: IntlParams;
  onBack: () => void;
  onCancel: () => void;
  onNext: (data: WireTransferData) => void;
}

export default function InternationalWireForm({ recipient, intlParams, onBack, onCancel, onNext }: Props) {
  const [usdAmount, setUsdAmount] = useState(intlParams.usdAmount);
  const [foreignAmount, setForeignAmount] = useState(intlParams.foreignAmount);
  const [fromAccount, setFromAccount] = useState(intlParams.fromAccount);
  const [showFromSheet, setShowFromSheet] = useState(false);
  const [wireDate] = useState(new Date());
  const [paymentCode, setPaymentCode] = useState('');
  const [showPaymentCode, setShowPaymentCode] = useState(false);
  const [msgBank, setMsgBank] = useState('');
  const [msgRecipient, setMsgRecipient] = useState('');
  const [internalMemo, setInternalMemo] = useState('');
  const [_lastEdited, setLastEdited] = useState<'usd' | 'foreign'>('usd');

  const { country, rate } = intlParams;
  const usdNum = parseFloat(usdAmount) || 0;
  const fee = usdNum >= 5000 ? 0 : 5;
  const total = usdNum + fee;
  const fmtDate = wireDate.toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: 'numeric' });

  function handleUsdChange(val: string) {
    setLastEdited('usd');
    setUsdAmount(val);
    const n = parseFloat(val) || 0;
    setForeignAmount(n > 0 ? (n * rate).toFixed(2) : '');
  }
  function handleForeignChange(val: string) {
    setLastEdited('foreign');
    setForeignAmount(val);
    const n = parseFloat(val) || 0;
    setUsdAmount(n > 0 ? (n / rate).toFixed(2) : '');
  }

  const canNext = usdNum > 0 && paymentCode;

  function handleNext() {
    onNext({
      recipientId: recipient.id,
      recipientName: recipient.name,
      recipientLast4: recipient.accountLast4,
      fromAccount: fromAccount.name,
      fromLast4: fromAccount.last4,
      amount: usdNum.toFixed(2),
      currency: 'USD',
      foreignAmount: foreignAmount,
      foreignCurrency: country.currency,
      wireDate,
      memo: internalMemo,
      msgToRecipientBank: msgBank,
      msgToRecipient: msgRecipient,
      paymentCode,
      type: 'international',
      fee,
    });
  }

  return (
    <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", background: '#fff', overflow: 'hidden' }}>
      <div style={{ background: navy, padding: '16px', flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
              <polyline points="12,3 6,9 12,15" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
          <span style={{ color: '#fff', fontWeight: 600, fontSize: 17 }}>Schedule Transfer</span>
          <button onClick={onCancel} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#fff', fontSize: 15 }}>Cancel</button>
        </div>
      </div>

      {/* Rate sub-header */}
      <div style={{ background: '#f7f9fc', padding: '10px 16px', borderBottom: '1px solid #e8e8e8', flexShrink: 0, textAlign: 'center' }}>
        <div style={{ fontSize: 14, fontWeight: 700, color: '#111' }}>
          JPMC rate $1.00 USD = {rate.toFixed(4)} {country.currency} {country.flag} ⓘ
        </div>
        <div style={{ fontSize: 12, color: '#888', marginTop: 2 }}>&#128336; expires in 30 min</div>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '20px', paddingBottom: 100 }}>
        {/* Wire to */}
        <div style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Wire to</div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1.5px solid #ddd', paddingBottom: 6 }}>
            <span style={{ fontSize: 16, fontWeight: 700, color: '#111' }}>{recipient.name} (...{recipient.accountLast4})</span>
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><polyline points="2,4 6,8 10,4" stroke="#999" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg>
          </div>
        </div>

        {/* Wire from */}
        <div style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Wire from</div>
          <button onClick={() => setShowFromSheet(true)} style={{ width: '100%', background: 'none', border: 'none', borderBottom: '1.5px solid #ddd', padding: '6px 0', textAlign: 'left', cursor: 'pointer', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontSize: 16, fontWeight: 700, color: '#111' }}>{fromAccount.name} (...{fromAccount.last4})</span>
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><polyline points="2,4 6,8 10,4" stroke="#999" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg>
          </button>
        </div>

        {/* Equivalent dollar amount */}
        <div style={{ marginBottom: 8 }}>
          <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Equivalent dollar amount (Amount debited)</div>
          <div style={{ display: 'flex', alignItems: 'center', borderBottom: '1.5px solid #ddd', paddingBottom: 6 }}>
            <input
              type="text" inputMode="decimal" placeholder="0"
              value={usdAmount}
              onChange={e => handleUsdChange(e.target.value)}
              style={{ flex: 1, border: 'none', outline: 'none', fontSize: 24, fontWeight: 700, color: '#111', background: 'transparent', padding: 0 }}
            />
            <span style={{ fontSize: 15, marginLeft: 8 }}>🇺🇸 USD</span>
          </div>
        </div>

        {/* Wire amount */}
        <div style={{ marginBottom: 8 }}>
          <div style={{ display: 'flex', gap: 16, alignItems: 'flex-end', borderBottom: '1.5px solid #ddd', paddingBottom: 6 }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Wire amount</div>
              <input
                type="text" inputMode="decimal" placeholder="0"
                value={foreignAmount}
                onChange={e => handleForeignChange(e.target.value)}
                style={{ width: '100%', border: 'none', outline: 'none', fontSize: 24, fontWeight: 700, color: '#111', background: 'transparent', padding: 0 }}
              />
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginBottom: 4 }}>
              <span style={{ fontSize: 15 }}>{country.flag}</span>
              <span style={{ fontSize: 14, fontWeight: 600, color: '#111' }}>{country.currency}</span>
              <svg width="10" height="10" viewBox="0 0 10 10" fill="none"><polyline points="2,3 5,7 8,3" stroke="#999" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" /></svg>
            </div>
          </div>
        </div>
        <div style={{ marginBottom: 24 }} />

        {/* Wire date */}
        <div style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Wire date ⓘ</div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1.5px solid #ddd', paddingBottom: 6 }}>
            <span style={{ fontSize: 16, color: '#111' }}>{fmtDate}</span>
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
              <rect x="1" y="3" width="16" height="14" rx="2" stroke={blue} strokeWidth="1.5" fill="none" />
              <line x1="1" y1="7" x2="17" y2="7" stroke={blue} strokeWidth="1.4" />
              <line x1="5" y1="1" x2="5" y2="5" stroke={blue} strokeWidth="1.6" strokeLinecap="round" />
              <line x1="13" y1="1" x2="13" y2="5" stroke={blue} strokeWidth="1.6" strokeLinecap="round" />
            </svg>
          </div>
        </div>

        <p style={{ fontSize: 13, color: '#666', lineHeight: 1.6, marginBottom: 16 }}>We'll start processing your wire the same business day if we receive it before 5PM. If we receive your request after that time, we'll process it the following business day.</p>
        <p style={{ fontSize: 13, color: '#666', lineHeight: 1.6, marginBottom: 24 }}>Before we send a wire, it goes through an internal review process, and in some cases we may need to contact you to verify your request. After we've sent the wire, the receiving bank may have its own review process, which could delay delivery.</p>

        {/* Payment purpose */}
        <div style={{ fontSize: 18, fontWeight: 700, color: '#111', marginBottom: 16 }}>Payment purpose</div>

        <div style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Payment code category ⓘ</div>
          <button onClick={() => setShowPaymentCode(true)} style={{ width: '100%', background: 'none', border: 'none', borderBottom: '1.5px solid #ddd', padding: '6px 0', textAlign: 'left', cursor: 'pointer', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontSize: 16, color: paymentCode ? '#111' : '#bbb' }}>{paymentCode || 'Choose one'}</span>
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><polyline points="2,4 6,8 10,4" stroke="#999" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg>
          </button>
        </div>

        {/* Additional information */}
        <div style={{ fontSize: 18, fontWeight: 700, color: '#111', marginBottom: 16 }}>Additional information</div>

        {[
          { label: 'Message to recipient bank', value: msgBank, onChange: setMsgBank, max: 75 },
          { label: 'Message to recipient', value: msgRecipient, onChange: setMsgRecipient, max: 140 },
          { label: 'Internal memo', value: internalMemo, onChange: setInternalMemo, max: 100 },
        ].map(f => (
          <div key={f.label} style={{ marginBottom: 20 }}>
            <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>{f.label}</div>
            <input
              value={f.value}
              onChange={e => e.target.value.length <= f.max && f.onChange(e.target.value)}
              style={{ width: '100%', border: 'none', borderBottom: '1.5px solid #ddd', outline: 'none', fontSize: 15, color: '#111', padding: '6px 0', background: 'transparent', boxSizing: 'border-box' }}
            />
            <div style={{ fontSize: 12, color: '#aaa', marginTop: 4 }}>Maximum {f.max} characters (optional) — {f.max - f.value.length} remaining</div>
          </div>
        ))}

        <p style={{ fontSize: 13, color: '#666', lineHeight: 1.6, marginBottom: 20 }}>
          We'll email you at the email address we have on file about your wire transfer's status. If you don't receive an email, please check the activity page for the status. You can update your email address under 'Profile &amp; Settings' at any time.
        </p>

        {/* Wire summary */}
        <div style={{ borderTop: '1px solid #eee' }}>
          {[
            { label: 'Wire amount', value: `${Number(foreignAmount || 0).toLocaleString()} ${country.currency}` },
            { label: 'Amount debited', value: `$${usdNum.toFixed(2)} USD` },
            { label: 'Wire transfer fee', value: fee === 0 ? 'No fee' : `$${fee.toFixed(2)} USD` },
            { label: 'Total', value: `$${total.toFixed(2)} USD`, bold: true },
          ].map(row => (
            <div key={row.label} style={{ display: 'flex', justifyContent: 'space-between', padding: '14px 0', borderBottom: '1px solid #f0f0f0' }}>
              <span style={{ fontSize: 14, color: '#555' }}>{row.label}</span>
              <span style={{ fontSize: 14, fontWeight: (row as {bold?: boolean}).bold ? 700 : 500, color: '#111' }}>{row.value}</span>
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding: '16px 20px', borderTop: '1px solid #eee', background: '#fff', flexShrink: 0 }}>
        <button
          onClick={handleNext}
          disabled={!canNext}
          style={{ width: '100%', background: canNext ? navy : '#a8c8f0', color: '#fff', border: 'none', borderRadius: 8, padding: '16px', fontSize: 16, fontWeight: 600, cursor: canNext ? 'pointer' : 'not-allowed' }}
        >
          Next
        </button>
      </div>

      {/* From Account Sheet */}
      {showFromSheet && (
        <>
          <div onClick={() => setShowFromSheet(false)} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', zIndex: 200 }} />
          <div style={{ position: 'fixed', bottom: 0, left: 0, right: 0, background: '#fff', borderRadius: '16px 16px 0 0', zIndex: 201, paddingBottom: 40 }}>
            <div style={{ width: 40, height: 4, background: '#ddd', borderRadius: 2, margin: '12px auto 8px' }} />
            <p style={{ textAlign: 'center', fontWeight: 700, fontSize: 17, padding: '0 0 8px' }}>Wire from</p>
            {DEMO_ACCOUNTS.map((acct, i) => (
              <div key={acct.id}>
                <button onClick={() => { setFromAccount(acct); setShowFromSheet(false); }}
                  style={{ width: '100%', background: 'none', border: 'none', cursor: 'pointer', padding: '16px 20px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', textAlign: 'left' }}>
                  <div>
                    <div style={{ fontSize: 15, fontWeight: 600, color: '#111' }}>{acct.name} (...{acct.last4})</div>
                    <div style={{ fontSize: 13, color: '#888', marginTop: 2 }}>{acct.balance}</div>
                  </div>
                  {fromAccount.id === acct.id && (
                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                      <polyline points="3,9 7,13 15,5" stroke={blue} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  )}
                </button>
                {i < DEMO_ACCOUNTS.length - 1 && <div style={{ borderTop: '1px solid #f0f0f0', margin: '0 16px' }} />}
              </div>
            ))}
          </div>
        </>
      )}

      {/* Payment Code Sheet */}
      {showPaymentCode && (
        <>
          <div onClick={() => setShowPaymentCode(false)} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', zIndex: 200 }} />
          <div style={{ position: 'fixed', bottom: 0, left: 0, right: 0, background: '#fff', borderRadius: '16px 16px 0 0', zIndex: 201, paddingBottom: 40 }}>
            <div style={{ width: 40, height: 4, background: '#ddd', borderRadius: 2, margin: '12px auto 8px' }} />
            <p style={{ textAlign: 'center', fontWeight: 700, fontSize: 17, padding: '0 0 8px' }}>Payment code category</p>
            {PAYMENT_CODES.map((code, i) => (
              <div key={code}>
                <button onClick={() => { setPaymentCode(code); setShowPaymentCode(false); }}
                  style={{ width: '100%', background: 'none', border: 'none', cursor: 'pointer', padding: '16px 24px', textAlign: 'left', fontSize: 16, fontWeight: paymentCode === code ? 700 : 400, color: '#111' }}>
                  {code}
                  {paymentCode === code && (
                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" style={{ float: 'right' }}>
                      <polyline points="3,9 7,13 15,5" stroke={blue} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  )}
                </button>
                {i < PAYMENT_CODES.length - 1 && <div style={{ borderTop: '1px solid #f0f0f0', margin: '0 16px' }} />}
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
