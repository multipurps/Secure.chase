const ACTIVITIES = [
  { id: '1', type: 'Transfer', desc: 'Chase Checking to Chase Savings', date: 'Aug 10, 2025', amount: '-$500.00', status: 'Completed', debit: true },
  { id: '2', type: 'Zelle', desc: 'Sent to Amber Davis', date: 'Aug 08, 2025', amount: '-$20.00', status: 'Completed', debit: true },
  { id: '3', type: 'Bill Pay', desc: 'Electric Company', date: 'Aug 07, 2025', amount: '-$142.00', status: 'Completed', debit: true },
  { id: '4', type: 'Transfer', desc: 'Chase Savings to Chase Checking', date: 'Aug 05, 2025', amount: '+$200.00', status: 'Completed', debit: false },
  { id: '5', type: 'Zelle', desc: 'Received from Daniel Jones', date: 'Aug 03, 2025', amount: '+$75.00', status: 'Completed', debit: false },
  { id: '6', type: 'Bill Pay', desc: 'Internet Service', date: 'Jul 30, 2025', amount: '-$89.99', status: 'Completed', debit: true },
  { id: '7', type: 'Wire', desc: 'Wire to SageTech Corp', date: 'Jul 25, 2025', amount: '-$3,000.00', status: 'Completed', debit: true },
];

interface Props { onBack: () => void; }

export default function SeeActivity({ onBack }: Props) {
  return (
    <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", background: '#f0f4f8', overflow: 'hidden' }}>
      {/* Header */}
      <div style={{ background: '#fff', padding: '16px 20px', display: 'flex', alignItems: 'center', gap: 14, borderBottom: '1px solid #eee', flexShrink: 0 }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer' }}>
          <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
            <polyline points="14,3 7,11 14,19" stroke="#333" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
        <span style={{ fontWeight: 700, fontSize: 17, color: '#111' }}>Activity</span>
      </div>
      <div style={{ flex: 1, overflowY: 'auto', padding: 16, paddingBottom: 100 }}>
        <div style={{ background: '#fff', borderRadius: 12, overflow: 'hidden', boxShadow: '0 2px 8px rgba(0,0,0,0.06)' }}>
          {ACTIVITIES.map((a, i) => (
            <div key={a.id}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '16px 20px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                  <div style={{
                    width: 40, height: 40, borderRadius: '50%',
                    background: a.debit ? '#fff0f0' : '#f0fff4',
                    display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
                  }}>
                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                      {a.debit
                        ? <path d="M9 3v12M9 15l-4-4M9 15l4-4" stroke="#e53e3e" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
                        : <path d="M9 15V3M9 3l-4 4M9 3l4 4" stroke="#22c55e" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />}
                    </svg>
                  </div>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 600, color: '#111' }}>{a.type}</div>
                    <div style={{ fontSize: 12, color: '#888', marginTop: 2 }}>{a.desc}</div>
                    <div style={{ fontSize: 11, color: '#aaa', marginTop: 1 }}>{a.date} &bull; {a.status}</div>
                  </div>
                </div>
                <div style={{ fontSize: 15, fontWeight: 700, color: a.debit ? '#e53e3e' : '#22c55e' }}>{a.amount}</div>
              </div>
              {i < ACTIVITIES.length - 1 && <div style={{ borderTop: '1px solid #f0f0f0', margin: '0 16px' }} />}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
