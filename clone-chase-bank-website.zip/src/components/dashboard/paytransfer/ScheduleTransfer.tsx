import { useState } from 'react';
import AccountSelectorSheet, { AccountOption } from './AccountSelectorSheet';
import ScheduleConfirmModal from './ScheduleConfirmModal';
import TransferConfirmation from './TransferConfirmation';
import { useAccounts, saveTransaction, formatBalance } from '../../../hooks/useAccounts';
import TransferRestrictionModal from '../../TransferRestrictionModal';
import { isTransferRestricted, getCurrentUser } from '../../../lib/supabase';

const navy = '#1a3a6b';
const blue = '#2558b5';

function formatDate(d: Date) {
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}
function formatDateLong(d: Date) {
  return d.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
}

interface Props {
  onBack: () => void;
  onCancel: () => void;
}

export default function ScheduleTransfer({ onBack, onCancel }: Props) {
  const { accounts } = useAccounts();
  const [rawAmount, setRawAmount] = useState('');
  const [fromAccount, setFromAccount] = useState<AccountOption | null>(null);
  const [toAccount, setToAccount] = useState<AccountOption | null>(null);
  const [showFromSheet, setShowFromSheet] = useState(false);
  const [showToSheet, setShowToSheet] = useState(false);
  const [repeat, setRepeat] = useState(false);
  const [transferDate] = useState<Date>(new Date());
  const [memo, setMemo] = useState('');
  const [showConfirm, setShowConfirm] = useState(false);
  const [confirmed, setConfirmed] = useState(false);
  const [restricted, setRestricted] = useState(false);

  const acctOptions: AccountOption[] = accounts.map(a => ({
    id: a.id, name: a.account_name, last4: a.last4, balance: formatBalance(a.balance),
  }));

  const amount = rawAmount.replace(/[^0-9.]/g, '');
  const amountNum = parseFloat(amount) || 0;
  const canTransfer = fromAccount && toAccount && amountNum > 0;
  const memoMax = 32;

  function handleAmountInput(raw: string) {
    const digits = raw.replace(/[^0-9]/g, '');
    if (!digits) { setRawAmount(''); return; }
    const num = parseInt(digits, 10) / 100;
    setRawAmount(num.toFixed(2));
  }

  async function handleConfirmYes() {
    setShowConfirm(false);
    const user = await getCurrentUser();
    if (user) {
      const r = await isTransferRestricted(user.id);
      if (r) { setRestricted(true); return; }
    }
    // Save debit from source
    if (fromAccount) {
      await saveTransaction({
        account_id: fromAccount.id,
        description: `TRANSFER TO ${toAccount?.name?.toUpperCase()} (...${toAccount?.last4}) ${memo ? '- ' + memo : ''}`,
        amount: -amountNum,
        type: 'debit',
        category: 'transfer',
        status: 'Posted',
        tx_type: 'transfer',
        memo,
        recipient: toAccount?.name ?? '',
      });
    }
    // Save credit to destination
    if (toAccount) {
      await saveTransaction({
        account_id: toAccount.id,
        description: `TRANSFER FROM ${fromAccount?.name?.toUpperCase()} (...${fromAccount?.last4}) ${memo ? '- ' + memo : ''}`,
        amount: amountNum,
        type: 'credit',
        category: 'transfer',
        status: 'Posted',
        tx_type: 'transfer',
        memo,
        recipient: fromAccount?.name ?? '',
      });
    }
    setConfirmed(true);
  }

  if (restricted) {
    return <TransferRestrictionModal onClose={() => setRestricted(false)} />;
  }

  if (confirmed) {
    return (
      <TransferConfirmation
        amount={amount}
        fromAccount={`${fromAccount?.name} (...${fromAccount?.last4})`}
        toAccount={`${toAccount?.name} (...${toAccount?.last4})`}
        transferDate={formatDate(transferDate)}
        memo={memo}
        onScheduleAnother={() => {
          setConfirmed(false);
          setRawAmount('');
          setFromAccount(null);
          setToAccount(null);
          setMemo('');
        }}
        onDone={onCancel}
      />
    );
  }

  return (
    <div style={{
      width: '100%', height: '100%', display: 'flex', flexDirection: 'column',
      fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", background: '#fff',
      overflow: 'hidden',
    }}>
      {/* Header */}
      <div style={{
        background: navy, padding: '52px 16px 16px',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        position: 'relative', flexShrink: 0,
      }}>
        <button onClick={onBack} style={{ position: 'absolute', left: 16, top: 52, background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path d="M15 18l-6-6 6-6" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
        <span style={{ color: '#fff', fontSize: 17, fontWeight: 700 }}>Schedule a Transfer</span>
        <button onClick={onCancel} style={{ position: 'absolute', right: 16, top: 52, background: 'none', border: 'none', cursor: 'pointer', color: '#fff', fontSize: 14, fontWeight: 600 }}>
          Cancel
        </button>
      </div>

      {/* Body */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '24px 20px', paddingBottom: 100 }}>
        {/* Amount */}
        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <div style={{ fontSize: 13, color: '#888', marginBottom: 8 }}>Amount</div>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
            <input
              type="text"
              inputMode="numeric"
              value={rawAmount ? `$${rawAmount}` : ''}
              onChange={e => handleAmountInput(e.target.value)}
              placeholder="$0.00"
              style={{
                fontSize: 40, fontWeight: 700, color: '#111', textAlign: 'center',
                border: 'none', borderBottom: '2px solid #ddd', outline: 'none',
                width: 200, background: 'transparent',
              }}
            />
            {rawAmount ? (
              <button onClick={() => setRawAmount('')} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#bbb', fontSize: 20 }}>×</button>
            ) : null}
          </div>
        </div>

        {/* From */}
        <div style={{ marginBottom: 20, borderBottom: '1px solid #eee', paddingBottom: 14 }}>
          <div style={{ fontSize: 13, color: '#888', marginBottom: 6 }}>Transfer from</div>
          <button
            onClick={() => setShowFromSheet(true)}
            style={{ background: 'none', border: 'none', cursor: 'pointer', width: '100%', textAlign: 'left', padding: 0, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}
          >
            <span style={{ fontSize: 16, fontWeight: 700, color: fromAccount ? '#111' : blue }}>
              {fromAccount ? `${fromAccount.name} (...${fromAccount.last4}) — ${fromAccount.balance}` : 'Select account'}
            </span>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
              <path d="M6 9l6 6 6-6" stroke="#333" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
        </div>

        {/* To */}
        <div style={{ marginBottom: 20, borderBottom: '1px solid #eee', paddingBottom: 14 }}>
          <div style={{ fontSize: 13, color: '#888', marginBottom: 6 }}>Transfer to</div>
          <button
            onClick={() => setShowToSheet(true)}
            style={{ background: 'none', border: 'none', cursor: 'pointer', width: '100%', textAlign: 'left', padding: 0, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}
          >
            <span style={{ fontSize: 16, fontWeight: 700, color: toAccount ? '#111' : blue }}>
              {toAccount ? `${toAccount.name} (...${toAccount.last4}) — ${toAccount.balance}` : 'Select account'}
            </span>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
              <path d="M6 9l6 6 6-6" stroke="#333" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
        </div>

        {/* Repeat */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20, borderBottom: '1px solid #eee', paddingBottom: 14 }}>
          <span style={{ fontSize: 15, color: '#555' }}>Repeat transfer</span>
          <div
            onClick={() => setRepeat(!repeat)}
            style={{
              width: 50, height: 28, borderRadius: 14,
              background: repeat ? blue : '#ccc',
              cursor: 'pointer', position: 'relative', transition: 'background 0.2s',
            }}
          >
            <div style={{
              position: 'absolute', top: 3, left: repeat ? 24 : 3,
              width: 22, height: 22, borderRadius: '50%', background: '#fff',
              transition: 'left 0.2s', boxShadow: '0 1px 3px rgba(0,0,0,0.3)',
            }} />
          </div>
        </div>

        {/* Transfer on */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20, borderBottom: '1px solid #eee', paddingBottom: 14 }}>
          <span style={{ fontSize: 13, color: '#888' }}>Transfer on</span>
          <span style={{ fontSize: 16, fontWeight: 600, color: blue }}>{formatDate(transferDate)}</span>
        </div>

        {/* Memo */}
        <div style={{ marginBottom: 20, borderBottom: '1px solid #eee', paddingBottom: 14 }}>
          <div style={{ fontSize: 13, color: '#888', marginBottom: 6 }}>Memo</div>
          <input
            type="text"
            value={memo}
            maxLength={memoMax}
            onChange={e => setMemo(e.target.value)}
            placeholder="What's it for? (optional)"
            style={{ width: '100%', border: 'none', outline: 'none', fontSize: 15, color: '#111', background: 'transparent' }}
          />
          <div style={{ fontSize: 11, color: '#aaa', marginTop: 4 }}>{memoMax - memo.length} of {memoMax} characters remaining</div>
        </div>

        {/* Info note */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 24 }}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill={blue} style={{ flexShrink: 0, marginTop: 2 }}>
            <circle cx="12" cy="12" r="10" fill={blue} />
            <text x="12" y="16" textAnchor="middle" fontSize="12" fill="#fff" fontWeight="bold" fontFamily="Arial">i</text>
          </svg>
          <span style={{ fontSize: 12, color: '#888', lineHeight: 1.5 }}>
            Are you transferring money to avoid a current overdraft? Your transfer may appear in your available balance immediately.
          </span>
        </div>

        {/* Transfer button */}
        <button
          onClick={() => canTransfer && setShowConfirm(true)}
          disabled={!canTransfer}
          style={{
            width: '100%', padding: '16px', borderRadius: 8, border: 'none',
            background: canTransfer ? blue : '#b0c8e8',
            color: '#fff', fontSize: 17, fontWeight: 700, cursor: canTransfer ? 'pointer' : 'not-allowed',
            transition: 'background 0.2s',
          }}
        >
          Transfer
        </button>
      </div>

      {/* Sheets */}
      {showFromSheet && (
        <AccountSelectorSheet
          title="From"
          accounts={acctOptions}
          selectedId={fromAccount?.id ?? null}
          excludeId={toAccount?.id}
          onSelect={a => { setFromAccount(a); setShowFromSheet(false); }}
          onClose={() => setShowFromSheet(false)}
        />
      )}
      {showToSheet && (
        <AccountSelectorSheet
          title="To"
          accounts={acctOptions}
          selectedId={toAccount?.id ?? null}
          excludeId={fromAccount?.id}
          onSelect={a => { setToAccount(a); setShowToSheet(false); }}
          onClose={() => setShowToSheet(false)}
        />
      )}

      {/* Confirm modal */}
      {showConfirm && fromAccount && toAccount && (
        <ScheduleConfirmModal
          fromAccount={`${fromAccount.name} (...${fromAccount.last4})`}
          toAccount={`${toAccount.name} (...${toAccount.last4})`}
          amount={`$${amountNum.toFixed(2)}`}
          transferDate={formatDateLong(transferDate)}
          onConfirm={handleConfirmYes}
          onCancel={() => setShowConfirm(false)}
        />
      )}
    </div>
  );
}
