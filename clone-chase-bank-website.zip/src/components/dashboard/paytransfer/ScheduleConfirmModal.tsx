const blue = '#2558b5';

interface Props {
  fromAccount: string;
  toAccount: string;
  amount: string;
  transferDate: string;
  onConfirm: () => void;
  onCancel: () => void;
}

export default function ScheduleConfirmModal({ fromAccount, toAccount, amount, transferDate, onConfirm, onCancel }: Props) {
  return (
    <div style={{
      position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', zIndex: 1000,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: '0 32px', fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
    }}>
      <div style={{
        background: '#fff', borderRadius: 12, padding: '28px 24px',
        width: '100%', maxWidth: 360, boxShadow: '0 8px 40px rgba(0,0,0,0.18)',
      }}>
        {/* Title */}
        <div style={{ fontSize: 17, fontWeight: 700, color: '#111', textAlign: 'center', marginBottom: 8 }}>
          Schedule this transfer?
        </div>

        {/* Details */}
        <div style={{ fontSize: 13, color: '#666', textAlign: 'center', marginBottom: 20, lineHeight: 1.8 }}>
          <div>Transfer From: <strong style={{ color: '#111' }}>{fromAccount}</strong></div>
          <div>Transfer To: <strong style={{ color: '#111' }}>{toAccount}</strong></div>
          <div>Amount: <strong style={{ color: '#111' }}>${parseFloat(amount || '0').toFixed(2)}</strong></div>
          <div>Transfer on: <strong style={{ color: '#111' }}>{transferDate}</strong></div>
        </div>

        <div style={{ borderTop: '1px solid #eee', marginBottom: 0 }} />

        {/* Yes button */}
        <button
          onClick={onConfirm}
          style={{
            width: '100%', background: 'none', border: 'none', cursor: 'pointer',
            padding: '18px 0', fontSize: 17, fontWeight: 600, color: blue, textAlign: 'center',
          }}
        >
          Yes
        </button>

        <div style={{ borderTop: '1px solid #eee' }} />

        {/* No button */}
        <button
          onClick={onCancel}
          style={{
            width: '100%', background: 'none', border: 'none', cursor: 'pointer',
            padding: '18px 0', fontSize: 17, fontWeight: 600, color: blue, textAlign: 'center',
          }}
        >
          No
        </button>
      </div>
    </div>
  );
}
