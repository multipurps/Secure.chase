import { useEffect, useRef, useState } from 'react';

const blue = '#2558b5';
const navy = '#1a3a6b';

interface Props {
  amount: string;
  fromAccount: string;
  toAccount: string;
  transferDate: string;
  memo: string;
  onScheduleAnother: () => void;
  onDone: () => void;
}

export default function TransferConfirmation({ amount, fromAccount, toAccount, transferDate, memo, onScheduleAnother, onDone }: Props) {
  const [phase, setPhase] = useState<'spinner' | 'check' | 'content'>('spinner');
  const [checkUp, setCheckUp] = useState(false);
  const [contentVisible, setContentVisible] = useState(false);
  const [btnVisible, setBtnVisible] = useState(false);
  const txnRef = useRef(Math.floor(1000000000 + Math.random() * 9000000000).toString());

  useEffect(() => {
    // Random wait between 1–2s
    const wait = 1000 + Math.random() * 1000;
    const t1 = setTimeout(() => {
      setPhase('check');
      setTimeout(() => {
        setCheckUp(true);
        setTimeout(() => {
          setPhase('content');
          setContentVisible(true);
          setTimeout(() => setBtnVisible(true), 800);
        }, 350 + 200);
      }, 300 + 200);
    }, wait);
    return () => clearTimeout(t1);
  }, []);

  return (
    <div style={{
      width: '100%', height: '100%', display: 'flex', flexDirection: 'column',
      background: '#fff', fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
      overflow: 'hidden',
    }}>
      {/* Header */}
      <div style={{
        background: navy, padding: '16px 20px',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        position: 'relative', flexShrink: 0,
      }}>
        <span style={{ color: '#fff', fontSize: 15, fontWeight: 700, letterSpacing: 1, textTransform: 'uppercase' }}>Confirmation</span>
        <button style={{ position: 'absolute', right: 16, background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
            <path d="M4 4l12 12M16 4L4 16" stroke="#fff" strokeWidth="2" strokeLinecap="round" />
          </svg>
        </button>
      </div>

      {/* Body */}
      <div style={{ flex: 1, overflowY: 'auto', paddingBottom: 120 }}>
        {/* Animation area */}
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', paddingTop: 50 }}>
          {/* Spinner */}
          {phase === 'spinner' && (
            <div style={{ width: 64, height: 64 }}>
              <style>{`@keyframes spin{to{transform:rotate(360deg)}} .pt-spin{animation:spin 0.9s linear infinite}`}</style>
              <svg className="pt-spin" width="64" height="64" viewBox="0 0 64 64" fill="none">
                <circle cx="32" cy="32" r="28" stroke="#e0e0e0" strokeWidth="5" />
                <path d="M60 32 A28 28 0 0 0 32 4" stroke={blue} strokeWidth="5" strokeLinecap="round" />
              </svg>
            </div>
          )}

          {/* Checkmark */}
          {(phase === 'check' || phase === 'content') && (
            <div style={{
              transform: checkUp ? 'translateY(-40px)' : 'translateY(0)',
              transition: 'transform 0.35s ease-out',
            }}>
              <style>{`
                @keyframes scaleIn{0%{transform:scale(0)}70%{transform:scale(1.1)}100%{transform:scale(1)}}
                @keyframes drawCheck{from{stroke-dashoffset:40}to{stroke-dashoffset:0}}
                .pt-check-circle{animation:scaleIn 0.5s ease-out forwards}
                .pt-check-stroke{stroke-dasharray:40;stroke-dashoffset:40;animation:drawCheck 0.4s 0.2s ease-out forwards}
              `}</style>
              <svg className="pt-check-circle" width="64" height="64" viewBox="0 0 64 64" fill="none">
                <circle cx="32" cy="32" r="30" fill="#22c55e" />
                <polyline className="pt-check-stroke" points="17,33 27,43 48,22" stroke="#fff" strokeWidth="4.5" strokeLinecap="round" strokeLinejoin="round" fill="none" />
              </svg>
            </div>
          )}

          {/* Content */}
          {phase === 'content' && (
            <div style={{
              opacity: contentVisible ? 1 : 0, transform: contentVisible ? 'translateY(0)' : 'translateY(20px)',
              transition: 'opacity 0.4s ease, transform 0.4s ease',
              width: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center',
              padding: '0 20px', marginTop: 8,
            }}>
              {/* Description */}
              <div style={{ fontSize: 16, color: '#555', textAlign: 'center', marginBottom: 6 }}>
                You scheduled a transfer of
              </div>

              {/* Amount */}
              <div style={{ fontSize: 36, fontWeight: 800, color: '#111', textAlign: 'center', marginBottom: 24 }}>
                ${parseFloat(amount || '0').toFixed(2)}
              </div>

              {/* Details card */}
              <div style={{ width: '100%', background: '#fff', borderRadius: 12, overflow: 'hidden', border: '1px solid #eee' }}>
                {[
                  { label: 'Transaction number', value: txnRef.current },
                  { label: 'Transfer from', value: fromAccount, bold: true },
                  { label: 'Transfer to', value: toAccount, bold: true },
                  { label: 'Transfer date', value: transferDate },
                  { label: 'Status', value: 'Funded' },
                  { label: 'Memo', value: memo || 'None' },
                ].map((row, i, arr) => (
                  <div key={i}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '14px 16px', gap: 12 }}>
                      <span style={{ fontSize: 14, color: '#666' }}>{row.label}</span>
                      <span style={{ fontSize: 14, color: '#111', fontWeight: row.bold ? 700 : 400, textAlign: 'right', flex: 1, wordBreak: 'break-all' }}>{row.value}</span>
                    </div>
                    {i < arr.length - 1 && <div style={{ borderTop: '1px solid #f0f0f0' }} />}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Bottom buttons */}
      {btnVisible && (
        <div style={{
          position: 'fixed', bottom: 70, left: 0, right: 0, padding: '16px 20px',
          background: '#fff', borderTop: '1px solid #eee', display: 'flex', flexDirection: 'column', gap: 10,
          opacity: btnVisible ? 1 : 0, transition: 'opacity 0.4s ease',
        }}>
          <button
            onClick={onScheduleAnother}
            style={{ width: '100%', background: blue, color: '#fff', border: 'none', borderRadius: 8, padding: '16px', fontSize: 16, fontWeight: 600, cursor: 'pointer' }}
          >
            Schedule another transfer
          </button>
          <button
            onClick={onDone}
            style={{ width: '100%', background: '#f0f0f0', color: '#111', border: 'none', borderRadius: 8, padding: '16px', fontSize: 16, fontWeight: 600, cursor: 'pointer' }}
          >
            Done
          </button>
        </div>
      )}
    </div>
  );
}
