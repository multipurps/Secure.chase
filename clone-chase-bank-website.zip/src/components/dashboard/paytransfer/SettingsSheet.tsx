import { useEffect, useRef } from 'react';

interface Props {
  onClose: () => void;
}

export default function SettingsSheet({ onClose }: Props) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const t = setTimeout(() => {
      if (ref.current) ref.current.style.transform = 'translateY(0)';
    }, 10);
    return () => clearTimeout(t);
  }, []);

  function dismiss() {
    if (ref.current) ref.current.style.transform = 'translateY(100%)';
    setTimeout(onClose, 320);
  }

  return (
    <div
      onClick={dismiss}
      style={{
        position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.45)', zIndex: 999,
        display: 'flex', alignItems: 'flex-end',
      }}
    >
      <div
        ref={ref}
        onClick={e => e.stopPropagation()}
        style={{
          width: '100%', background: '#fff', borderRadius: '16px 16px 0 0',
          transform: 'translateY(100%)', transition: 'transform 0.3s ease',
          paddingBottom: 32, fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
        }}
      >
        {/* Drag handle */}
        <div style={{ display: 'flex', justifyContent: 'center', padding: '12px 0 0' }}>
          <div style={{ width: 40, height: 4, borderRadius: 2, background: '#ccc' }} />
        </div>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '16px 20px 12px', position: 'relative' }}>
          <span style={{ fontSize: 17, fontWeight: 700, color: '#111' }}>Settings</span>
          <button onClick={dismiss} style={{ position: 'absolute', right: 20, background: 'none', border: 'none', cursor: 'pointer', fontSize: 22, color: '#888', lineHeight: 1 }}>&times;</button>
        </div>
        <div style={{ borderTop: '1px solid #eee' }} />
        {/* Zelle settings row */}
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          <ZelleSettingsContent />
          <div style={{ borderTop: '1px solid #eee' }} />
          <ExternalAccountRow />
        </div>
      </div>
    </div>
  );
}

function ZelleSettingsContent() {
  const purple = '#6d1ed4';
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '18px 20px', cursor: 'pointer' }}>
      <div>
        <div style={{ fontSize: 15, color: '#111', fontWeight: 400 }}>
          <span style={{ fontStyle: 'italic', color: purple, fontWeight: 700 }}>Zelle</span>
          <span style={{ fontStyle: 'italic', color: purple, fontWeight: 700, fontSize: 11, verticalAlign: 'super' }}>®</span>
          <span> settings</span>
        </div>
        <div style={{ fontSize: 12, color: '#888', marginTop: 3 }}>Enrolled email, limits &amp; notifications</div>
      </div>
      <ChevronRight />
    </div>
  );
}

function ExternalAccountRow() {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '18px 20px', cursor: 'pointer' }}>
      <div>
        <div style={{ fontSize: 15, color: '#111' }}>External account transfers</div>
        <div style={{ fontSize: 12, color: '#888', marginTop: 3 }}>Link or remove external bank accounts</div>
      </div>
      <ChevronRight />
    </div>
  );
}

function ChevronRight() {
  return (
    <svg width="9" height="16" viewBox="0 0 9 16" fill="none">
      <polyline points="1,1 8,8 1,15" stroke="#bbb" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
