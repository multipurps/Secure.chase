import { useState } from 'react';

const blue = '#2558b5';

const PAYEES = [
  { id: 'elec', name: 'Electric Company', account: 'Acc: ...4521', due: 'Aug 15', amount: '$142.00' },
  { id: 'inet', name: 'Internet Service', account: 'Acc: ...7832', due: 'Aug 18', amount: '$89.99' },
  { id: 'water', name: 'Water Bill', account: 'Acc: ...2201', due: 'Aug 22', amount: '$58.40' },
  { id: 'cc', name: 'Chase Credit Card', account: 'Acc: ...1234', due: 'Aug 25', amount: '$350.00' },
];

interface Props { onBack: () => void; }

export default function PayBillsPage({ onBack }: Props) {
  const [selected, setSelected] = useState<string | null>(null);
  const [payAmount, setPayAmount] = useState('');
  const [success, setSuccess] = useState(false);

  const payee = PAYEES.find(p => p.id === selected);

  if (success && payee) {
    return (
      <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', background: '#fff', fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", padding: 32 }}>
        <svg width="64" height="64" viewBox="0 0 64 64" fill="none" style={{ marginBottom: 20 }}>
          <circle cx="32" cy="32" r="30" fill="#22c55e" />
          <polyline points="17,33 27,43 48,22" stroke="#fff" strokeWidth="4.5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        <div style={{ fontSize: 22, fontWeight: 700, color: '#111', marginBottom: 8 }}>Payment Sent!</div>
        <div style={{ fontSize: 15, color: '#666', textAlign: 'center', marginBottom: 8 }}>
          ${parseFloat(payAmount || payee.amount.replace('$', '')).toFixed(2)} paid to {payee.name}
        </div>
        <button onClick={() => { setSuccess(false); setSelected(null); setPayAmount(''); }} style={{ marginTop: 24, background: blue, color: '#fff', border: 'none', borderRadius: 8, padding: '14px 40px', fontSize: 16, fontWeight: 600, cursor: 'pointer' }}>Done</button>
      </div>
    );
  }

  return (
    <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", background: '#f0f4f8', overflow: 'hidden' }}>
      {/* Header */}
      <div style={{ background: '#fff', padding: '16px 20px', display: 'flex', alignItems: 'center', gap: 14, borderBottom: '1px solid #eee', flexShrink: 0 }}>
        <button onClick={selected ? () => setSelected(null) : onBack} style={{ background: 'none', border: 'none', cursor: 'pointer' }}>
          <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
            <polyline points="14,3 7,11 14,19" stroke="#333" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
        <span style={{ fontWeight: 700, fontSize: 17, color: '#111' }}>{selected ? payee?.name : 'Pay Bills'}</span>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: 16, paddingBottom: 100 }}>
        {!selected ? (
          <>
            <div style={{ fontSize: 13, color: '#888', marginBottom: 12, fontWeight: 500 }}>SELECT A PAYEE</div>
            <div style={{ background: '#fff', borderRadius: 12, overflow: 'hidden', boxShadow: '0 2px 8px rgba(0,0,0,0.06)' }}>
              {PAYEES.map((p, i) => (
                <div key={p.id}>
                  <button onClick={() => setSelected(p.id)} style={{ width: '100%', background: 'none', border: 'none', cursor: 'pointer', display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '16px 20px', textAlign: 'left' }}>
                    <div>
                      <div style={{ fontSize: 15, fontWeight: 600, color: '#111' }}>{p.name}</div>
                      <div style={{ fontSize: 12, color: '#888', marginTop: 2 }}>{p.account} &bull; Due {p.due}</div>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <div style={{ fontSize: 15, fontWeight: 600, color: '#111' }}>{p.amount}</div>
                      <svg width="9" height="16" viewBox="0 0 9 16" fill="none" style={{ marginTop: 2 }}>
                        <polyline points="1,1 8,8 1,15" stroke="#bbb" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </div>
                  </button>
                  {i < PAYEES.length - 1 && <div style={{ borderTop: '1px solid #f0f0f0', margin: '0 16px' }} />}
                </div>
              ))}
            </div>
            <button style={{ width: '100%', marginTop: 16, background: blue, color: '#fff', border: 'none', borderRadius: 8, padding: '16px', fontSize: 16, fontWeight: 600, cursor: 'pointer' }}>
              Add a payee
            </button>
          </>
        ) : payee && (
          <div style={{ background: '#fff', borderRadius: 12, padding: 24, boxShadow: '0 2px 8px rgba(0,0,0,0.06)' }}>
            <div style={{ fontSize: 13, color: '#888', marginBottom: 4 }}>Pay to</div>
            <div style={{ fontSize: 17, fontWeight: 700, color: '#111', marginBottom: 4 }}>{payee.name}</div>
            <div style={{ fontSize: 13, color: '#888', marginBottom: 24 }}>{payee.account} &bull; Due {payee.due}</div>
            <div style={{ fontSize: 13, color: '#888', marginBottom: 8 }}>Amount</div>
            <input
              type="text"
              inputMode="decimal"
              placeholder={payee.amount}
              value={payAmount}
              onChange={e => setPayAmount(e.target.value)}
              style={{ width: '100%', fontSize: 28, fontWeight: 700, border: 'none', borderBottom: '2px solid #eee', outline: 'none', paddingBottom: 8, color: '#111', marginBottom: 24 }}
            />
            <div style={{ fontSize: 13, color: '#888', marginBottom: 8 }}>Pay from</div>
            <div style={{ fontSize: 15, fontWeight: 600, color: blue, borderBottom: '1px solid #eee', paddingBottom: 12, marginBottom: 24 }}>CHASE CHECKING (...3545) — $900.00</div>
            <div style={{ fontSize: 13, color: '#888', marginBottom: 8 }}>Send on</div>
            <div style={{ fontSize: 15, fontWeight: 600, color: blue, borderBottom: '1px solid #eee', paddingBottom: 12, marginBottom: 32 }}>Today, {new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</div>
            <button
              onClick={() => setSuccess(true)}
              style={{ width: '100%', background: blue, color: '#fff', border: 'none', borderRadius: 8, padding: '16px', fontSize: 16, fontWeight: 600, cursor: 'pointer' }}
            >
              Pay Now
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
