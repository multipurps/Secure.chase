import { useState } from 'react';

const blue = '#2558b5';
const purple = '#6d1ed4';

const RECIPIENTS = [
  { id: '1', name: 'Amber Davis', contact: 'adavis@gmail.com', type: 'Zelle' },
  { id: '2', name: 'Daniel Jones', contact: '(555) 345-1123', type: 'Zelle' },
  { id: '3', name: 'Travis Taylor', contact: 'ttaylor@gmail.com', type: 'Zelle' },
  { id: '4', name: 'Brinn Lo', contact: 'brinnlo@gmail.com', type: 'Zelle' },
  { id: '5', name: 'Electric Company', contact: 'Acc: ...4521', type: 'Bill Pay' },
  { id: '6', name: 'Internet Service', contact: 'Acc: ...7832', type: 'Bill Pay' },
];

interface Props { onBack: () => void; }

export default function ManageRecipients({ onBack }: Props) {
  const [deleted, setDeleted] = useState<string[]>([]);
  const visible = RECIPIENTS.filter(r => !deleted.includes(r.id));

  return (
    <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", background: '#f0f4f8', overflow: 'hidden' }}>
      <div style={{ background: '#fff', padding: '16px 20px', display: 'flex', alignItems: 'center', gap: 14, borderBottom: '1px solid #eee', flexShrink: 0 }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer' }}>
          <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
            <polyline points="14,3 7,11 14,19" stroke="#333" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
        <span style={{ fontWeight: 700, fontSize: 17, color: '#111' }}>Manage Recipients</span>
      </div>
      <div style={{ flex: 1, overflowY: 'auto', padding: 16, paddingBottom: 100 }}>
        {['Zelle', 'Bill Pay'].map(type => {
          const group = visible.filter(r => r.type === type);
          if (!group.length) return null;
          return (
            <div key={type} style={{ marginBottom: 20 }}>
              <div style={{ fontSize: 13, color: '#888', fontWeight: 600, marginBottom: 8, paddingLeft: 4 }}>
                {type === 'Zelle'
                  ? <><span style={{ color: purple, fontStyle: 'italic', fontWeight: 700 }}>Zelle</span><span style={{ color: purple, fontStyle: 'italic', fontWeight: 700, fontSize: 10, verticalAlign: 'super' }}>®</span> recipients</>
                  : 'Bill Pay recipients'}
              </div>
              <div style={{ background: '#fff', borderRadius: 12, overflow: 'hidden', boxShadow: '0 2px 8px rgba(0,0,0,0.06)' }}>
                {group.map((r, i) => (
                  <div key={r.id}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '14px 20px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                        <div style={{ width: 40, height: 40, borderRadius: '50%', background: '#e8f0fe', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 16, color: blue }}>
                          {r.name[0]}
                        </div>
                        <div>
                          <div style={{ fontSize: 14, fontWeight: 600, color: '#111' }}>{r.name}</div>
                          <div style={{ fontSize: 12, color: '#888', marginTop: 2 }}>{r.contact}</div>
                        </div>
                      </div>
                      <button
                        onClick={() => setDeleted(d => [...d, r.id])}
                        style={{ background: 'none', border: '1px solid #e53e3e', borderRadius: 6, cursor: 'pointer', color: '#e53e3e', fontSize: 12, fontWeight: 600, padding: '6px 12px' }}
                      >
                        Remove
                      </button>
                    </div>
                    {i < group.length - 1 && <div style={{ borderTop: '1px solid #f0f0f0', margin: '0 16px' }} />}
                  </div>
                ))}
              </div>
            </div>
          );
        })}
        <button style={{ width: '100%', background: blue, color: '#fff', border: 'none', borderRadius: 8, padding: '15px', fontSize: 15, fontWeight: 600, cursor: 'pointer', marginTop: 8 }}>
          Add a recipient
        </button>
      </div>
    </div>
  );
}
