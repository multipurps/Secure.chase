import { useEffect, useRef } from 'react';
import { useAccounts, formatBalance } from '../../../hooks/useAccounts';

export interface AccountOption {
  id: string;
  name: string;
  last4: string;
  balance: string;
}

interface Props {
  title: 'From' | 'To';
  accounts?: AccountOption[];       // optional override (use Supabase if not provided)
  selectedId: string | null;
  excludeId?: string | null;
  onSelect: (account: AccountOption) => void;
  onClose: () => void;
  filterTypes?: string[];           // e.g. ['checking','savings']
}

const blue = '#2558b5';

export default function AccountSelectorSheet({
  title, accounts: propAccounts, selectedId, excludeId, onSelect, onClose, filterTypes,
}: Props) {
  const ref = useRef<HTMLDivElement>(null);
  const { accounts: supabaseAccounts } = useAccounts();

  useEffect(() => {
    const t = setTimeout(() => {
      if (ref.current) ref.current.style.transform = 'translateY(0)';
    }, 10);
    return () => clearTimeout(t);
  }, []);

  function dismiss(cb?: () => void) {
    if (ref.current) ref.current.style.transform = 'translateY(100%)';
    setTimeout(() => { onClose(); cb?.(); }, 320);
  }

  // Build the account list — prefer Supabase data
  const allAccounts: AccountOption[] = propAccounts
    ? propAccounts
    : supabaseAccounts
        .filter(a => !filterTypes || filterTypes.includes(a.account_type))
        .map(a => ({
          id: a.id,
          name: a.account_name,
          last4: a.last4,
          balance: formatBalance(a.balance),
        }));

  const available = allAccounts.filter(a => a.id !== excludeId);

  return (
    <div
      onClick={() => dismiss()}
      style={{
        position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.45)', zIndex: 9999,
        display: 'flex', alignItems: 'flex-end',
      }}
    >
      <div
        ref={ref}
        onClick={e => e.stopPropagation()}
        style={{
          width: '100%', background: '#fff', borderRadius: '16px 16px 0 0',
          transform: 'translateY(100%)', transition: 'transform 0.3s ease',
          paddingBottom: 40, fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
          maxHeight: '70vh', display: 'flex', flexDirection: 'column',
        }}
      >
        {/* Handle */}
        <div style={{ display: 'flex', justifyContent: 'center', padding: '12px 0 0', flexShrink: 0 }}>
          <div style={{ width: 40, height: 4, borderRadius: 2, background: '#ccc' }} />
        </div>
        {/* Header */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '12px 16px', borderBottom: '1px solid #f0f0f0', flexShrink: 0,
        }}>
          <span style={{ fontSize: 17, fontWeight: 700, color: '#111' }}>{title} account</span>
          <button onClick={() => dismiss()} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 22, color: '#999', padding: 4 }}>×</button>
        </div>
        {/* Section label */}
        <div style={{ background: '#f5f5f5', padding: '8px 16px', flexShrink: 0 }}>
          <span style={{ fontSize: 12, fontWeight: 600, color: '#888', textTransform: 'uppercase', letterSpacing: 1 }}>
            Internal account
          </span>
        </div>
        {/* Accounts */}
        <div style={{ overflowY: 'auto', flex: 1 }}>
          {available.length === 0 ? (
            <div style={{ padding: 24, textAlign: 'center', color: '#888', fontSize: 14 }}>
              No accounts available. Please add an account in Supabase.
            </div>
          ) : (
            available.map((a, i) => {
              const isSelected = a.id === selectedId;
              return (
                <div
                  key={a.id}
                  onClick={() => dismiss(() => onSelect(a))}
                  style={{
                    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                    padding: '14px 16px',
                    borderBottom: i < available.length - 1 ? '1px solid #f0f0f0' : 'none',
                    cursor: 'pointer',
                    background: isSelected ? '#f0f5ff' : '#fff',
                  }}
                >
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 15, color: '#111' }}>
                      {a.name} (...{a.last4})
                    </div>
                    <div style={{ fontSize: 13, color: '#888', marginTop: 2 }}>{a.balance}</div>
                  </div>
                  {isSelected ? (
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
                      <path d="M5 13l4 4L19 7" stroke={blue} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  ) : (
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                      <path d="M9 18l6-6-6-6" stroke="#ccc" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
