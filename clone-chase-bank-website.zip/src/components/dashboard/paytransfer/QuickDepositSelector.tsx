const blue = '#2558b5';

const DEMO_ACCOUNTS = [
  { id: 'chk1', name: 'CHASE CHECKING', last4: '3545', balance: '$900.00' },
  { id: 'sav1', name: 'CHASE SAVINGS', last4: '3546', balance: '$5,250.00' },
  { id: 'chk2', name: 'HIGH SCHOOL CHECKING', last4: '8721', balance: '$2,122.73' },
  { id: 'prem', name: 'PREMIER PLUS CKG', last4: '1234', balance: '$2,250.00' },
];

interface Props {
  onBack: () => void;
  onSelectAccount: (name: string, last4: string, balance: string) => void;
}

export default function QuickDepositSelector({ onBack, onSelectAccount }: Props) {
  return (
    <div style={{
      width: '100%', height: '100%', display: 'flex', flexDirection: 'column',
      fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", background: '#fff',
      overflow: 'hidden',
    }}>
      {/* Header */}
      <div style={{
        background: '#fff', padding: '16px 20px',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        position: 'relative', borderBottom: '1px solid #eee', flexShrink: 0,
      }}>
        <button onClick={onBack} style={{ position: 'absolute', left: 16, background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
          <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
            <polyline points="14,3 7,11 14,19" stroke="#333" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
        <span style={{ fontSize: 17, fontWeight: 700, color: '#111' }}>Chase QuickDeposit</span>
        <button onClick={onBack} style={{ position: 'absolute', right: 16, background: 'none', border: 'none', cursor: 'pointer', color: blue, fontSize: 14, fontWeight: 600 }}>Cancel</button>
      </div>

      {/* Body */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '32px 20px' }}>
        {/* Title */}
        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <span style={{ fontSize: 24, fontWeight: 400, color: '#111' }}>Choose an </span>
          <span style={{ fontSize: 24, fontWeight: 700, color: '#111' }}>account</span>
        </div>

        {/* Account list */}
        <div style={{ borderRadius: 12, overflow: 'hidden', border: '1px solid #eee' }}>
          {DEMO_ACCOUNTS.map((acc, i) => (
            <div key={acc.id}>
              <button
                onClick={() => onSelectAccount(acc.name, acc.last4, acc.balance)}
                style={{
                  width: '100%', background: 'none', border: 'none', cursor: 'pointer',
                  display: 'flex', flexDirection: 'column', alignItems: 'flex-start',
                  padding: '18px 20px', textAlign: 'left',
                }}
              >
                <div style={{ fontSize: 15, fontWeight: 600, color: '#111' }}>
                  {acc.name} (...{acc.last4})
                </div>
                <div style={{ fontSize: 13, color: '#888', marginTop: 4 }}>{acc.balance}</div>
              </button>
              {i < DEMO_ACCOUNTS.length - 1 && <div style={{ borderTop: '1px solid #f0f0f0', margin: '0 16px' }} />}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
