import { useState } from 'react';

const blue = '#2558b5';

interface Props { onBack: () => void; }

export default function WiresPage({ onBack }: Props) {
  const [form, setForm] = useState({ recipientName: '', bankName: '', routing: '', accountNum: '', amount: '', memo: '' });

  const allFilled = Object.entries(form).every(([k, v]) => k === 'memo' || v.trim() !== '');

  return (
    <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", background: '#fff', overflow: 'hidden' }}>
      <div style={{ background: '#fff', padding: '16px 20px', display: 'flex', alignItems: 'center', gap: 14, borderBottom: '1px solid #eee', flexShrink: 0 }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer' }}>
          <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
            <polyline points="14,3 7,11 14,19" stroke="#333" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
        <span style={{ fontWeight: 700, fontSize: 17, color: '#111' }}>Wires & Global Transfers</span>
      </div>
      <div style={{ flex: 1, overflowY: 'auto', padding: '24px 20px', paddingBottom: 120 }}>
        <div style={{ background: '#fff3cd', borderRadius: 8, padding: '12px 16px', marginBottom: 24, fontSize: 13, color: '#856404', lineHeight: 1.6 }}>
          Wire transfers are typically processed within 1–2 business days. International wires may take 3–5 business days.
        </div>
        {[
          { key: 'recipientName', label: 'Recipient name', placeholder: 'Full legal name' },
          { key: 'bankName', label: 'Recipient bank name', placeholder: 'e.g. Bank of America' },
          { key: 'routing', label: 'Routing number', placeholder: '9 digits', inputMode: 'numeric' as const },
          { key: 'accountNum', label: 'Account number', placeholder: 'Account number', inputMode: 'numeric' as const },
          { key: 'amount', label: 'Amount (USD)', placeholder: '$0.00', inputMode: 'decimal' as const },
          { key: 'memo', label: 'Memo (optional)', placeholder: 'Purpose of transfer' },
        ].map(field => (
          <div key={field.key} style={{ marginBottom: 24 }}>
            <div style={{ fontSize: 12, color: '#888', marginBottom: 6 }}>{field.label}</div>
            <input
              type="text"
              inputMode={field.inputMode}
              placeholder={field.placeholder}
              value={form[field.key as keyof typeof form]}
              onChange={e => setForm(f => ({ ...f, [field.key]: e.target.value }))}
              style={{ width: '100%', border: 'none', borderBottom: '1.5px solid #ddd', outline: 'none', fontSize: 15, color: '#111', padding: '6px 0', background: 'transparent' }}
            />
          </div>
        ))}
      </div>
      <div style={{ padding: '16px 20px', borderTop: '1px solid #eee', background: '#fff' }}>
        <button
          disabled={!allFilled}
          style={{ width: '100%', background: allFilled ? blue : '#a8c8f0', color: '#fff', border: 'none', borderRadius: 8, padding: '16px', fontSize: 16, fontWeight: 600, cursor: allFilled ? 'pointer' : 'not-allowed' }}
        >
          Review Wire Transfer
        </button>
      </div>
    </div>
  );
}
