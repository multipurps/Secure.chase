import { useState, useRef, useEffect } from 'react';
import DepositLimitsSheet from './DepositLimitsSheet';

const blue = '#2558b5';
const navy = '#1a3a6b';

interface Props {
  accountName: string;
  accountLast4: string;
  accountBalance: string;
  onBack: () => void;
  onCancel: () => void;
}

type View = 'form' | 'review' | 'confirm';

export default function CheckDepositForm({ accountName, accountLast4, accountBalance, onBack, onCancel }: Props) {
  const [view, setView] = useState<View>('form');
  const [rawAmount, setRawAmount] = useState('');
  const [frontPhoto, setFrontPhoto] = useState<string | null>(null);
  const [backPhoto, setBackPhoto] = useState<string | null>(null);
  const [showLimits, setShowLimits] = useState(false);
  const frontInput = useRef<HTMLInputElement>(null);
  const backInput = useRef<HTMLInputElement>(null);

  // Confirm animation states
  const [checkVisible, setCheckVisible] = useState(false);
  const [checkUp, setCheckUp] = useState(false);
  const [contentVisible, setContentVisible] = useState(false);

  useEffect(() => {
    if (view === 'confirm') {
      setTimeout(() => setCheckVisible(true), 100);
      setTimeout(() => setCheckUp(true), 700);
      setTimeout(() => setContentVisible(true), 1000);
    }
  }, [view]);

  const amount = rawAmount.replace(/[^0-9.]/g, '');
  const amountNum = parseFloat(amount) || 0;
  const displayAmount = amountNum > 0 ? `$${amountNum.toFixed(2)}` : '$0.00';
  // Next becomes active when amount > 0 AND front photo captured (back photo optional)
  const canNext = amountNum > 0 && amountNum <= 2000 && !!frontPhoto;

  function handleAmountInput(raw: string) {
    const digits = raw.replace(/[^0-9]/g, '');
    if (!digits) { setRawAmount(''); return; }
    const num = parseInt(digits, 10) / 100;
    setRawAmount(num.toFixed(2));
  }

  function handlePhoto(e: React.ChangeEvent<HTMLInputElement>, side: 'front' | 'back') {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      const result = ev.target?.result as string;
      if (side === 'front') setFrontPhoto(result);
      else setBackPhoto(result);
    };
    reader.readAsDataURL(file);
  }

  // ── REVIEW SCREEN ──
  if (view === 'review') {
    return (
      <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', background: '#fff', fontFamily: "'Helvetica Neue', Arial, sans-serif" }}>
        {/* Header */}
        <div style={{ background: navy, padding: '14px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0 }}>
          <button onClick={() => setView('form')} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
              <path d="M15 18l-6-6 6-6" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
          <span style={{ color: '#fff', fontSize: 15, fontWeight: 700 }}>REVIEW DEPOSIT</span>
          <button onClick={onCancel} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#fff', fontSize: 14, fontWeight: 600, fontFamily: 'inherit' }}>CANCEL</button>
        </div>

        <div style={{ flex: 1, overflowY: 'auto', padding: '24px 20px', paddingBottom: 100 }}>
          <div style={{ fontWeight: 700, fontSize: 20, color: '#111', marginBottom: 6 }}>Review your deposit</div>
          <div style={{ fontSize: 14, color: '#888', marginBottom: 24 }}>Please confirm the details below before submitting.</div>

          {/* Details */}
          {[
            { label: 'Deposit to', value: `${accountName} (...${accountLast4})` },
            { label: 'Deposit amount', value: displayAmount },
            { label: 'Available balance', value: accountBalance },
            { label: 'Availability', value: 'Next business day by 9:00 AM' },
          ].map(row => (
            <div key={row.label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', padding: '14px 0', borderBottom: '1px solid #f0f0f0' }}>
              <span style={{ fontSize: 14, color: '#888' }}>{row.label}</span>
              <span style={{ fontSize: 14, fontWeight: 600, color: '#111', textAlign: 'right', maxWidth: '60%' }}>{row.value}</span>
            </div>
          ))}

          {/* Check thumbnails */}
          <div style={{ marginTop: 20, marginBottom: 8, fontWeight: 600, fontSize: 14, color: '#333' }}>Check images</div>
          <div style={{ display: 'flex', gap: 12 }}>
            {[{ label: 'Front', photo: frontPhoto }, { label: 'Back', photo: backPhoto }].map(side => (
              <div key={side.label} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
                <div style={{ fontSize: 12, color: '#888' }}>{side.label}</div>
                {side.photo && (
                  <img src={side.photo} alt={side.label} style={{ width: '100%', aspectRatio: '1.6', objectFit: 'cover', borderRadius: 6, border: `1px solid ${blue}` }} />
                )}
              </div>
            ))}
          </div>

          {/* Disclosure */}
          <div style={{ background: '#f5f8ff', borderRadius: 10, padding: '14px 16px', marginTop: 20, fontSize: 12, color: '#555', lineHeight: 1.6 }}>
            By submitting this deposit, you confirm that this check has not been previously deposited and you agree to Chase's Mobile Deposit terms and conditions.
          </div>
        </div>

        {/* Submit */}
        <div style={{ padding: '12px 16px 24px', flexShrink: 0 }}>
          <button
            onClick={() => setView('confirm')}
            style={{ width: '100%', background: blue, color: '#fff', border: 'none', borderRadius: 8, padding: '15px', fontSize: 16, fontWeight: 600, cursor: 'pointer' }}
          >
            Submit Deposit
          </button>
        </div>
      </div>
    );
  }

  // ── CONFIRM SCREEN ──
  if (view === 'confirm') {
    return (
      <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', background: '#fff', fontFamily: "'Helvetica Neue', Arial, sans-serif", overflow: 'hidden' }}>
        {/* Header */}
        <div style={{ background: navy, padding: '14px 16px', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
          <span style={{ color: '#fff', fontSize: 15, fontWeight: 700 }}>DEPOSIT SUBMITTED</span>
        </div>

        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'flex-start', paddingTop: 60, padding: '60px 24px 24px', overflowY: 'auto' }}>
          {/* Animated green checkmark */}
          <div style={{
            width: 72, height: 72, borderRadius: '50%', background: '#27ae60',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            opacity: checkVisible ? 1 : 0,
            transform: checkVisible ? (checkUp ? 'scale(1) translateY(-20px)' : 'scale(1)') : 'scale(0)',
            transition: checkVisible
              ? (checkUp ? 'transform 0.35s ease' : 'opacity 0.3s ease, transform 0.4s cubic-bezier(0.34,1.56,0.64,1)')
              : 'none',
            marginBottom: 24,
          }}>
            <svg width="36" height="36" viewBox="0 0 36 36" fill="none">
              <polyline points="8,19 15,26 28,12" stroke="#fff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"
                style={{
                  strokeDasharray: 40,
                  strokeDashoffset: checkVisible ? 0 : 40,
                  transition: 'stroke-dashoffset 0.4s ease 0.2s',
                }}
              />
            </svg>
          </div>

          {/* Content */}
          <div style={{
            opacity: contentVisible ? 1 : 0,
            transform: contentVisible ? 'translateY(0)' : 'translateY(20px)',
            transition: 'opacity 0.4s ease, transform 0.4s ease',
            width: '100%', textAlign: 'center',
          }}>
            <div style={{ fontWeight: 700, fontSize: 22, color: '#111', marginBottom: 8 }}>Deposit submitted!</div>
            <div style={{ fontSize: 14, color: '#666', marginBottom: 24, lineHeight: 1.6 }}>
              Your deposit of <strong>{displayAmount}</strong> has been submitted successfully.
            </div>

            <div style={{ background: '#f5f8ff', borderRadius: 12, padding: 20, textAlign: 'left', marginBottom: 24 }}>
              {[
                { label: 'Account', value: `${accountName} (...${accountLast4})` },
                { label: 'Amount', value: displayAmount },
                { label: 'Status', value: 'Submitted' },
                { label: 'Available', value: 'Next business day' },
                { label: 'Ref #', value: `DEP${Math.floor(1000000000 + Math.random() * 9000000000)}` },
              ].map(row => (
                <div key={row.label} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid #e8f0fb' }}>
                  <span style={{ fontSize: 13, color: '#888' }}>{row.label}</span>
                  <span style={{ fontSize: 13, fontWeight: 600, color: '#111' }}>{row.value}</span>
                </div>
              ))}
            </div>

            <button
              onClick={onCancel}
              style={{ width: '100%', background: blue, color: '#fff', border: 'none', borderRadius: 8, padding: '15px', fontSize: 16, fontWeight: 600, cursor: 'pointer' }}
            >
              Done
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ── FORM SCREEN ──
  return (
    <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', background: '#fff', fontFamily: "'Helvetica Neue', Arial, sans-serif", overflow: 'hidden' }}>
      {/* Header */}
      <div style={{ background: blue, padding: '14px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0 }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4 }}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path d="M15 18l-6-6 6-6" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
        <span style={{ color: '#fff', fontSize: 15, fontWeight: 700, letterSpacing: 0.5 }}>CHASE QUICKDEPOSIT℠</span>
        <button onClick={onCancel} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#fff', fontSize: 14, fontWeight: 600, fontFamily: 'inherit' }}>CANCEL</button>
      </div>

      {/* Body */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '24px 20px', paddingBottom: 160 }}>
        {/* Deposit to */}
        <div style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 13, color: '#888', marginBottom: 6 }}>Deposit to</div>
          <div style={{ fontSize: 15, fontWeight: 700, color: blue }}>{accountName} (...{accountLast4})</div>
          <div style={{ fontSize: 14, fontWeight: 600, color: blue, marginTop: 4 }}>{accountBalance}</div>
        </div>

        {/* Amount */}
        <div style={{ textAlign: 'center', marginBottom: 20 }}>
          <div style={{ fontSize: 13, color: '#888', marginBottom: 12 }}>Deposit amount</div>
          <input
            type="text"
            inputMode="numeric"
            value={rawAmount ? `$${rawAmount}` : ''}
            onChange={e => handleAmountInput(e.target.value)}
            placeholder="$0.00"
            style={{ fontSize: 36, fontWeight: 700, color: '#222', border: 'none', borderBottom: '1.5px solid #ddd', outline: 'none', textAlign: 'center', width: 180, background: 'transparent', padding: '0 0 8px 0' }}
          />
          <div style={{ fontSize: 12, color: '#999', marginTop: 10 }}>Your current mobile deposit limit is $2,000.00</div>
        </div>

        {/* Check photos */}
        <div style={{ display: 'flex', gap: 12, marginBottom: 12 }}>
          {/* Front */}
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
            <div style={{ fontSize: 13, color: '#333', fontWeight: 500 }}>Front</div>
            <div
              onClick={() => frontInput.current?.click()}
              style={{ width: '100%', aspectRatio: '1.6', border: `2px solid ${blue}`, borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', overflow: 'hidden', background: '#f8fbff' }}
            >
              {frontPhoto ? (
                <img src={frontPhoto} alt="Front" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              ) : (
                <svg width="36" height="36" viewBox="0 0 36 36" fill="none">
                  <rect x="4" y="10" width="28" height="18" rx="3" stroke={blue} strokeWidth="1.5" fill="none" />
                  <circle cx="18" cy="19" r="5" stroke={blue} strokeWidth="1.5" fill="none" />
                  <circle cx="27" cy="13" r="2" fill={blue} />
                </svg>
              )}
            </div>
            <input ref={frontInput} type="file" accept="image/*" capture="environment" onChange={e => handlePhoto(e, 'front')} style={{ display: 'none' }} />
            {frontPhoto && (
              <button onClick={() => setFrontPhoto(null)} style={{ background: 'none', border: 'none', color: blue, fontSize: 13, cursor: 'pointer' }}>Retake</button>
            )}
          </div>

          {/* Back */}
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
            <div style={{ fontSize: 13, color: '#333', fontWeight: 500 }}>Back</div>
            <div
              onClick={() => frontPhoto && backInput.current?.click()}
              style={{ width: '100%', aspectRatio: '1.6', border: frontPhoto ? `2px solid ${blue}` : '1.5px solid #ccc', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: frontPhoto ? 'pointer' : 'default', overflow: 'hidden', background: frontPhoto ? '#f8fbff' : '#fafafa', opacity: frontPhoto ? 1 : 0.6 }}
            >
              {backPhoto ? (
                <img src={backPhoto} alt="Back" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              ) : (
                <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
                  <path d="M6 16a10 10 0 0 1 20 0" stroke="#ccc" strokeWidth="1.8" fill="none" strokeLinecap="round" />
                  <circle cx="16" cy="16" r="4" stroke="#ccc" strokeWidth="1.8" fill="none" />
                </svg>
              )}
            </div>
            <input ref={backInput} type="file" accept="image/*" capture="environment" onChange={e => handlePhoto(e, 'back')} style={{ display: 'none' }} />
            {backPhoto && (
              <button onClick={() => setBackPhoto(null)} style={{ background: 'none', border: 'none', color: blue, fontSize: 13, cursor: 'pointer' }}>Retake</button>
            )}
          </div>
        </div>
      </div>

      {/* Info bar */}
      <div style={{ background: '#f5f5f5', borderTop: '1px solid #eee', padding: '12px 16px', display: 'flex', alignItems: 'flex-start', gap: 10, flexShrink: 0 }}>
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" style={{ flexShrink: 0, marginTop: 2 }}>
          <circle cx="8" cy="8" r="7" stroke={blue} strokeWidth="1.4" fill="none" />
          <line x1="8" y1="7" x2="8" y2="12" stroke={blue} strokeWidth="1.6" strokeLinecap="round" />
          <circle cx="8" cy="4.5" r="0.9" fill={blue} />
        </svg>
        <span style={{ fontSize: 12, color: '#888', lineHeight: 1.6 }}>
          Deposit by 11PM ET and your money will typically be available for withdrawal by the next business day...
        </span>
      </div>

      {/* Bottom buttons */}
      <div style={{ padding: '12px 16px 24px', background: '#fff', flexShrink: 0, display: 'flex', flexDirection: 'column', gap: 10 }}>
        <button
          disabled={!canNext}
          onClick={() => canNext && setView('review')}
          style={{
            width: '100%', background: canNext ? blue : '#e0e0e0',
            color: canNext ? '#fff' : '#666', border: 'none', borderRadius: 8,
            padding: '15px', fontSize: 16, fontWeight: 600, cursor: canNext ? 'pointer' : 'not-allowed',
            transition: 'all 0.2s',
          }}
        >
          Next
        </button>
        <button onClick={() => setShowLimits(true)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: blue, fontSize: 13, textAlign: 'center', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4 }}>
          <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
            <polyline points="2,6 5,3 8,6" stroke={blue} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          Mobile Deposit limits
        </button>
      </div>

      {showLimits && <DepositLimitsSheet onClose={() => setShowLimits(false)} />}
    </div>
  );
}
