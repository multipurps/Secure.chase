const blue = '#2558b5';

interface MoreProps {
  onProfile?: () => void;
  onFraudAI?: () => void;
  onDigitalAssistant?: () => void;
}

export default function More({ onProfile, onFraudAI, onDigitalAssistant }: MoreProps) {
  const sections = [
    {
      title: 'Account services',
      items: [
        { label: 'Statements & documents', onPress: onProfile },
        { label: 'Account alerts', onPress: onProfile },
        { label: 'Overdraft services', onPress: undefined },
        { label: 'Order checks', onPress: undefined },
      ],
    },
    {
      title: 'Security & privacy',
      items: [
        { label: 'Fraud & security center', onPress: onFraudAI },
        { label: 'Privacy settings', onPress: onProfile },
        { label: 'Paperless settings', onPress: undefined },
      ],
    },
    {
      title: 'Contact us',
      items: [
        { label: 'Chat with the Chase Digital Assistant™', onPress: onDigitalAssistant },
        { label: 'Call Chase', onPress: undefined },
        { label: 'Schedule a meeting', onPress: undefined },
        { label: 'Send a message', onPress: onProfile },
      ],
    },
    {
      title: 'App settings',
      items: [
        { label: 'Profile & Settings', onPress: onProfile },
        { label: 'Notifications', onPress: undefined },
        { label: 'Face ID / Biometrics', onPress: undefined },
        { label: 'App version 5.8.2', onPress: undefined },
      ],
    },
  ];

  return (
    <div style={{
      width: '100%',
      height: '100%',
      overflowY: 'auto',
      background: '#f0f4f8',
      paddingBottom: 80,
      fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
    }}>
      <div style={{ background: '#fff', padding: '20px 20px 16px' }}>
        <div style={{ fontSize: 26, fontWeight: 700, color: '#111' }}>More</div>
      </div>

      <div style={{ padding: '16px 16px 0', display: 'flex', flexDirection: 'column', gap: 14 }}>
        {sections.map((sec, si) => (
          <div key={si}>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#888', marginBottom: 6, paddingLeft: 4, textTransform: 'uppercase', letterSpacing: 0.5 }}>
              {sec.title}
            </div>
            <div style={{ background: '#fff', borderRadius: 12, overflow: 'hidden', boxShadow: '0 2px 8px rgba(0,0,0,0.05)' }}>
              {sec.items.map((item, ii) => (
                <button
                  key={ii}
                  onClick={item.onPress}
                  style={{
                    width: '100%',
                    background: 'none',
                    border: 'none',
                    borderBottom: ii < sec.items.length - 1 ? '1px solid #f0f0f0' : 'none',
                    padding: '16px 18px',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    cursor: item.onPress ? 'pointer' : 'default',
                    textAlign: 'left',
                  }}
                >
                  <span style={{ fontSize: 15, color: '#111' }}>{item.label}</span>
                  {item.onPress && (
                    <svg width="9" height="16" viewBox="0 0 9 16" fill="none">
                      <polyline points="1,1 8,8 1,15" stroke="#bbb" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  )}
                </button>
              ))}
            </div>
          </div>
        ))}

        {/* Sign out */}
        <button style={{
          width: '100%',
          background: '#fff',
          border: `1.5px solid ${blue}`,
          borderRadius: 8,
          padding: '16px',
          fontSize: 16,
          fontWeight: 700,
          color: blue,
          cursor: 'pointer',
          marginTop: 6,
        }}>
          Sign out
        </button>
      </div>
    </div>
  );
}
