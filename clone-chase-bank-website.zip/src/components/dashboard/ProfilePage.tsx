interface ProfilePageProps {
  onBack: () => void;
  onSignOut: () => void;
}

const blue = '#2558b5';

export default function ProfilePage({ onBack, onSignOut }: ProfilePageProps) {
  return (
    <div style={{
      width: '100%',
      height: '100%',
      overflowY: 'auto',
      background: '#f0f4f8',
      paddingBottom: 80,
      fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
    }}>
      {/* Header */}
      <div style={{
        background: blue,
        padding: '20px 20px 40px',
        position: 'relative',
      }}>
        <button
          onClick={onBack}
          style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0, marginBottom: 16 }}
        >
          <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
            <polyline points="14,3 7,11 14,19" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
        <div style={{ textAlign: 'center' }}>
          {/* Avatar circle */}
          <div style={{
            width: 80, height: 80, borderRadius: '50%',
            background: '#fff',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            margin: '0 auto 12px',
          }}>
            <svg width="46" height="46" viewBox="0 0 46 46" fill="none">
              <circle cx="23" cy="18" r="9" stroke={blue} strokeWidth="2" fill="none" />
              <path d="M5 43c0-9.941 8.059-18 18-18s18 8.059 18 18" stroke={blue} strokeWidth="2" fill="none" />
            </svg>
          </div>
          <div style={{ color: '#fff', fontWeight: 700, fontSize: 20 }}>Demo User</div>
          <div style={{ color: 'rgba(255,255,255,0.8)', fontSize: 14, marginTop: 4 }}>demouser@chase.com</div>
        </div>
      </div>

      {/* Profile card */}
      <div style={{ padding: '0 16px', marginTop: -20 }}>
        <div style={{
          background: '#fff',
          borderRadius: 14,
          boxShadow: '0 4px 16px rgba(0,0,0,0.10)',
          overflow: 'hidden',
        }}>
          {[
            { label: 'Username', value: 'demouser01' },
            { label: 'Full name', value: 'Demo User' },
            { label: 'Email', value: 'demouser@chase.com' },
            { label: 'Phone', value: '(555) 867-5309' },
            { label: 'Member since', value: 'January 2020' },
          ].map((row, i, arr) => (
            <div key={i} style={{
              padding: '16px 18px',
              borderBottom: i < arr.length - 1 ? '1px solid #f0f0f0' : 'none',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}>
              <span style={{ fontSize: 13, color: '#888' }}>{row.label}</span>
              <span style={{ fontSize: 15, fontWeight: 600, color: '#111' }}>{row.value}</span>
            </div>
          ))}
        </div>

        {/* Actions */}
        <div style={{ marginTop: 14, background: '#fff', borderRadius: 14, overflow: 'hidden', boxShadow: '0 2px 8px rgba(0,0,0,0.06)' }}>
          {['Change username', 'Change password', 'Notification preferences', 'Privacy settings'].map((item, i, arr) => (
            <div key={i} style={{
              padding: '16px 18px',
              borderBottom: i < arr.length - 1 ? '1px solid #f0f0f0' : 'none',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              cursor: 'pointer',
            }}>
              <span style={{ fontSize: 15, color: '#111' }}>{item}</span>
              <svg width="9" height="16" viewBox="0 0 9 16" fill="none">
                <polyline points="1,1 8,8 1,15" stroke="#bbb" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
          ))}
        </div>

        {/* Sign out */}
        <button
          onClick={onSignOut}
          style={{
            width: '100%',
            marginTop: 18,
            background: '#fff',
            border: `1.5px solid ${blue}`,
            borderRadius: 8,
            padding: '16px',
            fontSize: 16,
            fontWeight: 700,
            color: blue,
            cursor: 'pointer',
          }}
        >
          Sign out
        </button>
      </div>
    </div>
  );
}
