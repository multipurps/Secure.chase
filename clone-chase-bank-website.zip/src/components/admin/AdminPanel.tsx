import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';

const NAVY = '#1a3a6b';
const BLUE = '#2558b5';

interface User {
  id: string;
  username: string;
  first_name: string;
  last_name: string;
  email: string;
  phone: string;
  account_type: string;
  approved?: boolean;
  transfer_restricted?: boolean;
  restriction_note?: string;
  restriction_image?: string;
  restriction_details?: string;
  created_at: string;
}

interface Account {
  id: string;
  user_id: string;
  name: string;
  type: string;
  last4: string;
  balance: number;
}

interface Transaction {
  id: string;
  account_id: string;
  description: string;
  amount: number;
  type: string;
  date: string;
  status: string;
  running_balance: number;
  category: string;
}

type Tab = 'users' | 'accounts' | 'transactions' | 'restrictions';

export default function AdminPanel({ onSignOut }: { onSignOut: () => void }) {
  const [tab, setTab] = useState<Tab>('users');
  const [users, setUsers] = useState<User[]>([]);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState('');

  // Edit states
  const [editingAccount, setEditingAccount] = useState<Account | null>(null);
  const [editingTx, setEditingTx] = useState<Transaction | null>(null);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [newPassword, setNewPassword] = useState('');
  const [showAddAccount, setShowAddAccount] = useState(false);
  const [newAccount, setNewAccount] = useState({ name: '', type: 'checking', last4: '', balance: '' });
  const [showAddTx, setShowAddTx] = useState(false);
  const [newTx, setNewTx] = useState({ description: '', amount: '', type: 'credit', date: new Date().toISOString().split('T')[0], status: 'Posted', category: '', running_balance: '' });
  const [restrictNote, setRestrictNote] = useState('');
  const [restrictDetails, setRestrictDetails] = useState('');

  useEffect(() => { loadUsers(); }, []);

  function showToast(msg: string) {
    setToast(msg);
    setTimeout(() => setToast(''), 3000);
  }

  async function loadUsers() {
    setLoading(true);
    try {
      const { data } = await supabase.from('users').select('*').order('created_at', { ascending: false });
      if (data) setUsers(data as User[]);
    } catch { /* ignore */ }
    setLoading(false);
  }

  async function loadAccounts(userId?: string) {
    try {
      let q = supabase.from('accounts').select('*').order('name');
      if (userId) q = q.eq('user_id', userId);
      const { data } = await q;
      if (data) setAccounts(data as Account[]);
    } catch { /* ignore */ }
  }

  async function loadTransactions(accountId?: string) {
    try {
      let q = supabase.from('transactions').select('*').order('date', { ascending: false });
      if (accountId) q = q.eq('account_id', accountId);
      const { data } = await q;
      if (data) setTransactions(data as Transaction[]);
    } catch { /* ignore */ }
  }

  async function approveUser(userId: string) {
    try {
      await supabase.from('users').update({ approved: true }).eq('id', userId);
      showToast('User approved.');
      loadUsers();
    } catch { showToast('Error approving user.'); }
  }

  async function rejectUser(userId: string) {
    if (!confirm('Permanently delete this user?')) return;
    try {
      await supabase.from('users').delete().eq('id', userId);
      showToast('User rejected and deleted.');
      loadUsers();
    } catch { showToast('Error rejecting user.'); }
  }

  async function saveUserEdit() {
    if (!editingUser) return;
    try {
      await supabase.from('users').update({
        first_name: editingUser.first_name,
        last_name: editingUser.last_name,
        username: editingUser.username,
        email: editingUser.email,
        phone: editingUser.phone,
      }).eq('id', editingUser.id);
      if (newPassword) {
        await supabase.auth.admin.updateUserById(editingUser.id, { password: newPassword });
      }
      showToast('User saved.');
      setEditingUser(null);
      setNewPassword('');
      loadUsers();
    } catch { showToast('Error saving user.'); }
  }

  async function saveAccountEdit() {
    if (!editingAccount) return;
    try {
      await supabase.from('accounts').update({
        name: editingAccount.name,
        balance: editingAccount.balance,
        last4: editingAccount.last4,
      }).eq('id', editingAccount.id);
      showToast('Account saved.');
      setEditingAccount(null);
      loadAccounts(selectedUser?.id);
    } catch { showToast('Error saving account.'); }
  }

  async function deleteAccount(id: string) {
    if (!confirm('Delete this account?')) return;
    try {
      await supabase.from('accounts').delete().eq('id', id);
      showToast('Account deleted.');
      loadAccounts(selectedUser?.id);
    } catch { showToast('Error deleting account.'); }
  }

  async function addAccount() {
    if (!selectedUser || !newAccount.name || !newAccount.last4 || !newAccount.balance) return;
    try {
      await supabase.from('accounts').insert([{
        user_id: selectedUser.id,
        name: newAccount.name.toUpperCase(),
        type: newAccount.type,
        last4: newAccount.last4,
        balance: parseFloat(newAccount.balance),
      }]);
      showToast('Account added.');
      setShowAddAccount(false);
      setNewAccount({ name: '', type: 'checking', last4: '', balance: '' });
      loadAccounts(selectedUser.id);
    } catch { showToast('Error adding account.'); }
  }

  async function saveTxEdit() {
    if (!editingTx) return;
    try {
      await supabase.from('transactions').update({
        description: editingTx.description,
        amount: editingTx.amount,
        type: editingTx.type,
        date: editingTx.date,
        status: editingTx.status,
        running_balance: editingTx.running_balance,
        category: editingTx.category,
      }).eq('id', editingTx.id);
      showToast('Transaction saved.');
      setEditingTx(null);
      loadTransactions();
    } catch { showToast('Error saving transaction.'); }
  }

  async function deleteTx(id: string) {
    if (!confirm('Delete transaction?')) return;
    try {
      await supabase.from('transactions').delete().eq('id', id);
      showToast('Transaction deleted.');
      loadTransactions();
    } catch { showToast('Error.'); }
  }

  async function addTransaction() {
    if (!newTx.description || !newTx.amount || !newTx.date) return;
    const [firstAccount] = accounts;
    if (!firstAccount) { showToast('No account selected for transaction.'); return; }
    try {
      await supabase.from('transactions').insert([{
        account_id: firstAccount.id,
        description: newTx.description,
        amount: parseFloat(newTx.amount),
        type: newTx.type,
        date: newTx.date,
        status: newTx.status,
        category: newTx.category,
        running_balance: parseFloat(newTx.running_balance) || 0,
      }]);
      showToast('Transaction added.');
      setShowAddTx(false);
      setNewTx({ description: '', amount: '', type: 'credit', date: new Date().toISOString().split('T')[0], status: 'Posted', category: '', running_balance: '' });
      loadTransactions();
    } catch { showToast('Error adding transaction.'); }
  }

  async function toggleRestriction(user: User) {
    const restricted = !user.transfer_restricted;
    try {
      await supabase.from('users').update({
        transfer_restricted: restricted,
        restriction_note: restricted ? restrictNote : null,
        restriction_details: restricted ? restrictDetails : null,
      }).eq('id', user.id);
      showToast(restricted ? 'Transfers restricted.' : 'Restriction lifted.');
      loadUsers();
    } catch { showToast('Error updating restriction.'); }
  }

  function selectUserAndLoad(user: User) {
    setSelectedUser(user);
    loadAccounts(user.id);
  }

  const inputStyle: React.CSSProperties = {
    width: '100%', border: 'none', borderBottom: '1.5px solid #ddd',
    outline: 'none', fontSize: 15, padding: '6px 0', background: 'transparent',
    boxSizing: 'border-box', marginBottom: 12, fontFamily: 'inherit',
  };

  const btnBlue: React.CSSProperties = {
    background: BLUE, color: '#fff', border: 'none', borderRadius: 6,
    padding: '8px 16px', fontSize: 14, fontWeight: 600, cursor: 'pointer',
  };
  const btnRed: React.CSSProperties = { ...btnBlue, background: '#c0392b' };
  const btnGray: React.CSSProperties = { ...btnBlue, background: '#888' };
  const btnGreen: React.CSSProperties = { ...btnBlue, background: '#27ae60' };

  return (
    <div style={{ width: '100%', minHeight: '100dvh', background: '#f0f4f8', fontFamily: "'Helvetica Neue', Arial, sans-serif" }}>
      {/* Header */}
      <div style={{ background: NAVY, padding: '16px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <div style={{ color: '#fff', fontSize: 20, fontWeight: 700 }}>Chase Admin Panel</div>
          <div style={{ color: 'rgba(255,255,255,0.6)', fontSize: 12, marginTop: 2 }}>Secure Management Console</div>
        </div>
        <button onClick={onSignOut} style={{ background: 'rgba(255,255,255,0.15)', border: 'none', color: '#fff', padding: '8px 16px', borderRadius: 6, cursor: 'pointer', fontSize: 14 }}>
          Sign Out
        </button>
      </div>

      {/* Tab bar */}
      <div style={{ background: '#fff', display: 'flex', borderBottom: '1px solid #e0e0e0', overflowX: 'auto' }}>
        {(['users', 'accounts', 'transactions', 'restrictions'] as Tab[]).map(t => (
          <button key={t} onClick={() => setTab(t)} style={{
            flex: 1, minWidth: 90, padding: '14px 8px', border: 'none', background: 'none', cursor: 'pointer',
            fontSize: 13, fontWeight: tab === t ? 700 : 400, color: tab === t ? BLUE : '#666',
            borderBottom: tab === t ? `3px solid ${BLUE}` : '3px solid transparent',
            textTransform: 'capitalize', fontFamily: 'inherit',
          }}>
            {t === 'users' ? 'Users' : t === 'accounts' ? 'Accounts' : t === 'transactions' ? 'Transactions' : 'Restrictions'}
          </button>
        ))}
      </div>

      <div style={{ padding: 16, paddingBottom: 40 }}>

        {/* ── USERS TAB ── */}
        {tab === 'users' && (
          <div>
            <div style={{ fontWeight: 700, fontSize: 18, color: '#111', marginBottom: 12 }}>All Users</div>
            {loading && <div style={{ color: '#888', textAlign: 'center', padding: 20 }}>Loading...</div>}
            {users.length === 0 && !loading && (
              <div style={{ textAlign: 'center', color: '#888', padding: 40 }}>No users found in Supabase.</div>
            )}
            {users.map(user => (
              <div key={user.id} style={{ background: '#fff', borderRadius: 12, padding: 16, marginBottom: 12, boxShadow: '0 1px 6px rgba(0,0,0,0.06)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 15, color: '#111' }}>{user.first_name} {user.last_name}</div>
                    <div style={{ fontSize: 13, color: '#666', marginTop: 2 }}>@{user.username} · {user.email}</div>
                    <div style={{ fontSize: 12, color: '#999', marginTop: 2 }}>{user.account_type} · {new Date(user.created_at).toLocaleDateString()}</div>
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 6, alignItems: 'flex-end' }}>
                    {user.approved === false && (
                      <>
                        <button onClick={() => approveUser(user.id)} style={btnGreen}>Approve</button>
                        <button onClick={() => rejectUser(user.id)} style={btnRed}>Reject</button>
                      </>
                    )}
                    {user.approved !== false && (
                      <span style={{ fontSize: 12, color: '#27ae60', fontWeight: 600 }}>Active</span>
                    )}
                    {user.transfer_restricted && (
                      <span style={{ fontSize: 12, color: '#e67e22', fontWeight: 600 }}>⚠ Restricted</span>
                    )}
                  </div>
                </div>
                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 8 }}>
                  <button onClick={() => setEditingUser({ ...user })} style={btnBlue}>Edit User</button>
                  <button onClick={() => { selectUserAndLoad(user); setTab('accounts'); }} style={btnGray}>Accounts</button>
                  <button onClick={() => { selectUserAndLoad(user); loadTransactions(); setTab('transactions'); }} style={btnGray}>Transactions</button>
                  <button onClick={() => { selectUserAndLoad(user); setTab('restrictions'); }} style={user.transfer_restricted ? { ...btnBlue, background: '#e67e22' } : btnBlue}>
                    {user.transfer_restricted ? 'Lift Restriction' : 'Restrict'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* ── ACCOUNTS TAB ── */}
        {tab === 'accounts' && (
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <div style={{ fontWeight: 700, fontSize: 18, color: '#111' }}>
                Accounts{selectedUser ? ` — ${selectedUser.first_name} ${selectedUser.last_name}` : ' (Select a user first)'}
              </div>
              {selectedUser && (
                <button onClick={() => setShowAddAccount(true)} style={btnBlue}>+ Add Account</button>
              )}
            </div>
            {!selectedUser && (
              <div style={{ textAlign: 'center', color: '#888', padding: 40 }}>Go to Users tab and tap "Accounts" for a user.</div>
            )}
            {accounts.map(acc => (
              <div key={acc.id} style={{ background: '#fff', borderRadius: 12, padding: 16, marginBottom: 10, boxShadow: '0 1px 6px rgba(0,0,0,0.06)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 14, color: '#111' }}>{acc.name} (...{acc.last4})</div>
                    <div style={{ fontSize: 13, color: '#666', marginTop: 2 }}>{acc.type} · Balance: ${acc.balance?.toLocaleString('en-US', { minimumFractionDigits: 2 })}</div>
                  </div>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <button onClick={() => setEditingAccount({ ...acc })} style={btnBlue}>Edit</button>
                    <button onClick={() => deleteAccount(acc.id)} style={btnRed}>Delete</button>
                  </div>
                </div>
              </div>
            ))}

            {showAddAccount && (
              <div style={{ background: '#fff', borderRadius: 12, padding: 20, marginTop: 12, boxShadow: '0 2px 12px rgba(0,0,0,0.1)' }}>
                <div style={{ fontWeight: 700, fontSize: 16, marginBottom: 16 }}>Add New Account</div>
                <input style={inputStyle} placeholder="Account name (e.g. CHASE CHECKING)" value={newAccount.name} onChange={e => setNewAccount(p => ({ ...p, name: e.target.value }))} />
                <select style={{ ...inputStyle, fontSize: 15 }} value={newAccount.type} onChange={e => setNewAccount(p => ({ ...p, type: e.target.value }))}>
                  {['checking', 'savings', 'investment', 'credit_card', 'business_checking', 'ira'].map(t => <option key={t} value={t}>{t}</option>)}
                </select>
                <input style={inputStyle} placeholder="Last 4 digits" maxLength={4} value={newAccount.last4} onChange={e => setNewAccount(p => ({ ...p, last4: e.target.value }))} />
                <input style={inputStyle} type="number" placeholder="Balance (e.g. 50000)" value={newAccount.balance} onChange={e => setNewAccount(p => ({ ...p, balance: e.target.value }))} />
                <div style={{ display: 'flex', gap: 10, marginTop: 8 }}>
                  <button onClick={addAccount} style={btnBlue}>Save Account</button>
                  <button onClick={() => setShowAddAccount(false)} style={btnGray}>Cancel</button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ── TRANSACTIONS TAB ── */}
        {tab === 'transactions' && (
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <div style={{ fontWeight: 700, fontSize: 18, color: '#111' }}>Transactions</div>
              <button onClick={() => setShowAddTx(true)} style={btnBlue}>+ Add</button>
            </div>
            {transactions.length === 0 && (
              <div style={{ textAlign: 'center', color: '#888', padding: 40 }}>No transactions. Select a user from Users tab first.</div>
            )}
            {transactions.slice(0, 50).map(tx => (
              <div key={tx.id} style={{ background: '#fff', borderRadius: 10, padding: 14, marginBottom: 8, boxShadow: '0 1px 4px rgba(0,0,0,0.05)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div style={{ flex: 1, marginRight: 12 }}>
                    <div style={{ fontWeight: 600, fontSize: 13, color: '#111', lineHeight: 1.4 }}>{tx.description}</div>
                    <div style={{ fontSize: 12, color: '#888', marginTop: 2 }}>{tx.date} · {tx.status} · {tx.category}</div>
                  </div>
                  <div style={{ textAlign: 'right', flexShrink: 0 }}>
                    <div style={{ fontWeight: 700, fontSize: 14, color: tx.type === 'credit' ? '#27ae60' : '#c0392b' }}>
                      {tx.type === 'credit' ? '+' : '-'}${Math.abs(tx.amount).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </div>
                    <div style={{ display: 'flex', gap: 6, marginTop: 6 }}>
                      <button onClick={() => setEditingTx({ ...tx })} style={{ ...btnBlue, padding: '4px 10px', fontSize: 12 }}>Edit</button>
                      <button onClick={() => deleteTx(tx.id)} style={{ ...btnRed, padding: '4px 10px', fontSize: 12 }}>Del</button>
                    </div>
                  </div>
                </div>
              </div>
            ))}

            {showAddTx && (
              <div style={{ background: '#fff', borderRadius: 12, padding: 20, marginTop: 12, boxShadow: '0 2px 12px rgba(0,0,0,0.1)' }}>
                <div style={{ fontWeight: 700, fontSize: 16, marginBottom: 16 }}>Add Transaction</div>
                <input style={inputStyle} placeholder="Description" value={newTx.description} onChange={e => setNewTx(p => ({ ...p, description: e.target.value }))} />
                <input style={inputStyle} type="number" placeholder="Amount" value={newTx.amount} onChange={e => setNewTx(p => ({ ...p, amount: e.target.value }))} />
                <select style={{ ...inputStyle, fontSize: 15 }} value={newTx.type} onChange={e => setNewTx(p => ({ ...p, type: e.target.value }))}>
                  <option value="credit">Credit (incoming)</option>
                  <option value="debit">Debit (outgoing)</option>
                </select>
                <input style={inputStyle} type="date" value={newTx.date} onChange={e => setNewTx(p => ({ ...p, date: e.target.value }))} />
                <select style={{ ...inputStyle, fontSize: 15 }} value={newTx.status} onChange={e => setNewTx(p => ({ ...p, status: e.target.value }))}>
                  <option>Posted</option>
                  <option>Pending</option>
                </select>
                <input style={inputStyle} placeholder="Category (e.g. Food & drink)" value={newTx.category} onChange={e => setNewTx(p => ({ ...p, category: e.target.value }))} />
                <input style={inputStyle} type="number" placeholder="Running balance after this tx" value={newTx.running_balance} onChange={e => setNewTx(p => ({ ...p, running_balance: e.target.value }))} />
                <div style={{ display: 'flex', gap: 10, marginTop: 8 }}>
                  <button onClick={addTransaction} style={btnBlue}>Save Transaction</button>
                  <button onClick={() => setShowAddTx(false)} style={btnGray}>Cancel</button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ── RESTRICTIONS TAB ── */}
        {tab === 'restrictions' && (
          <div>
            <div style={{ fontWeight: 700, fontSize: 18, color: '#111', marginBottom: 12 }}>Transfer Restrictions</div>
            {!selectedUser && <div style={{ textAlign: 'center', color: '#888', padding: 40 }}>Go to Users tab and tap "Restrict" for a user.</div>}
            {selectedUser && (
              <div style={{ background: '#fff', borderRadius: 12, padding: 20, boxShadow: '0 1px 6px rgba(0,0,0,0.06)' }}>
                <div style={{ fontWeight: 700, fontSize: 16, color: '#111', marginBottom: 8 }}>
                  {selectedUser.first_name} {selectedUser.last_name}
                </div>
                <div style={{ fontSize: 13, color: '#666', marginBottom: 16 }}>@{selectedUser.username}</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20 }}>
                  <span style={{ fontSize: 14, color: '#111' }}>Transfer restriction:</span>
                  <span style={{ fontWeight: 700, color: selectedUser.transfer_restricted ? '#c0392b' : '#27ae60', fontSize: 14 }}>
                    {selectedUser.transfer_restricted ? 'ACTIVE' : 'INACTIVE'}
                  </span>
                </div>
                <div style={{ marginBottom: 14 }}>
                  <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Custom note (shown in modal)</div>
                  <textarea
                    value={restrictNote}
                    onChange={e => setRestrictNote(e.target.value)}
                    placeholder="Add a custom note for this user..."
                    style={{ width: '100%', border: '1px solid #ddd', borderRadius: 8, padding: '10px 12px', fontSize: 14, minHeight: 80, resize: 'vertical', fontFamily: 'inherit', boxSizing: 'border-box' }}
                  />
                </div>
                <div style={{ marginBottom: 20 }}>
                  <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Details field (user can copy)</div>
                  <input
                    value={restrictDetails}
                    onChange={e => setRestrictDetails(e.target.value)}
                    placeholder="Case number, contact info, etc."
                    style={{ ...inputStyle, border: '1px solid #ddd', borderRadius: 8, padding: '10px 12px', marginBottom: 0 }}
                  />
                </div>
                <button onClick={() => toggleRestriction(selectedUser)} style={selectedUser.transfer_restricted ? btnGreen : btnRed}>
                  {selectedUser.transfer_restricted ? 'Lift Restriction' : 'Enable Restriction'}
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Edit User Modal */}
      {editingUser && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
          <div style={{ background: '#fff', borderRadius: 16, padding: 24, width: '100%', maxWidth: 420, maxHeight: '85vh', overflowY: 'auto' }}>
            <div style={{ fontWeight: 700, fontSize: 18, marginBottom: 20 }}>Edit User</div>
            {[
              { label: 'First Name', key: 'first_name' },
              { label: 'Last Name', key: 'last_name' },
              { label: 'Username', key: 'username' },
              { label: 'Email', key: 'email' },
              { label: 'Phone', key: 'phone' },
            ].map(f => (
              <div key={f.key} style={{ marginBottom: 14 }}>
                <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>{f.label}</div>
                <input
                  value={(editingUser as unknown as Record<string, string>)[f.key] || ''}
                  onChange={e => setEditingUser(u => u ? { ...u, [f.key]: e.target.value } : null)}
                  style={inputStyle}
                />
              </div>
            ))}
            <div style={{ marginBottom: 14 }}>
              <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>New Password (leave blank to keep current)</div>
              <input type="password" value={newPassword} onChange={e => setNewPassword(e.target.value)} style={inputStyle} placeholder="New password..." />
            </div>
            <div style={{ display: 'flex', gap: 10, marginTop: 8 }}>
              <button onClick={saveUserEdit} style={btnBlue}>Save</button>
              <button onClick={() => { setEditingUser(null); setNewPassword(''); }} style={btnGray}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Account Modal */}
      {editingAccount && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
          <div style={{ background: '#fff', borderRadius: 16, padding: 24, width: '100%', maxWidth: 380 }}>
            <div style={{ fontWeight: 700, fontSize: 18, marginBottom: 20 }}>Edit Account</div>
            <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Account Name</div>
            <input style={inputStyle} value={editingAccount.name} onChange={e => setEditingAccount(a => a ? { ...a, name: e.target.value } : null)} />
            <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Last 4 Digits</div>
            <input style={inputStyle} maxLength={4} value={editingAccount.last4} onChange={e => setEditingAccount(a => a ? { ...a, last4: e.target.value } : null)} />
            <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Balance</div>
            <input style={inputStyle} type="number" value={editingAccount.balance} onChange={e => setEditingAccount(a => a ? { ...a, balance: parseFloat(e.target.value) } : null)} />
            <div style={{ display: 'flex', gap: 10, marginTop: 8 }}>
              <button onClick={saveAccountEdit} style={btnBlue}>Save</button>
              <button onClick={() => setEditingAccount(null)} style={btnGray}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Transaction Modal */}
      {editingTx && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
          <div style={{ background: '#fff', borderRadius: 16, padding: 24, width: '100%', maxWidth: 400, maxHeight: '85vh', overflowY: 'auto' }}>
            <div style={{ fontWeight: 700, fontSize: 18, marginBottom: 20 }}>Edit Transaction</div>
            <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Description</div>
            <textarea value={editingTx.description} onChange={e => setEditingTx(t => t ? { ...t, description: e.target.value } : null)} style={{ ...inputStyle, minHeight: 60, resize: 'vertical', border: '1px solid #ddd', borderRadius: 6, padding: '8px' }} />
            <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Amount</div>
            <input style={inputStyle} type="number" value={editingTx.amount} onChange={e => setEditingTx(t => t ? { ...t, amount: parseFloat(e.target.value) } : null)} />
            <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Type</div>
            <select style={{ ...inputStyle, fontSize: 15 }} value={editingTx.type} onChange={e => setEditingTx(t => t ? { ...t, type: e.target.value } : null)}>
              <option value="credit">Credit</option>
              <option value="debit">Debit</option>
            </select>
            <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Date</div>
            <input style={inputStyle} type="date" value={editingTx.date?.split('T')[0] || ''} onChange={e => setEditingTx(t => t ? { ...t, date: e.target.value } : null)} />
            <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Status</div>
            <select style={{ ...inputStyle, fontSize: 15 }} value={editingTx.status} onChange={e => setEditingTx(t => t ? { ...t, status: e.target.value } : null)}>
              <option>Posted</option>
              <option>Pending</option>
            </select>
            <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Category</div>
            <input style={inputStyle} value={editingTx.category || ''} onChange={e => setEditingTx(t => t ? { ...t, category: e.target.value } : null)} />
            <div style={{ fontSize: 12, color: '#888', marginBottom: 4 }}>Running Balance</div>
            <input style={inputStyle} type="number" value={editingTx.running_balance || 0} onChange={e => setEditingTx(t => t ? { ...t, running_balance: parseFloat(e.target.value) } : null)} />
            <div style={{ display: 'flex', gap: 10, marginTop: 8 }}>
              <button onClick={saveTxEdit} style={btnBlue}>Save</button>
              <button onClick={() => setEditingTx(null)} style={btnGray}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {/* Toast */}
      {toast && (
        <div style={{ position: 'fixed', bottom: 30, left: '50%', transform: 'translateX(-50%)', background: '#222', color: '#fff', padding: '12px 24px', borderRadius: 30, fontSize: 14, fontWeight: 600, zIndex: 9999, whiteSpace: 'nowrap', boxShadow: '0 4px 20px rgba(0,0,0,0.3)' }}>
          {toast}
        </div>
      )}
    </div>
  );
}
