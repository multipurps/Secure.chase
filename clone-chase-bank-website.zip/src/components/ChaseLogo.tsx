/**
 * Authentic Chase Bank octagon logo built from real Wikimedia SVG path data.
 * Source: https://upload.wikimedia.org/wikipedia/commons/e/ed/Chase_logo_2007.svg
 *
 * The original SVG has a compound transform:
 *   translate(620.34041, -56.426733) + translate(0.4494891, 0.3945659)
 *   => effective offset: x += 620.7899, y -= 56.0322
 *
 * Original 4 octagon segment paths after applying the full transform:
 *
 * logo-ne (top-right blade):
 *   M 261.929, 0.274   C 260.857, 0.274  259.988, 1.143  259.988, 2.214
 *   L 259.988, 15.821   L 295.929, 15.821  L 279.562, 0.276  Z
 *
 * logo-se (right blade):
 *   M 297.244, 19.937   C 297.244, 18.863  296.381, 17.998  295.303, 17.998
 *   L 281.700, 17.998   L 281.700, 53.941  L 297.238, 37.566  Z
 *
 * logo-sw (bottom-left blade):
 *   M 277.579, 55.242   C 278.649, 55.242  279.518, 54.372  279.518, 53.299
 *   L 279.518, 39.697  L 243.575, 39.697  L 259.945, 55.240  Z
 *
 * logo-nw (left blade):
 *   M 242.261, 35.582   C 242.261, 36.655  243.130, 37.529  244.205, 37.529
 *   L 257.805, 37.529  L 257.805, 1.584  L 242.264, 17.954  Z
 *
 * The octagon spans: x: 242.26..297.24 (width=54.98), y: 0.27..55.24 (height=54.97)
 * Normalized to 0-based 55x55 grid by subtracting (242.26, 0.27):
 *
 * logo-ne: M 19.67,0  C 18.60,0  17.73,0.87  17.73,1.94  L 17.73,15.55  L 53.67,15.55  L 37.30,0  Z
 * logo-se: M 54.98,19.67  C 54.98,18.59  54.12,17.73  53.04,17.73  L 39.44,17.73  L 39.44,53.67  L 54.98,37.29  Z
 * logo-sw: M 35.32,54.97  C 36.39,54.97  37.26,54.10  37.26,53.03  L 37.26,39.43  L 1.32,39.43  L 17.68,54.97  Z
 * logo-nw: M 0,35.31  C 0,36.38  0.87,37.26  1.94,37.26  L 15.54,37.26  L 15.54,1.31  L 0,17.68  Z
 *
 * These are the 4 blades of the authentic Chase pinwheel octagon.
 * The white gap (central square) is formed by negative space between the blades.
 */

interface ChaseLogoProps {
  color?: string;
  size?: number;         // height in px (default 40)
  showText?: boolean;
  className?: string;
}

// Normalized octagon paths in a 55x55 unit square
const OCT_NE = "M 19.67,0 C 18.60,0 17.73,0.87 17.73,1.94 L 17.73,15.55 L 53.67,15.55 L 37.30,0.003 Z";
const OCT_SE = "M 54.98,19.67 C 54.98,18.59 54.12,17.73 53.04,17.73 L 39.44,17.73 L 39.44,53.67 L 54.977,37.29 Z";
const OCT_SW = "M 35.32,54.97 C 36.39,54.97 37.26,54.10 37.26,53.03 L 37.26,39.43 L 1.32,39.43 L 17.68,54.967 Z";
const OCT_NW = "M 0,35.31 C 0,36.38 0.87,37.26 1.94,37.26 L 15.54,37.26 L 15.54,1.31 L 0.003,17.68 Z";

export default function ChaseLogo({
  color = '#ffffff',
  size = 40,
  showText = true,
  className = '',
}: ChaseLogoProps) {
  // The octagon is 55 units tall. We scale to `size` px height.
  const scale = size / 55;
  const symW = 55 * scale;
  const symH = 55 * scale;

  // "CHASE" text: use a measured width ratio.
  // At size=40 (symH=40), the text at ~29px font is ~106px wide.
  // Ratio: textWidth ≈ symH * 2.8 + gap of symH*0.3
  const fontSize = symH * 0.73;
  const letterSpacing = symH * 0.04;
  const textW = showText ? symH * 2.88 : 0;
  const gap = showText ? symH * 0.14 : 0; // tight gap — matches real Chase app

  const totalW = textW + gap + symW;
  const totalH = symH;

  return (
    <svg
      width={totalW}
      height={totalH}
      viewBox={`0 0 ${totalW} ${totalH}`}
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      style={{ display: 'block', overflow: 'visible' }}
      aria-label="Chase"
      role="img"
    >
      {showText && (
        <text
          x={0}
          y={symH * 0.785}
          fontFamily="'Helvetica Neue', Helvetica, Arial, sans-serif"
          fontWeight="700"
          fontSize={fontSize}
          letterSpacing={letterSpacing}
          fill={color}
          dominantBaseline="auto"
        >
          CHASE
        </text>
      )}

      {/* Octagon symbol */}
      <g transform={`translate(${textW + gap}, 0) scale(${scale})`}>
        <path d={OCT_NE} fill={color} />
        <path d={OCT_SE} fill={color} />
        <path d={OCT_SW} fill={color} />
        <path d={OCT_NW} fill={color} />
      </g>
    </svg>
  );
}
