import ChaseLogo from './ChaseLogo';

interface WelcomeScreenProps {
  onSignIn: () => void;
  onSignUp: () => void;
  onOpenAccount?: () => void;
}

export default function WelcomeScreen({ onSignIn, onSignUp, onOpenAccount }: WelcomeScreenProps) {
  return (
    <div style={{
      position: 'fixed', inset: 0,
      fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
      overflowY: 'auto', overflowX: 'hidden',
      WebkitOverflowScrolling: 'touch',
      display: 'flex',
      flexDirection: 'column',
      // Blue top, white bottom — the blue "stops" around the Sign up button area
      // We achieve this by having blue bg on outer + white card that starts below logo
      // The card is semi-transparent at top so blue shows through behind the top card section
      background: '#fff',
    }}>
      {/* ── Full-width blue panel behind the logo + behind top of card ── */}
      <div style={{
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        // Blue extends down to roughly the "or" divider area inside the card
        // Logo area (~130px) + card top padding (28) + welcome text (~50) + sign-in btn (~52) + or divider (~50) ≈ 310px
        height: 'calc(130px + env(safe-area-inset-top, 44px) + 230px)',
        background: '#1352AA',
        zIndex: 0,
      }} />

      {/* ── CHASE logo — sits in blue area ── */}
      <div style={{
        position: 'relative',
        zIndex: 1,
        paddingTop: 'max(env(safe-area-inset-top, 54px), 54px)',
        paddingBottom: 32,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        flexShrink: 0,
      }}>
        <ChaseLogo color="#ffffff" size={30} showText />
      </div>

      {/* ── White card — floats on top, rounded top corners ── */}
      <div style={{
        position: 'relative',
        zIndex: 1,
        background: '#fff',
        borderTopLeftRadius: 20,
        borderTopRightRadius: 20,
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        padding: '28px 20px 0',
        // Box shadow at top to separate card from blue slightly
        boxShadow: '0 -2px 12px rgba(0,0,0,0.10)',
      }}>

        {/* ── Card inner content ── */}
        <div style={{ width: '100%', maxWidth: 440, alignSelf: 'center' }}>
          <p style={{
            textAlign: 'center', color: '#222',
            fontSize: 17, fontWeight: 400, margin: 0, lineHeight: 1.4,
          }}>
            Welcome to Chase Mobile!
          </p>
          <p style={{
            textAlign: 'center', color: '#666',
            fontSize: 14, fontWeight: 400, margin: '8px 0 0', lineHeight: 1.4,
          }}>
            Please choose an option below.
          </p>

          {/* Sign in button */}
          <button
            onClick={onSignIn}
            style={{
              display: 'block', width: '100%', marginTop: 24,
              background: '#1352AA', color: '#fff',
              fontSize: 17, fontWeight: 600, border: 'none',
              borderRadius: 8, padding: '15px 0', cursor: 'pointer',
              fontFamily: 'inherit',
            }}
          >
            Sign in
          </button>

          {/* "or" divider */}
          <div style={{ display: 'flex', alignItems: 'center', margin: '14px 0', gap: 10 }}>
            <div style={{ flex: 1, height: 1, background: '#e0e0e0' }} />
            <span style={{ color: '#999', fontSize: 13 }}>or</span>
            <div style={{ flex: 1, height: 1, background: '#e0e0e0' }} />
          </div>

          {/* Sign up button */}
          <button
            onClick={onSignUp}
            style={{
              display: 'block', width: '100%',
              background: '#fff', color: '#1352AA',
              fontSize: 17, fontWeight: 600,
              border: '2px solid #1352AA', borderRadius: 8,
              padding: '13px 0', cursor: 'pointer',
              fontFamily: 'inherit',
            }}
          >
            Sign up
          </button>
        </div>

        {/* Spacer */}
        <div style={{ flex: 1, minHeight: 24 }} />

        {/* ── Bottom nav links ── */}
        <div style={{ width: '100%', maxWidth: 440, alignSelf: 'center' }}>
          <div style={{
            display: 'flex', justifyContent: 'center',
            alignItems: 'center', flexWrap: 'wrap', paddingBottom: 4,
          }}>
            {[
              { label: 'Open an account', action: onOpenAccount },
              { label: 'ATM / Branch', action: undefined },
              { label: 'Privacy', action: undefined },
              { label: '···', action: undefined },
            ].map((item, i, arr) => (
              <span key={item.label} style={{ display: 'flex', alignItems: 'center' }}>
                <button
                  onClick={item.action || undefined}
                  style={{
                    background: 'none', border: 'none', color: '#1352AA',
                    fontSize: 12, cursor: 'pointer', fontFamily: 'inherit', padding: '4px 5px',
                  }}
                >
                  {item.label}
                </button>
                {i < arr.length - 1 && <span style={{ color: '#ccc', fontSize: 12 }}>|</span>}
              </span>
            ))}
          </div>

          {/* Legal footer */}
          <div style={{
            textAlign: 'center', color: '#888',
            fontSize: 10.5, lineHeight: 1.75, padding: '2px 12px 6px',
          }}>
            <div>Equal Housing Opportunity</div>
            <div>Deposit products provided by JPMorgan Chase Bank, N.A. Member FDIC</div>
            <div>Credit cards are issued by JPMorgan Chase Bank, N.A. Member FDIC</div>
            <div>© 2026 JPMorgan Chase &amp; Co.</div>
          </div>

          {/* Chase blue bottom bar */}
          <div style={{
            height: 8, background: '#1352AA',
            marginLeft: -20, marginRight: -20,
          }} />
        </div>
      </div>
    </div>
  );
}
