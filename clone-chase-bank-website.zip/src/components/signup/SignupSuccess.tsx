import ChaseLogo from '../ChaseLogo';

interface Props {
  onSignIn: () => void;
}

export default function SignupSuccess({ onSignIn }: Props) {
  return (
    <div
      style={{
        width: '100%',
        height: '100%',
        background: '#fff',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '40px 32px',
        fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
      }}
    >
      {/* Chase Logo */}
      <div style={{ marginBottom: 40 }}>
        <ChaseLogo color="#2558b5" size={48} showText />
      </div>

      {/* Green checkmark circle */}
      <div
        style={{
          width: 80,
          height: 80,
          borderRadius: '50%',
          background: '#e8f5ec',
          border: '3px solid #1a7a3c',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          marginBottom: 28,
        }}
      >
        {/* Checkmark drawn with CSS / border trick — no SVG, no emoji */}
        <div
          style={{
            width: 36,
            height: 20,
            borderLeft: '4px solid #1a7a3c',
            borderBottom: '4px solid #1a7a3c',
            transform: 'rotate(-45deg) translate(4px, -4px)',
          }}
        />
      </div>

      {/* Heading */}
      <div
        style={{
          fontSize: 26,
          fontWeight: 700,
          color: '#111',
          marginBottom: 14,
          textAlign: 'center',
        }}
      >
        You're all set!
      </div>

      {/* Sub text */}
      <div
        style={{
          fontSize: 15,
          color: '#555',
          textAlign: 'center',
          lineHeight: 1.6,
          maxWidth: 300,
          marginBottom: 40,
        }}
      >
        Welcome to Chase Mobile. You can now sign in with your new username and password.
      </div>

      {/* Sign in button */}
      <button
        onClick={onSignIn}
        style={{
          width: '100%',
          maxWidth: 340,
          background: '#2558b5',
          color: '#fff',
          border: 'none',
          borderRadius: 6,
          padding: '16px 0',
          fontSize: 17,
          fontWeight: 700,
          cursor: 'pointer',
          letterSpacing: 0.2,
        }}
      >
        Sign in
      </button>
    </div>
  );
}
