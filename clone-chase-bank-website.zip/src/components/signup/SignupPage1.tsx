import { useState } from 'react';
import SignupLayout, {
  UnderlineInput,
  ShowToggle,
  PrimaryBtn,
  BlueLink,
  SectionTitle,
  FixedBottom,
} from './SignupLayout';
import BottomSheetPicker from './BottomSheetPicker';
import type { SignupData } from './signupTypes';

interface Props {
  data: SignupData;
  onUpdate: (d: Partial<SignupData>) => void;
  onNext: () => void;
  onCancel: () => void;
}

const ACCOUNT_TYPES = ['Personal', 'Business', 'Business and personal'];

export default function SignupPage1({ data, onUpdate, onNext, onCancel }: Props) {
  const [showSheet, setShowSheet] = useState(false);
  const [showAcct, setShowAcct] = useState(false);
  const [showSSN, setShowSSN] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const usernameRules = [
    { label: '8–32 characters long', ok: data.username.length >= 8 && data.username.length <= 32 },
    { label: 'Contains at least one letter and one number', ok: /[a-zA-Z]/.test(data.username) && /[0-9]/.test(data.username) },
    { label: 'No special characters (&, %, *, etc.)', ok: !/[&%*<>!@#^()+=[\]{};:'",./\\|`~]/.test(data.username) },
  ];

  const validate = () => {
    const e: Record<string, string> = {};
    if (!data.accountType) e.accountType = 'Please select an account type.';
    if (!data.accountNumber) e.accountNumber = 'Account or card number is required.';
    if (!data.ssn) e.ssn = 'Social Security number is required.';
    if (!data.username) {
      e.username = 'Username is required.';
    } else if (!usernameRules.every((r) => r.ok)) {
      e.username = 'Username does not meet requirements.';
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  return (
    <SignupLayout step={1} onCancel={onCancel}>
      <div style={{ paddingTop: 20 }}>
        <SectionTitle text="Set up your account" />

        {/* Account Type picker trigger */}
        <div style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 12, color: errors.accountType ? '#c0392b' : '#666', marginBottom: 4, fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif" }}>
            Account type
          </div>
          <div
            onClick={() => setShowSheet(true)}
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              borderBottom: `1.5px solid ${errors.accountType ? '#c0392b' : data.accountType ? '#2558b5' : '#ccc'}`,
              paddingBottom: 8,
              cursor: 'pointer',
            }}
          >
            <span
              style={{
                fontSize: 16,
                color: data.accountType ? '#111' : '#aaa',
                fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
              }}
            >
              {data.accountType || 'Select account type'}
            </span>
            <span style={{ color: '#888', fontSize: 14 }}>›</span>
          </div>
          {errors.accountType && (
            <div style={{ fontSize: 12, color: '#c0392b', marginTop: 4, fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif" }}>
              {errors.accountType}
            </div>
          )}
        </div>

        {/* Fields revealed after account type selected */}
        {data.accountType && (
          <>
            <UnderlineInput
              label="Account or debit/credit card number"
              value={data.accountNumber}
              onChange={(v) => onUpdate({ accountNumber: v })}
              type={showAcct ? 'text' : 'password'}
              inputMode="numeric"
              maxLength={19}
              error={errors.accountNumber}
              rightSlot={
                <ShowToggle show={showAcct} onToggle={() => setShowAcct(!showAcct)} />
              }
            />
            <div style={{ marginTop: -16, marginBottom: 20 }}>
              <BlueLink label="Can't find your account number?" />
            </div>

            <UnderlineInput
              label="Social Security number"
              value={data.ssn}
              onChange={(v) => onUpdate({ ssn: v })}
              type={showSSN ? 'text' : 'password'}
              inputMode="numeric"
              maxLength={11}
              error={errors.ssn}
              rightSlot={
                <ShowToggle show={showSSN} onToggle={() => setShowSSN(!showSSN)} />
              }
            />
            <div style={{ marginTop: -16, marginBottom: 24 }}>
              <BlueLink label="Don't have a Social Security number?" />
            </div>

            <UnderlineInput
              label="Create a username"
              value={data.username}
              onChange={(v) => onUpdate({ username: v })}
              autoComplete="username"
              error={errors.username}
            />

            {/* Username rules */}
            <div style={{ marginTop: -16, marginBottom: 8 }}>
              {usernameRules.map((r) => (
                <div
                  key={r.label}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 6,
                    fontSize: 12,
                    color: data.username.length === 0 ? '#888' : r.ok ? '#1a7a3c' : '#c0392b',
                    fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
                    marginBottom: 4,
                  }}
                >
                  <span style={{ fontSize: 10 }}>
                    {data.username.length === 0 ? '•' : r.ok ? '✓' : '✗'}
                  </span>
                  {r.label}
                </div>
              ))}
            </div>
          </>
        )}
      </div>

      <FixedBottom>
        <PrimaryBtn label="Next" onClick={() => { if (validate()) onNext(); }} />
      </FixedBottom>

      <BottomSheetPicker
        isOpen={showSheet}
        onClose={() => setShowSheet(false)}
        options={ACCOUNT_TYPES}
        selected={data.accountType}
        onSelect={(v) => onUpdate({ accountType: v })}
        title="Select account type"
      />
    </SignupLayout>
  );
}
