import { useEffect, useRef, useState } from 'react';

interface BottomSheetPickerProps {
  isOpen: boolean;
  onClose: () => void;
  options: string[];
  selected: string;
  onSelect: (value: string) => void;
  title?: string;
}

export default function BottomSheetPicker({
  isOpen,
  onClose,
  options,
  selected,
  onSelect,
  title,
}: BottomSheetPickerProps) {
  const [visible, setVisible] = useState(false);
  const [animating, setAnimating] = useState(false);
  const startY = useRef(0);
  const currentY = useRef(0);
  const sheetRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      setVisible(true);
      requestAnimationFrame(() => {
        requestAnimationFrame(() => setAnimating(true));
      });
    } else {
      setAnimating(false);
      const t = setTimeout(() => setVisible(false), 320);
      return () => clearTimeout(t);
    }
  }, [isOpen]);

  const handleSelect = (opt: string) => {
    onSelect(opt);
    onClose();
  };

  const handleOverlayClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) onClose();
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    startY.current = e.touches[0].clientY;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    currentY.current = e.touches[0].clientY;
    const delta = currentY.current - startY.current;
    if (delta > 0 && sheetRef.current) {
      sheetRef.current.style.transform = `translateY(${delta}px)`;
    }
  };

  const handleTouchEnd = () => {
    const delta = currentY.current - startY.current;
    if (delta > 80) {
      onClose();
    } else if (sheetRef.current) {
      sheetRef.current.style.transform = 'translateY(0)';
    }
  };

  if (!visible) return null;

  return (
    <div
      onClick={handleOverlayClick}
      style={{
        position: 'fixed',
        inset: 0,
        background: animating ? 'rgba(0,0,0,0.45)' : 'rgba(0,0,0,0)',
        transition: 'background 0.32s ease',
        zIndex: 1000,
        display: 'flex',
        alignItems: 'flex-end',
      }}
    >
      <div
        ref={sheetRef}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        style={{
          width: '100%',
          background: '#fff',
          borderRadius: '16px 16px 0 0',
          transform: animating ? 'translateY(0)' : 'translateY(100%)',
          transition: 'transform 0.32s cubic-bezier(0.32,0.72,0,1)',
          maxHeight: '70vh',
          display: 'flex',
          flexDirection: 'column',
          overflow: 'hidden',
        }}
      >
        {/* Drag handle */}
        <div
          style={{
            display: 'flex',
            justifyContent: 'center',
            padding: '12px 0 4px',
            flexShrink: 0,
            cursor: 'grab',
          }}
        >
          <div
            style={{
              width: 40,
              height: 4,
              borderRadius: 2,
              background: '#aaa',
            }}
          />
        </div>

        {/* Title */}
        {title && (
          <div
            style={{
              textAlign: 'center',
              fontSize: 14,
              color: '#888',
              padding: '4px 0 12px',
              fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
              borderBottom: '1px solid #eee',
              flexShrink: 0,
            }}
          >
            {title}
          </div>
        )}

        {/* Options */}
        <div style={{ overflowY: 'auto', WebkitOverflowScrolling: 'touch' }}>
          {options.map((opt) => {
            const isSelected = opt === selected;
            return (
              <div
                key={opt}
                onClick={() => handleSelect(opt)}
                style={{
                  textAlign: 'center',
                  padding: '18px 20px',
                  fontSize: 20,
                  fontWeight: isSelected ? 700 : 400,
                  color: isSelected ? '#111' : '#777',
                  fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
                  borderBottom: '1px solid #f2f2f2',
                  cursor: 'pointer',
                  transition: 'background 0.15s',
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLDivElement).style.background = '#f7f7f7';
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLDivElement).style.background = 'transparent';
                }}
              >
                {opt}
              </div>
            );
          })}
        </div>

        {/* Cancel button */}
        <div style={{ flexShrink: 0, padding: '12px 20px 28px' }}>
          <button
            onClick={onClose}
            style={{
              width: '100%',
              background: '#f2f2f2',
              border: 'none',
              borderRadius: 10,
              padding: '15px 0',
              fontSize: 17,
              fontWeight: 600,
              color: '#111',
              cursor: 'pointer',
              fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
            }}
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}
