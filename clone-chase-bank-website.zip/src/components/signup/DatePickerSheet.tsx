import { useEffect, useRef, useState } from 'react';

interface DatePickerSheetProps {
  isOpen: boolean;
  onClose: () => void;
  value: { month: string; day: string; year: string };
  onChange: (v: { month: string; day: string; year: string }) => void;
}

const MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

const DAYS = Array.from({ length: 31 }, (_, i) => String(i + 1).padStart(2, '0'));

const currentYear = new Date().getFullYear();
const YEARS = Array.from({ length: 100 }, (_, i) => String(currentYear - i));

interface DrumProps {
  items: string[];
  selected: string;
  onSelect: (v: string) => void;
  width: number;
}

function Drum({ items, selected, onSelect, width }: DrumProps) {
  const ITEM_H = 44;
  const listRef = useRef<HTMLDivElement>(null);
  const isDragging = useRef(false);
  const startY = useRef(0);
  const scrollStart = useRef(0);

  const selectedIdx = items.indexOf(selected);

  useEffect(() => {
    if (listRef.current) {
      listRef.current.scrollTop = Math.max(0, selectedIdx) * ITEM_H;
    }
  }, [selectedIdx]);

  const getSelectedFromScroll = (scrollTop: number) => {
    const idx = Math.round(scrollTop / ITEM_H);
    const clamped = Math.max(0, Math.min(items.length - 1, idx));
    return items[clamped];
  };

  const handleScroll = () => {
    if (!listRef.current || isDragging.current) return;
    const val = getSelectedFromScroll(listRef.current.scrollTop);
    if (val !== selected) onSelect(val);
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    isDragging.current = true;
    startY.current = e.clientY;
    scrollStart.current = listRef.current?.scrollTop ?? 0;
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging.current || !listRef.current) return;
    const delta = startY.current - e.clientY;
    listRef.current.scrollTop = scrollStart.current + delta;
  };

  const handleMouseUp = () => {
    if (!isDragging.current || !listRef.current) return;
    isDragging.current = false;
    const val = getSelectedFromScroll(listRef.current.scrollTop);
    onSelect(val);
    // Snap to nearest
    const idx = items.indexOf(val);
    listRef.current.scrollTo({ top: idx * ITEM_H, behavior: 'smooth' });
  };

  return (
    <div
      style={{
        width,
        position: 'relative',
        height: ITEM_H * 5,
        overflow: 'hidden',
        cursor: 'grab',
      }}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
    >
      {/* Selection highlight */}
      <div
        style={{
          position: 'absolute',
          top: ITEM_H * 2,
          left: 0,
          right: 0,
          height: ITEM_H,
          background: 'rgba(37,88,181,0.08)',
          borderTop: '1px solid rgba(37,88,181,0.2)',
          borderBottom: '1px solid rgba(37,88,181,0.2)',
          pointerEvents: 'none',
          zIndex: 1,
        }}
      />

      {/* Fade top */}
      <div
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          height: ITEM_H * 2,
          background: 'linear-gradient(to bottom, rgba(255,255,255,1), rgba(255,255,255,0))',
          pointerEvents: 'none',
          zIndex: 2,
        }}
      />
      {/* Fade bottom */}
      <div
        style={{
          position: 'absolute',
          bottom: 0,
          left: 0,
          right: 0,
          height: ITEM_H * 2,
          background: 'linear-gradient(to top, rgba(255,255,255,1), rgba(255,255,255,0))',
          pointerEvents: 'none',
          zIndex: 2,
        }}
      />

      <div
        ref={listRef}
        onScroll={handleScroll}
        style={{
          height: '100%',
          overflowY: 'scroll',
          scrollSnapType: 'y mandatory',
          WebkitOverflowScrolling: 'touch',
          scrollbarWidth: 'none',
        }}
      >
        {/* Padding top/bottom so first/last items can center */}
        <div style={{ height: ITEM_H * 2 }} />
        {items.map((item) => (
          <div
            key={item}
            onClick={() => {
              onSelect(item);
              const idx = items.indexOf(item);
              listRef.current?.scrollTo({ top: idx * ITEM_H, behavior: 'smooth' });
            }}
            style={{
              height: ITEM_H,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              scrollSnapAlign: 'center',
              fontSize: item === selected ? 18 : 16,
              fontWeight: item === selected ? 700 : 400,
              color: item === selected ? '#111' : '#aaa',
              fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
              transition: 'font-size 0.1s, color 0.1s',
              userSelect: 'none',
            }}
          >
            {item}
          </div>
        ))}
        <div style={{ height: ITEM_H * 2 }} />
      </div>
    </div>
  );
}

export default function DatePickerSheet({
  isOpen,
  onClose,
  value,
  onChange,
}: DatePickerSheetProps) {
  const [visible, setVisible] = useState(false);
  const [animating, setAnimating] = useState(false);
  const [local, setLocal] = useState(value);

  useEffect(() => {
    if (isOpen) {
      setLocal(value);
      setVisible(true);
      requestAnimationFrame(() => requestAnimationFrame(() => setAnimating(true)));
    } else {
      setAnimating(false);
      const t = setTimeout(() => setVisible(false), 320);
      return () => clearTimeout(t);
    }
  }, [isOpen]);

  const handleDone = () => {
    onChange(local);
    onClose();
  };

  if (!visible) return null;

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
      style={{
        position: 'fixed',
        inset: 0,
        background: animating ? 'rgba(0,0,0,0.45)' : 'rgba(0,0,0,0)',
        transition: 'background 0.32s ease',
        zIndex: 1000,
        display: 'flex',
        alignItems: 'flex-end',
      }}
    >
      <div
        style={{
          width: '100%',
          background: '#fff',
          borderRadius: '16px 16px 0 0',
          transform: animating ? 'translateY(0)' : 'translateY(100%)',
          transition: 'transform 0.32s cubic-bezier(0.32,0.72,0,1)',
        }}
      >
        {/* Handle */}
        <div style={{ display: 'flex', justifyContent: 'center', padding: '12px 0 4px' }}>
          <div style={{ width: 40, height: 4, borderRadius: 2, background: '#aaa' }} />
        </div>

        {/* Toolbar */}
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            padding: '8px 20px 12px',
            borderBottom: '1px solid #eee',
          }}
        >
          <button
            onClick={onClose}
            style={{
              background: 'none',
              border: 'none',
              color: '#2558b5',
              fontSize: 16,
              fontWeight: 600,
              cursor: 'pointer',
              fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
            }}
          >
            Cancel
          </button>
          <span
            style={{
              fontSize: 16,
              fontWeight: 600,
              color: '#111',
              fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
            }}
          >
            Date of Birth
          </span>
          <button
            onClick={handleDone}
            style={{
              background: 'none',
              border: 'none',
              color: '#2558b5',
              fontSize: 16,
              fontWeight: 600,
              cursor: 'pointer',
              fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
            }}
          >
            Done
          </button>
        </div>

        {/* Drums */}
        <div
          style={{
            display: 'flex',
            justifyContent: 'center',
            gap: 4,
            padding: '8px 16px 24px',
          }}
        >
          <Drum
            items={MONTHS}
            selected={local.month}
            onSelect={(v) => setLocal((p) => ({ ...p, month: v }))}
            width={130}
          />
          <Drum
            items={DAYS}
            selected={local.day}
            onSelect={(v) => setLocal((p) => ({ ...p, day: v }))}
            width={70}
          />
          <Drum
            items={YEARS}
            selected={local.year}
            onSelect={(v) => setLocal((p) => ({ ...p, year: v }))}
            width={90}
          />
        </div>
      </div>
    </div>
  );
}
