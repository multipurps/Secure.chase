import { useState, useRef } from 'react';
import SignupLayout, {
  PrimaryBtn,
  SectionTitle,
  FixedBottom,
} from './SignupLayout';
import type { SignupData } from './signupTypes';

interface Props {
  data: SignupData;
  onUpdate: (d: Partial<SignupData>) => void;
  onNext: () => void;
  onCancel: () => void;
}

type VerifyStep = 'method' | 'code';

function maskPhone(phone: string) {
  const digits = phone.replace(/\D/g, '');
  if (digits.length < 4) return phone;
  return `(***) ***-${digits.slice(-4)}`;
}

function maskEmail(email: string) {
  const [local, domain] = email.split('@');
  if (!domain) return email;
  return `${local.slice(0, 2)}***@${domain}`;
}

export default function SignupPage4({ data, onUpdate, onNext, onCancel }: Props) {
  const [step, setStep] = useState<VerifyStep>('method');
  const [code, setCode] = useState(['', '', '', '', '', '']);
  const [codeError, setCodeError] = useState('');
  const [methodError, setMethodError] = useState('');
  const [resent, setResent] = useState(false);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  const maskedPhone = maskPhone(data.phone);
  const maskedEmail = maskEmail(data.email);

  const methods: { id: 'text' | 'call' | 'email'; label: string; sub: string }[] = [
    { id: 'text', label: 'Text to:', sub: maskedPhone },
    { id: 'call', label: 'Call:', sub: maskedPhone },
    { id: 'email', label: 'Email:', sub: maskedEmail },
  ];

  const handleSendCode = () => {
    if (!data.verificationMethod) {
      setMethodError('Please select a verification method.');
      return;
    }
    setMethodError('');
    setStep('code');
  };

  const handleCodeChange = (idx: number, val: string) => {
    const digit = val.replace(/\D/g, '').slice(-1);
    const next = [...code];
    next[idx] = digit;
    setCode(next);
    setCodeError('');
    if (digit && idx < 5) {
      inputRefs.current[idx + 1]?.focus();
    }
  };

  const handleCodeKeyDown = (idx: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !code[idx] && idx > 0) {
      inputRefs.current[idx - 1]?.focus();
    }
  };

  const handleVerify = () => {
    const fullCode = code.join('');
    if (fullCode.length < 6) {
      setCodeError('Please enter the complete 6-digit code.');
      return;
    }
    // In production, verify against Supabase OTP or backend
    // For demo, any 6-digit code passes
    onUpdate({ verificationCode: fullCode });
    onNext();
  };

  const handleResend = () => {
    setResent(true);
    setCode(['', '', '', '', '', '']);
    setTimeout(() => setResent(false), 3000);
  };

  return (
    <SignupLayout step={4} onCancel={onCancel}>
      {step === 'method' ? (
        <div style={{ paddingTop: 20 }}>
          <SectionTitle
            text="Verify it's you"
            sub="For added security, we'll send a one-time passcode to confirm your identity."
          />

          {methods.map((m) => {
            const isSelected = data.verificationMethod === m.id;
            return (
              <div
                key={m.id}
                onClick={() => {
                  onUpdate({ verificationMethod: m.id });
                  setMethodError('');
                }}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 14,
                  padding: '18px 0',
                  borderBottom: '1px solid #eee',
                  cursor: 'pointer',
                }}
              >
                {/* Radio dot */}
                <div
                  style={{
                    width: 22,
                    height: 22,
                    borderRadius: '50%',
                    border: `2px solid ${isSelected ? '#2558b5' : '#ccc'}`,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    flexShrink: 0,
                    transition: 'border-color 0.2s',
                  }}
                >
                  {isSelected && (
                    <div
                      style={{
                        width: 12,
                        height: 12,
                        borderRadius: '50%',
                        background: '#2558b5',
                      }}
                    />
                  )}
                </div>

                <div>
                  <div
                    style={{
                      fontSize: 15,
                      color: '#555',
                      fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
                    }}
                  >
                    {m.label}
                  </div>
                  <div
                    style={{
                      fontSize: 16,
                      fontWeight: 600,
                      color: '#111',
                      fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
                      marginTop: 2,
                    }}
                  >
                    {m.sub}
                  </div>
                </div>
              </div>
            );
          })}

          {methodError && (
            <div
              style={{
                fontSize: 13,
                color: '#c0392b',
                marginTop: 10,
                fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
              }}
            >
              {methodError}
            </div>
          )}
        </div>
      ) : (
        <div style={{ paddingTop: 20 }}>
          <SectionTitle
            text="Enter your code"
            sub={`We sent a one-time passcode to ${data.verificationMethod === 'email' ? maskedEmail : maskedPhone}`}
          />

          {/* 6-box OTP input */}
          <div
            style={{
              display: 'flex',
              justifyContent: 'center',
              gap: 10,
              marginBottom: 20,
            }}
          >
            {code.map((digit, idx) => (
              <input
                key={idx}
                ref={(el) => { inputRefs.current[idx] = el; }}
                type="text"
                inputMode="numeric"
                maxLength={1}
                value={digit}
                onChange={(e) => handleCodeChange(idx, e.target.value)}
                onKeyDown={(e) => handleCodeKeyDown(idx, e)}
                style={{
                  width: 44,
                  height: 52,
                  textAlign: 'center',
                  fontSize: 22,
                  fontWeight: 700,
                  fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
                  color: '#111',
                  border: 'none',
                  borderBottom: `2px solid ${codeError ? '#c0392b' : digit ? '#2558b5' : '#ccc'}`,
                  outline: 'none',
                  background: 'transparent',
                  transition: 'border-color 0.2s',
                }}
              />
            ))}
          </div>

          {codeError && (
            <div
              style={{
                textAlign: 'center',
                fontSize: 13,
                color: '#c0392b',
                marginBottom: 12,
                fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
              }}
            >
              {codeError}
            </div>
          )}

          <div
            style={{
              textAlign: 'center',
              fontSize: 14,
              color: '#555',
              fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
              marginBottom: 4,
            }}
          >
            Didn't receive a code?{' '}
            <button
              onClick={handleResend}
              style={{
                background: 'none',
                border: 'none',
                color: '#2558b5',
                fontWeight: 600,
                fontSize: 14,
                cursor: 'pointer',
                fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
                padding: 0,
              }}
            >
              Resend
            </button>
          </div>

          {resent && (
            <div
              style={{
                textAlign: 'center',
                fontSize: 13,
                color: '#1a7a3c',
                fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
                marginBottom: 4,
              }}
            >
              A new code has been sent.
            </div>
          )}
        </div>
      )}

      <FixedBottom>
        {step === 'method' ? (
          <PrimaryBtn label="Send code" onClick={handleSendCode} />
        ) : (
          <PrimaryBtn label="Verify" onClick={handleVerify} />
        )}
      </FixedBottom>
    </SignupLayout>
  );
}
