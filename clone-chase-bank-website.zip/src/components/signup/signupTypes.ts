export interface SignupData {
  // Page 1
  accountType: string;
  accountNumber: string;
  ssn: string;
  username: string;

  // Page 2
  firstName: string;
  middleName: string;
  lastName: string;
  dateOfBirth: { month: string; day: string; year: string };
  email: string;
  confirmEmail: string;
  phone: string;

  // Page 3
  streetAddress: string;
  aptSuite: string;
  city: string;
  state: string;
  zip: string;

  // Page 4
  verificationMethod: 'text' | 'call' | 'email' | '';
  verificationCode: string;

  // Page 5
  password: string;
  confirmPassword: string;
  securityQuestion: string;
  securityAnswer: string;
  agreedToTerms: boolean;
}

export const initialSignupData: SignupData = {
  accountType: '',
  accountNumber: '',
  ssn: '',
  username: '',

  firstName: '',
  middleName: '',
  lastName: '',
  dateOfBirth: { month: 'January', day: '01', year: String(new Date().getFullYear() - 25) },
  email: '',
  confirmEmail: '',
  phone: '',

  streetAddress: '',
  aptSuite: '',
  city: '',
  state: '',
  zip: '',

  verificationMethod: '',
  verificationCode: '',

  password: '',
  confirmPassword: '',
  securityQuestion: '',
  securityAnswer: '',
  agreedToTerms: false,
};
