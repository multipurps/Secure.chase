import { useState } from 'react';
import SignupLayout, {
  UnderlineInput,
  PrimaryBtn,
  SectionTitle,
  FixedBottom,
} from './SignupLayout';
import DatePickerSheet from './DatePickerSheet';
import type { SignupData } from './signupTypes';

interface Props {
  data: SignupData;
  onUpdate: (d: Partial<SignupData>) => void;
  onNext: () => void;
  onCancel: () => void;
}

export default function SignupPage2({ data, onUpdate, onNext, onCancel }: Props) {
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const e: Record<string, string> = {};
    if (!data.firstName.trim()) e.firstName = 'First name is required.';
    if (!data.lastName.trim()) e.lastName = 'Last name is required.';
    if (!data.email.trim()) {
      e.email = 'Email is required.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
      e.email = 'Please enter a valid email address.';
    }
    if (!data.confirmEmail.trim()) {
      e.confirmEmail = 'Please confirm your email.';
    } else if (data.email !== data.confirmEmail) {
      e.confirmEmail = 'Email addresses do not match.';
    }
    if (!data.phone.trim()) {
      e.phone = 'Phone number is required.';
    } else if (data.phone.replace(/\D/g, '').length < 10) {
      e.phone = 'Please enter a valid 10-digit phone number.';
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const dobDisplay = `${data.dateOfBirth.month} ${data.dateOfBirth.day}, ${data.dateOfBirth.year}`;

  return (
    <SignupLayout step={2} onCancel={onCancel}>
      <div style={{ paddingTop: 20 }}>
        <SectionTitle text="Tell us about yourself" />

        <UnderlineInput
          label="First name"
          value={data.firstName}
          onChange={(v) => onUpdate({ firstName: v })}
          autoComplete="given-name"
          error={errors.firstName}
        />

        <UnderlineInput
          label="Middle name"
          value={data.middleName}
          onChange={(v) => onUpdate({ middleName: v })}
          optional
          autoComplete="additional-name"
        />

        <UnderlineInput
          label="Last name"
          value={data.lastName}
          onChange={(v) => onUpdate({ lastName: v })}
          autoComplete="family-name"
          error={errors.lastName}
        />

        {/* Date of Birth — tap to open drum picker */}
        <div style={{ marginBottom: 24 }}>
          <div style={{ fontSize: 12, color: '#666', marginBottom: 4, fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif" }}>
            Date of birth
          </div>
          <div
            onClick={() => setShowDatePicker(true)}
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              borderBottom: `1.5px solid ${data.dateOfBirth.year ? '#2558b5' : '#ccc'}`,
              paddingBottom: 8,
              cursor: 'pointer',
            }}
          >
            <span
              style={{
                fontSize: 16,
                color: '#111',
                fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
              }}
            >
              {dobDisplay}
            </span>
            <span style={{ color: '#888', fontSize: 14 }}>›</span>
          </div>
        </div>

        <UnderlineInput
          label="Email address"
          value={data.email}
          onChange={(v) => onUpdate({ email: v })}
          type="email"
          inputMode="email"
          autoComplete="email"
          error={errors.email}
        />

        <UnderlineInput
          label="Confirm email address"
          value={data.confirmEmail}
          onChange={(v) => onUpdate({ confirmEmail: v })}
          type="email"
          inputMode="email"
          autoComplete="email"
          error={errors.confirmEmail}
        />

        <UnderlineInput
          label="Mobile phone number"
          value={data.phone}
          onChange={(v) => {
            // Format as (XXX) XXX-XXXX
            const digits = v.replace(/\D/g, '').slice(0, 10);
            let formatted = digits;
            if (digits.length >= 6) {
              formatted = `(${digits.slice(0, 3)}) ${digits.slice(3, 6)}-${digits.slice(6)}`;
            } else if (digits.length >= 3) {
              formatted = `(${digits.slice(0, 3)}) ${digits.slice(3)}`;
            }
            onUpdate({ phone: formatted });
          }}
          type="tel"
          inputMode="numeric"
          autoComplete="tel"
          prefix="+1"
          helper="We'll send a verification code to this number"
          error={errors.phone}
        />
      </div>

      <FixedBottom>
        <PrimaryBtn label="Next" onClick={() => { if (validate()) onNext(); }} />
      </FixedBottom>

      <DatePickerSheet
        isOpen={showDatePicker}
        onClose={() => setShowDatePicker(false)}
        value={data.dateOfBirth}
        onChange={(v) => onUpdate({ dateOfBirth: v })}
      />
    </SignupLayout>
  );
}
