import { useState } from 'react';
import SignupLayout, {
  UnderlineInput,
  ShowToggle,
  PrimaryBtn,
  SectionTitle,
  FixedBottom,
} from './SignupLayout';
import BottomSheetPicker from './BottomSheetPicker';
import type { SignupData } from './signupTypes';
import { signUpUser } from '../../lib/supabase';

interface Props {
  data: SignupData;
  onUpdate: (d: Partial<SignupData>) => void;
  onDone: () => void;
  onCancel: () => void;
}

const SECURITY_QUESTIONS = [
  'What was the name of your first pet?',
  'What is your mother\'s maiden name?',
  'What city were you born in?',
  'What was your childhood nickname?',
  'What is the name of your first school?',
];

function hashString(str: string): string {
  // Simple client-side hash (in production use bcrypt via backend)
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash).toString(16);
}

export default function SignupPage5({ data, onUpdate, onDone, onCancel }: Props) {
  const [showPw, setShowPw] = useState(false);
  const [showConfirmPw, setShowConfirmPw] = useState(false);
  const [showAnswer, setShowAnswer] = useState(false);
  const [showQuestionSheet, setShowQuestionSheet] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [apiError, setApiError] = useState('');

  const pwRules = [
    { label: '8–32 characters long', ok: data.password.length >= 8 && data.password.length <= 32 },
    { label: 'At least one uppercase letter', ok: /[A-Z]/.test(data.password) },
    { label: 'At least one number', ok: /[0-9]/.test(data.password) },
    { label: 'At least one special character', ok: /[^A-Za-z0-9]/.test(data.password) },
    { label: 'Does not contain your username', ok: data.username.length > 0 && !data.password.toLowerCase().includes(data.username.toLowerCase()) },
  ];

  const validate = () => {
    const e: Record<string, string> = {};
    if (!data.password) {
      e.password = 'Password is required.';
    } else if (!pwRules.every((r) => r.ok)) {
      e.password = 'Password does not meet all requirements.';
    }
    if (!data.confirmPassword) {
      e.confirmPassword = 'Please confirm your password.';
    } else if (data.password !== data.confirmPassword) {
      e.confirmPassword = 'Passwords do not match.';
    }
    if (!data.securityQuestion) e.securityQuestion = 'Please select a security question.';
    if (!data.securityAnswer.trim()) e.securityAnswer = 'Security answer is required.';
    if (!data.agreedToTerms) e.terms = 'You must agree to the Service Agreement.';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async () => {
    if (!validate()) return;
    setLoading(true);
    setApiError('');

    try {
      await signUpUser(data.email, data.password, {
        account_type: data.accountType,
        username: data.username,
        first_name: data.firstName,
        middle_name: data.middleName,
        last_name: data.lastName,
        date_of_birth: `${data.dateOfBirth.year}-${String(new Date(`${data.dateOfBirth.month} 1`).getMonth() + 1).padStart(2, '0')}-${data.dateOfBirth.day}`,
        email: data.email,
        phone: data.phone,
        street_address: data.streetAddress,
        apt_suite: data.aptSuite,
        city: data.city,
        state: data.state,
        zip: data.zip,
        security_question: data.securityQuestion,
        security_answer_hash: hashString(data.securityAnswer.toLowerCase().trim()),
      });
      onDone();
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'An error occurred. Please try again.';
      setApiError(message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <SignupLayout step={5} onCancel={onCancel}>
      <div style={{ paddingTop: 20 }}>
        <SectionTitle
          text="Create a password"
          sub="Your password will be used each time you sign in."
        />

        <UnderlineInput
          label="Password"
          value={data.password}
          onChange={(v) => onUpdate({ password: v })}
          type={showPw ? 'text' : 'password'}
          autoComplete="new-password"
          error={errors.password}
          rightSlot={<ShowToggle show={showPw} onToggle={() => setShowPw(!showPw)} />}
        />

        {/* Password rules */}
        <div style={{ marginTop: -14, marginBottom: 20 }}>
          {pwRules.map((r) => (
            <div
              key={r.label}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 6,
                fontSize: 12,
                color: data.password.length === 0 ? '#888' : r.ok ? '#1a7a3c' : '#c0392b',
                fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
                marginBottom: 4,
              }}
            >
              <span style={{ fontSize: 10 }}>
                {data.password.length === 0 ? '•' : r.ok ? '✓' : '✗'}
              </span>
              {r.label}
            </div>
          ))}
        </div>

        <UnderlineInput
          label="Confirm password"
          value={data.confirmPassword}
          onChange={(v) => onUpdate({ confirmPassword: v })}
          type={showConfirmPw ? 'text' : 'password'}
          autoComplete="new-password"
          error={errors.confirmPassword}
          rightSlot={
            <ShowToggle show={showConfirmPw} onToggle={() => setShowConfirmPw(!showConfirmPw)} />
          }
        />

        {/* Security Question picker */}
        <div style={{ marginBottom: 8 }}>
          <div
            style={{
              fontSize: 12,
              color: errors.securityQuestion ? '#c0392b' : '#666',
              marginBottom: 4,
              fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
            }}
          >
            Security question
          </div>
          <div
            onClick={() => setShowQuestionSheet(true)}
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              borderBottom: `1.5px solid ${errors.securityQuestion ? '#c0392b' : data.securityQuestion ? '#2558b5' : '#ccc'}`,
              paddingBottom: 8,
              cursor: 'pointer',
              minHeight: 32,
            }}
          >
            <span
              style={{
                fontSize: 15,
                color: data.securityQuestion ? '#111' : '#aaa',
                fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
                flex: 1,
                paddingRight: 8,
                lineHeight: 1.3,
              }}
            >
              {data.securityQuestion || 'Select a security question'}
            </span>
            <span style={{ color: '#888', fontSize: 14, flexShrink: 0 }}>›</span>
          </div>
          {errors.securityQuestion && (
            <div
              style={{
                fontSize: 12,
                color: '#c0392b',
                marginTop: 4,
                fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
              }}
            >
              {errors.securityQuestion}
            </div>
          )}
        </div>

        <div style={{ marginBottom: 20 }} />

        <UnderlineInput
          label="Security answer"
          value={data.securityAnswer}
          onChange={(v) => onUpdate({ securityAnswer: v })}
          type={showAnswer ? 'text' : 'password'}
          error={errors.securityAnswer}
          rightSlot={<ShowToggle show={showAnswer} onToggle={() => setShowAnswer(!showAnswer)} />}
        />

        {/* Terms checkbox */}
        <div
          style={{
            display: 'flex',
            alignItems: 'flex-start',
            gap: 10,
            marginBottom: 8,
            marginTop: 4,
          }}
        >
          <input
            type="checkbox"
            id="terms"
            checked={data.agreedToTerms}
            onChange={(e) => onUpdate({ agreedToTerms: e.target.checked })}
            style={{
              accentColor: '#2558b5',
              width: 18,
              height: 18,
              marginTop: 2,
              flexShrink: 0,
              cursor: 'pointer',
            }}
          />
          <label
            htmlFor="terms"
            style={{
              fontSize: 14,
              color: '#333',
              fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
              lineHeight: 1.5,
              cursor: 'pointer',
            }}
          >
            I agree to the{' '}
            <span
              style={{
                color: '#2558b5',
                textDecoration: 'underline',
                cursor: 'pointer',
              }}
            >
              Chase Online Service Agreement
            </span>
          </label>
        </div>

        {errors.terms && (
          <div
            style={{
              fontSize: 12,
              color: '#c0392b',
              marginBottom: 8,
              fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
            }}
          >
            {errors.terms}
          </div>
        )}

        {apiError && (
          <div
            style={{
              fontSize: 13,
              color: '#c0392b',
              marginTop: 8,
              marginBottom: 4,
              fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
              textAlign: 'center',
            }}
          >
            {apiError}
          </div>
        )}
      </div>

      <FixedBottom>
        <PrimaryBtn label="Submit" onClick={handleSubmit} loading={loading} />
      </FixedBottom>

      <BottomSheetPicker
        isOpen={showQuestionSheet}
        onClose={() => setShowQuestionSheet(false)}
        options={SECURITY_QUESTIONS}
        selected={data.securityQuestion}
        onSelect={(v) => onUpdate({ securityQuestion: v })}
        title="Select a security question"
      />
    </SignupLayout>
  );
}
