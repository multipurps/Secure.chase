interface SignupLayoutProps {
  step: number; // 1–5
  onCancel: () => void;
  children: React.ReactNode;
}

export default function SignupLayout({ step, onCancel, children }: SignupLayoutProps) {
  return (
    <div
      style={{
        width: '100%',
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        background: '#fff',
        overflow: 'hidden',
      }}
    >
      {/* ── Header ── */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          padding: '16px 20px',
          borderBottom: '1px solid #e5e5e5',
          position: 'relative',
          flexShrink: 0,
        }}
      >
        <span
          style={{
            fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
            fontWeight: 700,
            fontSize: 18,
            color: '#111',
          }}
        >
          Basic Info
        </span>
        <button
          onClick={onCancel}
          style={{
            position: 'absolute',
            right: 20,
            background: 'none',
            border: 'none',
            color: '#2558b5',
            fontSize: 16,
            fontWeight: 600,
            cursor: 'pointer',
            fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
          }}
        >
          Cancel
        </button>
      </div>

      {/* ── Progress Bar (5 segments) ── */}
      <div
        style={{
          display: 'flex',
          gap: 4,
          padding: '12px 20px',
          flexShrink: 0,
        }}
      >
        {[1, 2, 3, 4, 5].map((s) => (
          <div
            key={s}
            style={{
              flex: 1,
              height: 4,
              borderRadius: 2,
              background: s <= step ? '#2558b5' : '#d0d0d0',
              transition: 'background 0.3s ease',
            }}
          />
        ))}
      </div>

      {/* ── Scrollable Content ── */}
      <div
        style={{
          flex: 1,
          overflowY: 'auto',
          padding: '0 20px 120px',
          WebkitOverflowScrolling: 'touch',
        }}
      >
        {children}
      </div>
    </div>
  );
}

// ── Reusable underline input ─────────────────────────────────────────────────

interface UnderlineInputProps {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  placeholder?: string;
  optional?: boolean;
  helper?: string;
  rightSlot?: React.ReactNode;
  inputMode?: React.HTMLAttributes<HTMLInputElement>['inputMode'];
  maxLength?: number;
  autoComplete?: string;
  error?: string;
  prefix?: string;
}

export function UnderlineInput({
  label,
  value,
  onChange,
  type = 'text',
  placeholder = '',
  optional = false,
  helper,
  rightSlot,
  inputMode,
  maxLength,
  autoComplete,
  error,
  prefix,
}: UnderlineInputProps) {
  return (
    <div style={{ marginBottom: 24 }}>
      <div
        style={{
          fontSize: 12,
          color: error ? '#c0392b' : '#666',
          fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
          marginBottom: 4,
          display: 'flex',
          gap: 4,
          alignItems: 'baseline',
        }}
      >
        {label}
        {optional && (
          <span style={{ color: '#999', fontStyle: 'italic' }}>(optional)</span>
        )}
      </div>

      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          borderBottom: `1.5px solid ${error ? '#c0392b' : value ? '#2558b5' : '#ccc'}`,
          paddingBottom: 6,
          transition: 'border-color 0.2s',
        }}
      >
        {prefix && (
          <span
            style={{
              fontSize: 16,
              color: '#333',
              marginRight: 6,
              fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
            }}
          >
            {prefix}
          </span>
        )}
        <input
          type={type}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          inputMode={inputMode}
          maxLength={maxLength}
          autoComplete={autoComplete}
          style={{
            flex: 1,
            border: 'none',
            outline: 'none',
            fontSize: 16,
            color: '#111',
            background: 'transparent',
            fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
          }}
        />
        {rightSlot}
      </div>

      {error && (
        <div
          style={{
            fontSize: 12,
            color: '#c0392b',
            marginTop: 4,
            fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
          }}
        >
          {error}
        </div>
      )}

      {helper && !error && (
        <div
          style={{
            fontSize: 12,
            color: '#888',
            marginTop: 4,
            fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
          }}
        >
          {helper}
        </div>
      )}
    </div>
  );
}

// ── Show/Hide toggle button ───────────────────────────────────────────────────
interface ShowToggleProps {
  show: boolean;
  onToggle: () => void;
}
export function ShowToggle({ show, onToggle }: ShowToggleProps) {
  return (
    <button
      type="button"
      onClick={onToggle}
      style={{
        background: 'none',
        border: 'none',
        color: '#2558b5',
        fontSize: 14,
        fontWeight: 600,
        cursor: 'pointer',
        fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
        whiteSpace: 'nowrap',
        padding: '0 0 0 8px',
      }}
    >
      {show ? 'Hide' : 'Show'}
    </button>
  );
}

// ── Primary button ───────────────────────────────────────────────────────────
interface PrimaryBtnProps {
  label: string;
  onClick: () => void;
  disabled?: boolean;
  loading?: boolean;
}
export function PrimaryBtn({ label, onClick, disabled, loading }: PrimaryBtnProps) {
  return (
    <button
      onClick={onClick}
      disabled={disabled || loading}
      style={{
        width: '100%',
        background: disabled || loading ? '#8ab0e0' : '#2558b5',
        color: '#fff',
        border: 'none',
        borderRadius: 6,
        padding: '16px 0',
        fontSize: 17,
        fontWeight: 700,
        fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
        cursor: disabled || loading ? 'not-allowed' : 'pointer',
        transition: 'background 0.2s',
        letterSpacing: 0.2,
      }}
    >
      {loading ? 'Please wait...' : label}
    </button>
  );
}

// ── Blue link ────────────────────────────────────────────────────────────────
interface BlueLinkProps {
  label: string;
  onClick?: () => void;
}
export function BlueLink({ label, onClick }: BlueLinkProps) {
  return (
    <button
      onClick={onClick}
      style={{
        background: 'none',
        border: 'none',
        color: '#2558b5',
        fontSize: 14,
        fontWeight: 600,
        cursor: 'pointer',
        fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
        textDecoration: 'none',
        padding: 0,
        textAlign: 'left',
      }}
    >
      {label}
    </button>
  );
}

// ── Section title ────────────────────────────────────────────────────────────
export function SectionTitle({ text, sub }: { text: string; sub?: string }) {
  return (
    <div style={{ marginBottom: 28, marginTop: 8 }}>
      <div
        style={{
          fontSize: 20,
          fontWeight: 700,
          color: '#111',
          fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
        }}
      >
        {text}
      </div>
      {sub && (
        <div
          style={{
            fontSize: 14,
            color: '#555',
            marginTop: 6,
            fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
            lineHeight: 1.5,
          }}
        >
          {sub}
        </div>
      )}
    </div>
  );
}

// ── Fixed bottom button container ────────────────────────────────────────────
export function FixedBottom({ children }: { children: React.ReactNode }) {
  return (
    <div
      style={{
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        background: '#fff',
        padding: '16px 20px 32px',
        borderTop: '1px solid #eee',
      }}
    >
      {children}
    </div>
  );
}
