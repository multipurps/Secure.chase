import { useState } from 'react';
import SignupLayout, {
  UnderlineInput,
  PrimaryBtn,
  SectionTitle,
  FixedBottom,
} from './SignupLayout';
import BottomSheetPicker from './BottomSheetPicker';
import type { SignupData } from './signupTypes';

interface Props {
  data: SignupData;
  onUpdate: (d: Partial<SignupData>) => void;
  onNext: () => void;
  onCancel: () => void;
}

const US_STATES = [
  'Alabama','Alaska','Arizona','Arkansas','California','Colorado','Connecticut',
  'Delaware','Florida','Georgia','Hawaii','Idaho','Illinois','Indiana','Iowa',
  'Kansas','Kentucky','Louisiana','Maine','Maryland','Massachusetts','Michigan',
  'Minnesota','Mississippi','Missouri','Montana','Nebraska','Nevada',
  'New Hampshire','New Jersey','New Mexico','New York','North Carolina',
  'North Dakota','Ohio','Oklahoma','Oregon','Pennsylvania','Rhode Island',
  'South Carolina','South Dakota','Tennessee','Texas','Utah','Vermont',
  'Virginia','Washington','West Virginia','Wisconsin','Wyoming',
];

export default function SignupPage3({ data, onUpdate, onNext, onCancel }: Props) {
  const [showStateSheet, setShowStateSheet] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const e: Record<string, string> = {};
    if (!data.streetAddress.trim()) e.streetAddress = 'Street address is required.';
    if (!data.city.trim()) e.city = 'City is required.';
    if (!data.state) e.state = 'Please select a state.';
    if (!data.zip.trim()) {
      e.zip = 'ZIP code is required.';
    } else if (!/^\d{5}$/.test(data.zip)) {
      e.zip = 'Please enter a valid 5-digit ZIP code.';
    }
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  return (
    <SignupLayout step={3} onCancel={onCancel}>
      <div style={{ paddingTop: 20 }}>
        <SectionTitle
          text="What's your address?"
          sub="We use your address to verify your identity"
        />

        <UnderlineInput
          label="Street address"
          value={data.streetAddress}
          onChange={(v) => onUpdate({ streetAddress: v })}
          autoComplete="street-address"
          error={errors.streetAddress}
        />

        <UnderlineInput
          label="Apt / Suite / Floor"
          value={data.aptSuite}
          onChange={(v) => onUpdate({ aptSuite: v })}
          optional
        />

        <UnderlineInput
          label="City"
          value={data.city}
          onChange={(v) => onUpdate({ city: v })}
          autoComplete="address-level2"
          error={errors.city}
        />

        {/* State picker */}
        <div style={{ marginBottom: 24 }}>
          <div
            style={{
              fontSize: 12,
              color: errors.state ? '#c0392b' : '#666',
              marginBottom: 4,
              fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
            }}
          >
            State
          </div>
          <div
            onClick={() => setShowStateSheet(true)}
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              borderBottom: `1.5px solid ${errors.state ? '#c0392b' : data.state ? '#2558b5' : '#ccc'}`,
              paddingBottom: 8,
              cursor: 'pointer',
            }}
          >
            <span
              style={{
                fontSize: 16,
                color: data.state ? '#111' : '#aaa',
                fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
              }}
            >
              {data.state || 'Select state'}
            </span>
            <span style={{ color: '#888', fontSize: 14 }}>›</span>
          </div>
          {errors.state && (
            <div
              style={{
                fontSize: 12,
                color: '#c0392b',
                marginTop: 4,
                fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
              }}
            >
              {errors.state}
            </div>
          )}
        </div>

        <UnderlineInput
          label="ZIP code"
          value={data.zip}
          onChange={(v) => onUpdate({ zip: v.replace(/\D/g, '').slice(0, 5) })}
          inputMode="numeric"
          maxLength={5}
          autoComplete="postal-code"
          error={errors.zip}
        />

        <div
          style={{
            fontSize: 12,
            color: '#888',
            marginTop: -12,
            fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
          }}
        >
          We use your address to verify your identity
        </div>
      </div>

      <FixedBottom>
        <PrimaryBtn label="Next" onClick={() => { if (validate()) onNext(); }} />
      </FixedBottom>

      <BottomSheetPicker
        isOpen={showStateSheet}
        onClose={() => setShowStateSheet(false)}
        options={US_STATES}
        selected={data.state}
        onSelect={(v) => onUpdate({ state: v })}
        title="Select your state"
      />
    </SignupLayout>
  );
}
