import { useState } from 'react';
import SignupPage1 from './SignupPage1';
import SignupPage2 from './SignupPage2';
import SignupPage3 from './SignupPage3';
import SignupPage4 from './SignupPage4';
import SignupPage5 from './SignupPage5';
import SignupSuccess from './SignupSuccess';
import { initialSignupData } from './signupTypes';
import type { SignupData } from './signupTypes';

interface Props {
  onCancel: () => void;
  onSignIn: () => void;
}

type SignupStep = 1 | 2 | 3 | 4 | 5 | 'success';

export default function SignupFlow({ onCancel, onSignIn }: Props) {
  const [step, setStep] = useState<SignupStep>(1);
  const [data, setData] = useState<SignupData>(initialSignupData);

  const update = (partial: Partial<SignupData>) => {
    setData((prev) => ({ ...prev, ...partial }));
  };

  return (
    <div
      style={{
        width: '100%',
        height: '100%',
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      {step === 1 && (
        <SignupPage1
          data={data}
          onUpdate={update}
          onNext={() => setStep(2)}
          onCancel={onCancel}
        />
      )}

      {step === 2 && (
        <SignupPage2
          data={data}
          onUpdate={update}
          onNext={() => setStep(3)}
          onCancel={onCancel}
        />
      )}

      {step === 3 && (
        <SignupPage3
          data={data}
          onUpdate={update}
          onNext={() => setStep(4)}
          onCancel={onCancel}
        />
      )}

      {step === 4 && (
        <SignupPage4
          data={data}
          onUpdate={update}
          onNext={() => setStep(5)}
          onCancel={onCancel}
        />
      )}

      {step === 5 && (
        <SignupPage5
          data={data}
          onUpdate={update}
          onDone={() => setStep('success')}
          onCancel={onCancel}
        />
      )}

      {step === 'success' && (
        <SignupSuccess onSignIn={onSignIn} />
      )}
    </div>
  );
}
