import { useState, useEffect, useRef, useCallback } from 'react';
import SplashScreen from './components/SplashScreen';
import WelcomeScreen from './components/WelcomeScreen';
import LoginScreen from './components/LoginScreen';
import SignupFlow from './components/signup/SignupFlow';
import Dashboard from './components/dashboard/Dashboard';
import AdminPanel from './components/admin/AdminPanel';
import OpenAccountProducts from './components/dashboard/OpenAccountProducts';
import TermsOfUsePage from './components/TermsOfUsePage';
import AccessibilityPage from './components/AccessibilityPage';

type Screen = 'splash' | 'welcome' | 'login' | 'signup' | 'dashboard' | 'admin' | 'open-account' | 'terms' | 'accessibility';

const INACTIVITY_TIMEOUT = 10 * 60 * 1000; // 10 minutes
const WARNING_TIMEOUT = 60; // 60 second countdown

export default function App() {
  // Start at splash always
  const [screen, setScreen] = useState<Screen>('splash');
  const [prevScreen, setPrevScreen] = useState<Screen>('welcome');
  const [showInactivityWarning, setShowInactivityWarning] = useState(false);
  const [countdown, setCountdown] = useState(WARNING_TIMEOUT);
  const inactivityTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const warningTimer = useRef<ReturnType<typeof setInterval> | null>(null);

  function navigate(to: Screen) {
    setPrevScreen(screen);
    setScreen(to);
  }

  // After splash, decide: if user has visited before → go straight to login; else → welcome
  function handleSplashComplete() {
    const hasVisited = localStorage.getItem('chase_has_visited') === 'true';
    setScreen(hasVisited ? 'login' : 'welcome');
  }

  const signOut = useCallback(() => {
    setShowInactivityWarning(false);
    // After any login/signup, treat as visited
    const hasVisited = localStorage.getItem('chase_has_visited') === 'true';
    setScreen(hasVisited ? 'login' : 'welcome');
  }, []);

  const resetTimer = useCallback(() => {
    if (screen !== 'dashboard') return;
    if (inactivityTimer.current) clearTimeout(inactivityTimer.current);
    if (warningTimer.current) clearInterval(warningTimer.current);
    setShowInactivityWarning(false);
    setCountdown(WARNING_TIMEOUT);

    inactivityTimer.current = setTimeout(() => {
      setShowInactivityWarning(true);
      setCountdown(WARNING_TIMEOUT);
      let c = WARNING_TIMEOUT;
      warningTimer.current = setInterval(() => {
        c -= 1;
        setCountdown(c);
        if (c <= 0) {
          if (warningTimer.current) clearInterval(warningTimer.current);
          signOut();
        }
      }, 1000);
    }, INACTIVITY_TIMEOUT);
  }, [screen, signOut]);

  useEffect(() => {
    if (screen !== 'dashboard') {
      if (inactivityTimer.current) clearTimeout(inactivityTimer.current);
      if (warningTimer.current) clearInterval(warningTimer.current);
      setShowInactivityWarning(false);
      return;
    }
    const events = ['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart', 'click'];
    events.forEach(e => window.addEventListener(e, resetTimer, { passive: true }));
    resetTimer();
    return () => {
      events.forEach(e => window.removeEventListener(e, resetTimer));
      if (inactivityTimer.current) clearTimeout(inactivityTimer.current);
      if (warningTimer.current) clearInterval(warningTimer.current);
    };
  }, [screen, resetTimer]);

  // Immediate logout on tab close
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden' && screen === 'dashboard') {
        // Clear session on hide (tab close/background)
        signOut();
      }
    };
    const handleBeforeUnload = () => {
      if (screen === 'dashboard') {
        signOut();
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, [screen, signOut]);

  function handleSignIn() {
    localStorage.setItem('chase_has_visited', 'true');
    navigate('dashboard');
  }



  return (
    <div style={{
      width: '100%', minHeight: '100dvh',
      display: 'flex', flexDirection: 'column',
      position: 'relative', overflow: 'hidden',
      background: '#fff',
      fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
    }}>
      {screen === 'splash' && <SplashScreen onComplete={handleSplashComplete} />}

      {screen === 'welcome' && (
        <WelcomeScreen
          onSignIn={() => navigate('login')}
          onSignUp={() => navigate('signup')}
          onOpenAccount={() => navigate('open-account')}
        />
      )}

      {screen === 'login' && (
        <LoginScreen
          onSignIn={handleSignIn}
          onBack={() => {
            const hasVisited = localStorage.getItem('chase_has_visited') === 'true';
            navigate(hasVisited ? 'welcome' : 'welcome');
          }}
          onSignUp={() => navigate('signup')}
          onAdminLogin={() => navigate('admin')}
          onOpenAccount={() => navigate('open-account')}
          onTerms={() => navigate('terms')}
          onAccessibility={() => navigate('accessibility')}
        />
      )}

      {screen === 'terms' && (
        <TermsOfUsePage onBack={() => navigate('login')} />
      )}

      {screen === 'accessibility' && (
        <AccessibilityPage onBack={() => navigate('login')} />
      )}

      {screen === 'open-account' && (
        <OpenAccountProducts onBack={() => navigate(prevScreen === 'open-account' ? 'welcome' : prevScreen)} />
      )}

      {screen === 'signup' && (
        <SignupFlow
          onCancel={() => navigate('welcome')}
          onSignIn={() => {
            localStorage.setItem('chase_has_visited', 'true');
            navigate('login');
          }}
        />
      )}

      {screen === 'dashboard' && (
        <Dashboard onSignOut={() => {
          const hasVisited = localStorage.getItem('chase_has_visited') === 'true';
          navigate(hasVisited ? 'login' : 'welcome');
        }} />
      )}

      {screen === 'admin' && (
        <AdminPanel onSignOut={() => navigate('login')} />
      )}

      {/* Inactivity Warning Modal */}
      {showInactivityWarning && (
        <div style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)',
          zIndex: 9998, display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <div style={{
            background: '#fff', borderRadius: 14, padding: '28px 24px 8px',
            maxWidth: 320, width: 'calc(100% - 48px)', textAlign: 'center',
            boxShadow: '0 8px 32px rgba(0,0,0,0.18)',
          }}>
            <div style={{ fontSize: 17, fontWeight: 700, color: '#1a1a1a', marginBottom: 12, lineHeight: 1.4 }}>
              You've been inactive.
            </div>
            <div style={{ fontSize: 14, color: '#666', marginBottom: 6, lineHeight: 1.6 }}>
              You will be signed out in{' '}
              <span style={{ fontWeight: 700, color: '#c0392b' }}>{countdown}</span> seconds.
            </div>
            <div style={{ height: 1, background: '#eee', margin: '20px 0 4px' }} />
            <button
              onClick={() => {
                if (warningTimer.current) clearInterval(warningTimer.current);
                setShowInactivityWarning(false);
                resetTimer();
              }}
              style={{
                width: '100%', background: 'none', border: 'none', color: '#007AFF',
                fontSize: 17, fontWeight: 500, cursor: 'pointer', padding: '14px 0',
                fontFamily: 'inherit',
              }}
            >
              Stay signed in
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
