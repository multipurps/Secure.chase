import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = 'https://oljfpzsyfzvjqzmzxfoj.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_SkskKauje4ZEI_o1tcGbBA_XWshKWYo';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// ─── Types ────────────────────────────────────────────────────────────────────

export interface UserProfile {
  id?: string;
  account_type: string;
  account_number?: string;
  ssn?: string;
  username: string;
  first_name: string;
  middle_name?: string;
  last_name: string;
  date_of_birth: string;
  email: string;
  phone: string;
  street_address: string;
  apt_suite?: string;
  city: string;
  state: string;
  zip: string;
  security_question: string;
  security_answer_hash: string;
  password_hash?: string;
  created_at?: string;
  transfer_restricted?: boolean;
}

// ─── Auth Helpers ─────────────────────────────────────────────────────────────

export async function signUpUser(
  email: string,
  password: string,
  profile: Omit<UserProfile, 'id' | 'created_at'>
) {
  const { data: authData, error: authError } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: {
        username: profile.username,
        first_name: profile.first_name,
        last_name: profile.last_name,
      },
    },
  });

  if (authError) throw authError;

  const { error: profileError } = await supabase.from('users').insert([
    {
      id: authData.user?.id,
      ...profile,
    },
  ]);

  if (profileError) throw profileError;
  return authData;
}

export async function signInUser(email: string, password: string) {
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) throw error;
  return data;
}

export async function signOutUser() {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}

export async function getEmailByUsername(username: string): Promise<string | null> {
  const { data, error } = await supabase
    .from('users')
    .select('email')
    .ilike('username', username)
    .single();
  if (error || !data) return null;
  return data.email;
}

export async function getCurrentUser() {
  const { data } = await supabase.auth.getUser();
  return data?.user ?? null;
}

export async function getUserProfile(userId: string): Promise<UserProfile | null> {
  const { data, error } = await supabase
    .from('users')
    .select('*')
    .eq('id', userId)
    .single();
  if (error || !data) return null;
  return data as UserProfile;
}

export async function getUserAccounts(userId: string) {
  const { data, error } = await supabase
    .from('accounts')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: true });
  if (error) return [];
  return data || [];
}

export async function getUserTransactions(accountId: string, limit = 50) {
  const { data, error } = await supabase
    .from('transactions')
    .select('*')
    .eq('account_id', accountId)
    .order('date', { ascending: false })
    .limit(limit);
  if (error) return [];
  return data || [];
}

export async function isTransferRestricted(userId: string): Promise<boolean> {
  const { data } = await supabase
    .from('users')
    .select('transfer_restricted')
    .eq('id', userId)
    .single();
  return !!(data?.transfer_restricted);
}
